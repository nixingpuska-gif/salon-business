import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Client, Prisma } from '@prisma/client';

@Injectable()
export class ClientService {
  constructor(private prisma: PrismaService) {}

  /**
   * Find or create client by phone number
   */
  async findOrCreate(businessId: string, data: {
    phone: string;
    firstName?: string;
    lastName?: string;
    telegramId?: bigint;
    whatsappId?: string;
    instagramId?: string;
  }): Promise<Client> {
    // Try to find existing client by phone
    let client = await this.prisma.client.findUnique({
      where: {
        businessId_phone: {
          businessId,
          phone: data.phone,
        },
      },
    });

    if (!client) {
      // Create new client
      client = await this.prisma.client.create({
        data: {
          businessId,
          phone: data.phone,
          firstName: data.firstName,
          lastName: data.lastName,
          telegramId: data.telegramId,
          whatsappId: data.whatsappId,
          instagramId: data.instagramId,
        },
      });
    } else {
      // Update channel IDs if provided and not already set
      const updateData: Prisma.ClientUpdateInput = {};
      
      if (data.telegramId && !client.telegramId) {
        updateData.telegramId = data.telegramId;
      }
      if (data.whatsappId && !client.whatsappId) {
        updateData.whatsappId = data.whatsappId;
      }
      if (data.instagramId && !client.instagramId) {
        updateData.instagramId = data.instagramId;
      }
      if (data.firstName && !client.firstName) {
        updateData.firstName = data.firstName;
      }
      if (data.lastName && !client.lastName) {
        updateData.lastName = data.lastName;
      }

      if (Object.keys(updateData).length > 0) {
        client = await this.prisma.client.update({
          where: { id: client.id },
          data: updateData,
        });
      }
    }

    return client;
  }

  /**
   * Find client by ID
   */
  async findOne(id: string): Promise<Client> {
    const client = await this.prisma.client.findUnique({
      where: { id },
      include: {
        bookings: {
          include: {
            service: true,
          },
          orderBy: { startTime: 'desc' },
          take: 10,
        },
        notes: {
          orderBy: { createdAt: 'desc' },
        },
        _count: {
          select: {
            bookings: true,
          },
        },
      },
    });

    if (!client) {
      throw new NotFoundException(`Client with ID ${id} not found`);
    }

    return client;
  }

  /**
   * Find client by Telegram ID
   */
  async findByTelegramId(businessId: string, telegramId: bigint): Promise<Client | null> {
    return this.prisma.client.findFirst({
      where: {
        businessId,
        telegramId,
      },
    });
  }

  /**
   * Find client by WhatsApp ID
   */
  async findByWhatsappId(businessId: string, whatsappId: string): Promise<Client | null> {
    return this.prisma.client.findFirst({
      where: {
        businessId,
        whatsappId,
      },
    });
  }

  /**
   * Find client by Instagram ID
   */
  async findByInstagramId(businessId: string, instagramId: string): Promise<Client | null> {
    return this.prisma.client.findFirst({
      where: {
        businessId,
        instagramId,
      },
    });
  }

  /**
   * Find all clients for a business
   */
  async findByBusiness(businessId: string, params?: {
    search?: string;
    tags?: string[];
    skip?: number;
    take?: number;
  }): Promise<Client[]> {
    const where: Prisma.ClientWhereInput = {
      businessId,
    };

    if (params?.search) {
      where.OR = [
        { firstName: { contains: params.search, mode: 'insensitive' } },
        { lastName: { contains: params.search, mode: 'insensitive' } },
        { phone: { contains: params.search } },
      ];
    }

    if (params?.tags && params.tags.length > 0) {
      where.tags = {
        hasSome: params.tags,
      };
    }

    return this.prisma.client.findMany({
      where,
      include: {
        _count: {
          select: {
            bookings: true,
          },
        },
      },
      orderBy: [
        { lastVisitAt: 'desc' },
        { createdAt: 'desc' },
      ],
      skip: params?.skip || 0,
      take: params?.take || 50,
    });
  }

  /**
   * Update client information
   */
  async update(id: string, data: Partial<{
    firstName: string;
    lastName: string;
    phone: string;
    email: string;
    tags: string[];
    preferences: Prisma.JsonValue;
  }>): Promise<Client> {
    const client = await this.findOne(id);

    return this.prisma.client.update({
      where: { id: client.id },
      data,
    });
  }

  /**
   * Add note to client
   */
  async addNote(clientId: string, businessId: string, note: string, createdBy?: string): Promise<void> {
    await this.prisma.clientNote.create({
      data: {
        clientId,
        businessId,
        note,
        createdBy,
      },
    });
  }

  /**
   * Update client statistics after booking
   */
  async updateStats(clientId: string, data: {
    totalBookings?: number;
    totalSpent?: number;
    lastVisitAt?: Date;
  }): Promise<void> {
    const updateData: Prisma.ClientUpdateInput = {};

    if (data.totalBookings !== undefined) {
      updateData.totalBookings = { increment: data.totalBookings };
    }
    if (data.totalSpent !== undefined) {
      updateData.totalSpent = { increment: data.totalSpent };
    }
    if (data.lastVisitAt) {
      updateData.lastVisitAt = data.lastVisitAt;
    }

    await this.prisma.client.update({
      where: { id: clientId },
      data: updateData,
    });
  }

  /**
   * Delete client (soft delete)
   */
  async delete(id: string): Promise<Client> {
    const client = await this.findOne(id);

    return this.prisma.client.update({
      where: { id: client.id },
      data: {
        deletedAt: new Date(),
      },
    });
  }
}
