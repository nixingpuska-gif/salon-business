"""
Business OS - User Models
Модели пользователей системы (владельцы, администраторы платформы)
"""

from datetime import datetime
from typing import Optional
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, BigInteger, 
    DateTime, ForeignKey, JSON
)
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel


class UserRole(str, enum.Enum):
    """Роли пользователей"""
    PLATFORM_ADMIN = "platform_admin"  # Администратор платформы
    OWNER = "owner"  # Владелец салона
    PARTNER = "partner"  # Партнёр (поставщик)


class User(BaseModel):
    """
    Пользователь системы.
    Это владельцы салонов, администраторы платформы и партнёры.
    Не путать с Client (клиенты салонов) и Staff (сотрудники салонов).
    """
    __tablename__ = "users"
    
    # === Аутентификация ===
    email = Column(String(255), unique=True, nullable=False, index=True)
    phone = Column(String(50), unique=True, nullable=True, index=True)
    password_hash = Column(String(255), nullable=False)
    
    # === Профиль ===
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=True)
    avatar_url = Column(String(500), nullable=True)
    
    # === Роль ===
    role = Column(String(50), default=UserRole.OWNER.value, nullable=False)
    
    # === Привязка к тенанту (для владельцев) ===
    owned_tenant_id = Column(BigInteger, ForeignKey("tenants.id"), nullable=True, unique=True)
    
    # === Статус ===
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    verified_at = Column(DateTime, nullable=True)
    
    # === Безопасность ===
    last_login_at = Column(DateTime, nullable=True)
    last_login_ip = Column(String(50), nullable=True)
    failed_login_attempts = Column(Integer, default=0)
    locked_until = Column(DateTime, nullable=True)
    
    # === Двухфакторная аутентификация ===
    two_factor_enabled = Column(Boolean, default=False)
    two_factor_secret = Column(String(255), nullable=True)
    
    # === Настройки ===
    language = Column(String(5), default="ru")
    timezone = Column(String(50), default="Europe/Moscow")
    notification_settings = Column(JSON, default={
        "email": True,
        "telegram": True,
        "push": True
    })
    
    # === Telegram ===
    telegram_id = Column(BigInteger, nullable=True, unique=True)
    telegram_username = Column(String(100), nullable=True)
    
    # === Партнёрская программа (для партнёров) ===
    partner_code = Column(String(50), unique=True, nullable=True, index=True)
    partner_commission_first = Column(Integer, default=25)  # % с первой оплаты
    partner_commission_monthly = Column(Integer, default=15)  # % ежемесячно
    partner_balance = Column(Integer, default=0)  # Баланс в копейках
    
    # === Relationships ===
    owned_tenant = relationship("Tenant", back_populates="owner", 
                               foreign_keys=[owned_tenant_id])
    refresh_tokens = relationship("RefreshToken", back_populates="user", lazy="dynamic")
    
    @property
    def full_name(self) -> str:
        if self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.first_name


class RefreshToken(BaseModel):
    """
    Refresh токены для обновления access токенов.
    Хранятся в БД для возможности отзыва.
    """
    __tablename__ = "refresh_tokens"
    
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False, index=True)
    token_hash = Column(String(255), nullable=False, unique=True)
    
    # === Метаданные ===
    device_info = Column(String(500), nullable=True)
    ip_address = Column(String(50), nullable=True)
    
    # === Срок действия ===
    expires_at = Column(DateTime, nullable=False)
    
    # === Статус ===
    is_revoked = Column(Boolean, default=False)
    revoked_at = Column(DateTime, nullable=True)
    
    # === Relationships ===
    user = relationship("User", back_populates="refresh_tokens")


class PasswordReset(BaseModel):
    """Токены для сброса пароля"""
    __tablename__ = "password_resets"
    
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False, index=True)
    token_hash = Column(String(255), nullable=False, unique=True)
    expires_at = Column(DateTime, nullable=False)
    is_used = Column(Boolean, default=False)
    used_at = Column(DateTime, nullable=True)


class EmailVerification(BaseModel):
    """Токены для подтверждения email"""
    __tablename__ = "email_verifications"
    
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=False, index=True)
    email = Column(String(255), nullable=False)
    token_hash = Column(String(255), nullable=False, unique=True)
    expires_at = Column(DateTime, nullable=False)
    is_used = Column(Boolean, default=False)
    used_at = Column(DateTime, nullable=True)


class AuditLog(BaseModel):
    """
    Аудит-лог действий пользователей.
    Для безопасности и отслеживания изменений.
    """
    __tablename__ = "audit_logs"
    
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=True, index=True)
    tenant_id = Column(BigInteger, nullable=True, index=True)
    
    # === Действие ===
    action = Column(String(100), nullable=False, index=True)
    entity_type = Column(String(100), nullable=True)
    entity_id = Column(BigInteger, nullable=True)
    
    # === Детали ===
    details = Column(JSON, default=dict)
    old_values = Column(JSON, nullable=True)
    new_values = Column(JSON, nullable=True)
    
    # === Метаданные ===
    ip_address = Column(String(50), nullable=True)
    user_agent = Column(String(500), nullable=True)
