import { useState, useEffect } from 'react'
import { API_URL } from '../config/api'
import { Plus, Clock, DollarSign, MoreVertical, ChevronDown, ChevronRight } from 'lucide-react'
// import clsx from 'clsx'

interface Service {
  id: number
  name: string
  description: string | null
  price: number
  duration_minutes: number
  category_id: number | null
  is_active: boolean
  is_popular: boolean
  total_bookings: number
}

interface ServiceCategory {
  id: number
  name: string
  description: string | null
  sort_order: number
  services_count: number
}

function formatMoney(amount: number): string {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    minimumFractionDigits: 0,
  }).format(amount)
}

function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} мин`
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  return mins > 0 ? `${hours} ч ${mins} мин` : `${hours} ч`
}

export default function Services() {
  const [services, setServices] = useState<Service[]>([])
  const [categories, setCategories] = useState<ServiceCategory[]>([])
  const [loading, setLoading] = useState(true)
  const [expandedCategories, setExpandedCategories] = useState<Set<number>>(new Set())

  useEffect(() => {
    Promise.all([
      fetch(`${API_URL}/api/v1/services`).then(res => res.json()),
      fetch(`${API_URL}/api/v1/services/categories`).then(res => res.json())
    ])
      .then(([servicesData, categoriesData]) => {
        setServices(servicesData.items || [])
        setCategories(categoriesData.items || categoriesData || [])
        // Expand all categories by default
        const allCategoryIds = new Set<number>((categoriesData.items || categoriesData || []).map((c: ServiceCategory) => c.id))
        setExpandedCategories(allCategoryIds)
        setLoading(false)
      })
      .catch(err => {
        console.error('Error:', err)
        setLoading(false)
      })
  }, [])

  const toggleCategory = (categoryId: number) => {
    setExpandedCategories(prev => {
      const next = new Set(prev)
      if (next.has(categoryId)) {
        next.delete(categoryId)
      } else {
        next.add(categoryId)
      }
      return next
    })
  }

  const getServicesByCategory = (categoryId: number | null) => {
    return services.filter(s => s.category_id === categoryId)
  }

  const uncategorizedServices = services.filter(s => !s.category_id)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Услуги</h1>
          <p className="text-gray-500 mt-1">Каталог услуг салона</p>
        </div>
        <button className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Добавить услугу
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
        </div>
      ) : services.length === 0 ? (
        <div className="card">
          <div className="text-center py-12">
            <p className="text-gray-500">Услуги не найдены</p>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {categories.map((category) => {
            const categoryServices = getServicesByCategory(category.id)
            const isExpanded = expandedCategories.has(category.id)
            
            return (
              <div key={category.id} className="card p-0 overflow-hidden">
                <button
                  onClick={() => toggleCategory(category.id)}
                  className="w-full px-6 py-4 flex items-center justify-between bg-gray-50 hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    {isExpanded ? (
                      <ChevronDown className="w-5 h-5 text-gray-400" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-gray-400" />
                    )}
                    <h3 className="font-semibold text-gray-900">{category.name}</h3>
                    <span className="text-sm text-gray-500">({categoryServices.length})</span>
                  </div>
                </button>
                
                {isExpanded && categoryServices.length > 0 && (
                  <div className="divide-y divide-gray-100">
                    {categoryServices.map((service) => (
                      <div key={service.id} className="px-6 py-4 flex items-center justify-between hover:bg-gray-50">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-medium text-gray-900">{service.name}</h4>
                            {service.is_popular && (
                              <span className="px-2 py-0.5 bg-amber-100 text-amber-700 text-xs rounded-full">
                                Популярная
                              </span>
                            )}
                            {!service.is_active && (
                              <span className="px-2 py-0.5 bg-gray-100 text-gray-500 text-xs rounded-full">
                                Неактивна
                              </span>
                            )}
                          </div>
                          {service.description && (
                            <p className="text-sm text-gray-500 mt-1">{service.description}</p>
                          )}
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="flex items-center gap-1 text-gray-500">
                            <Clock className="w-4 h-4" />
                            <span className="text-sm">{formatDuration(service.duration_minutes)}</span>
                          </div>
                          <div className="flex items-center gap-1 text-gray-900 font-medium">
                            <DollarSign className="w-4 h-4" />
                            <span>{formatMoney(service.price)}</span>
                          </div>
                          <button className="text-gray-400 hover:text-gray-600">
                            <MoreVertical className="w-5 h-5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )
          })}

          {uncategorizedServices.length > 0 && (
            <div className="card p-0 overflow-hidden">
              <div className="px-6 py-4 bg-gray-50">
                <h3 className="font-semibold text-gray-900">Без категории ({uncategorizedServices.length})</h3>
              </div>
              <div className="divide-y divide-gray-100">
                {uncategorizedServices.map((service) => (
                  <div key={service.id} className="px-6 py-4 flex items-center justify-between hover:bg-gray-50">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{service.name}</h4>
                    </div>
                    <div className="flex items-center gap-6">
                      <div className="flex items-center gap-1 text-gray-500">
                        <Clock className="w-4 h-4" />
                        <span className="text-sm">{formatDuration(service.duration_minutes)}</span>
                      </div>
                      <div className="flex items-center gap-1 text-gray-900 font-medium">
                        <DollarSign className="w-4 h-4" />
                        <span>{formatMoney(service.price)}</span>
                      </div>
                      <button className="text-gray-400 hover:text-gray-600">
                        <MoreVertical className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
