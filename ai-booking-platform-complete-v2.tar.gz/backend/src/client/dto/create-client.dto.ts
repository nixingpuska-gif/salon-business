import { IsString, IsOptional, IsNotEmpty, IsEmail, IsArray, IsBigInt } from 'class-validator';

export class CreateClientDto {
  @IsString()
  @IsNotEmpty()
  businessId: string;

  @IsString()
  @IsNotEmpty()
  phone: string;

  @IsString()
  @IsOptional()
  firstName?: string;

  @IsString()
  @IsOptional()
  lastName?: string;

  @IsEmail()
  @IsOptional()
  email?: string;

  @IsOptional()
  telegramId?: bigint;

  @IsString()
  @IsOptional()
  whatsappId?: string;

  @IsString()
  @IsOptional()
  instagramId?: string;

  @IsArray()
  @IsString({ each: true })
  @IsOptional()
  tags?: string[];
}
