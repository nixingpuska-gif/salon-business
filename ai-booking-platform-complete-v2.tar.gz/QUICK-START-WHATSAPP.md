# 🚀 Быстрый старт: WhatsApp Business API

## За 5 минут до первого сообщения

### Шаг 1: Получите учетные данные (3 минуты)

1. Откройте [developers.facebook.com](https://developers.facebook.com/)
2. Войдите и создайте приложение (тип: **Business**)
3. Добавьте продукт **WhatsApp**
4. В разделе **Getting Started** скопируйте:
   - **Phone Number ID** → `WHATSAPP_PHONE_NUMBER_ID`
   - **Temporary Access Token** → `WHATSAPP_ACCESS_TOKEN`
5. Придумайте случайную строку → `WHATSAPP_VERIFY_TOKEN`

### Шаг 2: Настройте переменные окружения (30 секунд)

Добавьте в `backend/.env`:
```bash
WHATSAPP_PHONE_NUMBER_ID=123456789012345
WHATSAPP_ACCESS_TOKEN=EAAGxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
WHATSAPP_VERIFY_TOKEN=my_secure_token_12345
```

### Шаг 3: Запустите сервер (30 секунд)

```bash
cd backend
npm install  # если ещё не установлено
npm run start:dev
```

### Шаг 4: Настройте Webhook (1 минута)

1. В Meta Console: **WhatsApp** → **Configuration** → **Edit Webhook**
2. Заполните:
   - **Callback URL**: `https://ваш-домен.com/webhooks/whatsapp`
   - **Verify Token**: Ваш `WHATSAPP_VERIFY_TOKEN`
3. Нажмите **Verify and Save**
4. Подпишитесь на `messages`

### Шаг 5: Тестируйте! (30 секунд)

1. В Meta Console: **WhatsApp** → **API Setup**
2. Добавьте свой номер в **"To"** (формат: `+79991234567`)
3. Нажмите **"Send message"**
4. Ответьте боту в WhatsApp
5. Проверьте логи сервера — должно быть сообщение

## ✅ Готово!

Теперь ваш бот работает в WhatsApp. 

**Что дальше?**
- Интегрируйте с AI Orchestrator (см. `WHATSAPP-IMPLEMENTATION-SUMMARY.md`)
- Создайте Message Templates для уведомлений
- Верифицируйте бизнес-аккаунт для снятия лимитов

**Полная документация**: `WHATSAPP-SETUP-GUIDE.md`

---

## 🔧 Быстрое решение проблем

**Webhook не проходит верификацию?**
- Проверьте, что сервер доступен по HTTPS
- Убедитесь, что `WHATSAPP_VERIFY_TOKEN` совпадает

**Бот не отвечает?**
- Проверьте, что webhook подписан на `messages`
- Посмотрите логи: `npm run start:dev`

**Сообщения не отправляются?**
- Проверьте формат номера: `+79991234567`
- Убедитесь, что номер добавлен в тестовые (до верификации)
