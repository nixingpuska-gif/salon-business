import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TelegramService } from './telegram.service';
import { AIModule } from '../ai/ai.module';
import { ChannelGatewayModule } from '../channel-gateway/channel-gateway.module';
import { ClientModule } from '../client/client.module';
import { BusinessModule } from '../business/business.module';

@Module({
  imports: [
    ConfigModule,
    AIModule,
    ChannelGatewayModule,
    ClientModule,
    BusinessModule,
  ],
  providers: [TelegramService],
  exports: [TelegramService],
})
export class TelegramModule {}
