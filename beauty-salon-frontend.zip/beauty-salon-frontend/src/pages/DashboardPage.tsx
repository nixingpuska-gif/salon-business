/**
 * DashboardPage Component
 * Main dashboard with KPI and statistics
 */
export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-gray-900 p-8">
      <h1 className="text-3xl font-bold text-white mb-8">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* KPI Cards */}
        {[
          { title: 'Total Revenue', value: '$12,500', change: '+12.5%' },
          { title: 'Appointments', value: '48', change: '+8.2%' },
          { title: 'Clients', value: '324', change: '+5.1%' },
          { title: 'Staff', value: '12', change: '+2.3%' },
        ].map((kpi, idx) => (
          <div key={idx} className="card">
            <h3 className="text-gray-400 text-sm font-medium mb-2">{kpi.title}</h3>
            <p className="text-2xl font-bold text-white mb-2">{kpi.value}</p>
            <p className="text-green-400 text-sm">{kpi.change}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
