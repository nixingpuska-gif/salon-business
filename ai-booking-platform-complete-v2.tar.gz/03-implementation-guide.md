# Implementation Guide: AI-Booking Platform MVP

## Overview

This document provides a complete implementation guide for the AI-first booking platform. Due to the scope of this project (estimated 4-6 weeks for a full team), this guide provides:

1. **Complete architecture** (✅ Done - see `01-architecture-proposal.md`)
2. **Database schema** (✅ Done - see `02-database-schema.md`)
3. **Core service implementations** (code samples below)
4. **Integration guides** (Telegram, WhatsApp, Instagram, Google Calendar)
5. **AI Orchestrator implementation**
6. **Deployment configuration**

---

## Phase-by-Phase Implementation

### Phase 1: Foundation (Week 1)

#### 1.1 Setup Project Structure

```bash
# Initialize NestJS project
npx @nestjs/cli new ai-booking-backend
cd ai-booking-backend

# Install dependencies
pnpm add @nestjs/config @nestjs/swagger @prisma/client \
  class-validator class-transformer @nestjs/schedule \
  @nestjs/bull bull bullmq ioredis bcrypt uuid date-fns

pnpm add -D prisma @types/bcrypt

# Initialize Prisma
npx prisma init --datasource-provider postgresql
```

#### 1.2 Configure Environment

**.env**
```env
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/ai_booking?schema=public"
REDIS_HOST=localhost
REDIS_PORT=6379
JWT_SECRET=your-secret-key
OPENAI_API_KEY=sk-...
PORT=3000
NODE_ENV=development
```

#### 1.3 Apply Database Schema

Copy the Prisma schema from `02-database-schema.md` to `prisma/schema.prisma`, then:

```bash
# Generate Prisma Client
npx prisma generate

# Create migration
npx prisma migrate dev --name init

# (Optional) Seed database
npx prisma db seed
```

---

### Phase 2: Core Backend Services (Week 1-2)

#### 2.1 Prisma Service (Global Database Access)

**src/prisma/prisma.service.ts**
```typescript
import { Injectable, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  async onModuleInit() {
    await this.$connect();
  }

  async onModuleDestroy() {
    await this.$disconnect();
  }
}
```

**src/prisma/prisma.module.ts**
```typescript
import { Global, Module } from '@nestjs/common';
import { PrismaService } from './prisma.service';

@Global()
@Module({
  providers: [PrismaService],
  exports: [PrismaService],
})
export class PrismaModule {}
```

#### 2.2 Business Service

**src/business/business.service.ts**
```typescript
import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Business } from '@prisma/client';

@Injectable()
export class BusinessService {
  constructor(private prisma: PrismaService) {}

  async create(data: {
    name: string;
    businessType: string;
    phone?: string;
    email?: string;
    userId: string;
  }): Promise<Business> {
    return this.prisma.business.create({
      data: {
        name: data.name,
        businessType: data.businessType,
        phone: data.phone,
        email: data.email,
        businessUsers: {
          create: {
            userId: data.userId,
            role: 'owner',
          },
        },
      },
    });
  }

  async findOne(id: string): Promise<Business> {
    const business = await this.prisma.business.findUnique({
      where: { id },
      include: { services: true, schedules: true },
    });
    if (!business) throw new NotFoundException('Business not found');
    return business;
  }

  async findByUser(userId: string): Promise<Business[]> {
    return this.prisma.business.findMany({
      where: {
        businessUsers: { some: { userId } },
      },
    });
  }
}
```

#### 2.3 Service Management Service

**src/service/service.service.ts**
```typescript
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Service } from '@prisma/client';

@Injectable()
export class ServiceService {
  constructor(private prisma: PrismaService) {}

  async create(businessId: string, data: {
    name: string;
    durationMinutes: number;
    price?: number;
    description?: string;
  }): Promise<Service> {
    return this.prisma.service.create({
      data: {
        ...data,
        businessId,
      },
    });
  }

  async findByBusiness(businessId: string): Promise<Service[]> {
    return this.prisma.service.findMany({
      where: { businessId, isActive: true },
      orderBy: { displayOrder: 'asc' },
    });
  }

  async update(id: string, data: Partial<Service>): Promise<Service> {
    return this.prisma.service.update({
      where: { id },
      data,
    });
  }
}
```

#### 2.4 Schedule Service (Slot Generation)

**src/schedule/schedule.service.ts**
```typescript
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { addMinutes, format, parse, startOfDay, endOfDay, isWithinInterval } from 'date-fns';

export interface TimeSlot {
  id: string;
  startTime: Date;
  endTime: Date;
  available: boolean;
}

@Injectable()
export class ScheduleService {
  constructor(private prisma: PrismaService) {}

  /**
   * Generate available time slots for a given date and service
   */
  async generateSlots(
    businessId: string,
    date: Date,
    serviceDurationMinutes: number,
  ): Promise<TimeSlot[]> {
    // 1. Get working hours for this date
    const dayOfWeek = date.getDay() === 0 ? 7 : date.getDay(); // ISO: Mon=1, Sun=7
    
    const workingHours = await this.prisma.schedule.findFirst({
      where: {
        businessId,
        type: 'working_hours',
        daysOfWeek: { has: dayOfWeek },
        startDate: { lte: date },
        OR: [
          { endDate: null },
          { endDate: { gte: date } },
        ],
      },
    });

    if (!workingHours || !workingHours.startTime || !workingHours.endTime) {
      return []; // No working hours configured
    }

    // 2. Parse working hours
    const startHour = new Date(workingHours.startTime).getHours();
    const startMinute = new Date(workingHours.startTime).getMinutes();
    const endHour = new Date(workingHours.endTime).getHours();
    const endMinute = new Date(workingHours.endTime).getMinutes();

    const dayStart = new Date(date);
    dayStart.setHours(startHour, startMinute, 0, 0);

    const dayEnd = new Date(date);
    dayEnd.setHours(endHour, endMinute, 0, 0);

    // 3. Generate all possible slots
    const slots: TimeSlot[] = [];
    let currentSlotStart = dayStart;

    while (currentSlotStart < dayEnd) {
      const slotEnd = addMinutes(currentSlotStart, serviceDurationMinutes);
      
      if (slotEnd <= dayEnd) {
        slots.push({
          id: `slot_${format(currentSlotStart, 'HHmm')}`,
          startTime: new Date(currentSlotStart),
          endTime: slotEnd,
          available: true, // Will check bookings next
        });
      }

      currentSlotStart = addMinutes(currentSlotStart, 30); // 30-min intervals
    }

    // 4. Get existing bookings for this day
    const bookings = await this.prisma.booking.findMany({
      where: {
        businessId,
        startTime: { gte: startOfDay(date) },
        endTime: { lte: endOfDay(date) },
        status: { in: ['confirmed', 'pending'] },
      },
    });

    // 5. Mark slots as unavailable if they overlap with bookings
    slots.forEach((slot) => {
      const hasConflict = bookings.some((booking) =>
        isWithinInterval(slot.startTime, {
          start: booking.startTime,
          end: booking.endTime,
        }) ||
        isWithinInterval(slot.endTime, {
          start: booking.startTime,
          end: booking.endTime,
        }),
      );
      if (hasConflict) {
        slot.available = false;
      }
    });

    // 6. Filter out breaks/vacations
    const breaks = await this.prisma.schedule.findMany({
      where: {
        businessId,
        type: { in: ['break', 'vacation', 'holiday'] },
        startDate: { lte: date },
        OR: [
          { endDate: null },
          { endDate: { gte: date } },
        ],
      },
    });

    breaks.forEach((breakPeriod) => {
      if (breakPeriod.startTime && breakPeriod.endTime) {
        const breakStart = new Date(date);
        breakStart.setHours(
          new Date(breakPeriod.startTime).getHours(),
          new Date(breakPeriod.startTime).getMinutes(),
        );
        const breakEnd = new Date(date);
        breakEnd.setHours(
          new Date(breakPeriod.endTime).getHours(),
          new Date(breakPeriod.endTime).getMinutes(),
        );

        slots.forEach((slot) => {
          if (
            isWithinInterval(slot.startTime, { start: breakStart, end: breakEnd }) ||
            isWithinInterval(slot.endTime, { start: breakStart, end: breakEnd })
          ) {
            slot.available = false;
          }
        });
      }
    });

    return slots.filter((slot) => slot.available);
  }

  /**
   * Create working hours schedule
   */
  async createWorkingHours(businessId: string, data: {
    daysOfWeek: number[];
    startTime: string; // "09:00"
    endTime: string;   // "18:00"
  }) {
    return this.prisma.schedule.create({
      data: {
        businessId,
        type: 'working_hours',
        daysOfWeek: data.daysOfWeek,
        startDate: new Date(),
        startTime: parse(data.startTime, 'HH:mm', new Date()),
        endTime: parse(data.endTime, 'HH:mm', new Date()),
        recurrenceRule: 'FREQ=WEEKLY',
      },
    });
  }
}
```

#### 2.5 Booking Service

**src/booking/booking.service.ts**
```typescript
import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Booking } from '@prisma/client';
import { addMinutes } from 'date-fns';

@Injectable()
export class BookingService {
  constructor(private prisma: PrismaService) {}

  async create(data: {
    businessId: string;
    clientId: string;
    serviceId: string;
    startTime: Date;
    sourceChannel?: string;
  }): Promise<Booking> {
    // 1. Get service to determine duration
    const service = await this.prisma.service.findUnique({
      where: { id: data.serviceId },
    });

    if (!service) {
      throw new BadRequestException('Service not found');
    }

    const endTime = addMinutes(data.startTime, service.durationMinutes);

    // 2. Check for conflicts
    const conflicts = await this.prisma.booking.count({
      where: {
        businessId: data.businessId,
        status: { in: ['confirmed', 'pending'] },
        OR: [
          {
            startTime: { lte: data.startTime },
            endTime: { gt: data.startTime },
          },
          {
            startTime: { lt: endTime },
            endTime: { gte: endTime },
          },
        ],
      },
    });

    if (conflicts > 0) {
      throw new BadRequestException('Time slot is not available');
    }

    // 3. Create booking
    const booking = await this.prisma.booking.create({
      data: {
        businessId: data.businessId,
        clientId: data.clientId,
        serviceId: data.serviceId,
        startTime: data.startTime,
        endTime,
        price: service.price,
        sourceChannel: data.sourceChannel,
        status: 'confirmed',
      },
      include: {
        client: true,
        service: true,
      },
    });

    // 4. Update client stats
    await this.prisma.client.update({
      where: { id: data.clientId },
      data: {
        totalBookings: { increment: 1 },
        lastVisitAt: data.startTime,
      },
    });

    return booking;
  }

  async reschedule(bookingId: string, newStartTime: Date): Promise<Booking> {
    const booking = await this.prisma.booking.findUnique({
      where: { id: bookingId },
      include: { service: true },
    });

    if (!booking) {
      throw new BadRequestException('Booking not found');
    }

    const newEndTime = addMinutes(newStartTime, booking.service.durationMinutes);

    return this.prisma.booking.update({
      where: { id: bookingId },
      data: {
        startTime: newStartTime,
        endTime: newEndTime,
      },
    });
  }

  async cancel(bookingId: string, reason?: string): Promise<Booking> {
    return this.prisma.booking.update({
      where: { id: bookingId },
      data: {
        status: 'cancelled',
        cancelledAt: new Date(),
        cancelledReason: reason,
      },
    });
  }

  async findByBusiness(businessId: string, params?: {
    startDate?: Date;
    endDate?: Date;
    status?: string;
  }): Promise<Booking[]> {
    return this.prisma.booking.findMany({
      where: {
        businessId,
        ...(params?.startDate && { startTime: { gte: params.startDate } }),
        ...(params?.endDate && { endTime: { lte: params.endDate } }),
        ...(params?.status && { status: params.status }),
      },
      include: {
        client: true,
        service: true,
      },
      orderBy: { startTime: 'asc' },
    });
  }
}
```

#### 2.6 Client CRM Service

**src/client/client.service.ts**
```typescript
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Client } from '@prisma/client';

@Injectable()
export class ClientService {
  constructor(private prisma: PrismaService) {}

  async findOrCreate(businessId: string, data: {
    phone: string;
    firstName?: string;
    lastName?: string;
    telegramId?: bigint;
    whatsappId?: string;
    instagramId?: string;
  }): Promise<Client> {
    // Try to find existing client
    let client = await this.prisma.client.findUnique({
      where: {
        businessId_phone: {
          businessId,
          phone: data.phone,
        },
      },
    });

    if (!client) {
      // Create new client
      client = await this.prisma.client.create({
        data: {
          businessId,
          ...data,
        },
      });
    } else if (data.telegramId || data.whatsappId || data.instagramId) {
      // Update channel IDs if provided
      client = await this.prisma.client.update({
        where: { id: client.id },
        data: {
          telegramId: data.telegramId || client.telegramId,
          whatsappId: data.whatsappId || client.whatsappId,
          instagramId: data.instagramId || client.instagramId,
        },
      });
    }

    return client;
  }

  async findByBusiness(businessId: string): Promise<Client[]> {
    return this.prisma.client.findMany({
      where: { businessId },
      orderBy: { createdAt: 'desc' },
    });
  }

  async addNote(clientId: string, businessId: string, note: string, createdBy?: string): Promise<void> {
    await this.prisma.clientNote.create({
      data: {
        clientId,
        businessId,
        note,
        createdBy,
      },
    });
  }
}
```

---

### Phase 3: Google Calendar Integration (Week 2)

#### 3.1 Install Google APIs

```bash
pnpm add googleapis
```

#### 3.2 Calendar Integration Service

**src/calendar/calendar.service.ts**
```typescript
import { Injectable } from '@nestjs/common';
import { google, calendar_v3 } from 'googleapis';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class CalendarService {
  constructor(private prisma: PrismaService) {}

  async createEvent(businessId: string, booking: {
    id: string;
    startTime: Date;
    endTime: Date;
    clientName: string;
    serviceName: string;
  }): Promise<string> {
    // Get calendar integration
    const integration = await this.prisma.calendarIntegration.findFirst({
      where: { businessId, provider: 'google', isActive: true },
    });

    if (!integration) {
      return null; // No calendar integration
    }

    const credentials = integration.credentials as any;
    
    const oauth2Client = new google.auth.OAuth2();
    oauth2Client.setCredentials({
      access_token: credentials.accessToken,
      refresh_token: credentials.refreshToken,
    });

    const calendar = google.calendar({ version: 'v3', auth: oauth2Client });

    const event: calendar_v3.Schema$Event = {
      summary: `${booking.serviceName} - ${booking.clientName}`,
      start: { dateTime: booking.startTime.toISOString() },
      end: { dateTime: booking.endTime.toISOString() },
      description: `Booking ID: ${booking.id}`,
    };

    const response = await calendar.events.insert({
      calendarId: credentials.calendarId || 'primary',
      requestBody: event,
    });

    return response.data.id;
  }

  async updateEvent(eventId: string, businessId: string, updates: {
    startTime?: Date;
    endTime?: Date;
  }): Promise<void> {
    const integration = await this.prisma.calendarIntegration.findFirst({
      where: { businessId, provider: 'google', isActive: true },
    });

    if (!integration) return;

    const credentials = integration.credentials as any;
    const oauth2Client = new google.auth.OAuth2();
    oauth2Client.setCredentials({
      access_token: credentials.accessToken,
      refresh_token: credentials.refreshToken,
    });

    const calendar = google.calendar({ version: 'v3', auth: oauth2Client });

    await calendar.events.patch({
      calendarId: credentials.calendarId || 'primary',
      eventId,
      requestBody: {
        start: updates.startTime ? { dateTime: updates.startTime.toISOString() } : undefined,
        end: updates.endTime ? { dateTime: updates.endTime.toISOString() } : undefined,
      },
    });
  }

  async deleteEvent(eventId: string, businessId: string): Promise<void> {
    const integration = await this.prisma.calendarIntegration.findFirst({
      where: { businessId, provider: 'google', isActive: true },
    });

    if (!integration) return;

    const credentials = integration.credentials as any;
    const oauth2Client = new google.auth.OAuth2();
    oauth2Client.setCredentials({
      access_token: credentials.accessToken,
      refresh_token: credentials.refreshToken,
    });

    const calendar = google.calendar({ version: 'v3', auth: oauth2Client });

    await calendar.events.delete({
      calendarId: credentials.calendarId || 'primary',
      eventId,
    });
  }
}
```

---

### Phase 4: Telegram Bots (Week 2-3)

#### 4.1 Install Telegram Bot Library

```bash
pnpm add grammy
```

#### 4.2 Channel Gateway (Abstraction Layer)

**src/channel-gateway/channel-gateway.service.ts**
```typescript
import { Injectable } from '@nestjs/common';

export interface NormalizedMessage {
  channel: 'telegram' | 'whatsapp' | 'instagram';
  userId: string;
  chatId: string;
  text?: string;
  attachments?: Array<{ type: string; url: string }>;
  metadata: Record<string, any>;
  timestamp: Date;
}

export interface UIChoices {
  type: 'choices';
  question: string;
  options: Array<{ id: string; label: string }>;
}

@Injectable()
export class ChannelGatewayService {
  /**
   * Normalize incoming message from any channel
   */
  normalizeMessage(channel: string, rawMessage: any): NormalizedMessage {
    if (channel === 'telegram') {
      return {
        channel: 'telegram',
        userId: rawMessage.from.id.toString(),
        chatId: rawMessage.chat.id.toString(),
        text: rawMessage.text,
        metadata: { username: rawMessage.from.username },
        timestamp: new Date(rawMessage.date * 1000),
      };
    }
    // Add WhatsApp, Instagram normalization here
    throw new Error('Unsupported channel');
  }

  /**
   * Render UI choices for specific channel
   */
  renderChoices(channel: string, ui: UIChoices): any {
    if (channel === 'telegram') {
      return {
        text: ui.question,
        reply_markup: {
          inline_keyboard: ui.options.map((opt) => [
            { text: opt.label, callback_data: opt.id },
          ]),
        },
      };
    }
    // Fallback: numbered list
    return {
      text: `${ui.question}\n\n${ui.options.map((opt, i) => `${i + 1}. ${opt.label}`).join('\n')}`,
    };
  }
}
```

#### 4.3 Telegram Client Bot

**src/telegram/telegram-client.bot.ts**
```typescript
import { Injectable, OnModuleInit } from '@nestjs/common';
import { Bot, Context } from 'grammy';
import { ConfigService } from '@nestjs/config';
import { AIService } from '../ai/ai.service';
import { ChannelGatewayService } from '../channel-gateway/channel-gateway.service';

@Injectable()
export class TelegramClientBot implements OnModuleInit {
  private bot: Bot;

  constructor(
    private config: ConfigService,
    private aiService: AIService,
    private channelGateway: ChannelGatewayService,
  ) {}

  async onModuleInit() {
    const token = this.config.get<string>('TELEGRAM_CLIENT_BOT_TOKEN');
    if (!token) return;

    this.bot = new Bot(token);

    this.bot.on('message:text', async (ctx) => {
      const normalized = this.channelGateway.normalizeMessage('telegram', ctx.message);
      
      // Pass to AI Orchestrator (Client Agent)
      const response = await this.aiService.handleClientMessage(normalized);
      
      await ctx.reply(response.text, response.ui);
    });

    this.bot.start();
  }
}
```

---

### Phase 5: AI Orchestrator (Week 3)

#### 5.1 Install OpenAI SDK

```bash
pnpm add openai
```

#### 5.2 AI Service with Function Calling

**src/ai/ai.service.ts**
```typescript
import { Injectable } from '@nestjs/common';
import OpenAI from 'openai';
import { ConfigService } from '@nestjs/config';
import { BookingService } from '../booking/booking.service';
import { ScheduleService } from '../schedule/schedule.service';
import { NormalizedMessage } from '../channel-gateway/channel-gateway.service';

@Injectable()
export class AIService {
  private openai: OpenAI;

  constructor(
    private config: ConfigService,
    private bookingService: BookingService,
    private scheduleService: ScheduleService,
  ) {
    this.openai = new OpenAI({
      apiKey: this.config.get<string>('OPENAI_API_KEY'),
    });
  }

  async handleClientMessage(message: NormalizedMessage) {
    const tools: OpenAI.Chat.Completions.ChatCompletionTool[] = [
      {
        type: 'function',
        function: {
          name: 'getAvailableSlots',
          description: 'Get available time slots for booking',
          parameters: {
            type: 'object',
            properties: {
              businessId: { type: 'string' },
              serviceId: { type: 'string' },
              date: { type: 'string', format: 'date' },
            },
            required: ['businessId', 'serviceId', 'date'],
          },
        },
      },
      {
        type: 'function',
        function: {
          name: 'createBooking',
          description: 'Create a new booking',
          parameters: {
            type: 'object',
            properties: {
              businessId: { type: 'string' },
              clientId: { type: 'string' },
              serviceId: { type: 'string' },
              slotId: { type: 'string' },
            },
            required: ['businessId', 'clientId', 'serviceId', 'slotId'],
          },
        },
      },
    ];

    const completion = await this.openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: `Вы — вежливый AI-администратор салона красоты. Общайтесь на "Вы", помогайте клиентам записаться, перенести или отменить запись.`,
        },
        {
          role: 'user',
          content: message.text,
        },
      ],
      tools,
      tool_choice: 'auto',
    });

    const responseMessage = completion.choices[0].message;

    if (responseMessage.tool_calls) {
      // Execute function calls
      for (const toolCall of responseMessage.tool_calls) {
        const functionName = toolCall.function.name;
        const args = JSON.parse(toolCall.function.arguments);

        if (functionName === 'getAvailableSlots') {
          const slots = await this.scheduleService.generateSlots(
            args.businessId,
            new Date(args.date),
            60, // TODO: get from service
          );
          // Return slots to AI for formatting
          return {
            text: 'Доступные окошки:',
            ui: {
              type: 'choices',
              options: slots.map((slot) => ({
                id: slot.id,
                label: slot.startTime.toLocaleTimeString('ru-RU', {
                  hour: '2-digit',
                  minute: '2-digit',
                }),
              })),
            },
          };
        }
      }
    }

    return {
      text: responseMessage.content,
      ui: null,
    };
  }
}
```

---

### Phase 6: Import Service (Week 3)

**src/import/import.service.ts**
```typescript
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import OpenAI from 'openai';
import { ConfigService } from '@nestjs/config';

export interface ParsedAppointment {
  date: string;
  time: string;
  clientName: string;
  service?: string;
  raw: string;
}

@Injectable()
export class ImportService {
  private openai: OpenAI;

  constructor(
    private prisma: PrismaService,
    private config: ConfigService,
  ) {
    this.openai = new OpenAI({
      apiKey: this.config.get<string>('OPENAI_API_KEY'),
    });
  }

  async importFromText(businessId: string, text: string): Promise<ParsedAppointment[]> {
    const completion = await this.openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: `Вы — парсер записей. Извлеките из текста записи в формате JSON:
          [{ "date": "2025-05-12", "time": "12:00", "clientName": "Анна", "service": "маникюр", "raw": "..." }]`,
        },
        {
          role: 'user',
          content: text,
        },
      ],
      response_format: { type: 'json_object' },
    });

    const result = JSON.parse(completion.choices[0].message.content);
    return result.appointments || [];
  }

  async confirmImport(businessId: string, batchId: string): Promise<void> {
    const batch = await this.prisma.importBatch.findUnique({
      where: { id: batchId },
    });

    if (!batch || batch.status !== 'preview') return;

    const appointments = batch.parsedData as ParsedAppointment[];

    for (const apt of appointments) {
      // Create client if not exists
      const client = await this.prisma.client.upsert({
        where: {
          businessId_phone: {
            businessId,
            phone: 'imported', // TODO: extract phone if available
          },
        },
        create: {
          businessId,
          firstName: apt.clientName,
          phone: 'imported',
        },
        update: {},
      });

      // Create booking
      const startTime = new Date(`${apt.date}T${apt.time}`);
      const endTime = new Date(startTime.getTime() + 60 * 60 * 1000); // 1 hour default

      await this.prisma.booking.create({
        data: {
          businessId,
          clientId: client.id,
          startTime,
          endTime,
          status: 'confirmed',
          sourceChannel: 'import',
        },
      });
    }

    await this.prisma.importBatch.update({
      where: { id: batchId },
      data: {
        status: 'confirmed',
        confirmedAt: new Date(),
        bookingsCreated: appointments.length,
      },
    });
  }
}
```

---

### Phase 7: SMM Module (Week 4)

**src/smm/smm.service.ts**
```typescript
import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import OpenAI from 'openai';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class SMMService {
  private openai: OpenAI;

  constructor(
    private prisma: PrismaService,
    private config: ConfigService,
  ) {
    this.openai = new OpenAI({
      apiKey: this.config.get<string>('OPENAI_API_KEY'),
    });
  }

  async generateContentPlan(businessId: string, params: {
    topics: string[];
    postsPerWeek: number;
    durationWeeks: number;
  }) {
    const completion = await this.openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: `Создайте контент-план для салона красоты на ${params.durationWeeks} недель, ${params.postsPerWeek} поста в неделю. Темы: ${params.topics.join(', ')}.`,
        },
      ],
      response_format: { type: 'json_object' },
    });

    const plan = JSON.parse(completion.choices[0].message.content);

    // Save to database
    const contentPlan = await this.prisma.contentPlan.create({
      data: {
        businessId,
        title: `План на ${params.durationWeeks} недель`,
        topics: params.topics,
        postsPerWeek: params.postsPerWeek,
        startDate: new Date(),
        endDate: new Date(Date.now() + params.durationWeeks * 7 * 24 * 60 * 60 * 1000),
      },
    });

    return contentPlan;
  }

  async generatePost(businessId: string, params: {
    topic: string;
    photoUrls?: string[];
  }) {
    const completion = await this.openai.chat.completions.create({
      model: 'gpt-4',
      messages: [
        {
          role: 'system',
          content: `Создайте пост для Instagram салона красоты. Тема: ${params.topic}. Добавьте призыв к записи и хэштеги.`,
        },
      ],
    });

    const content = completion.choices[0].message.content;

    const post = await this.prisma.post.create({
      data: {
        businessId,
        content,
        mediaUrls: params.photoUrls || [],
        platforms: ['instagram', 'telegram'],
        status: 'draft',
      },
    });

    return post;
  }

  async publishPost(postId: string) {
    const post = await this.prisma.post.findUnique({
      where: { id: postId },
    });

    if (!post) return;

    // TODO: Publish to Instagram via Graph API
    // TODO: Publish to Telegram channel

    await this.prisma.post.update({
      where: { id: postId },
      data: {
        status: 'published',
        publishedAt: new Date(),
      },
    });
  }
}
```

---

### Phase 8: Notification Queue (Week 4)

#### 8.1 Setup BullMQ

**src/queue/queue.module.ts**
```typescript
import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bull';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { NotificationProcessor } from './notification.processor';

@Module({
  imports: [
    BullModule.forRootAsync({
      imports: [ConfigModule],
      useFactory: (config: ConfigService) => ({
        redis: {
          host: config.get('REDIS_HOST'),
          port: config.get('REDIS_PORT'),
        },
      }),
      inject: [ConfigService],
    }),
    BullModule.registerQueue({
      name: 'notifications',
    }),
  ],
  providers: [NotificationProcessor],
})
export class QueueModule {}
```

**src/queue/notification.processor.ts**
```typescript
import { Processor, Process } from '@nestjs/bull';
import { Job } from 'bull';
import { PrismaService } from '../prisma/prisma.service';

@Processor('notifications')
export class NotificationProcessor {
  constructor(private prisma: PrismaService) {}

  @Process('send-reminder')
  async handleReminder(job: Job) {
    const { notificationId } = job.data;

    const notification = await this.prisma.notification.findUnique({
      where: { id: notificationId },
      include: { booking: true, client: true },
    });

    if (!notification) return;

    // TODO: Send via appropriate channel (Telegram, WhatsApp, etc.)
    console.log(`Sending reminder to ${notification.client.firstName}`);

    await this.prisma.notification.update({
      where: { id: notificationId },
      data: {
        status: 'sent',
        sentAt: new Date(),
      },
    });
  }
}
```

---

## Deployment Configuration

### Docker Compose

**docker-compose.yml**
```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
      POSTGRES_DB: ai_booking_platform
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  backend:
    build: .
    ports:
      - "3000:3000"
    environment:
      DATABASE_URL: postgresql://postgres:postgres@postgres:5432/ai_booking_platform
      REDIS_HOST: redis
      REDIS_PORT: 6379
    depends_on:
      - postgres
      - redis

volumes:
  postgres_data:
```

### Dockerfile

**Dockerfile**
```dockerfile
FROM node:22-alpine

WORKDIR /app

COPY package.json pnpm-lock.yaml ./
RUN npm install -g pnpm && pnpm install

COPY . .

RUN npx prisma generate
RUN pnpm run build

CMD ["pnpm", "run", "start:prod"]
```

---

## Testing Strategy

### Unit Tests Example

**src/booking/booking.service.spec.ts**
```typescript
import { Test } from '@nestjs/testing';
import { BookingService } from './booking.service';
import { PrismaService } from '../prisma/prisma.service';

describe('BookingService', () => {
  let service: BookingService;
  let prisma: PrismaService;

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [BookingService, PrismaService],
    }).compile();

    service = module.get<BookingService>(BookingService);
    prisma = module.get<PrismaService>(PrismaService);
  });

  it('should create a booking', async () => {
    const booking = await service.create({
      businessId: 'test-business',
      clientId: 'test-client',
      serviceId: 'test-service',
      startTime: new Date('2025-05-12T12:00:00'),
    });

    expect(booking).toBeDefined();
    expect(booking.status).toBe('confirmed');
  });
});
```

---

## Example Dialogues

### Client Booking Flow

```
Client: Хочу записаться на маникюр в субботу
Bot: На субботу 12 мая есть свободные окошки:
     [10:00] [12:00] [14:00] [16:00]
Client: [clicks 12:00]
Bot: Отлично! Вы записаны на маникюр в субботу 12.05 в 12:00.
     Адрес: ул. Ленина, 10
     Напомню за 24 часа и за 2 часа до визита.
```

### Admin Onboarding Flow

```
Admin: /start
Bot: Добро пожаловать! Давайте настроим Ваш бизнес.
     Какой у Вас тип деятельности?
     [Маникюр] [Парикмахер] [Косметолог] [Тренер] [Другое]
Admin: [clicks Маникюр]
Bot: Отлично! Как называется Ваш салон?
Admin: Салон "Элегант"
Bot: Какой у Вас график работы?
Admin: Пн-Пт 9-18
Bot: Понял. Добавьте Ваши услуги (название, длительность, цена):
Admin: Маникюр классический, 60 минут, 1500 руб
Bot: Услуга добавлена! Хотите импортировать существующие записи?
     [Да, из блокнота (фото)] [Да, из текста] [Нет, начать с нуля]
```

---

## Next Steps

1. Implement remaining modules (WhatsApp, Instagram bots)
2. Add comprehensive error handling
3. Implement rate limiting and security
4. Add monitoring (Prometheus + Grafana)
5. Set up CI/CD pipeline
6. Conduct load testing
7. Deploy to production (Yandex Cloud / VK Cloud for Russian market)

---

**Document Version:** 1.0  
**Last Updated:** 2025-11-23
