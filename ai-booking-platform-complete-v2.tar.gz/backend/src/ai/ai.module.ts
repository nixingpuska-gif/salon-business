import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AIService } from './ai.service';
import { BusinessModule } from '../business/business.module';
import { ClientModule } from '../client/client.module';
import { ServiceModule } from '../service/service.module';
import { ScheduleModule } from '../schedule/schedule.module';
import { BookingModule } from '../booking/booking.module';

@Module({
  imports: [
    ConfigModule,
    BusinessModule,
    ClientModule,
    ServiceModule,
    ScheduleModule,
    BookingModule,
  ],
  providers: [AIService],
  exports: [AIService],
})
export class AIModule {}
