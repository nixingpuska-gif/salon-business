"""
Business OS - Client Models
Модели клиентов салонов
"""

from datetime import datetime, date
from typing import Optional
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, BigInteger, 
    DateTime, Date, Numeric, ForeignKey, JSON, Index
)
from sqlalchemy.orm import relationship
import enum

from app.models.base import TenantBaseModel


class ClientSource(str, enum.Enum):
    """Источник привлечения клиента"""
    WALK_IN = "walk_in"  # Пришёл сам
    REFERRAL = "referral"  # Рекомендация
    INSTAGRAM = "instagram"
    FACEBOOK = "facebook"
    GOOGLE = "google"
    YANDEX = "yandex"
    WEBSITE = "website"
    OTHER = "other"


class ClientSegment(str, enum.Enum):
    """Автоматические сегменты клиентов"""
    NEW = "new"  # Новый (1-2 визита)
    REGULAR = "regular"  # Постоянный
    VIP = "vip"  # VIP (топ-10% по LTV)
    SLEEPING = "sleeping"  # Спящий (просрочил цикл)
    LOST = "lost"  # Потерянный (90+ дней)
    AT_RISK = "at_risk"  # Под угрозой ухода
    PROBLEMATIC = "problematic"  # Проблемный (частые отмены)


class Client(TenantBaseModel):
    """
    Клиент салона.
    Основная сущность для работы с клиентской базой.
    """
    __tablename__ = "clients"
    
    # === Основная информация ===
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=True)
    middle_name = Column(String(100), nullable=True)
    
    # === Контакты ===
    phone = Column(String(50), nullable=False, index=True)
    email = Column(String(255), nullable=True)
    
    # === Мессенджеры ===
    telegram_id = Column(BigInteger, nullable=True, index=True)
    telegram_username = Column(String(100), nullable=True)
    whatsapp_phone = Column(String(50), nullable=True)
    instagram_username = Column(String(100), nullable=True)
    
    # === Предпочтительный канал связи ===
    preferred_channel = Column(String(20), default="telegram")
    
    # === Демография ===
    birth_date = Column(Date, nullable=True)
    gender = Column(String(10), nullable=True)  # male, female, other
    
    # === Привязка к филиалу ===
    primary_branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=True)
    
    # === Предпочтения ===
    preferred_staff_id = Column(BigInteger, nullable=True)  # Любимый мастер
    notes = Column(Text, nullable=True)  # Заметки администратора
    
    # === Источник привлечения ===
    source = Column(String(50), default=ClientSource.WALK_IN.value)
    source_details = Column(String(255), nullable=True)  # Детали (реф. код, кампания)
    acquisition_cost = Column(Numeric(10, 2), nullable=True)  # Стоимость привлечения
    
    # === Сегментация (автоматическая) ===
    segment = Column(String(50), default=ClientSegment.NEW.value, index=True)
    risk_score = Column(Integer, default=0)  # 0-100, выше = выше риск ухода
    
    # === LTV и финансы ===
    ltv = Column(Numeric(12, 2), default=0)  # Lifetime Value
    total_spent = Column(Numeric(12, 2), default=0)
    total_visits = Column(Integer, default=0)
    avg_check = Column(Numeric(10, 2), default=0)
    
    # === Бонусная программа ===
    bonus_balance = Column(Integer, default=0)  # В копейках
    total_bonus_earned = Column(Integer, default=0)
    total_bonus_spent = Column(Integer, default=0)
    
    # === Статистика визитов ===
    first_visit_at = Column(DateTime, nullable=True)
    last_visit_at = Column(DateTime, nullable=True)
    next_expected_visit_at = Column(DateTime, nullable=True)  # Прогноз
    personal_return_cycle_days = Column(Integer, nullable=True)  # Персональный цикл
    
    # === Статистика отмен ===
    total_cancellations = Column(Integer, default=0)
    total_no_shows = Column(Integer, default=0)
    total_reschedules = Column(Integer, default=0)
    
    # === Коммуникации ===
    last_message_at = Column(DateTime, nullable=True)
    messages_sent_count = Column(Integer, default=0)
    is_unsubscribed = Column(Boolean, default=False)  # Отписался от рассылок
    unsubscribed_at = Column(DateTime, nullable=True)
    
    # === Отзывы ===
    avg_rating = Column(Numeric(3, 2), nullable=True)  # Средняя оценка
    total_reviews = Column(Integer, default=0)
    last_review_at = Column(DateTime, nullable=True)
    
    # === Метки ===
    tags = Column(JSON, default=list)  # ["vip", "аллергия на гель", "опаздывает"]
    
    # === Дополнительные данные ===
    custom_fields = Column(JSON, default=dict)  # Кастомные поля
    
    # === Relationships ===
    appointments = relationship("Appointment", back_populates="client", lazy="dynamic")
    payments = relationship("Payment", back_populates="client", lazy="dynamic")
    reviews = relationship("Review", back_populates="client", lazy="dynamic")
    messages = relationship("Message", back_populates="client", lazy="dynamic")
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_clients_tenant_phone', 'tenant_id', 'phone'),
        Index('ix_clients_tenant_segment', 'tenant_id', 'segment'),
        Index('ix_clients_tenant_last_visit', 'tenant_id', 'last_visit_at'),
    )
    
    @property
    def full_name(self) -> str:
        parts = [self.first_name]
        if self.last_name:
            parts.append(self.last_name)
        return " ".join(parts)
    
    @property
    def days_since_last_visit(self) -> Optional[int]:
        if self.last_visit_at:
            return (datetime.utcnow() - self.last_visit_at).days
        return None


class ClientNote(TenantBaseModel):
    """
    Заметки о клиенте.
    История комментариев от сотрудников.
    """
    __tablename__ = "client_notes"
    
    client_id = Column(BigInteger, ForeignKey("clients.id"), nullable=False, index=True)
    staff_id = Column(BigInteger, nullable=True)  # Кто добавил
    
    content = Column(Text, nullable=False)
    is_important = Column(Boolean, default=False)  # Важная заметка
    
    # === Relationships ===
    client = relationship("Client")


class ClientBlacklist(TenantBaseModel):
    """
    Чёрный список клиентов.
    """
    __tablename__ = "client_blacklist"
    
    client_id = Column(BigInteger, ForeignKey("clients.id"), nullable=False, index=True)
    
    reason = Column(Text, nullable=False)
    blocked_by_staff_id = Column(BigInteger, nullable=True)
    blocked_at = Column(DateTime, default=datetime.utcnow)
    
    # Можно разблокировать
    is_permanent = Column(Boolean, default=False)
    unblocked_at = Column(DateTime, nullable=True)
    unblocked_by_staff_id = Column(BigInteger, nullable=True)


class ClientMerge(TenantBaseModel):
    """
    История объединения дубликатов клиентов.
    """
    __tablename__ = "client_merges"
    
    # Клиент, который остался
    primary_client_id = Column(BigInteger, ForeignKey("clients.id"), nullable=False)
    # Клиент, который был объединён
    merged_client_id = Column(BigInteger, nullable=False)
    
    merged_by_staff_id = Column(BigInteger, nullable=True)
    merged_at = Column(DateTime, default=datetime.utcnow)
    
    # Данные объединённого клиента (для возможного отката)
    merged_client_data = Column(JSON, nullable=True)
