import { Injectable, Logger } from '@nestjs/common';
import axios, { AxiosInstance } from 'axios';

/**
 * WhatsApp Business Cloud API Service
 * 
 * Официальная интеграция с WhatsApp Business Platform через Cloud API.
 * 
 * Требуется:
 * - WHATSAPP_PHONE_NUMBER_ID (ID телефонного номера из Meta Business)
 * - WHATSAPP_ACCESS_TOKEN (Постоянный токен доступа)
 * - WHATSAPP_VERIFY_TOKEN (Токен для верификации webhook)
 * 
 * Документация: https://developers.facebook.com/docs/whatsapp/cloud-api
 */
@Injectable()
export class WhatsAppService {
  private readonly logger = new Logger(WhatsAppService.name);
  private readonly apiClient: AxiosInstance;
  private readonly phoneNumberId: string;
  private readonly accessToken: string;
  private readonly verifyToken: string;

  constructor() {
    this.phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID || '';
    this.accessToken = process.env.WHATSAPP_ACCESS_TOKEN || '';
    this.verifyToken = process.env.WHATSAPP_VERIFY_TOKEN || 'your_verify_token';

    // Инициализация HTTP клиента для WhatsApp Cloud API
    this.apiClient = axios.create({
      baseURL: `https://graph.facebook.com/v21.0/${this.phoneNumberId}`,
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
      },
    });

    this.logger.log('WhatsApp Service initialized');
  }

  /**
   * Верификация webhook от Meta
   */
  verifyWebhook(mode: string, token: string, challenge: string): string | null {
    if (mode === 'subscribe' && token === this.verifyToken) {
      this.logger.log('Webhook verified successfully');
      return challenge;
    }
    this.logger.warn('Webhook verification failed');
    return null;
  }

  /**
   * Отправка текстового сообщения
   */
  async sendMessage(to: string, text: string): Promise<any> {
    try {
      const formattedPhone = this.formatPhoneNumber(to);
      const response = await this.apiClient.post('/messages', {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: formattedPhone,
        type: 'text',
        text: {
          preview_url: false,
          body: text,
        },
      });

      this.logger.log(`Message sent to ${formattedPhone}: ${text.substring(0, 50)}...`);
      return response.data;
    } catch (error) {
      this.logger.error(`Failed to send message to ${to}:`, error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Отправка Message Template (предварительно одобренный шаблон)
   */
  async sendTemplate(
    to: string,
    templateName: string,
    parameters: string[],
    languageCode: string = 'ru',
  ): Promise<any> {
    try {
      const formattedPhone = this.formatPhoneNumber(to);
      const response = await this.apiClient.post('/messages', {
        messaging_product: 'whatsapp',
        to: formattedPhone,
        type: 'template',
        template: {
          name: templateName,
          language: {
            code: languageCode,
          },
          components: [
            {
              type: 'body',
              parameters: parameters.map((param) => ({
                type: 'text',
                text: param,
              })),
            },
          ],
        },
      });

      this.logger.log(`Template "${templateName}" sent to ${formattedPhone}`);
      return response.data;
    } catch (error) {
      this.logger.error(`Failed to send template to ${to}:`, error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Отправка интерактивных кнопок (до 3 кнопок)
   */
  async sendInteractiveButtons(
    to: string,
    bodyText: string,
    buttons: Array<{ id: string; title: string }>,
  ): Promise<any> {
    try {
      const formattedPhone = this.formatPhoneNumber(to);
      
      // WhatsApp поддерживает максимум 3 кнопки
      if (buttons.length > 3) {
        throw new Error('WhatsApp supports maximum 3 buttons');
      }

      const response = await this.apiClient.post('/messages', {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: formattedPhone,
        type: 'interactive',
        interactive: {
          type: 'button',
          body: {
            text: bodyText,
          },
          action: {
            buttons: buttons.map((btn) => ({
              type: 'reply',
              reply: {
                id: btn.id,
                title: btn.title.substring(0, 20), // Макс 20 символов
              },
            })),
          },
        },
      });

      this.logger.log(`Button message sent to ${formattedPhone}`);
      return response.data;
    } catch (error) {
      this.logger.error(`Failed to send button message to ${to}:`, error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Отправка интерактивного списка (до 10 пунктов в секции)
   */
  async sendInteractiveList(
    to: string,
    bodyText: string,
    buttonText: string,
    sections: Array<{
      title: string;
      rows: Array<{ id: string; title: string; description?: string }>;
    }>,
  ): Promise<any> {
    try {
      const formattedPhone = this.formatPhoneNumber(to);

      const response = await this.apiClient.post('/messages', {
        messaging_product: 'whatsapp',
        recipient_type: 'individual',
        to: formattedPhone,
        type: 'interactive',
        interactive: {
          type: 'list',
          body: {
            text: bodyText,
          },
          action: {
            button: buttonText.substring(0, 20),
            sections: sections.map((section) => ({
              title: section.title.substring(0, 24),
              rows: section.rows.map((row) => ({
                id: row.id,
                title: row.title.substring(0, 24),
                description: row.description?.substring(0, 72) || '',
              })),
            })),
          },
        },
      });

      this.logger.log(`List message sent to ${formattedPhone}`);
      return response.data;
    } catch (error) {
      this.logger.error(`Failed to send list message to ${to}:`, error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Обработка входящего webhook от WhatsApp
   */
  async handleIncomingMessage(body: any): Promise<void> {
    try {
      const messageData = this.parseWebhookPayload(body);
      
      if (!messageData) {
        this.logger.warn('No valid message data in webhook payload');
        return;
      }

      const { from, text, type, messageId } = messageData;

      this.logger.log(`Received ${type} message from ${from}: ${text}`);

      // TODO: Интеграция с AI Orchestrator
      // const response = await this.aiService.processMessage({
      //   channel: 'whatsapp',
      //   userId: from,
      //   message: text,
      //   businessId: 1, // Определяется по номеру телефона бота
      // });
      
      // await this.sendMessage(from, response);

      // Временный автоответ для тестирования
      await this.sendMessage(from, `Получено ваше сообщение: "${text}". AI-интеграция в процессе.`);

    } catch (error) {
      this.logger.error('Error handling incoming message:', error);
    }
  }

  /**
   * Парсинг webhook payload от Meta
   */
  private parseWebhookPayload(body: any): {
    from: string;
    text: string;
    type: string;
    messageId: string;
  } | null {
    try {
      const entry = body.entry?.[0];
      const changes = entry?.changes?.[0];
      const value = changes?.value;
      const messages = value?.messages;

      if (!messages || messages.length === 0) {
        return null;
      }

      const message = messages[0];
      const from = message.from;
      const messageId = message.id;
      const type = message.type;

      let text = '';

      // Обработка разных типов сообщений
      if (type === 'text') {
        text = message.text.body;
      } else if (type === 'button') {
        text = message.button.text;
      } else if (type === 'interactive') {
        if (message.interactive.type === 'button_reply') {
          text = message.interactive.button_reply.title;
        } else if (message.interactive.type === 'list_reply') {
          text = message.interactive.list_reply.title;
        }
      }

      return { from, text, type, messageId };
    } catch (error) {
      this.logger.error('Error parsing webhook payload:', error);
      return null;
    }
  }

  /**
   * Форматирование телефонного номера для WhatsApp
   * Преобразует российские номера в международный формат
   */
  formatPhoneNumber(phone: string): string {
    // Удаляем все нецифровые символы
    let cleaned = phone.replace(/\D/g, '');
    
    // Преобразуем 8XXXXXXXXXX в 7XXXXXXXXXX
    if (cleaned.startsWith('8') && cleaned.length === 11) {
      cleaned = '7' + cleaned.substring(1);
    }
    
    // Добавляем код России если номер 10-значный
    if (cleaned.length === 10) {
      cleaned = '7' + cleaned;
    }
    
    return cleaned;
  }
}
