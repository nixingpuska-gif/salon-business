"""
Business OS - Tenant Models
Модели для салонов, филиалов и подписок
"""

from datetime import datetime, date
from typing import Optional, List
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, BigInteger, 
    DateTime, Date, Numeric, ForeignKey, JSON, Enum as SQLEnum
)
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel, TimestampMixin, SoftDeleteMixin
from app.core.database import Base


class SubscriptionPlan(str, enum.Enum):
    """Тарифные планы"""
    TRIAL = "trial"
    STARTER = "starter"
    PROFESSIONAL = "professional"
    ENTERPRISE = "enterprise"


class TenantStatus(str, enum.Enum):
    """Статусы тенанта"""
    ACTIVE = "active"
    SUSPENDED = "suspended"
    CANCELLED = "cancelled"
    TRIAL = "trial"


class Tenant(BaseModel):
    """
    Тенант - основная сущность (салон или сеть салонов).
    Все данные привязаны к тенанту для изоляции.
    """
    __tablename__ = "tenants"
    
    # === Основная информация ===
    name = Column(String(255), nullable=False)
    slug = Column(String(100), unique=True, nullable=False, index=True)
    description = Column(Text, nullable=True)
    logo_url = Column(String(500), nullable=True)
    
    # === Контакты ===
    email = Column(String(255), nullable=False)
    phone = Column(String(50), nullable=True)
    website = Column(String(255), nullable=True)
    
    # === Адрес (для основного офиса/салона) ===
    country = Column(String(100), default="Russia")
    city = Column(String(100), nullable=True)
    address = Column(String(500), nullable=True)
    postal_code = Column(String(20), nullable=True)
    
    # === Настройки ===
    timezone = Column(String(50), default="Europe/Moscow")
    currency = Column(String(3), default="RUB")
    language = Column(String(5), default="ru")
    
    # === Подписка ===
    subscription_plan = Column(SQLEnum(SubscriptionPlan), default=SubscriptionPlan.TRIAL)
    subscription_status = Column(SQLEnum(TenantStatus), default=TenantStatus.TRIAL)
    subscription_started_at = Column(DateTime, nullable=True)
    subscription_expires_at = Column(DateTime, nullable=True)
    monthly_price = Column(Numeric(10, 2), default=100000)  # 100k рублей
    
    # === Лимиты по тарифу ===
    max_branches = Column(Integer, default=1)
    max_staff = Column(Integer, default=10)
    max_clients = Column(Integer, default=1000)
    
    # === Реферальная программа ===
    referral_code = Column(String(50), unique=True, nullable=True, index=True)
    referred_by_tenant_id = Column(BigInteger, ForeignKey("tenants.id"), nullable=True)
    referred_by_partner_id = Column(BigInteger, nullable=True)  # ID поставщика
    
    # === Статистика ===
    total_revenue = Column(Numeric(15, 2), default=0)
    total_clients = Column(Integer, default=0)
    total_appointments = Column(Integer, default=0)
    
    # === Настройки модулей ===
    settings = Column(JSON, default=dict)
    # Пример: {
    #   "reminders": {"enabled": true, "hours_before": [24, 2]},
    #   "ai_assistant": {"enabled": true, "auto_reply": true},
    #   "retention": {"enabled": true, "cycles": {...}}
    # }
    
    # === Onboarding ===
    onboarding_completed = Column(Boolean, default=False)
    onboarding_step = Column(Integer, default=0)
    onboarding_data = Column(JSON, default=dict)
    
    # === Relationships ===
    branches = relationship("Branch", back_populates="tenant", lazy="dynamic")
    owner = relationship("User", back_populates="owned_tenant", uselist=False, 
                        foreign_keys="User.owned_tenant_id")


class Branch(BaseModel):
    """
    Филиал салона.
    У одного тенанта может быть несколько филиалов.
    """
    __tablename__ = "branches"
    
    # === Привязка к тенанту ===
    tenant_id = Column(BigInteger, ForeignKey("tenants.id"), nullable=False, index=True)
    
    # === Основная информация ===
    name = Column(String(255), nullable=False)
    is_main = Column(Boolean, default=False)  # Главный филиал
    is_active = Column(Boolean, default=True)
    
    # === Контакты ===
    phone = Column(String(50), nullable=True)
    email = Column(String(255), nullable=True)
    
    # === Адрес ===
    country = Column(String(100), nullable=True)
    city = Column(String(100), nullable=True)
    address = Column(String(500), nullable=True)
    postal_code = Column(String(20), nullable=True)
    latitude = Column(Numeric(10, 8), nullable=True)
    longitude = Column(Numeric(11, 8), nullable=True)
    
    # === Настройки ===
    timezone = Column(String(50), nullable=True)  # Если отличается от тенанта
    currency = Column(String(3), nullable=True)
    
    # === Рабочие часы ===
    working_hours = Column(JSON, default=dict)
    # Пример: {
    #   "monday": {"open": "09:00", "close": "21:00", "breaks": []},
    #   "tuesday": {"open": "09:00", "close": "21:00", "breaks": []},
    #   ...
    #   "sunday": null  # Выходной
    # }
    
    # === Статистика филиала ===
    total_revenue = Column(Numeric(15, 2), default=0)
    total_clients = Column(Integer, default=0)
    avg_rating = Column(Numeric(3, 2), default=0)
    
    # === Relationships ===
    tenant = relationship("Tenant", back_populates="branches")
    staff = relationship("Staff", back_populates="branch", lazy="dynamic")
    services = relationship("Service", back_populates="branch", lazy="dynamic")


class Subscription(BaseModel):
    """
    История подписок тенанта.
    Для отслеживания платежей и изменений тарифа.
    """
    __tablename__ = "subscriptions"
    
    tenant_id = Column(BigInteger, ForeignKey("tenants.id"), nullable=False, index=True)
    
    # === Период ===
    plan = Column(SQLEnum(SubscriptionPlan), nullable=False)
    started_at = Column(DateTime, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    
    # === Оплата ===
    amount = Column(Numeric(10, 2), nullable=False)
    currency = Column(String(3), default="RUB")
    payment_method = Column(String(50), nullable=True)
    payment_id = Column(String(255), nullable=True)  # ID транзакции
    
    # === Статус ===
    is_paid = Column(Boolean, default=False)
    paid_at = Column(DateTime, nullable=True)
    
    # === Реферальные выплаты ===
    referral_paid = Column(Boolean, default=False)
    referral_amount = Column(Numeric(10, 2), default=0)


class TenantSettings(BaseModel):
    """
    Детальные настройки тенанта.
    Вынесено в отдельную таблицу для удобства.
    """
    __tablename__ = "tenant_settings"
    
    tenant_id = Column(BigInteger, ForeignKey("tenants.id"), nullable=False, unique=True)
    
    # === Напоминания ===
    reminder_enabled = Column(Boolean, default=True)
    reminder_hours_before = Column(JSON, default=[24, 2])  # За сколько часов
    reminder_channels = Column(JSON, default=["telegram", "whatsapp"])
    
    # === AI-ассистент ===
    ai_enabled = Column(Boolean, default=True)
    ai_auto_reply = Column(Boolean, default=True)
    ai_escalation_keywords = Column(JSON, default=[])  # Слова для эскалации
    
    # === Retention ===
    retention_enabled = Column(Boolean, default=True)
    default_return_cycle_days = Column(Integer, default=21)
    
    # === Отзывы ===
    feedback_enabled = Column(Boolean, default=True)
    feedback_delay_minutes = Column(Integer, default=60)  # Через сколько после визита
    
    # === Бонусная программа ===
    bonus_enabled = Column(Boolean, default=True)
    bonus_percent = Column(Numeric(5, 2), default=5)  # % от оплаты
    
    # === Уведомления владельцу ===
    owner_notifications = Column(JSON, default={
        "critical_alerts": True,
        "daily_summary": True,
        "weekly_report": True,
        "new_payments": True
    })
    
    # === Политики ===
    cancellation_policy_hours = Column(Integer, default=4)  # За сколько часов можно отменить
    no_show_penalty = Column(Numeric(10, 2), default=0)  # Штраф за неявку
    max_reschedules = Column(Integer, default=2)  # Макс. переносов
