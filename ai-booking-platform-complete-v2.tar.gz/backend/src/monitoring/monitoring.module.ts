import { Module, Global } from '@nestjs/common';
import { LoggerService } from './logger.service';
import { MetricsService } from './metrics.service';
import { HealthService } from './health.service';
import { AuditService } from './audit.service';
import { MonitoringController } from './monitoring.controller';
import { PrismaModule } from '../prisma/prisma.module';

@Global()
@Module({
  imports: [PrismaModule],
  controllers: [MonitoringController],
  providers: [LoggerService, MetricsService, HealthService, AuditService],
  exports: [LoggerService, MetricsService, HealthService, AuditService],
})
export class MonitoringModule {}
