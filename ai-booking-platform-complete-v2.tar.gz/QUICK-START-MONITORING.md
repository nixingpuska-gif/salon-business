# 🚀 Quick Start: Мониторинг и Логирование

## За 10 минут

### 1. Обновить Prisma Schema

Добавьте в `schema.prisma`:

```prisma
model AuditLog {
  id           String   @id @default(cuid())
  action       String
  userId       String
  businessId   String?
  resourceType String?
  resourceId   String?
  details      Json     @default({})
  ipAddress    String?
  userAgent    String?
  createdAt    DateTime @default(now())

  @@index([userId])
  @@index([businessId])
  @@index([action])
  @@index([createdAt])
}
```

### 2. Применить миграцию

```bash
cd backend
npx prisma migrate dev --name add_audit_logs
```

### 3. Установить зависимости

```bash
npm install winston prom-client
```

### 4. Добавить в `.env`

```env
# Логирование
LOG_DIR=./logs
LOG_LEVEL=info
NODE_ENV=production
```

### 5. Запустить сервер

```bash
npm run start:dev
```

### 6. Проверить endpoints

#### Health Check:
```bash
curl http://localhost:3000/health
```

**Response:**
```json
{
  "status": "healthy",
  "uptime": 123,
  "checks": {
    "database": { "status": "up" },
    "redis": { "status": "up" }
  }
}
```

#### Prometheus Metrics:
```bash
curl http://localhost:3000/metrics
```

**Response:**
```
# HELP http_requests_total Total number of HTTP requests
# TYPE http_requests_total counter
http_requests_total{method="GET",route="/health",status="200"} 1
```

#### Audit Logs:
```bash
curl http://localhost:3000/audit/logs?limit=10
```

---

## Использование в коде

### Логирование

```typescript
import { LoggerService } from './monitoring/logger.service';

@Injectable()
export class MyService {
  constructor(private logger: LoggerService) {
    this.logger.setContext('MyService');
  }

  async doSomething() {
    this.logger.log('Operation started');
    
    try {
      // ...
      this.logger.log('Operation completed', undefined, { duration: 123 });
    } catch (error) {
      this.logger.logError(error);
    }
  }
}
```

### Метрики

```typescript
import { MetricsService } from './monitoring/metrics.service';

@Injectable()
export class BookingService {
  constructor(private metrics: MetricsService) {}

  async createBooking() {
    // Записать метрику
    this.metrics.recordBookingCreated('confirmed');
  }
}
```

### Аудит

```typescript
import { AuditService } from './monitoring/audit.service';

@Injectable()
export class BookingService {
  constructor(private audit: AuditService) {}

  async createBooking(userId: string, businessId: string, data: any) {
    const booking = await this.create(data);
    
    // Записать аудит лог
    await this.audit.logBookingCreated(
      userId,
      businessId,
      booking.id,
      { clientName: data.clientName },
    );
  }
}
```

---

## Интеграция с Prometheus

### prometheus.yml

```yaml
scrape_configs:
  - job_name: 'ai-booking'
    scrape_interval: 15s
    static_configs:
      - targets: ['localhost:3000']
    metrics_path: '/metrics'
```

### Запустить Prometheus

```bash
docker run -d \
  -p 9090:9090 \
  -v $(pwd)/prometheus.yml:/etc/prometheus/prometheus.yml \
  prom/prometheus
```

Откройте: http://localhost:9090

---

## Интеграция с Grafana

### Запустить Grafana

```bash
docker run -d \
  -p 3001:3000 \
  grafana/grafana
```

Откройте: http://localhost:3001 (admin/admin)

### Добавить Datasource

1. Configuration → Data Sources → Add data source
2. Выберите Prometheus
3. URL: `http://localhost:9090`
4. Save & Test

### Создать Dashboard

**Панели:**
- HTTP Requests: `rate(http_requests_total[5m])`
- Response Time: `rate(http_request_duration_seconds_sum[5m]) / rate(http_request_duration_seconds_count[5m])`
- Active Bookings: `bookings_active`
- Revenue: `increase(payments_amount_rub{status="succeeded"}[1h])`

---

## Kubernetes

### Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-booking
spec:
  template:
    spec:
      containers:
      - name: backend
        image: ai-booking:latest
        livenessProbe:
          httpGet:
            path: /health/live
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 3000
          initialDelaySeconds: 10
          periodSeconds: 5
```

---

## Готово! 🎉

**Мониторинг работает!**

Подробнее: см. **MONITORING-LOGGING-GUIDE.md**
