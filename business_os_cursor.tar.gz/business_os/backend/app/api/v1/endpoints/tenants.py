"""Business OS - Tenants Endpoints"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db

router = APIRouter()

@router.get("/me")
async def get_current_tenant(db: AsyncSession = Depends(get_db)):
    """Get current tenant info"""
    # TODO: Implement
    return {"id": 1, "name": "Demo Salon", "status": "active"}

@router.patch("/me")
async def update_tenant(db: AsyncSession = Depends(get_db)):
    """Update tenant settings"""
    raise HTTPException(status_code=501, detail="Not implemented")

@router.get("/me/stats")
async def get_tenant_stats(db: AsyncSession = Depends(get_db)):
    """Get tenant statistics"""
    raise HTTPException(status_code=501, detail="Not implemented")
