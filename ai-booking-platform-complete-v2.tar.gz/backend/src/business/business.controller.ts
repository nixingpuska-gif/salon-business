import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { BusinessService } from './business.service';
import { CreateBusinessDto } from './dto/create-business.dto';
import { UpdateBusinessDto } from './dto/update-business.dto';

@Controller('businesses')
export class BusinessController {
  constructor(private readonly businessService: BusinessService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createBusinessDto: CreateBusinessDto) {
    return this.businessService.create(createBusinessDto);
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    return this.businessService.findOne(id);
  }

  @Get()
  async findByUser(@Query('userId') userId: string) {
    return this.businessService.findByUser(userId);
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() updateBusinessDto: UpdateBusinessDto,
  ) {
    return this.businessService.update(id, updateBusinessDto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  async delete(@Param('id') id: string) {
    await this.businessService.delete(id);
  }

  @Post(':id/users')
  @HttpCode(HttpStatus.CREATED)
  async addUser(
    @Param('id') id: string,
    @Body() body: { userId: string; role?: string },
  ) {
    await this.businessService.addUser(id, body.userId, body.role);
    return { message: 'User added successfully' };
  }

  @Delete(':id/users/:userId')
  @HttpCode(HttpStatus.NO_CONTENT)
  async removeUser(
    @Param('id') id: string,
    @Param('userId') userId: string,
  ) {
    await this.businessService.removeUser(id, userId);
  }
}
