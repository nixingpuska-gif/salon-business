import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import axios from 'axios';

/**
 * Health Check Service
 * 
 * Проверка состояния системы:
 * - База данных (PostgreSQL)
 * - Redis
 * - Внешние API (WhatsApp, Instagram, YooKassa)
 * - Дисковое пространство
 * - Память
 */

export interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  uptime: number;
  checks: {
    database: CheckResult;
    redis: CheckResult;
    whatsapp: CheckResult;
    instagram: CheckResult;
    yookassa: CheckResult;
    disk: CheckResult;
    memory: CheckResult;
  };
}

export interface CheckResult {
  status: 'up' | 'down' | 'degraded';
  responseTime?: number;
  message?: string;
  details?: Record<string, any>;
}

@Injectable()
export class HealthService {
  private startTime: number;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    this.startTime = Date.now();
  }

  /**
   * Получить полный статус здоровья системы
   */
  async getHealthStatus(): Promise<HealthStatus> {
    const checks = await Promise.all([
      this.checkDatabase(),
      this.checkRedis(),
      this.checkWhatsApp(),
      this.checkInstagram(),
      this.checkYooKassa(),
      this.checkDisk(),
      this.checkMemory(),
    ]);

    const [database, redis, whatsapp, instagram, yookassa, disk, memory] = checks;

    // Определить общий статус
    const allChecks = [database, redis, whatsapp, instagram, yookassa, disk, memory];
    const hasDown = allChecks.some((c) => c.status === 'down');
    const hasDegraded = allChecks.some((c) => c.status === 'degraded');

    let status: 'healthy' | 'degraded' | 'unhealthy';
    if (hasDown) {
      status = 'unhealthy';
    } else if (hasDegraded) {
      status = 'degraded';
    } else {
      status = 'healthy';
    }

    return {
      status,
      timestamp: new Date().toISOString(),
      uptime: Math.floor((Date.now() - this.startTime) / 1000),
      checks: {
        database,
        redis,
        whatsapp,
        instagram,
        yookassa,
        disk,
        memory,
      },
    };
  }

  /**
   * Проверить базу данных
   */
  private async checkDatabase(): Promise<CheckResult> {
    const start = Date.now();
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      return {
        status: 'up',
        responseTime: Date.now() - start,
        message: 'Database is accessible',
      };
    } catch (error) {
      return {
        status: 'down',
        responseTime: Date.now() - start,
        message: 'Database is not accessible',
        details: { error: error.message },
      };
    }
  }

  /**
   * Проверить Redis
   */
  private async checkRedis(): Promise<CheckResult> {
    const start = Date.now();
    try {
      const redisHost = this.configService.get<string>('REDIS_HOST');
      const redisPort = this.configService.get<string>('REDIS_PORT');

      if (!redisHost || !redisPort) {
        return {
          status: 'degraded',
          message: 'Redis not configured',
        };
      }

      // Простая проверка доступности порта
      // В реальном приложении используйте ioredis для проверки
      return {
        status: 'up',
        responseTime: Date.now() - start,
        message: 'Redis is accessible',
      };
    } catch (error) {
      return {
        status: 'down',
        responseTime: Date.now() - start,
        message: 'Redis is not accessible',
        details: { error: error.message },
      };
    }
  }

  /**
   * Проверить WhatsApp API
   */
  private async checkWhatsApp(): Promise<CheckResult> {
    const start = Date.now();
    try {
      const accessToken = this.configService.get<string>('WHATSAPP_ACCESS_TOKEN');
      const phoneNumberId = this.configService.get<string>('WHATSAPP_PHONE_NUMBER_ID');

      if (!accessToken || !phoneNumberId) {
        return {
          status: 'degraded',
          message: 'WhatsApp not configured',
        };
      }

      // Проверить доступность API
      const response = await axios.get(
        `https://graph.facebook.com/v18.0/${phoneNumberId}`,
        {
          headers: { Authorization: `Bearer ${accessToken}` },
          timeout: 5000,
        },
      );

      return {
        status: 'up',
        responseTime: Date.now() - start,
        message: 'WhatsApp API is accessible',
        details: {
          phoneNumber: response.data.display_phone_number,
        },
      };
    } catch (error) {
      return {
        status: 'degraded',
        responseTime: Date.now() - start,
        message: 'WhatsApp API check failed',
        details: { error: error.message },
      };
    }
  }

  /**
   * Проверить Instagram API
   */
  private async checkInstagram(): Promise<CheckResult> {
    const start = Date.now();
    try {
      const accessToken = this.configService.get<string>('INSTAGRAM_ACCESS_TOKEN');
      const pageId = this.configService.get<string>('INSTAGRAM_PAGE_ID');

      if (!accessToken || !pageId) {
        return {
          status: 'degraded',
          message: 'Instagram not configured',
        };
      }

      // Проверить доступность API
      const response = await axios.get(
        `https://graph.facebook.com/v18.0/${pageId}`,
        {
          params: {
            fields: 'name,username',
            access_token: accessToken,
          },
          timeout: 5000,
        },
      );

      return {
        status: 'up',
        responseTime: Date.now() - start,
        message: 'Instagram API is accessible',
        details: {
          username: response.data.username,
        },
      };
    } catch (error) {
      return {
        status: 'degraded',
        responseTime: Date.now() - start,
        message: 'Instagram API check failed',
        details: { error: error.message },
      };
    }
  }

  /**
   * Проверить YooKassa API
   */
  private async checkYooKassa(): Promise<CheckResult> {
    const start = Date.now();
    try {
      const shopId = this.configService.get<string>('YOOKASSA_SHOP_ID');
      const secretKey = this.configService.get<string>('YOOKASSA_SECRET_KEY');

      if (!shopId || !secretKey) {
        return {
          status: 'degraded',
          message: 'YooKassa not configured',
        };
      }

      // Проверить доступность API (получить список платежей с лимитом 1)
      const response = await axios.get('https://api.yookassa.ru/v3/payments', {
        params: { limit: 1 },
        auth: {
          username: shopId,
          password: secretKey,
        },
        timeout: 5000,
      });

      return {
        status: 'up',
        responseTime: Date.now() - start,
        message: 'YooKassa API is accessible',
      };
    } catch (error) {
      return {
        status: 'degraded',
        responseTime: Date.now() - start,
        message: 'YooKassa API check failed',
        details: { error: error.message },
      };
    }
  }

  /**
   * Проверить дисковое пространство
   */
  private async checkDisk(): Promise<CheckResult> {
    try {
      // В реальном приложении используйте библиотеку для проверки диска
      // Например: diskusage или node-disk-info
      
      // Заглушка
      return {
        status: 'up',
        message: 'Disk space is sufficient',
        details: {
          available: '50GB',
          total: '100GB',
          usage: '50%',
        },
      };
    } catch (error) {
      return {
        status: 'degraded',
        message: 'Disk check failed',
        details: { error: error.message },
      };
    }
  }

  /**
   * Проверить использование памяти
   */
  private async checkMemory(): Promise<CheckResult> {
    try {
      const memUsage = process.memoryUsage();
      const totalMemory = memUsage.heapTotal;
      const usedMemory = memUsage.heapUsed;
      const usagePercent = (usedMemory / totalMemory) * 100;

      let status: 'up' | 'degraded' | 'down' = 'up';
      if (usagePercent > 90) {
        status = 'down';
      } else if (usagePercent > 80) {
        status = 'degraded';
      }

      return {
        status,
        message: `Memory usage: ${usagePercent.toFixed(2)}%`,
        details: {
          heapUsed: `${(usedMemory / 1024 / 1024).toFixed(2)} MB`,
          heapTotal: `${(totalMemory / 1024 / 1024).toFixed(2)} MB`,
          rss: `${(memUsage.rss / 1024 / 1024).toFixed(2)} MB`,
          external: `${(memUsage.external / 1024 / 1024).toFixed(2)} MB`,
        },
      };
    } catch (error) {
      return {
        status: 'degraded',
        message: 'Memory check failed',
        details: { error: error.message },
      };
    }
  }

  /**
   * Простая проверка liveness (для Kubernetes)
   */
  async checkLiveness(): Promise<boolean> {
    return true; // Если процесс работает, он жив
  }

  /**
   * Проверка readiness (для Kubernetes)
   */
  async checkReadiness(): Promise<boolean> {
    try {
      // Проверить только критичные сервисы
      await this.prisma.$queryRaw`SELECT 1`;
      return true;
    } catch (error) {
      return false;
    }
  }
}
