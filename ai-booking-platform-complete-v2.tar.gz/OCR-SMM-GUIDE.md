# 📸 Руководство по OCR и SMM модулям

## Обзор

Два мощных модуля для автоматизации работы с изображениями и социальными сетями:

1. **OCR Module** - извлечение данных о записях из скриншотов и фотографий
2. **SMM Module** - автоматический постинг в Instagram и Facebook

---

## OCR Module

### Возможности

- ✅ Извлечение записей из скриншотов мессенджеров
- ✅ Распознавание рукописных заметок
- ✅ Автоматический импорт в систему
- ✅ Создание клиентов при импорте
- ✅ Сопоставление с существующими услугами
- ✅ Анализ типа изображения
- ✅ Извлечение текста (общий OCR)

### Технология

**OpenAI Vision API (GPT-4o)** - мультимодальная модель с возможностью анализа изображений.

### API Endpoints

#### POST /ocr/extract
Извлечь записи из изображения (без импорта)

**Request:**
```json
{
  "imageUrl": "https://example.com/screenshot.jpg",
  "businessId": "1"
}
```

**Response:**
```json
{
  "success": true,
  "count": 3,
  "data": [
    {
      "clientName": "Иван Иванов",
      "clientPhone": "+79991234567",
      "date": "2024-12-01",
      "time": "14:00",
      "serviceName": "Маникюр",
      "price": 1500,
      "notes": "Гель-лак красный"
    }
  ]
}
```

#### POST /ocr/import
Импортировать записи из изображения в систему

**Request:**
```json
{
  "imageUrl": "https://example.com/screenshot.jpg",
  "businessId": "1"
}
```

**Response:**
```json
{
  "success": true,
  "success": 3,
  "failed": 0,
  "errors": [],
  "imported": [
    {
      "id": 123,
      "clientId": "456",
      "serviceId": "789",
      "startTime": "2024-12-01T14:00:00.000Z",
      ...
    }
  ]
}
```

#### POST /ocr/analyze
Анализ изображения (определить тип)

**Request:**
```json
{
  "imageUrl": "https://example.com/image.jpg"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "type": "booking_screenshot",
    "description": "Скриншот из WhatsApp с записями клиентов",
    "hasBookings": true
  }
}
```

#### POST /ocr/text
Извлечь весь текст из изображения

**Request:**
```json
{
  "imageUrl": "https://example.com/image.jpg"
}
```

**Response:**
```json
{
  "success": true,
  "text": "Иван Иванов\n+79991234567\n1 декабря, 14:00\nМаникюр\n..."
}
```

---

## SMM Module

### Возможности

#### Публикация постов:
- ✅ Instagram (через Meta Graph API)
- ✅ Facebook (через Meta Graph API)
- ✅ Одновременная публикация в обе платформы
- ✅ Поддержка изображений
- ✅ История публикаций

#### Генерация контента:
- ✅ Автоматическое создание постов
- ✅ Генерация хэштегов
- ✅ Адаптация под платформу
- ✅ Разные тоны (professional, friendly, casual, luxury)
- ✅ Рекламные посты
- ✅ Посты "До и После"
- ✅ Улучшение существующего текста

#### Аналитика:
- ✅ Статистика Instagram (impressions, reach, engagement)
- ✅ Статистика Facebook (likes, comments, shares)
- ✅ История постов

### API Endpoints

#### POST /smm/post/instagram
Опубликовать пост в Instagram

**Request:**
```json
{
  "imageUrl": "https://example.com/photo.jpg",
  "caption": "Новая работа! 💅 #маникюр #красота",
  "businessId": "1"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "postId": "123456789",
    "platform": "instagram",
    "url": "https://www.instagram.com/p/123456789"
  }
}
```

#### POST /smm/post/facebook
Опубликовать пост в Facebook

**Request:**
```json
{
  "message": "Приглашаем на маникюр! 💅",
  "imageUrl": "https://example.com/photo.jpg",
  "businessId": "1"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "postId": "987654321",
    "platform": "facebook",
    "url": "https://www.facebook.com/987654321"
  }
}
```

#### POST /smm/post/both
Опубликовать в обе платформы

**Request:**
```json
{
  "imageUrl": "https://example.com/photo.jpg",
  "caption": "Короткий текст для Instagram 💅",
  "message": "Более подробный текст для Facebook с описанием услуги 💅",
  "businessId": "1"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "instagram": {
      "success": true,
      "postId": "123456789"
    },
    "facebook": {
      "success": true,
      "postId": "987654321"
    }
  }
}
```

#### POST /smm/generate/instagram
Сгенерировать пост для Instagram

**Request:**
```json
{
  "businessName": "Салон красоты Мария",
  "serviceName": "Маникюр",
  "description": "Классический маникюр с покрытием гель-лак",
  "tone": "friendly"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "caption": "Преобразим ваши ручки! 💅✨ Классический маникюр с гель-лаком ждёт вас! Записывайтесь прямо сейчас!",
    "hashtags": [
      "маникюр",
      "гельлак",
      "красота",
      "ногти",
      "салонкрасоты",
      ...
    ]
  }
}
```

#### POST /smm/generate/facebook
Сгенерировать пост для Facebook

**Request:**
```json
{
  "businessName": "Салон красоты Мария",
  "serviceName": "Маникюр",
  "tone": "professional"
}
```

**Response:**
```json
{
  "success": true,
  "text": "Профессиональный маникюр в салоне красоты Мария 💅\n\nМы используем качественные материалы и современные техники. Запишитесь на удобное время по телефону или в Direct."
}
```

#### POST /smm/generate/both
Сгенерировать для обеих платформ

**Request:**
```json
{
  "businessName": "Салон красоты Мария",
  "serviceName": "Маникюр",
  "tone": "friendly"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "instagram": {
      "caption": "Короткий текст для Instagram 💅",
      "hashtags": ["маникюр", "красота", ...]
    },
    "facebook": "Более подробный текст для Facebook 💅"
  }
}
```

#### POST /smm/generate/hashtags
Сгенерировать хэштеги

**Request:**
```json
{
  "serviceName": "Маникюр",
  "count": 15
}
```

**Response:**
```json
{
  "success": true,
  "data": [
    "маникюр",
    "гельлак",
    "ногти",
    "красота",
    "салонкрасоты",
    ...
  ]
}
```

#### POST /smm/generate/promo
Сгенерировать рекламный пост

**Request:**
```json
{
  "businessName": "Салон красоты Мария",
  "serviceName": "Маникюр",
  "discount": 20,
  "validUntil": "2024-12-31",
  "platform": "instagram"
}
```

**Response:**
```json
{
  "success": true,
  "text": "🔥 АКЦИЯ! Скидка 20% на маникюр до 31 декабря! ⏰ Успейте записаться! Количество мест ограничено! 💅✨"
}
```

#### POST /smm/improve
Улучшить текст поста

**Request:**
```json
{
  "text": "Делаем маникюр. Записывайтесь.",
  "platform": "instagram"
}
```

**Response:**
```json
{
  "success": true,
  "text": "Преобразим ваши ручки! 💅✨ Профессиональный маникюр с любовью к деталям. Записывайтесь прямо сейчас!"
}
```

#### GET /smm/history/:businessId
История постов

**Request:**
```
GET /smm/history/1?platform=instagram&limit=10&offset=0
```

**Response:**
```json
{
  "success": true,
  "count": 10,
  "data": [
    {
      "id": 1,
      "businessId": "1",
      "platform": "instagram",
      "postId": "123456789",
      "content": "Текст поста",
      "imageUrl": "https://...",
      "publishedAt": "2024-11-25T10:00:00.000Z"
    }
  ]
}
```

#### GET /smm/insights/instagram/:postId
Статистика Instagram поста

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "name": "impressions",
      "values": [{ "value": 1234 }]
    },
    {
      "name": "reach",
      "values": [{ "value": 987 }]
    },
    {
      "name": "engagement",
      "values": [{ "value": 156 }]
    }
  ]
}
```

#### GET /smm/insights/facebook/:postId
Статистика Facebook поста

**Response:**
```json
{
  "success": true,
  "data": {
    "likes": 45,
    "comments": 12,
    "shares": 8,
    "reactions": 52
  }
}
```

---

## Настройка

### Переменные окружения

Добавьте в `backend/.env`:

```env
# OpenAI (для OCR и генерации контента)
OPENAI_API_KEY=sk-...

# Instagram (для SMM)
INSTAGRAM_ACCESS_TOKEN=EAAGxxxxxx...
INSTAGRAM_ACCOUNT_ID=123456789

# Facebook (для SMM)
FACEBOOK_PAGE_ACCESS_TOKEN=EAAGxxxxxx...
FACEBOOK_PAGE_ID=987654321
```

### Получение учетных данных

#### OpenAI API Key
1. Откройте [platform.openai.com](https://platform.openai.com/)
2. **API keys** → **Create new secret key**
3. Скопируйте ключ

#### Instagram & Facebook
1. Откройте [developers.facebook.com](https://developers.facebook.com/)
2. Создайте приложение (Business)
3. Добавьте продукт **Instagram**
4. Получите **Access Token** и **Account ID**

---

## Примеры использования

### OCR: Импорт записей из скриншота

```typescript
// 1. Загрузите изображение на сервер или используйте URL
const imageUrl = 'https://example.com/screenshot.jpg';

// 2. Импортируйте записи
const result = await fetch('http://localhost:3000/ocr/import', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    imageUrl,
    businessId: '1',
  }),
});

const data = await result.json();
console.log(`Импортировано: ${data.success} записей`);
console.log(`Ошибок: ${data.failed}`);
```

### SMM: Автоматический постинг

```typescript
// 1. Сгенерировать контент
const content = await fetch('http://localhost:3000/smm/generate/both', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    businessName: 'Салон красоты Мария',
    serviceName: 'Маникюр',
    tone: 'friendly',
  }),
});

const { instagram, facebook } = (await content.json()).data;

// 2. Опубликовать
const result = await fetch('http://localhost:3000/smm/post/both', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    imageUrl: 'https://example.com/photo.jpg',
    caption: instagram.caption + '\n\n' + instagram.hashtags.join(' '),
    message: facebook,
    businessId: '1',
  }),
});

console.log('Опубликовано!', await result.json());
```

---

## Ограничения и рекомендации

### OCR Module

#### Поддерживаемые форматы:
- ✅ Скриншоты мессенджеров (WhatsApp, Telegram, Instagram)
- ✅ Фотографии записных книжек
- ✅ Календари и расписания
- ⚠️ Качество изображения влияет на точность

#### Рекомендации:
- Используйте чёткие изображения
- Убедитесь, что текст читаем
- Для рукописных заметок используйте разборчивый почерк
- Проверяйте результаты перед импортом

### SMM Module

#### Instagram ограничения:
- ⚠️ Требуется Business Account
- ⚠️ Изображение должно быть доступно по HTTPS URL
- ⚠️ Соотношение сторон: 1:1, 4:5, 1.91:1
- ⚠️ Минимум 320px, максимум 1080px

#### Facebook ограничения:
- ⚠️ Требуется Page Access Token
- ⚠️ Изображение должно быть доступно по URL
- ⚠️ Рекомендуемый размер: 1200x630px

#### Рекомендации по контенту:
- Instagram: 100-150 символов + хэштеги
- Facebook: 150-250 символов
- Используйте эмодзи для привлекательности
- Добавляйте призыв к действию
- Тестируйте разные тоны (tone)

---

## Стоимость использования

### OpenAI API (GPT-4o)

#### OCR (Vision):
- **Цена**: ~$0.01 за изображение
- **Лимит**: 100 запросов/минуту

#### Генерация контента:
- **Цена**: ~$0.001 за пост
- **Лимит**: 10,000 запросов/минуту

### Meta Graph API

- **Бесплатно** для стандартного использования
- Ограничения: 200 запросов/час (стандартные аккаунты)

---

## Решение проблем

### OCR не работает

**Ошибка**: "OpenAI API key not configured"
- Проверьте `OPENAI_API_KEY` в `.env`
- Убедитесь, что ключ активен

**Ошибка**: "No JSON found in response"
- Изображение не содержит записей
- Попробуйте другое изображение

**Ошибка**: "Service not found"
- Услуга из изображения не найдена в БД
- Создайте услугу вручную

### SMM не работает

**Ошибка**: "Instagram credentials not configured"
- Проверьте `INSTAGRAM_ACCESS_TOKEN` и `INSTAGRAM_ACCOUNT_ID`
- Убедитесь, что токен не истёк

**Ошибка**: "Invalid OAuth access token"
- Токен истёк — создайте новый
- Проверьте разрешения: `instagram_basic`, `instagram_content_publish`

**Ошибка**: "Image URL not accessible"
- Изображение должно быть доступно по HTTPS
- Проверьте, что URL открывается в браузере

---

## Будущие улучшения

### OCR Module
- [ ] Поддержка PDF файлов
- [ ] Пакетная обработка изображений
- [ ] Распознавание таблиц
- [ ] Извлечение контактов
- [ ] Автоматическое создание услуг

### SMM Module
- [ ] Планирование постов (отложенная публикация)
- [ ] Автоматический постинг по расписанию
- [ ] Генерация изображений (DALL-E)
- [ ] Stories для Instagram
- [ ] Reels для Instagram
- [ ] Carousel posts
- [ ] A/B тестирование контента

---

## Полезные ссылки

- [OpenAI Vision API](https://platform.openai.com/docs/guides/vision)
- [Instagram Graph API](https://developers.facebook.com/docs/instagram-api/)
- [Facebook Graph API](https://developers.facebook.com/docs/graph-api/)

**Готово!** 🎉 OCR и SMM модули полностью интегрированы.
