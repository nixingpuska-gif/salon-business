import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Schedule } from '@prisma/client';
import { 
  addMinutes, 
  format, 
  startOfDay, 
  endOfDay, 
  isWithinInterval,
  parseISO,
  setHours,
  setMinutes,
} from 'date-fns';

export interface TimeSlot {
  id: string;
  startTime: Date;
  endTime: Date;
  available: boolean;
}

@Injectable()
export class ScheduleService {
  constructor(private prisma: PrismaService) {}

  /**
   * Generate available time slots for a given date and service
   */
  async generateSlots(
    businessId: string,
    date: Date,
    serviceDurationMinutes: number,
    slotIntervalMinutes: number = 30,
  ): Promise<TimeSlot[]> {
    // 1. Get working hours for this date
    const dayOfWeek = date.getDay() === 0 ? 7 : date.getDay(); // ISO: Mon=1, Sun=7
    
    const workingHours = await this.prisma.schedule.findFirst({
      where: {
        businessId,
        type: 'working_hours',
        daysOfWeek: { has: dayOfWeek },
        startDate: { lte: date },
        OR: [
          { endDate: null },
          { endDate: { gte: date } },
        ],
      },
    });

    if (!workingHours || !workingHours.startTime || !workingHours.endTime) {
      return []; // No working hours configured
    }

    // 2. Parse working hours
    const startHour = new Date(workingHours.startTime).getHours();
    const startMinute = new Date(workingHours.startTime).getMinutes();
    const endHour = new Date(workingHours.endTime).getHours();
    const endMinute = new Date(workingHours.endTime).getMinutes();

    let dayStart = setHours(setMinutes(new Date(date), startMinute), startHour);
    let dayEnd = setHours(setMinutes(new Date(date), endMinute), endHour);

    // 3. Generate all possible slots
    const slots: TimeSlot[] = [];
    let currentSlotStart = dayStart;

    while (currentSlotStart < dayEnd) {
      const slotEnd = addMinutes(currentSlotStart, serviceDurationMinutes);
      
      if (slotEnd <= dayEnd) {
        slots.push({
          id: `slot_${format(currentSlotStart, 'HHmm')}`,
          startTime: new Date(currentSlotStart),
          endTime: slotEnd,
          available: true, // Will check bookings next
        });
      }

      currentSlotStart = addMinutes(currentSlotStart, slotIntervalMinutes);
    }

    // 4. Get existing bookings for this day
    const bookings = await this.prisma.booking.findMany({
      where: {
        businessId,
        startTime: { gte: startOfDay(date) },
        endTime: { lte: endOfDay(date) },
        status: { in: ['confirmed', 'pending'] },
      },
    });

    // 5. Mark slots as unavailable if they overlap with bookings
    slots.forEach((slot) => {
      const hasConflict = bookings.some((booking) => {
        // Check if slot overlaps with booking
        return (
          (slot.startTime >= booking.startTime && slot.startTime < booking.endTime) ||
          (slot.endTime > booking.startTime && slot.endTime <= booking.endTime) ||
          (slot.startTime <= booking.startTime && slot.endTime >= booking.endTime)
        );
      });
      
      if (hasConflict) {
        slot.available = false;
      }
    });

    // 6. Filter out breaks/vacations
    const breaks = await this.prisma.schedule.findMany({
      where: {
        businessId,
        type: { in: ['break', 'vacation', 'holiday'] },
        startDate: { lte: date },
        OR: [
          { endDate: null },
          { endDate: { gte: date } },
        ],
      },
    });

    breaks.forEach((breakPeriod) => {
      if (breakPeriod.startTime && breakPeriod.endTime) {
        const breakStart = setHours(
          setMinutes(new Date(date), new Date(breakPeriod.startTime).getMinutes()),
          new Date(breakPeriod.startTime).getHours(),
        );
        const breakEnd = setHours(
          setMinutes(new Date(date), new Date(breakPeriod.endTime).getMinutes()),
          new Date(breakPeriod.endTime).getHours(),
        );

        slots.forEach((slot) => {
          if (
            (slot.startTime >= breakStart && slot.startTime < breakEnd) ||
            (slot.endTime > breakStart && slot.endTime <= breakEnd) ||
            (slot.startTime <= breakStart && slot.endTime >= breakEnd)
          ) {
            slot.available = false;
          }
        });
      }
    });

    return slots.filter((slot) => slot.available);
  }

  /**
   * Create working hours schedule
   */
  async createWorkingHours(businessId: string, data: {
    daysOfWeek: number[];
    startTime: string; // "09:00"
    endTime: string;   // "18:00"
    startDate?: Date;
    endDate?: Date;
  }): Promise<Schedule> {
    const [startHour, startMin] = data.startTime.split(':').map(Number);
    const [endHour, endMin] = data.endTime.split(':').map(Number);

    const startTime = setHours(setMinutes(new Date(), startMin), startHour);
    const endTime = setHours(setMinutes(new Date(), endMin), endHour);

    return this.prisma.schedule.create({
      data: {
        businessId,
        type: 'working_hours',
        daysOfWeek: data.daysOfWeek,
        startDate: data.startDate || new Date(),
        endDate: data.endDate,
        startTime,
        endTime,
        recurrenceRule: 'FREQ=WEEKLY',
      },
    });
  }

  /**
   * Create break schedule
   */
  async createBreak(businessId: string, data: {
    daysOfWeek: number[];
    startTime: string;
    endTime: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<Schedule> {
    const [startHour, startMin] = data.startTime.split(':').map(Number);
    const [endHour, endMin] = data.endTime.split(':').map(Number);

    const startTime = setHours(setMinutes(new Date(), startMin), startHour);
    const endTime = setHours(setMinutes(new Date(), endMin), endHour);

    return this.prisma.schedule.create({
      data: {
        businessId,
        type: 'break',
        daysOfWeek: data.daysOfWeek,
        startDate: data.startDate || new Date(),
        endDate: data.endDate,
        startTime,
        endTime,
        recurrenceRule: 'FREQ=WEEKLY',
      },
    });
  }

  /**
   * Create vacation/holiday
   */
  async createVacation(businessId: string, data: {
    startDate: Date;
    endDate: Date;
    type?: 'vacation' | 'holiday';
  }): Promise<Schedule> {
    return this.prisma.schedule.create({
      data: {
        businessId,
        type: data.type || 'vacation',
        startDate: data.startDate,
        endDate: data.endDate,
      },
    });
  }

  /**
   * Find schedule by ID
   */
  async findOne(id: string): Promise<Schedule> {
    const schedule = await this.prisma.schedule.findUnique({
      where: { id },
    });

    if (!schedule) {
      throw new NotFoundException(`Schedule with ID ${id} not found`);
    }

    return schedule;
  }

  /**
   * Find all schedules for a business
   */
  async findByBusiness(businessId: string, type?: string): Promise<Schedule[]> {
    return this.prisma.schedule.findMany({
      where: {
        businessId,
        ...(type && { type }),
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Update schedule
   */
  async update(id: string, data: Partial<{
    daysOfWeek: number[];
    startTime: Date;
    endTime: Date;
    startDate: Date;
    endDate: Date;
  }>): Promise<Schedule> {
    const schedule = await this.findOne(id);

    return this.prisma.schedule.update({
      where: { id: schedule.id },
      data,
    });
  }

  /**
   * Delete schedule
   */
  async delete(id: string): Promise<Schedule> {
    const schedule = await this.findOne(id);

    return this.prisma.schedule.delete({
      where: { id: schedule.id },
    });
  }
}
