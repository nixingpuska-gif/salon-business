import { Controller, Post, Get, Body, Query, Res, HttpStatus, Logger } from '@nestjs/common';
import { Response } from 'express';
import { InstagramService } from './instagram.service';

@Controller('webhooks/instagram')
export class InstagramController {
  private readonly logger = new Logger(InstagramController.name);

  constructor(private readonly instagramService: InstagramService) {}

  /**
   * GET /webhooks/instagram - Верификация webhook от Instagram/Facebook
   */
  @Get()
  verifyWebhook(
    @Query('hub.mode') mode: string,
    @Query('hub.verify_token') token: string,
    @Query('hub.challenge') challenge: string,
    @Res() res: Response,
  ) {
    this.logger.log('Instagram webhook verification request received');
    
    const result = this.instagramService.verifyWebhook(mode, token, challenge);
    
    if (result) {
      return res.status(HttpStatus.OK).send(result);
    }
    
    return res.status(HttpStatus.FORBIDDEN).send('Verification failed');
  }

  /**
   * POST /webhooks/instagram - Получение сообщений от Instagram
   */
  @Post()
  async handleWebhook(@Body() body: any, @Res() res: Response) {
    this.logger.log('Webhook received from Instagram');
    
    // Instagram требует быстрого ответа 200 OK
    res.status(HttpStatus.OK).send('EVENT_RECEIVED');
    
    try {
      // Обрабатываем сообщение асинхронно
      await this.instagramService.handleIncomingMessage(body);
    } catch (error) {
      this.logger.error('Error processing Instagram webhook:', error);
    }
  }
}
