"""Business OS - Messages Endpoints"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db

router = APIRouter()

@router.get("")
async def list_messages(db: AsyncSession = Depends(get_db)):
    return {"items": [], "total": 0}

@router.post("")
async def send_message(db: AsyncSession = Depends(get_db)):
    raise HTTPException(status_code=501, detail="Not implemented")

@router.get("/templates")
async def list_templates(db: AsyncSession = Depends(get_db)):
    return {"items": [], "total": 0}

@router.get("/conversations")
async def list_conversations(db: AsyncSession = Depends(get_db)):
    return {"items": [], "total": 0}
