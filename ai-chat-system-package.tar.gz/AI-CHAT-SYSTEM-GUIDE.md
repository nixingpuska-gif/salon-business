# 🤖 AI Chat System - Полное руководство

## Обзор

AI Chat System — это интеллектуальная система чат-ботов с двумя режимами:

1. **Admin Chat Bot** — для владельцев бизнеса (запрос статистики, настройка ботов)
2. **Client Chat Bot** — для клиентов (запись, перенос, отмена, вопросы)

### Ключевые возможности

✅ **Память контекста** — бот запоминает информацию о клиенте  
✅ **Кастомизация сценариев** — владельцы настраивают промпты и тон общения (Pro уровень)  
✅ **Не спрашивает дважды** — уже известная информация не запрашивается повторно  
✅ **Function calling** — AI вызывает функции для выполнения действий  
✅ **История диалогов** — сохранение всех разговоров  
✅ **Аудит** — логирование всех действий  

---

## Архитектура

### Модули

```
backend/src/ai-chat/
├── conversation-context.service.ts  # Управление контекстом и памятью
├── scenario.service.ts              # Управление сценариями
├── admin-chat.service.ts            # Админ-бот
├── client-chat.service.ts           # Клиентский бот
├── ai-chat.controller.ts            # API endpoints
└── ai-chat.module.ts                # NestJS модуль
```

### Сервисы

#### 1. ConversationContextService
Управление контекстом диалогов и памятью клиентов.

**Функции:**
- Создание и получение контекста диалога
- Добавление сообщений в историю
- Извлечение и сохранение данных клиента
- Связывание диалога с клиентом
- Получение истории диалогов
- Статистика диалогов

#### 2. ScenarioService
Управление сценариями для клиентского бота.

**Функции:**
- Создание, обновление, удаление сценариев
- Активация сценария
- Получение системного промпта с контекстом
- Проверка обязательных полей
- Форматирование сообщений

#### 3. AdminChatService
AI-бот для владельцев бизнеса.

**Функции:**
- Запрос статистики (записи, клиенты, доход)
- Просмотр записей и клиентов
- Настройка сценариев клиентского бота
- Управление услугами
- Рекомендации по улучшению бизнеса

#### 4. ClientChatService
AI-бот для клиентов.

**Функции:**
- Помощь с записью
- Просмотр своих записей
- Перенос и отмена записей
- Ответы на вопросы
- Запоминание информации о клиенте

---

## API Endpoints

### Admin Chat

#### POST `/ai-chat/admin/message`
Отправить сообщение в админ-чат.

**Request:**
```json
{
  "businessId": "business-id",
  "userId": "user-id",
  "message": "Покажи статистику за неделю",
  "channel": "telegram",
  "channelUserId": "123456789"
}
```

**Response:**
```json
{
  "reply": "За последнюю неделю:\n- Записей: 45\n- Новых клиентов: 12\n- Доход: 67,500 ₽"
}
```

---

### Client Chat

#### POST `/ai-chat/client/message`
Отправить сообщение в клиентский чат.

**Request:**
```json
{
  "businessId": "business-id",
  "message": "Хочу записаться на маникюр",
  "channel": "whatsapp",
  "channelUserId": "+79991234567"
}
```

**Response:**
```json
{
  "reply": "Отлично! На какую дату вы хотите записаться?"
}
```

---

### Scenarios (Сценарии)

#### GET `/ai-chat/scenarios/:businessId`
Получить все сценарии бизнеса.

**Response:**
```json
[
  {
    "id": "scenario-id",
    "name": "Дружелюбный стиль",
    "tone": "friendly",
    "isActive": true,
    "systemPrompt": "Вы — дружелюбный AI-помощник...",
    "welcomeMessage": "Привет! 👋 Рада помочь!",
    "requiredFields": [
      {
        "field": "name",
        "question": "Как тебя зовут?",
        "order": 1
      }
    ]
  }
]
```

#### GET `/ai-chat/scenarios/:businessId/active`
Получить активный сценарий.

#### POST `/ai-chat/scenarios/:businessId`
Создать новый сценарий.

**Request:**
```json
{
  "name": "Формальный стиль",
  "description": "Для премиум-клиентов",
  "isActive": false,
  "systemPrompt": "Вы — профессиональный администратор...",
  "tone": "formal",
  "welcomeMessage": "Добрый день! Чем могу помочь?",
  "bookingConfirmationTemplate": "Ваша запись подтверждена...",
  "errorMessage": "Приношу извинения...",
  "requiredFields": [
    {
      "field": "name",
      "question": "Как Вас зовут?",
      "order": 1
    },
    {
      "field": "phone",
      "question": "Укажите номер телефона",
      "validation": "phone",
      "order": 2
    }
  ],
  "faq": [
    {
      "question": "Где вы находитесь?",
      "answer": "Мы находимся по адресу: {business.address}"
    }
  ],
  "settings": {
    "askForFeedback": true,
    "sendReminders": true,
    "allowRescheduling": true,
    "allowCancellation": true,
    "maxReschedulesPerBooking": 2
  }
}
```

#### PUT `/ai-chat/scenarios/:businessId/:scenarioId`
Обновить сценарий.

#### DELETE `/ai-chat/scenarios/:businessId/:scenarioId`
Удалить сценарий.

#### POST `/ai-chat/scenarios/:businessId/:scenarioId/activate`
Активировать сценарий.

#### POST `/ai-chat/scenarios/:businessId/default`
Создать сценарий по умолчанию.

**Request:**
```json
{
  "template": "friendly"
}
```

Доступные шаблоны: `formal`, `friendly`, `professional`

---

### Conversations (Диалоги)

#### GET `/ai-chat/conversations/:businessId/stats`
Получить статистику диалогов.

**Response:**
```json
{
  "total": 150,
  "active": 12,
  "completed": 138,
  "averageMessagesPerConversation": 8.5
}
```

#### GET `/ai-chat/conversations/:businessId/client/:clientId/history`
Получить историю диалогов клиента.

**Query params:**
- `limit` (optional) — количество диалогов (default: 10)

---

### Memory (Память клиента)

#### GET `/ai-chat/memory/:businessId/client/:clientId`
Получить память клиента.

**Response:**
```json
{
  "clientId": "client-id",
  "businessId": "business-id",
  "name": "Анна",
  "phone": "+79991234567",
  "email": "anna@example.com",
  "preferredServices": ["Маникюр", "Педикюр"],
  "preferredTime": "18:00",
  "totalBookings": 5,
  "lastBookingDate": "2024-11-20T15:00:00.000Z",
  "firstContactDate": "2024-10-01T10:00:00.000Z",
  "lastContactDate": "2024-11-20T15:30:00.000Z"
}
```

#### PUT `/ai-chat/memory/:businessId/client/:clientId`
Обновить память клиента.

**Request:**
```json
{
  "preferredServices": ["Маникюр", "Педикюр", "Массаж"],
  "preferredTime": "19:00",
  "notes": "Предпочитает мастера Марию"
}
```

#### POST `/ai-chat/conversations/:conversationId/complete`
Завершить диалог.

---

## Сценарии (Scenarios)

### Структура сценария

```typescript
{
  id: string;
  businessId: string;
  name: string;
  description?: string;
  isActive: boolean;
  
  // Системный промпт для AI
  systemPrompt: string;
  
  // Тон общения
  tone: 'formal' | 'friendly' | 'professional' | 'casual';
  
  // Обязательные поля для сбора
  requiredFields: Array<{
    field: 'name' | 'phone' | 'email' | 'custom';
    customFieldName?: string;
    question: string;
    validation?: string;
    order: number;
  }>;
  
  // Приветственное сообщение
  welcomeMessage: string;
  
  // Сообщение при завершении записи
  bookingConfirmationTemplate: string;
  
  // Сообщение при ошибке
  errorMessage: string;
  
  // Часто задаваемые вопросы
  faq: Array<{
    question: string;
    answer: string;
  }>;
  
  // Дополнительные настройки
  settings: {
    askForFeedback: boolean;
    sendReminders: boolean;
    allowRescheduling: boolean;
    allowCancellation: boolean;
    maxReschedulesPerBooking: number;
  };
}
```

### Шаблоны по умолчанию

#### 1. Formal (Формальный)
```
Тон: Вежливый, на "Вы", деловой
Приветствие: "Добрый день! Я администратор салона. Чем могу Вам помочь?"
Использование: Премиум-салоны, медицинские центры
```

#### 2. Friendly (Дружелюбный)
```
Тон: Тёплый, дружеский, с эмодзи
Приветствие: "Привет! 👋 Рада помочь с записью! Что тебя интересует?"
Использование: Молодёжные салоны, студии
```

#### 3. Professional (Профессиональный)
```
Тон: Профессиональный, но тёплый
Приветствие: "Здравствуйте! Я помогу Вам с записью. Какая услуга Вас интересует?"
Использование: Универсальный вариант
```

---

## Память контекста

### Что запоминается

**О клиенте:**
- Имя
- Телефон
- Email
- Предпочитаемые услуги
- Предпочитаемое время
- Предпочитаемый мастер
- История записей
- Средний чек
- Заметки

**О диалоге:**
- История сообщений (последние 20)
- Текущий intent (намерение)
- Текущий шаг диалога
- Извлечённые данные
- Метаданные

### Как работает память

1. **Первый контакт:**
   - Бот собирает базовую информацию (имя, телефон)
   - Сохраняет в контекст диалога
   - Создаёт клиента в БД

2. **Повторный контакт:**
   - Бот узнаёт клиента по channel ID или телефону
   - Загружает память клиента
   - Персонализирует общение
   - НЕ спрашивает уже известную информацию

3. **Обновление памяти:**
   - После каждого диалога обновляются предпочтения
   - Сохраняется история
   - Обновляется статистика

---

## Function Calling

### Admin Functions

1. **get_statistics** — статистика бизнеса
2. **get_bookings** — список записей
3. **get_clients** — список клиентов
4. **get_scenario_settings** — настройки сценария
5. **update_scenario** — обновить сценарий
6. **get_services** — список услуг
7. **create_service** — создать услугу

### Client Functions

1. **get_available_services** — доступные услуги
2. **get_available_slots** — свободные слоты
3. **create_booking** — создать запись
4. **get_my_bookings** — мои записи
5. **cancel_booking** — отменить запись
6. **reschedule_booking** — перенести запись

---

## Примеры использования

### Пример 1: Админ запрашивает статистику

**Админ:** "Покажи статистику за месяц"

**AI вызывает:**
```json
{
  "function": "get_statistics",
  "arguments": {
    "period": "month",
    "metrics": ["bookings", "clients", "revenue"]
  }
}
```

**Ответ AI:**
"За последний месяц:
- Записей: 180
- Новых клиентов: 45
- Доход: 270,000 ₽

Отличные результаты! Рост на 15% по сравнению с прошлым месяцем."

---

### Пример 2: Клиент записывается впервые

**Клиент:** "Хочу записаться на маникюр"

**AI:** "Отлично! Как Вас зовут?"

**Клиент:** "Анна"

**AI:** "Приятно познакомиться, Анна! Укажите номер телефона для связи"

**Клиент:** "+79991234567"

**AI вызывает:** `get_available_services`

**AI:** "На какую дату вы хотите записаться?"

**Клиент:** "На завтра в 18:00"

**AI вызывает:** `get_available_slots` → `create_booking`

**AI:** "Отлично! 🎉 Вы записаны на 26 ноября в 18:00. Маникюр — будет супер! Жду вас: ул. Пушкина, д. 10 ✨"

---

### Пример 3: Клиент записывается повторно

**Клиент:** "Хочу записаться"

**AI:** "Привет, Анна! 👋 Рада снова тебя видеть! На маникюр, как обычно?"

*(Бот узнал клиента и помнит её предпочтения)*

**Клиент:** "Да, на пятницу"

**AI:** "В 18:00, как ты любишь?"

**Клиент:** "Да"

**AI вызывает:** `create_booking`

**AI:** "Готово! Записала тебя на 29 ноября в 18:00. До встречи! 💅"

---

### Пример 4: Админ настраивает сценарий

**Админ:** "Измени тон бота на более формальный"

**AI вызывает:**
```json
{
  "function": "update_scenario",
  "arguments": {
    "tone": "formal",
    "systemPrompt": "Вы — профессиональный администратор салона красоты. Общайтесь вежливо на \"Вы\", используйте деловой тон...",
    "welcomeMessage": "Добрый день! Чем могу Вам помочь?"
  }
}
```

**AI:** "Готово! Я изменил тон общения клиентского бота на формальный. Теперь бот будет обращаться к клиентам на \"Вы\" и использовать деловой стиль."

---

## Интеграция с каналами

### WhatsApp

```typescript
// В WhatsAppService
async handleMessage(from: string, message: string, businessId: string) {
  const reply = await this.clientChatService.processMessage(
    businessId,
    message,
    'whatsapp',
    from,
  );
  
  await this.sendMessage(from, reply);
}
```

### Instagram

```typescript
// В InstagramService
async handleMessage(senderId: string, message: string, businessId: string) {
  const reply = await this.clientChatService.processMessage(
    businessId,
    message,
    'instagram',
    senderId,
  );
  
  await this.sendMessage(senderId, reply);
}
```

### Telegram

```typescript
// В TelegramService
async handleMessage(chatId: number, message: string, businessId: string) {
  const reply = await this.clientChatService.processMessage(
    businessId,
    message,
    'telegram',
    chatId.toString(),
  );
  
  await this.sendMessage(chatId, reply);
}
```

---

## Настройка

### Environment Variables

```env
# OpenAI API
OPENAI_API_KEY=sk-...

# Database
DATABASE_URL=postgresql://...

# Redis (для кэша контекста)
REDIS_HOST=localhost
REDIS_PORT=6379
```

### Создание первого сценария

```bash
curl -X POST http://localhost:3000/ai-chat/scenarios/business-id/default \
  -H "Content-Type: application/json" \
  -d '{"template": "friendly"}'
```

---

## Мониторинг

### Метрики

- `ai_chat_messages_total` — всего сообщений
- `ai_chat_conversations_active` — активных диалогов
- `ai_chat_function_calls_total` — вызовов функций
- `ai_chat_response_time` — время ответа AI

### Логи

```typescript
// Все действия логируются
this.logger.log('Client function call: create_booking', undefined, {
  businessId,
  clientId,
  serviceId,
});
```

---

## Стоимость

### OpenAI API (GPT-4 Turbo)

- **Input:** $0.01 / 1K tokens
- **Output:** $0.03 / 1K tokens

**Средний диалог:**
- ~500 tokens input
- ~200 tokens output
- **Стоимость:** ~$0.011 за диалог

**1000 диалогов/месяц:** ~$11

---

## Best Practices

### 1. Оптимизация промптов
- Делайте промпты конкретными и краткими
- Добавляйте примеры желаемого поведения
- Используйте структурированные инструкции

### 2. Управление контекстом
- Ограничивайте историю сообщений (20 последних)
- Очищайте завершённые диалоги
- Кэшируйте часто используемые данные

### 3. Обработка ошибок
- Всегда возвращайте понятное сообщение об ошибке
- Логируйте все ошибки для анализа
- Используйте fallback сценарии

### 4. Персонализация
- Используйте имя клиента
- Учитывайте историю взаимодействий
- Адаптируйте тон под клиента

---

## Troubleshooting

### Проблема: Бот не запоминает клиента

**Решение:**
1. Проверьте, что `clientId` связан с диалогом
2. Убедитесь, что `channelIds` в БД корректны
3. Проверьте логи `findOrCreateClient`

### Проблема: Бот спрашивает уже известную информацию

**Решение:**
1. Проверьте, что память клиента загружается
2. Убедитесь, что `extractedData` обновляется
3. Проверьте системный промпт

### Проблема: Function calling не работает

**Решение:**
1. Проверьте формат функций (должен быть JSON Schema)
2. Убедитесь, что `function_call: 'auto'`
3. Проверьте логи OpenAI API

---

## Roadmap

### Планируется

- [ ] Голосовые сообщения (Speech-to-Text)
- [ ] Мультиязычность
- [ ] A/B тестирование сценариев
- [ ] Sentiment analysis
- [ ] Автоматическая оптимизация промптов
- [ ] Интеграция с CRM
- [ ] Webhooks для событий

---

## Заключение

AI Chat System — это мощная система для автоматизации общения с клиентами и управления бизнесом через AI.

**Преимущества:**
- ✅ Экономия времени владельца
- ✅ 24/7 доступность для клиентов
- ✅ Персонализированное общение
- ✅ Автоматизация рутинных задач
- ✅ Масштабируемость

**Готово к production! 🚀**
