import { IsArray, IsString, IsNotEmpty, IsOptional, IsDateString } from 'class-validator';

export class CreateBreakDto {
  @IsString()
  @IsNotEmpty()
  businessId: string;

  @IsArray()
  daysOfWeek: number[];

  @IsString()
  @IsNotEmpty()
  startTime: string;

  @IsString()
  @IsNotEmpty()
  endTime: string;

  @IsDateString()
  @IsOptional()
  startDate?: string;

  @IsDateString()
  @IsOptional()
  endDate?: string;
}
