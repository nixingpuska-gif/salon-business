"""
Business OS - Synchronous Demo Data Seeder
Создание демо-данных для тестирования платформы
"""

import sqlite3
from datetime import datetime, timedelta
import random
import bcrypt
import json

DB_PATH = "business_os.db"

def get_password_hash(password: str) -> str:
    """Hash password using sha256 (compatible with security.py)"""
    import hashlib
    return hashlib.sha256(password.encode()).hexdigest()

def seed_demo_data():
    """Заполнение базы демо-данными"""
    
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    
    print("🚀 Starting demo data seeding...")
    
    now = datetime.utcnow()
    now_str = now.isoformat()
    expires_str = (now + timedelta(days=365)).isoformat()
    
    # 1. Create Demo Tenant
    print("📦 Creating demo tenant...")
    cur.execute("""
        INSERT INTO tenants (
            name, slug, email, phone, subscription_status, subscription_plan,
            subscription_expires_at, created_at, updated_at, is_deleted, settings, onboarding_data
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        "Салон красоты 'Гламур'", "glamour-demo", "demo@business-os.ru", "+79001234567",
        "ACTIVE", "business", expires_str, now_str, now_str, 0, "{}", "{}"
    ))
    tenant_id = cur.lastrowid
    print(f"   Created tenant ID: {tenant_id}")
    
    # 2. Create Demo User (Owner)
    print("👤 Creating demo user...")
    password_hash = get_password_hash("demo123456")
    cur.execute("""
        INSERT INTO users (
            email, phone, password_hash, first_name, last_name, role,
            is_active, is_verified, owned_tenant_id, created_at, updated_at, is_deleted, failed_login_attempts
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        "demo@business-os.ru", "+79001234567", password_hash, "Демо", "Пользователь",
        "owner", 1, 1, tenant_id, now_str, now_str, 0, 0
    ))
    user_id = cur.lastrowid
    print(f"   Created user ID: {user_id}")
    
    
    # 3. Create Demo Branch
    print("🏢 Creating demo branch...")
    working_hours = json.dumps({
        "monday": {"open": "09:00", "close": "21:00"},
        "tuesday": {"open": "09:00", "close": "21:00"},
        "wednesday": {"open": "09:00", "close": "21:00"},
        "thursday": {"open": "09:00", "close": "21:00"},
        "friday": {"open": "09:00", "close": "21:00"},
        "saturday": {"open": "10:00", "close": "20:00"},
        "sunday": {"open": "10:00", "close": "18:00"},
    })
    cur.execute("""
        INSERT INTO branches (
            tenant_id, name, address, phone, email, is_main, is_active,
            working_hours, created_at, updated_at, is_deleted
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        tenant_id, "Основной филиал", "г. Москва, ул. Тверская, д. 1",
        "+79001234567", "main@glamour.ru", 1, 1, working_hours, now_str, now_str, 0
    ))
    branch_id = cur.lastrowid
    print(f"   Created branch ID: {branch_id}")
    
    # 4. Create Service Categories
    print("📂 Creating service categories...")
    categories_data = [
        ("Парикмахерские услуги", "✂️", 1),
        ("Ногтевой сервис", "💅", 2),
        ("Косметология", "✨", 3),
        ("Массаж и SPA", "🧖", 4),
    ]
    
    category_ids = []
    for name, icon, sort_order in categories_data:
        cur.execute("""
            INSERT INTO service_categories (
                tenant_id, name, icon, sort_order, is_active, created_at, updated_at, is_deleted
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (tenant_id, name, icon, sort_order, 1, now_str, now_str, 0))
        category_ids.append(cur.lastrowid)
    print(f"   Created {len(category_ids)} categories")
    
    # 5. Create Services
    print("💇 Creating services...")
    services_data = [
        # Парикмахерские (category 0)
        (category_ids[0], "Женская стрижка", 2500, 60, 1),
        (category_ids[0], "Мужская стрижка", 1500, 45, 0),
        (category_ids[0], "Окрашивание волос", 5000, 120, 1),
        (category_ids[0], "Укладка", 1800, 45, 0),
        (category_ids[0], "Мелирование", 4500, 150, 0),
        # Ногтевой сервис (category 1)
        (category_ids[1], "Маникюр классический", 1200, 60, 0),
        (category_ids[1], "Маникюр с покрытием гель-лак", 2200, 90, 1),
        (category_ids[1], "Педикюр классический", 1800, 75, 0),
        (category_ids[1], "Педикюр с покрытием", 2800, 105, 0),
        (category_ids[1], "Наращивание ногтей", 4000, 180, 0),
        # Косметология (category 2)
        (category_ids[2], "Чистка лица", 3500, 90, 1),
        (category_ids[2], "Пилинг", 2500, 60, 0),
        (category_ids[2], "Уход за лицом", 4000, 75, 0),
        (category_ids[2], "Инъекции ботокса", 12000, 45, 0),
        # Массаж и SPA (category 3)
        (category_ids[3], "Массаж спины", 2000, 45, 0),
        (category_ids[3], "Общий массаж", 3500, 90, 1),
        (category_ids[3], "SPA-программа", 8000, 180, 0),
    ]
    
    service_ids = []
    for cat_id, name, price, duration, is_popular in services_data:
        cur.execute("""
            INSERT INTO services (
                tenant_id, category_id, name, price, duration_minutes, is_active,
                online_booking_enabled, is_popular, return_cycle_days, consumables,
                total_bookings, created_at, updated_at, is_deleted
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            tenant_id, cat_id, name, price, duration, 1, 1, is_popular, 21, "[]", 0,
            now_str, now_str, 0
        ))
        service_ids.append(cur.lastrowid)
    print(f"   Created {len(service_ids)} services")
    
    # 6. Create Staff
    print("👥 Creating staff...")
    staff_data = [
        ("Анна", "Иванова", "Стилист", "+79001111111", "anna@glamour.ru"),
        ("Мария", "Петрова", "Мастер маникюра", "+79002222222", "maria@glamour.ru"),
        ("Елена", "Сидорова", "Косметолог", "+79003333333", "elena@glamour.ru"),
        ("Ольга", "Козлова", "Массажист", "+79004444444", "olga@glamour.ru"),
        ("Наталья", "Смирнова", "Стилист", "+79005555555", "natalia@glamour.ru"),
    ]
    
    staff_ids = []
    for first_name, last_name, position, phone, email in staff_data:
        cur.execute("""
            INSERT INTO staff (
                tenant_id, branch_id, first_name, last_name, position, phone, email,
                role, status, working_hours, specializations, permissions, notification_settings,
                created_at, updated_at, is_deleted
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            tenant_id, branch_id, first_name, last_name, position, phone, email,
            "master", "active", "{}", "[]", "{}", "{}", now_str, now_str, 0
        ))
        staff_ids.append(cur.lastrowid)
    print(f"   Created {len(staff_ids)} staff members")
    
    # 7. Create Clients
    print("👨‍👩‍👧‍👦 Creating clients...")
    client_names = [
        ("Екатерина", "Волкова"), ("Светлана", "Новикова"), ("Татьяна", "Морозова"),
        ("Ирина", "Соколова"), ("Юлия", "Лебедева"), ("Ксения", "Козлова"),
        ("Дарья", "Николаева"), ("Алина", "Попова"), ("Виктория", "Федорова"),
        ("Полина", "Михайлова"), ("Александра", "Павлова"), ("Валерия", "Кузнецова"),
        ("Анастасия", "Орлова"), ("Кристина", "Андреева"), ("Маргарита", "Макарова"),
        ("Диана", "Степанова"), ("Елизавета", "Захарова"), ("София", "Васильева"),
        ("Вероника", "Петрова"), ("Арина", "Семенова"),
    ]
    
    segments = ["new", "regular", "vip", "sleeping", "at_risk"]
    segment_weights = [0.2, 0.4, 0.15, 0.15, 0.1]
    
    client_ids = []
    for i, (first, last) in enumerate(client_names):
        segment = random.choices(segments, weights=segment_weights)[0]
        total_visits = random.randint(1, 30) if segment != "new" else random.randint(0, 2)
        total_spent = total_visits * random.randint(1500, 5000)
        bonus_balance = random.randint(0, 500)
        
        last_visit = None
        if total_visits > 0:
            days_ago = random.randint(1, 90)
            last_visit = (now - timedelta(days=days_ago)).isoformat()
        
        cur.execute("""
            INSERT INTO clients (
                tenant_id, first_name, last_name, phone, email, segment,
                total_visits, total_spent, bonus_balance, last_visit_at,
                preferred_channel, source, tags, custom_fields,
                created_at, updated_at, is_deleted
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            tenant_id, first, last, f"+7900{i:07d}", f"{first.lower()}.{last.lower()}@mail.ru",
            segment, total_visits, total_spent, bonus_balance, last_visit,
            "telegram", "walk_in", "[]", "{}", now_str, now_str, 0
        ))
        client_ids.append(cur.lastrowid)
    print(f"   Created {len(client_ids)} clients")
    
    # 8. Create Appointments (past and future)
    print("📅 Creating appointments...")
    statuses = ["completed", "completed", "completed", "cancelled_by_client", "no_show"]
    
    appointment_ids = []
    
    # Past appointments
    for _ in range(50):
        client_id = random.choice(client_ids)
        staff_id = random.choice(staff_ids)
        service_idx = random.randint(0, len(service_ids) - 1)
        service_id = service_ids[service_idx]
        price = services_data[service_idx][2]
        duration = services_data[service_idx][3]
        
        days_ago = random.randint(1, 60)
        hour = random.randint(9, 18)
        apt_date = (now - timedelta(days=days_ago)).date()
        start_time_str = f"{hour:02d}:00:00"
        end_hour = hour + (duration // 60)
        end_min = duration % 60
        end_time_str = f"{end_hour:02d}:{end_min:02d}:00"
        status = random.choice(statuses)
        
        cur.execute("""
            INSERT INTO appointments (
                tenant_id, branch_id, client_id, staff_id, service_id,
                date, start_time, end_time, duration_minutes, status, price, final_price, source,
                created_at, updated_at, is_deleted
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            tenant_id, branch_id, client_id, staff_id, service_id,
            apt_date.isoformat(), start_time_str, end_time_str, duration, status, price, price, "admin",
            now_str, now_str, 0
        ))
        apt_datetime = datetime.combine(apt_date, datetime.strptime(end_time_str, "%H:%M:%S").time())
        appointment_ids.append((cur.lastrowid, status, client_id, price, apt_datetime))
    
    # Future appointments
    for _ in range(15):
        client_id = random.choice(client_ids)
        staff_id = random.choice(staff_ids)
        service_idx = random.randint(0, len(service_ids) - 1)
        service_id = service_ids[service_idx]
        price = services_data[service_idx][2]
        duration = services_data[service_idx][3]
        
        days_ahead = random.randint(1, 14)
        hour = random.randint(9, 18)
        apt_date = (now + timedelta(days=days_ahead)).date()
        start_time_str = f"{hour:02d}:00:00"
        end_hour = hour + (duration // 60)
        end_min = duration % 60
        end_time_str = f"{end_hour:02d}:{end_min:02d}:00"
        
        cur.execute("""
            INSERT INTO appointments (
                tenant_id, branch_id, client_id, staff_id, service_id,
                date, start_time, end_time, duration_minutes, status, price, final_price, source,
                created_at, updated_at, is_deleted
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            tenant_id, branch_id, client_id, staff_id, service_id,
            apt_date.isoformat(), start_time_str, end_time_str, duration, "confirmed", price, price, "admin",
            now_str, now_str, 0
        ))
    print(f"   Created {50 + 15} appointments")
    
    # 9. Create Payments
    print("💰 Creating payments...")
    payment_methods = ["cash", "card", "card"]
    payment_count = 0
    
    for apt_id, status, client_id, price, end_time in appointment_ids:
        if status == "completed":
            method = random.choice(payment_methods)
            cur.execute("""
                INSERT INTO payments (
                    tenant_id, branch_id, client_id, appointment_id,
                    amount, final_amount, payment_method, status, paid_at,
                    created_at, updated_at, is_deleted
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                tenant_id, branch_id, client_id, apt_id,
                price, price, method, "completed", end_time.isoformat(),
                now_str, now_str, 0
            ))
            payment_count += 1
    print(f"   Created {payment_count} payments")
    
    conn.commit()
    conn.close()
    
    print("\n✅ Demo data seeding completed!")
    print(f"   - Tenant: Салон красоты 'Гламур'")
    print(f"   - User: demo@business-os.ru / demo123456")
    print(f"   - Branch: Основной филиал")
    print(f"   - Categories: {len(category_ids)}")
    print(f"   - Services: {len(service_ids)}")
    print(f"   - Staff: {len(staff_ids)}")
    print(f"   - Clients: {len(client_ids)}")
    print(f"   - Appointments: {50 + 15}")
    print(f"   - Payments: {payment_count}")


if __name__ == "__main__":
    seed_demo_data()
