"""
Business OS - Onboarding Endpoints
Настройка салона после регистрации
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.database import get_db
from app.core.security import get_current_user, TokenData
from app.models import Tenant, Branch, Staff, Service, ServiceCategory

router = APIRouter()


# ==================== SCHEMAS ====================

class SalonInfoUpdate(BaseModel):
    """Обновление информации о салоне"""
    city: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None


class StaffCreate(BaseModel):
    """Создание сотрудника"""
    first_name: str
    last_name: Optional[str] = None
    position: Optional[str] = None
    phone: str


class ServiceTemplateSelect(BaseModel):
    """Выбор услуг из шаблонов"""
    services: List[str]


class WorkingHoursUpdate(BaseModel):
    """Обновление графика работы"""
    working_days: List[int]  # 0-6, 0=Sunday
    working_hours_start: str  # "09:00"
    working_hours_end: str  # "21:00"


class OnboardingComplete(BaseModel):
    """Полные данные онбординга"""
    salon_info: Optional[SalonInfoUpdate] = None
    staff: Optional[List[StaffCreate]] = None
    services: Optional[List[str]] = None
    working_hours: Optional[WorkingHoursUpdate] = None


# ==================== ENDPOINTS ====================

@router.post("/salon-info")
async def update_salon_info(
    data: SalonInfoUpdate,
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Обновление информации о салоне"""
    # Get tenant
    result = await db.execute(select(Tenant).where(Tenant.id == current_user.tenant_id))
    tenant = result.scalar_one_or_none()
    
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    # Update tenant
    if data.city:
        tenant.city = data.city
    if data.phone:
        tenant.phone = data.phone
    
    # Get or create main branch
    result = await db.execute(
        select(Branch).where(Branch.tenant_id == current_user.tenant_id).limit(1)
    )
    branch = result.scalar_one_or_none()
    
    if not branch:
        branch = Branch(
            tenant_id=current_user.tenant_id,
            name="Главный филиал",
            address=data.address,
            city=data.city,
            phone=data.phone,
            is_main=True,
        )
        db.add(branch)
    else:
        if data.address:
            branch.address = data.address
        if data.city:
            branch.city = data.city
        if data.phone:
            branch.phone = data.phone
    
    await db.commit()
    return {"message": "Salon info updated"}


@router.post("/staff")
async def add_staff(
    data: List[StaffCreate],
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Добавление сотрудников"""
    # Get main branch
    result = await db.execute(
        select(Branch).where(Branch.tenant_id == current_user.tenant_id).limit(1)
    )
    branch = result.scalar_one_or_none()
    
    if not branch:
        # Create default branch
        branch = Branch(
            tenant_id=current_user.tenant_id,
            name="Главный филиал",
            is_main=True,
        )
        db.add(branch)
        await db.flush()
    
    created_staff = []
    for staff_data in data:
        if not staff_data.first_name:
            continue
            
        staff = Staff(
            tenant_id=current_user.tenant_id,
            branch_id=branch.id,
            first_name=staff_data.first_name,
            last_name=staff_data.last_name,
            position=staff_data.position,
            phone=staff_data.phone,
            role="master",
            status="active",
        )
        db.add(staff)
        created_staff.append(staff)
    
    await db.commit()
    return {"message": f"Created {len(created_staff)} staff members"}


@router.post("/services")
async def add_services(
    data: ServiceTemplateSelect,
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Добавление услуг из шаблонов"""
    # Service templates with default prices and durations
    service_templates = {
        # Парикмахерские услуги
        "Стрижка женская": {"category": "Парикмахерские услуги", "price": 2500, "duration": 60},
        "Стрижка мужская": {"category": "Парикмахерские услуги", "price": 1500, "duration": 30},
        "Окрашивание": {"category": "Парикмахерские услуги", "price": 5000, "duration": 120},
        "Укладка": {"category": "Парикмахерские услуги", "price": 2000, "duration": 45},
        # Ногтевой сервис
        "Маникюр классический": {"category": "Ногтевой сервис", "price": 2500, "duration": 60},
        "Маникюр с покрытием": {"category": "Ногтевой сервис", "price": 3500, "duration": 90},
        "Педикюр": {"category": "Ногтевой сервис", "price": 3000, "duration": 75},
        # Косметология
        "Чистка лица": {"category": "Косметология", "price": 5000, "duration": 90},
        "Пилинг": {"category": "Косметология", "price": 4000, "duration": 60},
        "Массаж лица": {"category": "Косметология", "price": 3000, "duration": 45},
        # Массаж
        "Массаж спины": {"category": "Массаж", "price": 3500, "duration": 60},
        "Общий массаж": {"category": "Массаж", "price": 5000, "duration": 90},
    }
    
    # Get or create categories
    categories_cache = {}
    
    for service_name in data.services:
        if service_name not in service_templates:
            continue
            
        template = service_templates[service_name]
        category_name = template["category"]
        
        # Get or create category
        if category_name not in categories_cache:
            result = await db.execute(
                select(ServiceCategory).where(
                    ServiceCategory.tenant_id == current_user.tenant_id,
                    ServiceCategory.name == category_name
                )
            )
            category = result.scalar_one_or_none()
            
            if not category:
                category = ServiceCategory(
                    tenant_id=current_user.tenant_id,
                    name=category_name,
                    sort_order=len(categories_cache),
                )
                db.add(category)
                await db.flush()
            
            categories_cache[category_name] = category
        
        category = categories_cache[category_name]
        
        # Create service
        service = Service(
            tenant_id=current_user.tenant_id,
            category_id=category.id,
            name=service_name,
            price=template["price"],
            duration_minutes=template["duration"],
            is_active=True,
        )
        db.add(service)
    
    await db.commit()
    return {"message": f"Created {len(data.services)} services"}


@router.post("/working-hours")
async def update_working_hours(
    data: WorkingHoursUpdate,
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Обновление графика работы"""
    # Get main branch
    result = await db.execute(
        select(Branch).where(Branch.tenant_id == current_user.tenant_id).limit(1)
    )
    branch = result.scalar_one_or_none()
    
    if branch:
        branch.working_hours_start = data.working_hours_start
        branch.working_hours_end = data.working_hours_end
        # Store working days as JSON or comma-separated
        branch.working_days = ",".join(map(str, data.working_days))
        await db.commit()
    
    return {"message": "Working hours updated"}


@router.post("/complete")
async def complete_onboarding(
    data: OnboardingComplete,
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Завершение онбординга - сохранение всех данных"""
    # Update salon info
    if data.salon_info:
        result = await db.execute(select(Tenant).where(Tenant.id == current_user.tenant_id))
        tenant = result.scalar_one_or_none()
        if tenant:
            if data.salon_info.city:
                tenant.city = data.salon_info.city
            if data.salon_info.phone:
                tenant.phone = data.salon_info.phone
            tenant.onboarding_completed = True
    
    await db.commit()
    return {"message": "Onboarding completed"}


@router.get("/status")
async def get_onboarding_status(
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Получение статуса онбординга"""
    result = await db.execute(select(Tenant).where(Tenant.id == current_user.tenant_id))
    tenant = result.scalar_one_or_none()
    
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    # Check what's completed
    result = await db.execute(
        select(Branch).where(Branch.tenant_id == current_user.tenant_id)
    )
    has_branch = result.scalar_one_or_none() is not None
    
    result = await db.execute(
        select(Staff).where(Staff.tenant_id == current_user.tenant_id)
    )
    has_staff = result.first() is not None
    
    result = await db.execute(
        select(Service).where(Service.tenant_id == current_user.tenant_id)
    )
    has_services = result.first() is not None
    
    return {
        "completed": getattr(tenant, 'onboarding_completed', False),
        "steps": {
            "salon_info": has_branch,
            "staff": has_staff,
            "services": has_services,
        }
    }
