import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

/**
 * Conversation Context Service
 * 
 * Управление контекстом диалогов и памятью клиентов:
 * - Сохранение истории сообщений
 * - Извлечение и сохранение информации о клиенте
 * - Управление состоянием диалога
 * - Персонализация на основе истории
 */

export interface ConversationContext {
  conversationId: string;
  businessId: string;
  clientId?: string;
  channel: 'telegram' | 'whatsapp' | 'instagram';
  channelUserId: string;
  
  // Состояние диалога
  currentIntent?: string;
  currentStep?: string;
  
  // Извлечённая информация
  extractedData: {
    name?: string;
    phone?: string;
    email?: string;
    preferences?: Record<string, any>;
  };
  
  // История сообщений (последние N для контекста)
  messages: Array<{
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp: Date;
  }>;
  
  // Метаданные
  metadata: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

export interface ClientMemory {
  clientId: string;
  businessId: string;
  
  // Базовая информация
  name?: string;
  phone?: string;
  email?: string;
  
  // Предпочтения
  preferredServices?: string[];
  preferredTime?: string;
  preferredMaster?: string;
  
  // История
  totalBookings: number;
  lastBookingDate?: Date;
  averageSpending?: number;
  
  // Дополнительная информация
  notes?: string;
  tags?: string[];
  customFields?: Record<string, any>;
  
  // Метаданные
  firstContactDate: Date;
  lastContactDate: Date;
}

@Injectable()
export class ConversationContextService {
  constructor(private prisma: PrismaService) {}

  /**
   * Получить или создать контекст диалога
   */
  async getOrCreateContext(
    businessId: string,
    channel: string,
    channelUserId: string,
  ): Promise<ConversationContext> {
    // Найти активный диалог
    let conversation = await this.prisma.conversation.findFirst({
      where: {
        businessId,
        channel,
        channelUserId,
        status: 'active',
      },
      include: {
        messages: {
          orderBy: { createdAt: 'desc' },
          take: 20, // Последние 20 сообщений для контекста
        },
        client: true,
      },
    });

    // Если нет активного диалога, создать новый
    if (!conversation) {
      conversation = await this.prisma.conversation.create({
        data: {
          businessId,
          channel,
          channelUserId,
          status: 'active',
          context: {},
          extractedData: {},
        },
        include: {
          messages: true,
          client: true,
        },
      });
    }

    // Преобразовать в ConversationContext
    return {
      conversationId: conversation.id,
      businessId: conversation.businessId,
      clientId: conversation.clientId,
      channel: conversation.channel as any,
      channelUserId: conversation.channelUserId,
      currentIntent: conversation.currentIntent,
      currentStep: conversation.currentStep,
      extractedData: (conversation.extractedData as any) || {},
      messages: conversation.messages.map((m) => ({
        role: m.role as any,
        content: m.content,
        timestamp: m.createdAt,
      })),
      metadata: (conversation.context as any) || {},
      createdAt: conversation.createdAt,
      updatedAt: conversation.updatedAt,
    };
  }

  /**
   * Добавить сообщение в контекст
   */
  async addMessage(
    conversationId: string,
    role: 'user' | 'assistant' | 'system',
    content: string,
    metadata?: Record<string, any>,
  ): Promise<void> {
    await this.prisma.message.create({
      data: {
        conversationId,
        role,
        content,
        metadata: metadata || {},
      },
    });

    // Обновить timestamp диалога
    await this.prisma.conversation.update({
      where: { id: conversationId },
      data: { updatedAt: new Date() },
    });
  }

  /**
   * Обновить извлечённые данные
   */
  async updateExtractedData(
    conversationId: string,
    data: Partial<ConversationContext['extractedData']>,
  ): Promise<void> {
    const conversation = await this.prisma.conversation.findUnique({
      where: { id: conversationId },
    });

    const currentData = (conversation.extractedData as any) || {};
    const updatedData = { ...currentData, ...data };

    await this.prisma.conversation.update({
      where: { id: conversationId },
      data: { extractedData: updatedData },
    });
  }

  /**
   * Обновить состояние диалога
   */
  async updateState(
    conversationId: string,
    intent?: string,
    step?: string,
  ): Promise<void> {
    await this.prisma.conversation.update({
      where: { id: conversationId },
      data: {
        currentIntent: intent,
        currentStep: step,
      },
    });
  }

  /**
   * Получить память клиента
   */
  async getClientMemory(
    businessId: string,
    clientId: string,
  ): Promise<ClientMemory | null> {
    const client = await this.prisma.client.findUnique({
      where: {
        id: clientId,
        businessId,
      },
      include: {
        bookings: {
          orderBy: { dateTime: 'desc' },
          take: 1,
        },
        _count: {
          select: { bookings: true },
        },
      },
    });

    if (!client) return null;

    const preferences = (client.preferences as any) || {};
    const customFields = (client.customFields as any) || {};

    return {
      clientId: client.id,
      businessId: client.businessId,
      name: client.name,
      phone: client.phone,
      email: client.email,
      preferredServices: preferences.services || [],
      preferredTime: preferences.time,
      preferredMaster: preferences.master,
      totalBookings: client._count.bookings,
      lastBookingDate: client.bookings[0]?.dateTime,
      averageSpending: preferences.averageSpending,
      notes: client.notes,
      tags: client.tags || [],
      customFields,
      firstContactDate: client.createdAt,
      lastContactDate: client.updatedAt,
    };
  }

  /**
   * Обновить память клиента
   */
  async updateClientMemory(
    businessId: string,
    clientId: string,
    updates: Partial<ClientMemory>,
  ): Promise<void> {
    const client = await this.prisma.client.findUnique({
      where: { id: clientId, businessId },
    });

    if (!client) return;

    const currentPreferences = (client.preferences as any) || {};
    const currentCustomFields = (client.customFields as any) || {};

    const updatedPreferences = {
      ...currentPreferences,
      ...(updates.preferredServices && { services: updates.preferredServices }),
      ...(updates.preferredTime && { time: updates.preferredTime }),
      ...(updates.preferredMaster && { master: updates.preferredMaster }),
      ...(updates.averageSpending && { averageSpending: updates.averageSpending }),
    };

    const updatedCustomFields = {
      ...currentCustomFields,
      ...(updates.customFields || {}),
    };

    await this.prisma.client.update({
      where: { id: clientId, businessId },
      data: {
        ...(updates.name && { name: updates.name }),
        ...(updates.phone && { phone: updates.phone }),
        ...(updates.email && { email: updates.email }),
        ...(updates.notes && { notes: updates.notes }),
        ...(updates.tags && { tags: updates.tags }),
        preferences: updatedPreferences,
        customFields: updatedCustomFields,
      },
    });
  }

  /**
   * Связать диалог с клиентом
   */
  async linkConversationToClient(
    conversationId: string,
    clientId: string,
  ): Promise<void> {
    await this.prisma.conversation.update({
      where: { id: conversationId },
      data: { clientId },
    });
  }

  /**
   * Найти или создать клиента по извлечённым данным
   */
  async findOrCreateClient(
    businessId: string,
    extractedData: ConversationContext['extractedData'],
    channel: string,
    channelUserId: string,
  ): Promise<string> {
    // Попробовать найти по телефону
    if (extractedData.phone) {
      const existingClient = await this.prisma.client.findFirst({
        where: {
          businessId,
          phone: extractedData.phone,
        },
      });

      if (existingClient) {
        // Обновить channel ID если нужно
        const channelIds = (existingClient.channelIds as any) || {};
        if (!channelIds[channel]) {
          channelIds[channel] = channelUserId;
          await this.prisma.client.update({
            where: { id: existingClient.id },
            data: { channelIds },
          });
        }

        return existingClient.id;
      }
    }

    // Попробовать найти по channel ID
    const existingByChannel = await this.prisma.client.findFirst({
      where: {
        businessId,
        channelIds: {
          path: [channel],
          equals: channelUserId,
        },
      },
    });

    if (existingByChannel) {
      return existingByChannel.id;
    }

    // Создать нового клиента
    const newClient = await this.prisma.client.create({
      data: {
        businessId,
        name: extractedData.name || 'Клиент',
        phone: extractedData.phone,
        email: extractedData.email,
        channelIds: {
          [channel]: channelUserId,
        },
        preferences: extractedData.preferences || {},
        source: channel,
      },
    });

    return newClient.id;
  }

  /**
   * Завершить диалог
   */
  async completeConversation(conversationId: string): Promise<void> {
    await this.prisma.conversation.update({
      where: { id: conversationId },
      data: {
        status: 'completed',
        completedAt: new Date(),
      },
    });
  }

  /**
   * Получить историю диалогов клиента
   */
  async getClientConversationHistory(
    businessId: string,
    clientId: string,
    limit: number = 10,
  ): Promise<ConversationContext[]> {
    const conversations = await this.prisma.conversation.findMany({
      where: {
        businessId,
        clientId,
      },
      include: {
        messages: {
          orderBy: { createdAt: 'desc' },
          take: 5,
        },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    return conversations.map((conv) => ({
      conversationId: conv.id,
      businessId: conv.businessId,
      clientId: conv.clientId,
      channel: conv.channel as any,
      channelUserId: conv.channelUserId,
      currentIntent: conv.currentIntent,
      currentStep: conv.currentStep,
      extractedData: (conv.extractedData as any) || {},
      messages: conv.messages.map((m) => ({
        role: m.role as any,
        content: m.content,
        timestamp: m.createdAt,
      })),
      metadata: (conv.context as any) || {},
      createdAt: conv.createdAt,
      updatedAt: conv.updatedAt,
    }));
  }

  /**
   * Получить статистику диалогов
   */
  async getConversationStats(businessId: string): Promise<{
    total: number;
    active: number;
    completed: number;
    averageMessagesPerConversation: number;
  }> {
    const [total, active, completed, messageStats] = await Promise.all([
      this.prisma.conversation.count({ where: { businessId } }),
      this.prisma.conversation.count({ where: { businessId, status: 'active' } }),
      this.prisma.conversation.count({ where: { businessId, status: 'completed' } }),
      this.prisma.message.groupBy({
        by: ['conversationId'],
        where: { conversation: { businessId } },
        _count: true,
      }),
    ]);

    const averageMessages =
      messageStats.length > 0
        ? messageStats.reduce((sum, stat) => sum + stat._count, 0) / messageStats.length
        : 0;

    return {
      total,
      active,
      completed,
      averageMessagesPerConversation: Math.round(averageMessages * 10) / 10,
    };
  }
}
