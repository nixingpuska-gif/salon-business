"""
AI Assistant API - Автоматизация общения, классификация сообщений, подсказки
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime
from pydantic import BaseModel
from typing import Optional, List
from enum import Enum
import os

from app.core.database import get_db

router = APIRouter()


class MessageType(str, Enum):
    BOOKING = "booking"
    PRICE_INQUIRY = "price_inquiry"
    RESCHEDULE = "reschedule"
    CANCEL = "cancel"
    COMPLAINT = "complaint"
    GENERAL = "general"
    SPAM = "spam"


class MessageClassification(BaseModel):
    type: MessageType
    confidence: float
    suggested_response: str
    requires_human: bool
    priority: str  # low, medium, high, urgent


class AIResponse(BaseModel):
    response_text: str
    actions: List[str]
    upsell_suggestion: Optional[str]
    client_sentiment: str  # positive, neutral, negative


class ConversationContext(BaseModel):
    client_id: Optional[int]
    client_name: Optional[str]
    last_visit: Optional[str]
    favorite_services: List[str]
    total_spent: float
    segment: str


@router.post("/classify-message")
async def classify_message(
    message: str,
    client_phone: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """AI-классификация входящего сообщения"""
    
    message_lower = message.lower()
    
    # Простая классификация на основе ключевых слов
    if any(word in message_lower for word in ["запис", "хочу", "можно", "свободн", "время", "когда"]):
        msg_type = MessageType.BOOKING
        confidence = 0.92
        response = "Конечно! Подскажите, на какую услугу и к какому мастеру хотите записаться? У нас есть свободные окна на эту неделю."
        requires_human = False
    elif any(word in message_lower for word in ["цен", "стоит", "сколько", "прайс"]):
        msg_type = MessageType.PRICE_INQUIRY
        confidence = 0.95
        response = "Вот наши цены:\n• Маникюр — от 1,500₽\n• Маникюр с покрытием — от 2,500₽\n• Педикюр — от 2,000₽\n\nХотите записаться?"
        requires_human = False
    elif any(word in message_lower for word in ["перенес", "другое время", "сдвинуть"]):
        msg_type = MessageType.RESCHEDULE
        confidence = 0.88
        response = "Конечно, давайте перенесём. На какое время вам удобно?"
        requires_human = False
    elif any(word in message_lower for word in ["отмен", "не приду", "не смогу"]):
        msg_type = MessageType.CANCEL
        confidence = 0.90
        response = "Очень жаль! Может, перенесём на другой день? У нас есть окна на следующей неделе."
        requires_human = False
    elif any(word in message_lower for word in ["плохо", "ужас", "недовол", "жалоб", "верните"]):
        msg_type = MessageType.COMPLAINT
        confidence = 0.85
        response = None
        requires_human = True
    else:
        msg_type = MessageType.GENERAL
        confidence = 0.70
        response = "Спасибо за сообщение! Чем могу помочь? Вы можете записаться на услугу, узнать цены или задать вопрос."
        requires_human = False
    
    priority = "urgent" if msg_type == MessageType.COMPLAINT else "medium" if msg_type == MessageType.BOOKING else "low"
    
    return MessageClassification(
        type=msg_type,
        confidence=confidence,
        suggested_response=response or "Передаю ваш вопрос администратору. Ответим в ближайшее время!",
        requires_human=requires_human,
        priority=priority
    )


@router.post("/generate-response")
async def generate_response(
    message: str,
    client_id: Optional[int] = None,
    context: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Генерация AI-ответа с учётом контекста клиента"""
    
    # Контекст клиента (в реальности из БД)
    client_context = ConversationContext(
        client_id=client_id,
        client_name="Мария",
        last_visit="2024-12-01",
        favorite_services=["Маникюр с покрытием", "Педикюр"],
        total_spent=45000,
        segment="VIP"
    )
    
    # Генерация ответа
    response_text = f"Здравствуйте, {client_context.client_name}! Рады вас слышать. "
    
    if "запис" in message.lower():
        response_text += "К вашему любимому мастеру Анне есть окна в пятницу в 14:00 и 16:00. Какое время удобнее?"
        upsell = "Кстати, у нас новая коллекция гель-лаков! Хотите попробовать?"
    else:
        response_text += "Чем могу помочь?"
        upsell = None
    
    # Определение тональности
    sentiment = "positive" if any(w in message.lower() for w in ["спасибо", "отлично", "супер"]) else "neutral"
    
    return AIResponse(
        response_text=response_text,
        actions=["send_message", "log_interaction"],
        upsell_suggestion=upsell,
        client_sentiment=sentiment
    )


@router.get("/sales-hints")
async def get_sales_hints(
    client_id: int,
    current_service: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """AI-подсказки для допродаж в реальном времени"""
    
    hints = [
        {
            "type": "upsell",
            "text": "Клиент давно не делал педикюр — предложите комплекс маникюр+педикюр со скидкой 10%",
            "probability": 0.75,
            "potential_revenue": 2000
        },
        {
            "type": "addon",
            "text": "Предложите укрепление ногтей — популярно среди VIP-клиентов",
            "probability": 0.60,
            "potential_revenue": 500
        },
        {
            "type": "product",
            "text": "Клиент интересовался уходом — предложите крем для рук со скидкой",
            "probability": 0.45,
            "potential_revenue": 800
        }
    ]
    
    return {
        "client_id": client_id,
        "hints": hints,
        "total_potential": sum(h["potential_revenue"] * h["probability"] for h in hints)
    }


@router.get("/scripts")
async def get_sales_scripts(
    scenario: str = Query("objection_expensive"),
    db: AsyncSession = Depends(get_db)
):
    """Библиотека скриптов продаж"""
    
    scripts = {
        "objection_expensive": {
            "title": "Возражение: Дорого",
            "scripts": [
                "Понимаю вас. Давайте посмотрим, что входит в стоимость: качественные материалы, опытный мастер, гарантия 2 недели. В пересчёте на день носки получается всего 100₽.",
                "У нас есть программа лояльности — с каждого визита вы получаете бонусы. Уже сейчас у вас накоплено 500₽, которые можно использовать.",
                "Могу предложить базовый вариант услуги за меньшую стоимость. Хотите расскажу подробнее?"
            ]
        },
        "objection_think": {
            "title": "Возражение: Подумаю",
            "scripts": [
                "Конечно, подумайте. Но учтите, что на эту неделю осталось всего 2 окна к нашему топ-мастеру.",
                "Хорошо! Могу забронировать время на 30 минут, пока вы решаете?",
                "Что именно хотите обдумать? Может, я помогу с выбором?"
            ]
        },
        "upsell_combo": {
            "title": "Допродажа: Комплекс услуг",
            "scripts": [
                "Кстати, при записи на маникюр+педикюр действует скидка 15%. Сэкономите 600₽!",
                "Многие клиенты берут комплекс — это удобнее и выгоднее. Хотите добавить педикюр?",
                "У вас красивые руки! Хотите дополнить образ уходом за ногами?"
            ]
        },
        "reactivation": {
            "title": "Реактивация спящего клиента",
            "scripts": [
                "Давно вас не видели! Специально для вас — скидка 20% на следующий визит. Действует 7 дней.",
                "Соскучились по вам! У нас появились новые услуги — хотите попробовать со скидкой?",
                "Ваш любимый мастер Анна передаёт привет и приглашает на маникюр!"
            ]
        }
    }
    
    return scripts.get(scenario, {"error": "Script not found"})


@router.get("/efficiency")
async def get_ai_efficiency(
    tenant_id: int = Query(...),
    period: str = Query("month"),
    db: AsyncSession = Depends(get_db)
):
    """Аналитика эффективности AI"""
    
    return {
        "period": period,
        "messages_processed": 1250,
        "auto_responses": 1050,
        "auto_response_rate": 84,
        "escalated_to_human": 200,
        "avg_response_time_seconds": 3,
        "bookings_from_ai": 180,
        "revenue_from_ai_bookings": 540000,
        "time_saved_hours": 45,
        "cost_saved": 67500,  # 45 часов * 1500₽/час
        "satisfaction_rate": 4.7,
        "top_intents": [
            {"intent": "booking", "count": 450, "conversion": 0.40},
            {"intent": "price_inquiry", "count": 380, "conversion": 0.25},
            {"intent": "reschedule", "count": 220, "conversion": 0.85},
        ]
    }
