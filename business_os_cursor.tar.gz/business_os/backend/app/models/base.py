"""
Business OS - Base Models
Базовые модели с общими полями для всех сущностей
"""

from datetime import datetime
from typing import Optional
from sqlalchemy import Column, Integer, DateTime, Boolean, String, BigInteger, Index
from sqlalchemy.ext.declarative import declared_attr

from app.core.database import Base


class TimestampMixin:
    """Миксин для временных меток"""
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)


class SoftDeleteMixin:
    """Миксин для мягкого удаления"""
    is_deleted = Column(Boolean, default=False, nullable=False, index=True)
    deleted_at = Column(DateTime, nullable=True)
    
    def soft_delete(self):
        self.is_deleted = True
        self.deleted_at = datetime.utcnow()


class TenantMixin:
    """Миксин для multi-tenancy (привязка к салону)"""
    @declared_attr
    def tenant_id(cls):
        return Column(BigInteger, nullable=False, index=True)


class BaseModel(Base, TimestampMixin, SoftDeleteMixin):
    """Базовая модель для всех сущностей"""
    __abstract__ = True
    
    id = Column(Integer, primary_key=True, autoincrement=True)


class TenantBaseModel(BaseModel, TenantMixin):
    """Базовая модель для сущностей с привязкой к тенанту (салону)"""
    __abstract__ = True


# === Enums для использования в моделях ===

class ClientStatus:
    """Статусы клиента"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    BLOCKED = "blocked"
    VIP = "vip"


class ClientRiskLabel:
    """Метки риска клиента"""
    LOYAL = "loyal"
    VIP = "vip"
    LEAVING = "leaving"
    LOST = "lost"
    PROBLEMATIC = "problematic"
    NEW = "new"


class AppointmentStatus:
    """Статусы записи"""
    PENDING = "pending"  # Ожидает подтверждения
    CONFIRMED = "confirmed"  # Подтверждена
    IN_PROGRESS = "in_progress"  # В процессе
    COMPLETED = "completed"  # Завершена
    CANCELLED = "cancelled"  # Отменена клиентом
    NO_SHOW = "no_show"  # Не пришёл
    RESCHEDULED = "rescheduled"  # Перенесена


class PaymentStatus:
    """Статусы платежа"""
    PENDING = "pending"
    COMPLETED = "completed"
    REFUNDED = "refunded"
    PARTIAL = "partial"
    FAILED = "failed"


class PaymentMethod:
    """Способы оплаты"""
    CASH = "cash"
    CARD = "card"
    TRANSFER = "transfer"
    SBP = "sbp"
    BONUS = "bonus"
    MIXED = "mixed"


class StaffRole:
    """Роли сотрудников"""
    OWNER = "owner"
    MANAGER = "manager"
    ADMIN = "admin"
    MASTER = "master"


class NotificationChannel:
    """Каналы уведомлений"""
    TELEGRAM = "telegram"
    WHATSAPP = "whatsapp"
    SMS = "sms"
    EMAIL = "email"
    PUSH = "push"


class MessageType:
    """Типы сообщений"""
    REMINDER = "reminder"
    CONFIRMATION = "confirmation"
    FEEDBACK = "feedback"
    PROMO = "promo"
    REACTIVATION = "reactivation"
    BIRTHDAY = "birthday"
    CUSTOM = "custom"
