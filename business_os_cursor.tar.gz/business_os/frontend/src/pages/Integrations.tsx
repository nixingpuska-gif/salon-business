import { useState, useEffect } from 'react'
import { 
  MessageCircle, Send, Instagram, Mail, Smartphone,
  Check, X, ExternalLink, RefreshCw, Zap
} from 'lucide-react'

const API_URL = (import.meta as any).env?.VITE_API_URL || 'http://localhost:8000'

interface Integration {
  id: number
  type: string
  name: string
  description: string
  status: 'active' | 'inactive' | 'pending' | 'error'
  is_configured: boolean
  last_sync: string | null
  setup_url?: string
  docs_url?: string
}

const integrationIcons: Record<string, any> = {
  telegram: MessageCircle,
  whatsapp: Send,
  instagram: Instagram,
  sms: Smartphone,
  email: Mail,
}

const integrationColors: Record<string, string> = {
  telegram: 'bg-blue-500',
  whatsapp: 'bg-green-500',
  instagram: 'bg-gradient-to-br from-purple-500 to-pink-500',
  sms: 'bg-orange-500',
  email: 'bg-gray-600',
}

export default function Integrations() {
  const [integrations, setIntegrations] = useState<Integration[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedIntegration, setSelectedIntegration] = useState<Integration | null>(null)
  const [_configuring, _setConfiguring] = useState(false)

  useEffect(() => {
    fetchIntegrations()
  }, [])

  const fetchIntegrations = async () => {
    try {
      const response = await fetch(`${API_URL}/api/v1/integrations`)
      if (response.ok) {
        const data = await response.json()
        setIntegrations(data)
      }
    } catch (error) {
      console.error('Failed to fetch integrations:', error)
    } finally {
      setLoading(false)
    }
  }

  const testIntegration = async (type: string) => {
    try {
      const response = await fetch(`${API_URL}/api/v1/integrations/${type}/test`, {
        method: 'POST'
      })
      if (response.ok) {
        const data = await response.json()
        alert(data.message)
      }
    } catch (error) {
      console.error('Test failed:', error)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Интеграции</h1>
          <p className="text-gray-500 mt-1">
            Подключите мессенджеры и каналы коммуникации
          </p>
        </div>
        <button 
          onClick={fetchIntegrations}
          className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900"
        >
          <RefreshCw className="w-4 h-4" />
          Обновить
        </button>
      </div>

      {/* Info Banner */}
      <div className="bg-primary-50 border border-primary-200 rounded-xl p-4 flex items-start gap-3">
        <Zap className="w-5 h-5 text-primary-600 mt-0.5" />
        <div>
          <h3 className="font-medium text-primary-900">Автоматизируйте коммуникации</h3>
          <p className="text-sm text-primary-700 mt-1">
            Подключите интеграции для автоматической отправки напоминаний о записях, 
            поздравлений с днём рождения и реактивации спящих клиентов.
          </p>
        </div>
      </div>

      {/* Integrations Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {integrations.map((integration) => {
          const Icon = integrationIcons[integration.type] || MessageCircle
          const bgColor = integrationColors[integration.type] || 'bg-gray-500'
          
          return (
            <div 
              key={integration.id}
              className="bg-white rounded-xl border border-gray-200 p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div className={`w-12 h-12 ${bgColor} rounded-xl flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className={`px-2 py-1 rounded-full text-xs font-medium ${
                  integration.status === 'active' 
                    ? 'bg-green-100 text-green-700'
                    : integration.status === 'error'
                    ? 'bg-red-100 text-red-700'
                    : 'bg-gray-100 text-gray-600'
                }`}>
                  {integration.status === 'active' ? 'Активна' : 
                   integration.status === 'error' ? 'Ошибка' : 'Не настроена'}
                </div>
              </div>

              <h3 className="text-lg font-semibold text-gray-900 mb-1">
                {integration.name}
              </h3>
              <p className="text-sm text-gray-500 mb-4">
                {integration.description}
              </p>

              {integration.is_configured ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-green-600">
                    <Check className="w-4 h-4" />
                    Настроена
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => testIntegration(integration.type)}
                      className="flex-1 px-3 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200"
                    >
                      Тест
                    </button>
                    <button 
                      onClick={() => setSelectedIntegration(integration)}
                      className="flex-1 px-3 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700"
                    >
                      Настройки
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <button 
                    onClick={() => setSelectedIntegration(integration)}
                    className="w-full px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700"
                  >
                    Подключить
                  </button>
                  {integration.docs_url && (
                    <a 
                      href={integration.docs_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-1 text-sm text-gray-500 hover:text-gray-700"
                    >
                      Документация
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Notification Templates Section */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          Шаблоны уведомлений
        </h2>
        <div className="grid md:grid-cols-2 gap-4">
          {[
            { id: 'appointment_reminder', name: 'Напоминание о записи', channels: ['telegram', 'whatsapp', 'sms'] },
            { id: 'appointment_confirmation', name: 'Подтверждение записи', channels: ['telegram', 'whatsapp', 'sms', 'email'] },
            { id: 'birthday_greeting', name: 'Поздравление с ДР', channels: ['telegram', 'whatsapp', 'email'] },
            { id: 'reactivation', name: 'Реактивация клиента', channels: ['telegram', 'whatsapp', 'sms'] },
          ].map((template) => (
            <div key={template.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div>
                <div className="font-medium text-gray-900">{template.name}</div>
                <div className="flex items-center gap-2 mt-1">
                  {template.channels.map((channel) => {
                    const ChannelIcon = integrationIcons[channel]
                    return (
                      <div 
                        key={channel}
                        className={`w-5 h-5 ${integrationColors[channel]} rounded flex items-center justify-center`}
                      >
                        <ChannelIcon className="w-3 h-3 text-white" />
                      </div>
                    )
                  })}
                </div>
              </div>
              <button className="text-primary-600 hover:text-primary-700 text-sm font-medium">
                Настроить
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Configuration Modal */}
      {selectedIntegration && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full mx-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">
                Настройка {selectedIntegration.name}
              </h3>
              <button 
                onClick={() => setSelectedIntegration(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              {selectedIntegration.type === 'telegram' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Bot Token
                    </label>
                    <input 
                      type="text"
                      placeholder="123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      Получите токен у @BotFather в Telegram
                    </p>
                  </div>
                  <a 
                    href="https://t.me/BotFather"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-sm text-primary-600 hover:text-primary-700"
                  >
                    Создать бота в Telegram
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </>
              )}

              {selectedIntegration.type === 'whatsapp' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      WhatsApp Business API Key
                    </label>
                    <input 
                      type="text"
                      placeholder="Ваш API ключ"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Номер телефона
                    </label>
                    <input 
                      type="text"
                      placeholder="+7 999 123 45 67"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    />
                  </div>
                </>
              )}

              {selectedIntegration.type === 'instagram' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Instagram Access Token
                    </label>
                    <input 
                      type="text"
                      placeholder="Ваш access token"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Business Account ID
                    </label>
                    <input 
                      type="text"
                      placeholder="ID вашего бизнес-аккаунта"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    />
                  </div>
                </>
              )}

              {selectedIntegration.type === 'sms' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      SMS Провайдер
                    </label>
                    <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                      <option value="">Выберите провайдера</option>
                      <option value="smsru">SMS.ru</option>
                      <option value="twilio">Twilio</option>
                      <option value="smsc">SMSC.ru</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      API Key
                    </label>
                    <input 
                      type="text"
                      placeholder="Ваш API ключ"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    />
                  </div>
                </>
              )}

              {selectedIntegration.type === 'email' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      SMTP Сервер
                    </label>
                    <input 
                      type="text"
                      placeholder="smtp.gmail.com"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Порт
                      </label>
                      <input 
                        type="number"
                        placeholder="587"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Email
                      </label>
                      <input 
                        type="email"
                        placeholder="salon@example.com"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Пароль
                    </label>
                    <input 
                      type="password"
                      placeholder="••••••••"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    />
                  </div>
                </>
              )}

              <div className="flex gap-3 pt-4">
                <button 
                  onClick={() => setSelectedIntegration(null)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50"
                >
                  Отмена
                </button>
                <button 
                  onClick={() => {
                    alert('Интеграция сохранена!')
                    setSelectedIntegration(null)
                  }}
                  className="flex-1 px-4 py-2 bg-primary-600 text-white rounded-lg font-medium hover:bg-primary-700"
                >
                  Сохранить
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
