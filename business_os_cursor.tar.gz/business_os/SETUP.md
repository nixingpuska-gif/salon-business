# Инструкция по настройке Business OS в Cursor

## Шаг 1: Открыть проект в Cursor

1. Распакуйте архив `business_os_cursor.tar.gz`
2. Откройте папку `business_os` в Cursor: `File → Open Folder`

## Шаг 2: Настройка Backend

### 2.1 Создайте виртуальное окружение Python

```bash
cd backend
python -m venv venv

# Windows
venv\Scripts\activate

# macOS/Linux
source venv/bin/activate
```

### 2.2 Установите зависимости

```bash
pip install -r requirements.txt
```

**Примечание**: Если возникают ошибки с некоторыми пакетами, установите минимальный набор:

```bash
pip install fastapi uvicorn sqlalchemy aiosqlite pydantic pydantic-settings python-jose passlib python-multipart
```

### 2.3 Создайте демо-данные

```bash
python seed_sync.py
```

Это создаст файл `business_os.db` с тестовыми данными.

### 2.4 Запустите backend

```bash
uvicorn app.main:app --reload --port 8000
```

Backend будет доступен на http://localhost:8000

## Шаг 3: Настройка Frontend

### 3.1 Установите зависимости

```bash
cd frontend
pnpm install
# или
npm install
```

### 3.2 Настройте API URL (опционально)

Если backend на другом порту, отредактируйте `frontend/src/config/api.ts`:

```typescript
export const API_BASE_URL = 'http://localhost:8000';
```

### 3.3 Запустите frontend

```bash
pnpm dev
# или
npm run dev
```

Frontend будет доступен на http://localhost:5173

## Шаг 4: Вход в систему

1. Откройте http://localhost:5173
2. Нажмите "Login" или "Войти"
3. Введите:
   - **Email**: `demo@business-os.ru`
   - **Пароль**: `demo123456`

## Полезные команды

### Пересоздать базу данных

```bash
cd backend
rm -f business_os.db
python seed_sync.py
```

### Проверить API

```bash
# Health check
curl http://localhost:8000/health

# Получить клиентов
curl http://localhost:8000/api/v1/clients
```

### Запуск в режиме разработки (оба сервера)

**Терминал 1 (Backend)**:
```bash
cd backend
uvicorn app.main:app --reload --port 8000
```

**Терминал 2 (Frontend)**:
```bash
cd frontend
pnpm dev
```

## Структура для Cursor

Cursor автоматически подхватит файл `.cursorrules` с правилами проекта.

### Рекомендуемые расширения Cursor/VS Code

- Python
- Pylance
- ESLint
- Prettier
- Tailwind CSS IntelliSense

## Возможные проблемы

### "Module not found" в Python

```bash
pip install <имя_модуля>
```

### CORS ошибки

Backend уже настроен на прием запросов с localhost. Если проблема сохраняется, проверьте `backend/app/main.py` — там настроен CORS middleware.

### База данных не создается

Убедитесь, что вы находитесь в папке `backend` при запуске `seed_sync.py`.

### Frontend не видит API

1. Проверьте, что backend запущен на порту 8000
2. Проверьте `frontend/src/config/api.ts`
