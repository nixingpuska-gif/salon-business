import { Injectable, Logger } from '@nestjs/common';
import axios, { AxiosInstance } from 'axios';

/**
 * Instagram Direct Messages Service (Meta Graph API)
 * 
 * Интеграция с Instagram Messaging API через Meta Graph API.
 * Позволяет принимать и отправлять сообщения в Instagram Direct.
 * 
 * Требуется:
 * - INSTAGRAM_PAGE_ID (ID страницы Instagram Business)
 * - INSTAGRAM_ACCESS_TOKEN (Постоянный токен доступа)
 * - INSTAGRAM_VERIFY_TOKEN (Токен для верификации webhook)
 * 
 * Документация: https://developers.facebook.com/docs/messenger-platform/instagram
 */
@Injectable()
export class InstagramService {
  private readonly logger = new Logger(InstagramService.name);
  private readonly apiClient: AxiosInstance;
  private readonly pageId: string;
  private readonly accessToken: string;
  private readonly verifyToken: string;

  constructor() {
    this.pageId = process.env.INSTAGRAM_PAGE_ID || '';
    this.accessToken = process.env.INSTAGRAM_ACCESS_TOKEN || '';
    this.verifyToken = process.env.INSTAGRAM_VERIFY_TOKEN || 'your_verify_token';

    // Инициализация HTTP клиента для Instagram Graph API
    this.apiClient = axios.create({
      baseURL: 'https://graph.facebook.com/v21.0',
      headers: {
        'Authorization': `Bearer ${this.accessToken}`,
        'Content-Type': 'application/json',
      },
    });

    this.logger.log('Instagram Service initialized');
  }

  /**
   * Верификация webhook от Meta
   */
  verifyWebhook(mode: string, token: string, challenge: string): string | null {
    if (mode === 'subscribe' && token === this.verifyToken) {
      this.logger.log('Instagram webhook verified successfully');
      return challenge;
    }
    this.logger.warn('Instagram webhook verification failed');
    return null;
  }

  /**
   * Отправка текстового сообщения
   */
  async sendMessage(recipientId: string, text: string): Promise<any> {
    try {
      const response = await this.apiClient.post(`/${this.pageId}/messages`, {
        recipient: {
          id: recipientId,
        },
        message: {
          text: text,
        },
      });

      this.logger.log(`Message sent to Instagram user ${recipientId}: ${text.substring(0, 50)}...`);
      return response.data;
    } catch (error) {
      this.logger.error(`Failed to send Instagram message to ${recipientId}:`, error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Отправка сообщения с Quick Replies (быстрые ответы)
   */
  async sendQuickReplies(
    recipientId: string,
    text: string,
    quickReplies: Array<{ title: string; payload: string }>,
  ): Promise<any> {
    try {
      // Instagram поддерживает максимум 13 quick replies
      if (quickReplies.length > 13) {
        throw new Error('Instagram supports maximum 13 quick replies');
      }

      const response = await this.apiClient.post(`/${this.pageId}/messages`, {
        recipient: {
          id: recipientId,
        },
        message: {
          text: text,
          quick_replies: quickReplies.map((qr) => ({
            content_type: 'text',
            title: qr.title.substring(0, 20), // Макс 20 символов
            payload: qr.payload,
          })),
        },
      });

      this.logger.log(`Quick replies sent to Instagram user ${recipientId}`);
      return response.data;
    } catch (error) {
      this.logger.error(`Failed to send Instagram quick replies to ${recipientId}:`, error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Отправка изображения
   */
  async sendImage(recipientId: string, imageUrl: string): Promise<any> {
    try {
      const response = await this.apiClient.post(`/${this.pageId}/messages`, {
        recipient: {
          id: recipientId,
        },
        message: {
          attachment: {
            type: 'image',
            payload: {
              url: imageUrl,
              is_reusable: true,
            },
          },
        },
      });

      this.logger.log(`Image sent to Instagram user ${recipientId}`);
      return response.data;
    } catch (error) {
      this.logger.error(`Failed to send Instagram image to ${recipientId}:`, error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Отправка Generic Template (карточки с кнопками)
   */
  async sendGenericTemplate(
    recipientId: string,
    elements: Array<{
      title: string;
      subtitle?: string;
      image_url?: string;
      buttons?: Array<{ type: string; title: string; payload: string }>;
    }>,
  ): Promise<any> {
    try {
      const response = await this.apiClient.post(`/${this.pageId}/messages`, {
        recipient: {
          id: recipientId,
        },
        message: {
          attachment: {
            type: 'template',
            payload: {
              template_type: 'generic',
              elements: elements.map((el) => ({
                title: el.title.substring(0, 80),
                subtitle: el.subtitle?.substring(0, 80) || '',
                image_url: el.image_url || '',
                buttons: el.buttons?.slice(0, 3).map((btn) => ({
                  type: 'postback',
                  title: btn.title.substring(0, 20),
                  payload: btn.payload,
                })) || [],
              })),
            },
          },
        },
      });

      this.logger.log(`Generic template sent to Instagram user ${recipientId}`);
      return response.data;
    } catch (error) {
      this.logger.error(`Failed to send Instagram template to ${recipientId}:`, error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Отправка индикатора "печатает..."
   */
  async sendTypingIndicator(recipientId: string, isTyping: boolean = true): Promise<any> {
    try {
      const response = await this.apiClient.post(`/${this.pageId}/messages`, {
        recipient: {
          id: recipientId,
        },
        sender_action: isTyping ? 'typing_on' : 'typing_off',
      });

      return response.data;
    } catch (error) {
      this.logger.error(`Failed to send typing indicator to ${recipientId}:`, error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Отметить сообщение как прочитанное
   */
  async markAsRead(recipientId: string): Promise<any> {
    try {
      const response = await this.apiClient.post(`/${this.pageId}/messages`, {
        recipient: {
          id: recipientId,
        },
        sender_action: 'mark_seen',
      });

      return response.data;
    } catch (error) {
      this.logger.error(`Failed to mark message as read for ${recipientId}:`, error.response?.data || error.message);
      throw error;
    }
  }

  /**
   * Обработка входящего webhook от Instagram
   */
  async handleIncomingMessage(body: any): Promise<void> {
    try {
      const messageData = this.parseWebhookPayload(body);
      
      if (!messageData) {
        this.logger.warn('No valid message data in Instagram webhook payload');
        return;
      }

      const { senderId, text, type, messageId } = messageData;

      this.logger.log(`Received Instagram ${type} message from ${senderId}: ${text}`);

      // Отправляем индикатор "печатает..."
      await this.sendTypingIndicator(senderId, true);

      // TODO: Интеграция с AI Orchestrator
      // const response = await this.aiService.processMessage({
      //   channel: 'instagram',
      //   userId: senderId,
      //   message: text,
      //   businessId: 1, // Определяется по Instagram Page ID
      // });
      
      // await this.sendMessage(senderId, response);

      // Временный автоответ для тестирования
      await this.sendMessage(senderId, `Получено ваше сообщение в Instagram: "${text}". AI-интеграция в процессе.`);

      // Отключаем индикатор "печатает..."
      await this.sendTypingIndicator(senderId, false);

      // Отмечаем сообщение как прочитанное
      await this.markAsRead(senderId);

    } catch (error) {
      this.logger.error('Error handling incoming Instagram message:', error);
    }
  }

  /**
   * Парсинг webhook payload от Meta
   */
  private parseWebhookPayload(body: any): {
    senderId: string;
    text: string;
    type: string;
    messageId: string;
  } | null {
    try {
      const entry = body.entry?.[0];
      const messaging = entry?.messaging?.[0];

      if (!messaging) {
        return null;
      }

      const senderId = messaging.sender?.id;
      const messageId = messaging.message?.mid;
      let text = '';
      let type = 'unknown';

      // Обработка текстовых сообщений
      if (messaging.message?.text) {
        text = messaging.message.text;
        type = 'text';
      }
      // Обработка Quick Reply
      else if (messaging.message?.quick_reply) {
        text = messaging.message.quick_reply.payload;
        type = 'quick_reply';
      }
      // Обработка Postback (кнопки)
      else if (messaging.postback) {
        text = messaging.postback.payload;
        type = 'postback';
      }
      // Обработка вложений (изображения, стикеры)
      else if (messaging.message?.attachments) {
        const attachment = messaging.message.attachments[0];
        text = `[${attachment.type}]`;
        type = 'attachment';
      }

      if (!senderId || !text) {
        return null;
      }

      return { senderId, text, type, messageId };
    } catch (error) {
      this.logger.error('Error parsing Instagram webhook payload:', error);
      return null;
    }
  }

  /**
   * Получение информации о пользователе Instagram
   */
  async getUserProfile(userId: string): Promise<any> {
    try {
      const response = await this.apiClient.get(`/${userId}`, {
        params: {
          fields: 'name,profile_pic',
        },
      });

      return response.data;
    } catch (error) {
      this.logger.error(`Failed to get Instagram user profile for ${userId}:`, error.response?.data || error.message);
      return null;
    }
  }
}
