import { useState, useEffect } from 'react'
import { API_URL } from '../config/api'
import { 
  TrendingUp, 
  DollarSign, 
  Users, 
  Calendar,
  AlertTriangle,
  CheckCircle,
  Clock,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react'
import clsx from 'clsx'

interface DashboardData {
  hero: {
    revenue_today: number
    revenue_week: number
    revenue_month: number
    revenue_today_change: number
    revenue_week_change: number
    revenue_month_change: number
    appointments_today: number
    appointments_week: number
    new_clients_week: number
    avg_check: number
  }
  money_lost: {
    cancellations_amount: number
    cancellations_count: number
    no_shows_amount: number
    no_shows_count: number
    empty_slots_hours: number
    empty_slots_amount: number
    total_lost: number
  }
  money_recovered: {
    from_reminders: number
    from_reactivation: number
    from_upsells: number
    total_recovered: number
  }
  money_potential: {
    sleeping_clients_count: number
    sleeping_clients_potential: number
    overdue_clients_count: number
    overdue_clients_potential: number
    total_potential: number
  }
  health_score: number
  health_status: string
  staff_utilization: Array<{
    staff_id: number
    staff_name: string
    utilization_percent: number
    revenue: number
    appointments: number
    avg_check: number
  }>
}

function formatMoney(amount: number): string {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

function MetricCard({ 
  title, 
  value, 
  change, 
  icon: Icon, 
  color = 'primary' 
}: { 
  title: string
  value: string
  change?: number
  icon: React.ElementType
  color?: 'primary' | 'success' | 'warning' | 'danger'
}) {
  const colorClasses = {
    primary: 'bg-primary-50 text-primary-600',
    success: 'bg-green-50 text-green-600',
    warning: 'bg-amber-50 text-amber-600',
    danger: 'bg-red-50 text-red-600',
  }

  return (
    <div className="card">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-500 mb-1">{title}</p>
          <p className="text-2xl font-semibold text-gray-900">{value}</p>
          {change !== undefined && (
            <div className={clsx(
              "flex items-center gap-1 mt-2 text-sm",
              change >= 0 ? "text-green-600" : "text-red-600"
            )}>
              {change >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
              <span>{Math.abs(change).toFixed(1)}%</span>
              <span className="text-gray-400">vs прошлая неделя</span>
            </div>
          )}
        </div>
        <div className={clsx("p-3 rounded-lg", colorClasses[color])}>
          <Icon className="w-6 h-6" />
        </div>
      </div>
    </div>
  )
}

function HealthIndicator({ score, status }: { score: number; status: string }) {
  const statusColors = {
    green: { bg: 'bg-green-500', text: 'text-green-700', label: 'Отлично' },
    yellow: { bg: 'bg-amber-500', text: 'text-amber-700', label: 'Требует внимания' },
    red: { bg: 'bg-red-500', text: 'text-red-700', label: 'Критично' },
  }
  const colors = statusColors[status as keyof typeof statusColors] || statusColors.green

  return (
    <div className="card">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Здоровье бизнеса</h3>
      <div className="flex items-center gap-6">
        <div className="relative w-24 h-24">
          <svg className="w-24 h-24 transform -rotate-90">
            <circle
              cx="48"
              cy="48"
              r="40"
              stroke="#e5e7eb"
              strokeWidth="8"
              fill="none"
            />
            <circle
              cx="48"
              cy="48"
              r="40"
              stroke="currentColor"
              strokeWidth="8"
              fill="none"
              strokeDasharray={`${score * 2.51} 251`}
              className={colors.text}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-2xl font-bold text-gray-900">{score}</span>
          </div>
        </div>
        <div>
          <div className={clsx("inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium", 
            status === 'green' && "bg-green-100 text-green-700",
            status === 'yellow' && "bg-amber-100 text-amber-700",
            status === 'red' && "bg-red-100 text-red-700"
          )}>
            <div className={clsx("w-2 h-2 rounded-full", colors.bg)} />
            {colors.label}
          </div>
          <p className="text-sm text-gray-500 mt-2">
            Оценка на основе выручки, загрузки и retention
          </p>
        </div>
      </div>
    </div>
  )
}

function MoneyBlock({ 
  title, 
  items, 
  total, 
  type 
}: { 
  title: string
  items: Array<{ label: string; value: number; count?: number }>
  total: number
  type: 'lost' | 'recovered' | 'potential'
}) {
  const typeStyles = {
    lost: { bg: 'bg-red-50', border: 'border-red-200', text: 'text-red-700', icon: AlertTriangle },
    recovered: { bg: 'bg-green-50', border: 'border-green-200', text: 'text-green-700', icon: CheckCircle },
    potential: { bg: 'bg-amber-50', border: 'border-amber-200', text: 'text-amber-700', icon: Clock },
  }
  const styles = typeStyles[type]
  const Icon = styles.icon

  return (
    <div className={clsx("rounded-xl border p-5", styles.bg, styles.border)}>
      <div className="flex items-center gap-2 mb-4">
        <Icon className={clsx("w-5 h-5", styles.text)} />
        <h3 className="font-semibold text-gray-900">{title}</h3>
      </div>
      <div className="space-y-3">
        {items.map((item, i) => (
          <div key={i} className="flex justify-between items-center">
            <span className="text-sm text-gray-600">
              {item.label}
              {item.count !== undefined && (
                <span className="text-gray-400 ml-1">({item.count})</span>
              )}
            </span>
            <span className={clsx("font-medium", styles.text)}>
              {formatMoney(item.value)}
            </span>
          </div>
        ))}
      </div>
      <div className="mt-4 pt-4 border-t border-gray-200">
        <div className="flex justify-between items-center">
          <span className="font-medium text-gray-900">Итого</span>
          <span className={clsx("text-xl font-bold", styles.text)}>
            {formatMoney(total)}
          </span>
        </div>
      </div>
    </div>
  )
}

export default function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch(`${API_URL}/api/v1/dashboard/overview`)
      .then(res => res.json())
      .then(data => {
        setData(data)
        setLoading(false)
      })
      .catch(err => {
        console.error('Error fetching dashboard:', err)
        setLoading(false)
      })
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Не удалось загрузить данные</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Дашборд</h1>
          <p className="text-gray-500 mt-1">Обзор бизнеса за сегодня</p>
        </div>
        <div className="flex items-center gap-3">
          <select className="input w-40">
            <option>Сегодня</option>
            <option>Эта неделя</option>
            <option>Этот месяц</option>
          </select>
        </div>
      </div>

      {/* Hero Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Выручка сегодня"
          value={formatMoney(data.hero.revenue_today)}
          change={data.hero.revenue_today_change}
          icon={DollarSign}
          color="success"
        />
        <MetricCard
          title="Записей сегодня"
          value={data.hero.appointments_today.toString()}
          icon={Calendar}
          color="primary"
        />
        <MetricCard
          title="Новых клиентов"
          value={data.hero.new_clients_week.toString()}
          icon={Users}
          color="primary"
        />
        <MetricCard
          title="Средний чек"
          value={formatMoney(data.hero.avg_check)}
          icon={TrendingUp}
          color="primary"
        />
      </div>

      {/* Health Score + Money Blocks */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        <HealthIndicator score={data.health_score} status={data.health_status} />
        
        <MoneyBlock
          title="Потеряно денег"
          type="lost"
          items={[
            { label: 'Отмены', value: data.money_lost.cancellations_amount, count: data.money_lost.cancellations_count },
            { label: 'Неявки', value: data.money_lost.no_shows_amount, count: data.money_lost.no_shows_count },
            { label: 'Пустые слоты', value: data.money_lost.empty_slots_amount },
          ]}
          total={data.money_lost.total_lost}
        />

        <MoneyBlock
          title="Возвращено"
          type="recovered"
          items={[
            { label: 'Напоминания', value: data.money_recovered.from_reminders },
            { label: 'Реактивация', value: data.money_recovered.from_reactivation },
            { label: 'Допродажи', value: data.money_recovered.from_upsells },
          ]}
          total={data.money_recovered.total_recovered}
        />

        <MoneyBlock
          title="Можно вернуть"
          type="potential"
          items={[
            { label: 'Спящие клиенты', value: data.money_potential.sleeping_clients_potential, count: data.money_potential.sleeping_clients_count },
            { label: 'Просроченные', value: data.money_potential.overdue_clients_potential, count: data.money_potential.overdue_clients_count },
          ]}
          total={data.money_potential.total_potential}
        />
      </div>

      {/* Staff Utilization */}
      {data.staff_utilization.length > 0 && (
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Загрузка мастеров</h3>
          <div className="space-y-4">
            {data.staff_utilization.map((staff) => (
              <div key={staff.staff_id} className="flex items-center gap-4">
                <div className="w-32 text-sm font-medium text-gray-900 truncate">
                  {staff.staff_name}
                </div>
                <div className="flex-1">
                  <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className={clsx(
                        "h-full rounded-full transition-all",
                        staff.utilization_percent >= 70 ? "bg-green-500" :
                        staff.utilization_percent >= 40 ? "bg-amber-500" : "bg-red-500"
                      )}
                      style={{ width: `${staff.utilization_percent}%` }}
                    />
                  </div>
                </div>
                <div className="w-16 text-sm text-gray-600 text-right">
                  {staff.utilization_percent}%
                </div>
                <div className="w-24 text-sm text-gray-500 text-right">
                  {formatMoney(staff.revenue)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
