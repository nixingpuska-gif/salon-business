"""
Business OS - Inventory Models
Модели для учёта расходников и склада
"""

from datetime import datetime, date
from typing import Optional
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, BigInteger, 
    DateTime, Date, Numeric, ForeignKey, JSON, Index
)
from sqlalchemy.orm import relationship
import enum

from app.models.base import TenantBaseModel


class InventoryCategory(TenantBaseModel):
    """
    Категория расходников.
    """
    __tablename__ = "inventory_categories"
    
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    parent_id = Column(BigInteger, ForeignKey("inventory_categories.id"), nullable=True)
    
    sort_order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)


class InventoryItem(TenantBaseModel):
    """
    Расходник/товар на складе.
    """
    __tablename__ = "inventory_items"
    
    # === Привязка ===
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=True)  # null = общий склад
    category_id = Column(BigInteger, ForeignKey("inventory_categories.id"), nullable=True)
    
    # === Основная информация ===
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    sku = Column(String(100), nullable=True, index=True)  # Артикул
    barcode = Column(String(100), nullable=True, index=True)
    
    # === Единицы измерения ===
    unit = Column(String(20), default="шт")  # шт, мл, г, упак
    unit_in_package = Column(Numeric(10, 2), default=1)  # Сколько единиц в упаковке
    
    # === Цены ===
    purchase_price = Column(Numeric(10, 2), nullable=True)  # Закупочная цена
    retail_price = Column(Numeric(10, 2), nullable=True)  # Розничная цена (если продаётся)
    
    # === Остатки ===
    quantity = Column(Numeric(10, 3), default=0)  # Текущий остаток
    reserved_quantity = Column(Numeric(10, 3), default=0)  # Зарезервировано
    
    # === Минимумы ===
    min_quantity = Column(Numeric(10, 3), default=0)  # Минимальный остаток
    reorder_quantity = Column(Numeric(10, 3), nullable=True)  # Сколько заказывать
    
    # === Расход на услугу ===
    consumption_per_service = Column(Numeric(10, 4), nullable=True)  # Расход на 1 услугу
    linked_services = Column(JSON, default=list)
    # [{"service_id": 1, "quantity": 0.5}, ...]
    
    # === Поставщик ===
    supplier_id = Column(BigInteger, nullable=True)
    supplier_sku = Column(String(100), nullable=True)
    
    # === Срок годности ===
    has_expiry = Column(Boolean, default=False)
    default_expiry_days = Column(Integer, nullable=True)
    
    # === Изображение ===
    image_url = Column(String(500), nullable=True)
    
    # === Статус ===
    is_active = Column(Boolean, default=True)
    is_sellable = Column(Boolean, default=False)  # Можно продавать клиентам
    
    # === Статистика ===
    total_consumed = Column(Numeric(12, 3), default=0)
    total_purchased = Column(Numeric(12, 3), default=0)
    avg_monthly_consumption = Column(Numeric(10, 3), default=0)
    
    # === Последние операции ===
    last_purchase_at = Column(DateTime, nullable=True)
    last_purchase_price = Column(Numeric(10, 2), nullable=True)
    last_consumed_at = Column(DateTime, nullable=True)
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_inventory_items_tenant_branch', 'tenant_id', 'branch_id'),
        Index('ix_inventory_items_tenant_category', 'tenant_id', 'category_id'),
    )


class InventoryBatch(TenantBaseModel):
    """
    Партия товара.
    Для учёта сроков годности и партионного учёта.
    """
    __tablename__ = "inventory_batches"
    
    item_id = Column(BigInteger, ForeignKey("inventory_items.id"), nullable=False, index=True)
    
    # === Партия ===
    batch_number = Column(String(100), nullable=True)
    
    # === Количество ===
    initial_quantity = Column(Numeric(10, 3), nullable=False)
    current_quantity = Column(Numeric(10, 3), nullable=False)
    
    # === Цена закупки ===
    purchase_price = Column(Numeric(10, 2), nullable=True)
    
    # === Даты ===
    received_at = Column(DateTime, default=datetime.utcnow)
    expiry_date = Column(Date, nullable=True)
    
    # === Поставка ===
    supply_id = Column(BigInteger, nullable=True)


class InventorySupply(TenantBaseModel):
    """
    Поставка расходников.
    """
    __tablename__ = "inventory_supplies"
    
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=True)
    
    # === Поставщик ===
    supplier_id = Column(BigInteger, nullable=True)
    supplier_name = Column(String(255), nullable=True)
    
    # === Документ ===
    document_number = Column(String(100), nullable=True)
    document_date = Column(Date, nullable=True)
    document_url = Column(String(500), nullable=True)
    
    # === Суммы ===
    total_amount = Column(Numeric(12, 2), default=0)
    
    # === Статус ===
    status = Column(String(50), default="received")  # pending, received, cancelled
    
    # === Даты ===
    received_at = Column(DateTime, nullable=True)
    received_by_id = Column(BigInteger, nullable=True)
    
    # === AI-обработка ===
    ai_processed = Column(Boolean, default=False)
    ai_source = Column(String(50), nullable=True)  # photo, text, document
    ai_raw_input = Column(Text, nullable=True)  # Исходный текст/URL фото
    ai_confidence = Column(Numeric(5, 2), nullable=True)  # Уверенность AI
    
    # === Комментарий ===
    notes = Column(Text, nullable=True)
    
    # === Relationships ===
    items = relationship("InventorySupplyItem", back_populates="supply", lazy="dynamic")


class InventorySupplyItem(TenantBaseModel):
    """
    Позиция в поставке.
    """
    __tablename__ = "inventory_supply_items"
    
    supply_id = Column(BigInteger, ForeignKey("inventory_supplies.id"), nullable=False, index=True)
    item_id = Column(BigInteger, ForeignKey("inventory_items.id"), nullable=False)
    
    # === Количество ===
    quantity = Column(Numeric(10, 3), nullable=False)
    
    # === Цена ===
    unit_price = Column(Numeric(10, 2), nullable=True)
    total_price = Column(Numeric(10, 2), nullable=True)
    
    # === Партия ===
    batch_number = Column(String(100), nullable=True)
    expiry_date = Column(Date, nullable=True)
    
    # === AI-распознавание ===
    ai_matched = Column(Boolean, default=False)  # AI сопоставил с товаром
    ai_suggested_item_id = Column(BigInteger, nullable=True)  # Предложение AI
    ai_confidence = Column(Numeric(5, 2), nullable=True)
    
    # === Relationships ===
    supply = relationship("InventorySupply", back_populates="items")


class InventoryConsumption(TenantBaseModel):
    """
    Списание расходников.
    """
    __tablename__ = "inventory_consumptions"
    
    item_id = Column(BigInteger, ForeignKey("inventory_items.id"), nullable=False, index=True)
    batch_id = Column(BigInteger, ForeignKey("inventory_batches.id"), nullable=True)
    
    # === Привязка к услуге ===
    appointment_id = Column(BigInteger, ForeignKey("appointments.id"), nullable=True)
    service_id = Column(BigInteger, nullable=True)
    staff_id = Column(BigInteger, nullable=True)
    
    # === Количество ===
    quantity = Column(Numeric(10, 4), nullable=False)
    
    # === Тип списания ===
    consumption_type = Column(String(50), default="service")
    # service - на услугу, manual - ручное, loss - потери, expired - просрочка
    
    # === Стоимость ===
    cost = Column(Numeric(10, 2), nullable=True)  # Себестоимость списанного
    
    # === Комментарий ===
    reason = Column(String(255), nullable=True)
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_inventory_consumptions_tenant_item', 'tenant_id', 'item_id'),
        Index('ix_inventory_consumptions_tenant_date', 'tenant_id', 'created_at'),
    )


class InventoryAudit(TenantBaseModel):
    """
    Инвентаризация.
    """
    __tablename__ = "inventory_audits"
    
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=True)
    
    # === Период ===
    started_at = Column(DateTime, nullable=False)
    completed_at = Column(DateTime, nullable=True)
    
    # === Кто проводил ===
    conducted_by_id = Column(BigInteger, nullable=False)
    
    # === Статус ===
    status = Column(String(50), default="in_progress")  # in_progress, completed, cancelled
    
    # === Результаты ===
    total_items_checked = Column(Integer, default=0)
    items_with_discrepancy = Column(Integer, default=0)
    total_discrepancy_value = Column(Numeric(12, 2), default=0)
    
    # === Комментарий ===
    notes = Column(Text, nullable=True)


class InventoryAuditItem(TenantBaseModel):
    """
    Позиция инвентаризации.
    """
    __tablename__ = "inventory_audit_items"
    
    audit_id = Column(BigInteger, ForeignKey("inventory_audits.id"), nullable=False, index=True)
    item_id = Column(BigInteger, ForeignKey("inventory_items.id"), nullable=False)
    
    # === Количество ===
    expected_quantity = Column(Numeric(10, 3), nullable=False)  # По системе
    actual_quantity = Column(Numeric(10, 3), nullable=True)  # Фактическое
    discrepancy = Column(Numeric(10, 3), nullable=True)  # Расхождение
    
    # === Стоимость расхождения ===
    discrepancy_value = Column(Numeric(10, 2), nullable=True)
    
    # === Причина расхождения ===
    discrepancy_reason = Column(String(255), nullable=True)


class Supplier(TenantBaseModel):
    """
    Поставщик.
    """
    __tablename__ = "suppliers"
    
    # === Основная информация ===
    name = Column(String(255), nullable=False)
    contact_person = Column(String(255), nullable=True)
    
    # === Контакты ===
    phone = Column(String(50), nullable=True)
    email = Column(String(255), nullable=True)
    website = Column(String(255), nullable=True)
    
    # === Адрес ===
    address = Column(Text, nullable=True)
    
    # === Реквизиты ===
    inn = Column(String(20), nullable=True)
    bank_details = Column(Text, nullable=True)
    
    # === Условия ===
    payment_terms = Column(String(255), nullable=True)  # Условия оплаты
    delivery_terms = Column(String(255), nullable=True)  # Условия доставки
    min_order_amount = Column(Numeric(10, 2), nullable=True)
    
    # === Статистика ===
    total_orders = Column(Integer, default=0)
    total_amount = Column(Numeric(12, 2), default=0)
    avg_delivery_days = Column(Numeric(5, 1), nullable=True)
    
    # === Рейтинг ===
    rating = Column(Numeric(3, 2), nullable=True)
    
    # === Статус ===
    is_active = Column(Boolean, default=True)
    
    # === Заметки ===
    notes = Column(Text, nullable=True)
