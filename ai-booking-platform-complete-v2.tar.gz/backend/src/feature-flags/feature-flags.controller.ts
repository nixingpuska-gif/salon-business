import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  HttpStatus,
  HttpException,
} from '@nestjs/common';
import { FeatureFlagsService, Feature } from './feature-flags.service';

/**
 * Feature Flags Controller
 * 
 * API endpoints для управления feature flags
 */
@Controller('feature-flags')
export class FeatureFlagsController {
  constructor(private featureFlags: FeatureFlagsService) {}

  /**
   * GET /feature-flags/plans - Получить все тарифные планы
   */
  @Get('plans')
  async getAllPlans() {
    try {
      const plans = this.featureFlags.getAllPlans();

      return {
        success: true,
        data: plans,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get plans',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /feature-flags/business/:businessId - Получить подписку бизнеса
   */
  @Get('business/:businessId')
  async getBusinessSubscription(@Param('businessId') businessId: string) {
    try {
      const subscription = await this.featureFlags.getBusinessSubscription(
        businessId,
      );
      const plan = this.featureFlags.getPlan(subscription.tier);

      return {
        success: true,
        data: {
          ...subscription,
          plan,
        },
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get subscription',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /feature-flags/check-feature - Проверить доступ к функции
   */
  @Post('check-feature')
  async checkFeature(
    @Body() body: { businessId: string; feature: Feature },
  ) {
    try {
      const hasAccess = await this.featureFlags.hasFeature(
        body.businessId,
        body.feature,
      );

      return {
        success: true,
        hasAccess,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to check feature',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /feature-flags/business/:businessId/usage - Получить использование лимитов
   */
  @Get('business/:businessId/usage')
  async getUsageStats(@Param('businessId') businessId: string) {
    try {
      const usage = await this.featureFlags.getUsageStats(businessId);
      const subscription = await this.featureFlags.getBusinessSubscription(
        businessId,
      );
      const plan = this.featureFlags.getPlan(subscription.tier);

      // Сравнить с лимитами
      const limits = plan.limits;
      const usageWithLimits = {
        bookings: {
          current: usage.bookings,
          limit: limits.maxBookingsPerMonth,
          percentage:
            limits.maxBookingsPerMonth === -1
              ? 0
              : Math.round((usage.bookings / limits.maxBookingsPerMonth) * 100),
        },
        clients: {
          current: usage.clients,
          limit: limits.maxClients,
          percentage:
            limits.maxClients === -1
              ? 0
              : Math.round((usage.clients / limits.maxClients) * 100),
        },
        services: {
          current: usage.services,
          limit: limits.maxServices,
          percentage:
            limits.maxServices === -1
              ? 0
              : Math.round((usage.services / limits.maxServices) * 100),
        },
        staff: {
          current: usage.staff,
          limit: limits.maxStaff,
          percentage:
            limits.maxStaff === -1
              ? 0
              : Math.round((usage.staff / limits.maxStaff) * 100),
        },
        locations: {
          current: usage.locations,
          limit: limits.maxLocations,
          percentage:
            limits.maxLocations === -1
              ? 0
              : Math.round((usage.locations / limits.maxLocations) * 100),
        },
        smmPosts: {
          current: usage.smmPosts,
          limit: limits.maxSMMPostsPerMonth,
          percentage:
            limits.maxSMMPostsPerMonth === -1
              ? 0
              : Math.round((usage.smmPosts / limits.maxSMMPostsPerMonth) * 100),
        },
      };

      return {
        success: true,
        data: usageWithLimits,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get usage stats',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /feature-flags/business/:businessId/recommended-upgrade - Получить рекомендацию по upgrade
   */
  @Get('business/:businessId/recommended-upgrade')
  async getRecommendedUpgrade(@Param('businessId') businessId: string) {
    try {
      const recommendation = await this.featureFlags.getRecommendedUpgrade(
        businessId,
      );

      const currentPlan = this.featureFlags.getPlan(recommendation.currentTier);
      const recommendedPlan = this.featureFlags.getPlan(
        recommendation.recommendedTier,
      );

      return {
        success: true,
        data: {
          ...recommendation,
          currentPlan,
          recommendedPlan,
        },
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get recommendation',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /feature-flags/can-perform-action - Проверить возможность выполнения действия
   */
  @Post('can-perform-action')
  async canPerformAction(
    @Body()
    body: {
      businessId: string;
      feature?: Feature;
      limitType?: string;
    },
  ) {
    try {
      const result = await this.featureFlags.canPerformAction(body.businessId, {
        feature: body.feature,
        limitType: body.limitType as any,
      });

      return {
        success: true,
        data: result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to check action',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
