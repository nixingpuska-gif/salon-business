import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

/**
 * Scenario Service
 * 
 * Управление сценариями диалогов для клиентских ботов:
 * - Кастомизация промптов (Pro уровень)
 * - Настройка обязательных вопросов
 * - Порядок вопросов
 * - Тон общения
 * - Шаблоны ответов
 */

export interface ConversationScenario {
  id: string;
  businessId: string;
  name: string;
  description?: string;
  isActive: boolean;
  
  // Системный промпт для AI
  systemPrompt: string;
  
  // Тон общения
  tone: 'formal' | 'friendly' | 'professional' | 'casual';
  
  // Обязательные поля для сбора
  requiredFields: Array<{
    field: 'name' | 'phone' | 'email' | 'custom';
    customFieldName?: string;
    question: string;
    validation?: string;
    order: number;
  }>;
  
  // Приветственное сообщение
  welcomeMessage: string;
  
  // Сообщение при завершении записи
  bookingConfirmationTemplate: string;
  
  // Сообщение при ошибке
  errorMessage: string;
  
  // Часто задаваемые вопросы
  faq: Array<{
    question: string;
    answer: string;
  }>;
  
  // Дополнительные настройки
  settings: {
    askForFeedback: boolean;
    sendReminders: boolean;
    allowRescheduling: boolean;
    allowCancellation: boolean;
    maxReschedulesPerBooking: number;
  };
  
  createdAt: Date;
  updatedAt: Date;
}

export const DEFAULT_SCENARIOS = {
  formal: {
    name: 'Формальный стиль',
    systemPrompt: `Вы — профессиональный администратор салона красоты. Общайтесь вежливо на "Вы", используйте деловой тон. Помогайте клиентам записаться, перенести или отменить запись. Будьте точны и конкретны в ответах.`,
    tone: 'formal' as const,
    welcomeMessage: 'Добрый день! Я администратор салона. Чем могу Вам помочь?',
    bookingConfirmationTemplate: 'Ваша запись подтверждена на {date} в {time}. Услуга: {service}. Ждём Вас по адресу: {address}.',
    errorMessage: 'Приношу извинения, произошла ошибка. Пожалуйста, попробуйте ещё раз или свяжитесь с нами по телефону.',
  },
  friendly: {
    name: 'Дружелюбный стиль',
    systemPrompt: `Вы — дружелюбный AI-помощник салона красоты. Общайтесь тепло и по-дружески, но профессионально. Используйте эмодзи умеренно. Помогайте клиентам с записью, будьте позитивны и отзывчивы.`,
    tone: 'friendly' as const,
    welcomeMessage: 'Привет! 👋 Рада помочь с записью! Что тебя интересует?',
    bookingConfirmationTemplate: 'Отлично! 🎉 Ты записан(а) на {date} в {time}. {service} — будет супер! Жду тебя: {address} ✨',
    errorMessage: 'Ой, что-то пошло не так 😅 Давай попробуем ещё раз?',
  },
  professional: {
    name: 'Профессиональный стиль',
    systemPrompt: `Вы — опытный администратор с многолетним стажем. Общайтесь профессионально, но тепло. Предлагайте дополнительные услуги, когда уместно. Помогайте клиентам сделать лучший выбор.`,
    tone: 'professional' as const,
    welcomeMessage: 'Здравствуйте! Я помогу Вам с записью. Какая услуга Вас интересует?',
    bookingConfirmationTemplate: 'Запись успешно создана: {date} в {time}, услуга "{service}". Мы находимся по адресу: {address}. До встречи!',
    errorMessage: 'К сожалению, возникла техническая проблема. Пожалуйста, повторите попытку.',
  },
};

@Injectable()
export class ScenarioService {
  constructor(private prisma: PrismaService) {}

  /**
   * Получить активный сценарий для бизнеса
   */
  async getActiveScenario(businessId: string): Promise<ConversationScenario | null> {
    const scenario = await this.prisma.conversationScenario.findFirst({
      where: {
        businessId,
        isActive: true,
      },
    });

    if (!scenario) return null;

    return this.mapToScenario(scenario);
  }

  /**
   * Получить все сценарии бизнеса
   */
  async getScenarios(businessId: string): Promise<ConversationScenario[]> {
    const scenarios = await this.prisma.conversationScenario.findMany({
      where: { businessId },
      orderBy: { createdAt: 'desc' },
    });

    return scenarios.map((s) => this.mapToScenario(s));
  }

  /**
   * Создать сценарий
   */
  async createScenario(
    businessId: string,
    data: Omit<ConversationScenario, 'id' | 'businessId' | 'createdAt' | 'updatedAt'>,
  ): Promise<ConversationScenario> {
    // Если новый сценарий активный, деактивировать остальные
    if (data.isActive) {
      await this.prisma.conversationScenario.updateMany({
        where: { businessId, isActive: true },
        data: { isActive: false },
      });
    }

    const scenario = await this.prisma.conversationScenario.create({
      data: {
        businessId,
        name: data.name,
        description: data.description,
        isActive: data.isActive,
        systemPrompt: data.systemPrompt,
        tone: data.tone,
        requiredFields: data.requiredFields,
        welcomeMessage: data.welcomeMessage,
        bookingConfirmationTemplate: data.bookingConfirmationTemplate,
        errorMessage: data.errorMessage,
        faq: data.faq,
        settings: data.settings,
      },
    });

    return this.mapToScenario(scenario);
  }

  /**
   * Обновить сценарий
   */
  async updateScenario(
    scenarioId: string,
    businessId: string,
    updates: Partial<Omit<ConversationScenario, 'id' | 'businessId' | 'createdAt' | 'updatedAt'>>,
  ): Promise<ConversationScenario> {
    // Если делаем сценарий активным, деактивировать остальные
    if (updates.isActive) {
      await this.prisma.conversationScenario.updateMany({
        where: { businessId, isActive: true, id: { not: scenarioId } },
        data: { isActive: false },
      });
    }

    const scenario = await this.prisma.conversationScenario.update({
      where: { id: scenarioId, businessId },
      data: updates,
    });

    return this.mapToScenario(scenario);
  }

  /**
   * Удалить сценарий
   */
  async deleteScenario(scenarioId: string, businessId: string): Promise<void> {
    await this.prisma.conversationScenario.delete({
      where: { id: scenarioId, businessId },
    });
  }

  /**
   * Активировать сценарий
   */
  async activateScenario(scenarioId: string, businessId: string): Promise<void> {
    // Деактивировать все остальные
    await this.prisma.conversationScenario.updateMany({
      where: { businessId, isActive: true },
      data: { isActive: false },
    });

    // Активировать выбранный
    await this.prisma.conversationScenario.update({
      where: { id: scenarioId, businessId },
      data: { isActive: true },
    });
  }

  /**
   * Создать сценарий по умолчанию
   */
  async createDefaultScenario(
    businessId: string,
    template: keyof typeof DEFAULT_SCENARIOS = 'friendly',
  ): Promise<ConversationScenario> {
    const defaultTemplate = DEFAULT_SCENARIOS[template];

    return this.createScenario(businessId, {
      name: defaultTemplate.name,
      description: 'Сценарий по умолчанию',
      isActive: true,
      systemPrompt: defaultTemplate.systemPrompt,
      tone: defaultTemplate.tone,
      requiredFields: [
        {
          field: 'name',
          question: 'Как Вас зовут?',
          order: 1,
        },
        {
          field: 'phone',
          question: 'Укажите номер телефона для связи',
          validation: 'phone',
          order: 2,
        },
      ],
      welcomeMessage: defaultTemplate.welcomeMessage,
      bookingConfirmationTemplate: defaultTemplate.bookingConfirmationTemplate,
      errorMessage: defaultTemplate.errorMessage,
      faq: [
        {
          question: 'Где вы находитесь?',
          answer: 'Мы находимся по адресу: {business.address}',
        },
        {
          question: 'Какие у вас цены?',
          answer: 'Цены зависят от услуги. Могу показать прайс-лист?',
        },
      ],
      settings: {
        askForFeedback: true,
        sendReminders: true,
        allowRescheduling: true,
        allowCancellation: true,
        maxReschedulesPerBooking: 2,
      },
    });
  }

  /**
   * Получить системный промпт с подстановкой данных
   */
  async getSystemPromptWithContext(
    businessId: string,
    businessInfo?: any,
  ): Promise<string> {
    const scenario = await this.getActiveScenario(businessId);
    if (!scenario) {
      // Использовать дефолтный промпт
      return DEFAULT_SCENARIOS.friendly.systemPrompt;
    }

    let prompt = scenario.systemPrompt;

    // Добавить информацию о бизнесе
    if (businessInfo) {
      prompt += `\n\nИнформация о бизнесе:\n`;
      prompt += `- Название: ${businessInfo.name}\n`;
      if (businessInfo.address) prompt += `- Адрес: ${businessInfo.address}\n`;
      if (businessInfo.phone) prompt += `- Телефон: ${businessInfo.phone}\n`;
      if (businessInfo.workingHours) prompt += `- Режим работы: ${businessInfo.workingHours}\n`;
    }

    // Добавить FAQ
    if (scenario.faq && scenario.faq.length > 0) {
      prompt += `\n\nЧасто задаваемые вопросы:\n`;
      scenario.faq.forEach((item) => {
        prompt += `Q: ${item.question}\nA: ${item.answer}\n\n`;
      });
    }

    // Добавить правила сбора данных
    if (scenario.requiredFields && scenario.requiredFields.length > 0) {
      prompt += `\n\nОбязательные поля для сбора:\n`;
      scenario.requiredFields
        .sort((a, b) => a.order - b.order)
        .forEach((field) => {
          prompt += `- ${field.field}: ${field.question}\n`;
        });
    }

    return prompt;
  }

  /**
   * Форматировать сообщение с подстановкой переменных
   */
  formatMessage(
    template: string,
    variables: Record<string, any>,
  ): string {
    let message = template;

    Object.keys(variables).forEach((key) => {
      const regex = new RegExp(`\\{${key}\\}`, 'g');
      message = message.replace(regex, variables[key] || '');
    });

    return message;
  }

  /**
   * Проверить, все ли обязательные поля собраны
   */
  async checkRequiredFields(
    businessId: string,
    extractedData: Record<string, any>,
  ): Promise<{
    allCollected: boolean;
    missingFields: Array<{ field: string; question: string }>;
  }> {
    const scenario = await this.getActiveScenario(businessId);
    if (!scenario || !scenario.requiredFields) {
      return { allCollected: true, missingFields: [] };
    }

    const missingFields = scenario.requiredFields
      .filter((field) => {
        const fieldName = field.field === 'custom' ? field.customFieldName : field.field;
        return !extractedData[fieldName];
      })
      .map((field) => ({
        field: field.field === 'custom' ? field.customFieldName : field.field,
        question: field.question,
      }));

    return {
      allCollected: missingFields.length === 0,
      missingFields,
    };
  }

  /**
   * Преобразовать из Prisma модели в ConversationScenario
   */
  private mapToScenario(scenario: any): ConversationScenario {
    return {
      id: scenario.id,
      businessId: scenario.businessId,
      name: scenario.name,
      description: scenario.description,
      isActive: scenario.isActive,
      systemPrompt: scenario.systemPrompt,
      tone: scenario.tone,
      requiredFields: scenario.requiredFields as any,
      welcomeMessage: scenario.welcomeMessage,
      bookingConfirmationTemplate: scenario.bookingConfirmationTemplate,
      errorMessage: scenario.errorMessage,
      faq: scenario.faq as any,
      settings: scenario.settings as any,
      createdAt: scenario.createdAt,
      updatedAt: scenario.updatedAt,
    };
  }
}
