import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ScheduleService } from './schedule.service';
import { CreateWorkingHoursDto } from './dto/create-working-hours.dto';
import { CreateBreakDto } from './dto/create-break.dto';
import { CreateVacationDto } from './dto/create-vacation.dto';
import { GenerateSlotsDto } from './dto/generate-slots.dto';

@Controller('schedules')
export class ScheduleController {
  constructor(private readonly scheduleService: ScheduleService) {}

  @Post('working-hours')
  @HttpCode(HttpStatus.CREATED)
  async createWorkingHours(@Body() dto: CreateWorkingHoursDto) {
    return this.scheduleService.createWorkingHours(dto.businessId, {
      daysOfWeek: dto.daysOfWeek,
      startTime: dto.startTime,
      endTime: dto.endTime,
      startDate: dto.startDate ? new Date(dto.startDate) : undefined,
      endDate: dto.endDate ? new Date(dto.endDate) : undefined,
    });
  }

  @Post('breaks')
  @HttpCode(HttpStatus.CREATED)
  async createBreak(@Body() dto: CreateBreakDto) {
    return this.scheduleService.createBreak(dto.businessId, {
      daysOfWeek: dto.daysOfWeek,
      startTime: dto.startTime,
      endTime: dto.endTime,
      startDate: dto.startDate ? new Date(dto.startDate) : undefined,
      endDate: dto.endDate ? new Date(dto.endDate) : undefined,
    });
  }

  @Post('vacations')
  @HttpCode(HttpStatus.CREATED)
  async createVacation(@Body() dto: CreateVacationDto) {
    return this.scheduleService.createVacation(dto.businessId, {
      startDate: new Date(dto.startDate),
      endDate: new Date(dto.endDate),
      type: dto.type,
    });
  }

  @Post('slots')
  @HttpCode(HttpStatus.OK)
  async generateSlots(@Body() dto: GenerateSlotsDto) {
    return this.scheduleService.generateSlots(
      dto.businessId,
      new Date(dto.date),
      dto.serviceDurationMinutes,
      dto.slotIntervalMinutes,
    );
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    return this.scheduleService.findOne(id);
  }

  @Get()
  async findByBusiness(
    @Query('businessId') businessId: string,
    @Query('type') type?: string,
  ) {
    return this.scheduleService.findByBusiness(businessId, type);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  async delete(@Param('id') id: string) {
    await this.scheduleService.delete(id);
  }
}
