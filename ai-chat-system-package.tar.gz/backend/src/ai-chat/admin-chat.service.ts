import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { ConversationContextService } from './conversation-context.service';
import { ScenarioService } from './scenario.service';
import { PrismaService } from '../prisma/prisma.service';
import { LoggerService } from '../monitoring/logger.service';

/**
 * Admin Chat Service
 * 
 * AI-чат бот для владельцев бизнеса:
 * - Запрос статистики и аналитики
 * - Управление записями
 * - Настройка сценариев для клиентского бота
 * - Управление услугами и расписанием
 * - Просмотр информации о клиентах
 */

interface AdminChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

@Injectable()
export class AdminChatService {
  private openai: OpenAI;

  constructor(
    private configService: ConfigService,
    private contextService: ConversationContextService,
    private scenarioService: ScenarioService,
    private prisma: PrismaService,
    private logger: LoggerService,
  ) {
    this.openai = new OpenAI({
      apiKey: this.configService.get<string>('OPENAI_API_KEY'),
    });
    this.logger.setContext('AdminChatService');
  }

  /**
   * Обработать сообщение от админа
   */
  async processMessage(
    businessId: string,
    userId: string,
    message: string,
    channel: string,
    channelUserId: string,
  ): Promise<string> {
    try {
      // Получить или создать контекст
      const context = await this.contextService.getOrCreateContext(
        businessId,
        channel,
        channelUserId,
      );

      // Добавить сообщение пользователя
      await this.contextService.addMessage(context.conversationId, 'user', message);

      // Получить информацию о бизнесе
      const business = await this.prisma.business.findUnique({
        where: { id: businessId },
      });

      // Построить системный промпт
      const systemPrompt = this.buildAdminSystemPrompt(business);

      // Построить историю сообщений
      const messages: AdminChatMessage[] = [
        { role: 'system', content: systemPrompt },
        ...context.messages.map((m) => ({
          role: m.role,
          content: m.content,
        })),
        { role: 'user', content: message },
      ];

      // Вызвать OpenAI с function calling
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4-turbo-preview',
        messages: messages as any,
        functions: this.getAdminFunctions(),
        function_call: 'auto',
        temperature: 0.7,
      });

      const assistantMessage = response.choices[0].message;

      // Если AI вызывает функцию
      if (assistantMessage.function_call) {
        const functionName = assistantMessage.function_call.name;
        const functionArgs = JSON.parse(assistantMessage.function_call.arguments);

        this.logger.log(`Admin function call: ${functionName}`, undefined, { args: functionArgs });

        // Выполнить функцию
        const functionResult = await this.executeAdminFunction(
          businessId,
          functionName,
          functionArgs,
        );

        // Отправить результат обратно в AI
        const secondResponse = await this.openai.chat.completions.create({
          model: 'gpt-4-turbo-preview',
          messages: [
            ...messages,
            assistantMessage,
            {
              role: 'function',
              name: functionName,
              content: JSON.stringify(functionResult),
            },
          ] as any,
          temperature: 0.7,
        });

        const finalMessage = secondResponse.choices[0].message.content;

        // Сохранить ответ
        await this.contextService.addMessage(
          context.conversationId,
          'assistant',
          finalMessage,
        );

        return finalMessage;
      }

      // Если AI просто отвечает
      const reply = assistantMessage.content;

      // Сохранить ответ
      await this.contextService.addMessage(context.conversationId, 'assistant', reply);

      return reply;
    } catch (error) {
      this.logger.logError(error, 'AdminChatService', { businessId, message });
      return 'Извините, произошла ошибка. Пожалуйста, попробуйте ещё раз.';
    }
  }

  /**
   * Построить системный промпт для админ-бота
   */
  private buildAdminSystemPrompt(business: any): string {
    return `Вы — персональный AI-ассистент для владельца бизнеса "${business?.name || 'бизнес'}".

Ваши возможности:
1. Показывать статистику (записи, клиенты, доход)
2. Управлять записями (просмотр, создание, отмена)
3. Настраивать сценарии диалогов для клиентского бота
4. Управлять услугами и расписанием
5. Просматривать информацию о клиентах
6. Давать рекомендации по улучшению бизнеса

Будьте проактивны, предлагайте улучшения и помогайте владельцу принимать решения на основе данных.

Когда нужно получить данные, используйте доступные функции. Всегда форматируйте ответы понятно и структурированно.`;
  }

  /**
   * Получить список функций для админ-бота
   */
  private getAdminFunctions(): any[] {
    return [
      {
        name: 'get_statistics',
        description: 'Получить статистику бизнеса (записи, клиенты, доход)',
        parameters: {
          type: 'object',
          properties: {
            period: {
              type: 'string',
              enum: ['today', 'week', 'month', 'year'],
              description: 'Период для статистики',
            },
            metrics: {
              type: 'array',
              items: { type: 'string' },
              description: 'Метрики: bookings, clients, revenue, services',
            },
          },
          required: ['period'],
        },
      },
      {
        name: 'get_bookings',
        description: 'Получить список записей',
        parameters: {
          type: 'object',
          properties: {
            date: {
              type: 'string',
              description: 'Дата в формате YYYY-MM-DD',
            },
            status: {
              type: 'string',
              enum: ['all', 'confirmed', 'completed', 'cancelled'],
            },
            limit: {
              type: 'number',
              description: 'Количество записей',
            },
          },
        },
      },
      {
        name: 'get_clients',
        description: 'Получить список клиентов',
        parameters: {
          type: 'object',
          properties: {
            search: {
              type: 'string',
              description: 'Поиск по имени или телефону',
            },
            limit: {
              type: 'number',
            },
          },
        },
      },
      {
        name: 'get_scenario_settings',
        description: 'Получить текущие настройки сценария для клиентского бота',
        parameters: {
          type: 'object',
          properties: {},
        },
      },
      {
        name: 'update_scenario',
        description: 'Обновить настройки сценария для клиентского бота',
        parameters: {
          type: 'object',
          properties: {
            systemPrompt: {
              type: 'string',
              description: 'Новый системный промпт',
            },
            tone: {
              type: 'string',
              enum: ['formal', 'friendly', 'professional', 'casual'],
            },
            welcomeMessage: {
              type: 'string',
            },
            requiredFields: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  field: { type: 'string' },
                  question: { type: 'string' },
                  order: { type: 'number' },
                },
              },
            },
          },
        },
      },
      {
        name: 'get_services',
        description: 'Получить список услуг',
        parameters: {
          type: 'object',
          properties: {},
        },
      },
      {
        name: 'create_service',
        description: 'Создать новую услугу',
        parameters: {
          type: 'object',
          properties: {
            name: { type: 'string' },
            durationMinutes: { type: 'number' },
            price: { type: 'number' },
            description: { type: 'string' },
          },
          required: ['name', 'durationMinutes', 'price'],
        },
      },
    ];
  }

  /**
   * Выполнить функцию админ-бота
   */
  private async executeAdminFunction(
    businessId: string,
    functionName: string,
    args: any,
  ): Promise<any> {
    switch (functionName) {
      case 'get_statistics':
        return this.getStatistics(businessId, args.period, args.metrics);

      case 'get_bookings':
        return this.getBookings(businessId, args.date, args.status, args.limit);

      case 'get_clients':
        return this.getClients(businessId, args.search, args.limit);

      case 'get_scenario_settings':
        return this.getScenarioSettings(businessId);

      case 'update_scenario':
        return this.updateScenario(businessId, args);

      case 'get_services':
        return this.getServices(businessId);

      case 'create_service':
        return this.createService(businessId, args);

      default:
        return { error: 'Unknown function' };
    }
  }

  /**
   * Получить статистику
   */
  private async getStatistics(
    businessId: string,
    period: string,
    metrics?: string[],
  ): Promise<any> {
    const now = new Date();
    let startDate: Date;

    switch (period) {
      case 'today':
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'week':
        startDate = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    }

    const [bookingsCount, clientsCount, revenue] = await Promise.all([
      this.prisma.booking.count({
        where: {
          businessId,
          createdAt: { gte: startDate },
        },
      }),
      this.prisma.client.count({
        where: {
          businessId,
          createdAt: { gte: startDate },
        },
      }),
      this.prisma.booking.aggregate({
        where: {
          businessId,
          status: 'completed',
          createdAt: { gte: startDate },
        },
        _sum: { price: true },
      }),
    ]);

    return {
      period,
      bookings: bookingsCount,
      newClients: clientsCount,
      revenue: revenue._sum.price || 0,
      startDate: startDate.toISOString(),
      endDate: now.toISOString(),
    };
  }

  /**
   * Получить записи
   */
  private async getBookings(
    businessId: string,
    date?: string,
    status?: string,
    limit: number = 10,
  ): Promise<any> {
    const where: any = { businessId };

    if (date) {
      const targetDate = new Date(date);
      const nextDay = new Date(targetDate);
      nextDay.setDate(nextDay.getDate() + 1);

      where.dateTime = {
        gte: targetDate,
        lt: nextDay,
      };
    }

    if (status && status !== 'all') {
      where.status = status;
    }

    const bookings = await this.prisma.booking.findMany({
      where,
      include: {
        client: { select: { name: true, phone: true } },
        service: { select: { name: true } },
      },
      orderBy: { dateTime: 'asc' },
      take: limit,
    });

    return bookings.map((b) => ({
      id: b.id,
      date: b.dateTime.toISOString(),
      client: b.client.name,
      phone: b.client.phone,
      service: b.service.name,
      status: b.status,
      price: b.price,
    }));
  }

  /**
   * Получить клиентов
   */
  private async getClients(
    businessId: string,
    search?: string,
    limit: number = 10,
  ): Promise<any> {
    const where: any = { businessId };

    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { phone: { contains: search } },
      ];
    }

    const clients = await this.prisma.client.findMany({
      where,
      include: {
        _count: { select: { bookings: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    return clients.map((c) => ({
      id: c.id,
      name: c.name,
      phone: c.phone,
      email: c.email,
      totalBookings: c._count.bookings,
      source: c.source,
      createdAt: c.createdAt.toISOString(),
    }));
  }

  /**
   * Получить настройки сценария
   */
  private async getScenarioSettings(businessId: string): Promise<any> {
    const scenario = await this.scenarioService.getActiveScenario(businessId);

    if (!scenario) {
      return { error: 'No active scenario found' };
    }

    return {
      name: scenario.name,
      tone: scenario.tone,
      systemPrompt: scenario.systemPrompt,
      welcomeMessage: scenario.welcomeMessage,
      requiredFields: scenario.requiredFields,
      faq: scenario.faq,
      settings: scenario.settings,
    };
  }

  /**
   * Обновить сценарий
   */
  private async updateScenario(businessId: string, updates: any): Promise<any> {
    const scenario = await this.scenarioService.getActiveScenario(businessId);

    if (!scenario) {
      return { error: 'No active scenario found' };
    }

    await this.scenarioService.updateScenario(scenario.id, businessId, updates);

    return { success: true, message: 'Сценарий обновлён' };
  }

  /**
   * Получить услуги
   */
  private async getServices(businessId: string): Promise<any> {
    const services = await this.prisma.service.findMany({
      where: { businessId },
      orderBy: { displayOrder: 'asc' },
    });

    return services.map((s) => ({
      id: s.id,
      name: s.name,
      duration: s.durationMinutes,
      price: s.price,
      description: s.description,
      isActive: s.isActive,
    }));
  }

  /**
   * Создать услугу
   */
  private async createService(businessId: string, data: any): Promise<any> {
    const service = await this.prisma.service.create({
      data: {
        businessId,
        name: data.name,
        durationMinutes: data.durationMinutes,
        price: data.price,
        description: data.description,
      },
    });

    return {
      success: true,
      service: {
        id: service.id,
        name: service.name,
        duration: service.durationMinutes,
        price: service.price,
      },
    };
  }
}
