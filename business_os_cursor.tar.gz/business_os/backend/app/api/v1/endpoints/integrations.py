"""
Integrations API endpoints for Telegram, WhatsApp, Instagram
"""
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from enum import Enum

router = APIRouter()

class IntegrationType(str, Enum):
    TELEGRAM = "telegram"
    WHATSAPP = "whatsapp"
    INSTAGRAM = "instagram"
    SMS = "sms"
    EMAIL = "email"

class IntegrationStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    PENDING = "pending"
    ERROR = "error"

# Schemas
class IntegrationBase(BaseModel):
    type: IntegrationType
    name: str
    description: Optional[str] = None

class IntegrationConfig(BaseModel):
    # Telegram
    telegram_bot_token: Optional[str] = None
    telegram_chat_id: Optional[str] = None
    
    # WhatsApp
    whatsapp_api_key: Optional[str] = None
    whatsapp_phone_number: Optional[str] = None
    
    # Instagram
    instagram_access_token: Optional[str] = None
    instagram_business_id: Optional[str] = None
    
    # SMS
    sms_provider: Optional[str] = None  # twilio, smsru, etc.
    sms_api_key: Optional[str] = None
    sms_sender_id: Optional[str] = None
    
    # Email
    smtp_host: Optional[str] = None
    smtp_port: Optional[int] = None
    smtp_username: Optional[str] = None
    smtp_password: Optional[str] = None
    smtp_from_email: Optional[str] = None

class IntegrationResponse(BaseModel):
    id: int
    type: IntegrationType
    name: str
    description: Optional[str]
    status: IntegrationStatus
    is_configured: bool
    last_sync: Optional[datetime]
    created_at: datetime

class IntegrationCreate(BaseModel):
    type: IntegrationType
    config: IntegrationConfig

class WebhookPayload(BaseModel):
    type: IntegrationType
    event: str
    data: dict

class NotificationRequest(BaseModel):
    channel: IntegrationType
    recipient: str  # phone, email, telegram_id, etc.
    message: str
    template_id: Optional[str] = None
    variables: Optional[dict] = None

class NotificationResponse(BaseModel):
    success: bool
    message_id: Optional[str] = None
    error: Optional[str] = None

# Mock data for available integrations
AVAILABLE_INTEGRATIONS = [
    {
        "id": 1,
        "type": IntegrationType.TELEGRAM,
        "name": "Telegram Bot",
        "description": "Отправка уведомлений клиентам через Telegram",
        "status": IntegrationStatus.INACTIVE,
        "is_configured": False,
        "last_sync": None,
        "created_at": datetime.utcnow(),
        "setup_url": "https://t.me/BotFather",
        "docs_url": "https://core.telegram.org/bots/api"
    },
    {
        "id": 2,
        "type": IntegrationType.WHATSAPP,
        "name": "WhatsApp Business",
        "description": "Интеграция с WhatsApp Business API",
        "status": IntegrationStatus.INACTIVE,
        "is_configured": False,
        "last_sync": None,
        "created_at": datetime.utcnow(),
        "setup_url": "https://business.whatsapp.com/",
        "docs_url": "https://developers.facebook.com/docs/whatsapp"
    },
    {
        "id": 3,
        "type": IntegrationType.INSTAGRAM,
        "name": "Instagram Direct",
        "description": "Автоответы и уведомления через Instagram Direct",
        "status": IntegrationStatus.INACTIVE,
        "is_configured": False,
        "last_sync": None,
        "created_at": datetime.utcnow(),
        "setup_url": "https://developers.facebook.com/products/instagram/",
        "docs_url": "https://developers.facebook.com/docs/instagram-api"
    },
    {
        "id": 4,
        "type": IntegrationType.SMS,
        "name": "SMS уведомления",
        "description": "Отправка SMS через провайдеров (SMS.ru, Twilio)",
        "status": IntegrationStatus.INACTIVE,
        "is_configured": False,
        "last_sync": None,
        "created_at": datetime.utcnow(),
        "setup_url": None,
        "docs_url": None
    },
    {
        "id": 5,
        "type": IntegrationType.EMAIL,
        "name": "Email уведомления",
        "description": "Отправка email через SMTP или API",
        "status": IntegrationStatus.INACTIVE,
        "is_configured": False,
        "last_sync": None,
        "created_at": datetime.utcnow(),
        "setup_url": None,
        "docs_url": None
    },
]

@router.get("/", response_model=List[dict])
async def list_integrations(tenant_id: int = 1):
    """List all available integrations with their status"""
    return AVAILABLE_INTEGRATIONS

@router.get("/{integration_type}")
async def get_integration(integration_type: IntegrationType, tenant_id: int = 1):
    """Get specific integration details"""
    for integration in AVAILABLE_INTEGRATIONS:
        if integration["type"] == integration_type:
            return integration
    raise HTTPException(status_code=404, detail="Integration not found")

@router.post("/{integration_type}/configure")
async def configure_integration(
    integration_type: IntegrationType,
    config: IntegrationConfig,
    tenant_id: int = 1
):
    """Configure an integration with credentials"""
    # In production, this would save to database and validate credentials
    
    if integration_type == IntegrationType.TELEGRAM:
        if not config.telegram_bot_token:
            raise HTTPException(status_code=400, detail="telegram_bot_token is required")
        # Validate bot token by calling Telegram API
        return {
            "success": True,
            "message": "Telegram bot configured successfully",
            "webhook_url": f"https://api.business-os.com/webhooks/telegram/{tenant_id}"
        }
    
    elif integration_type == IntegrationType.WHATSAPP:
        if not config.whatsapp_api_key:
            raise HTTPException(status_code=400, detail="whatsapp_api_key is required")
        return {
            "success": True,
            "message": "WhatsApp Business configured successfully"
        }
    
    elif integration_type == IntegrationType.INSTAGRAM:
        if not config.instagram_access_token:
            raise HTTPException(status_code=400, detail="instagram_access_token is required")
        return {
            "success": True,
            "message": "Instagram integration configured successfully"
        }
    
    elif integration_type == IntegrationType.SMS:
        if not config.sms_api_key:
            raise HTTPException(status_code=400, detail="sms_api_key is required")
        return {
            "success": True,
            "message": "SMS provider configured successfully"
        }
    
    elif integration_type == IntegrationType.EMAIL:
        if not config.smtp_host:
            raise HTTPException(status_code=400, detail="smtp_host is required")
        return {
            "success": True,
            "message": "Email SMTP configured successfully"
        }
    
    raise HTTPException(status_code=400, detail="Unknown integration type")

@router.post("/{integration_type}/test")
async def test_integration(integration_type: IntegrationType, tenant_id: int = 1):
    """Test integration connection"""
    # In production, this would actually test the connection
    return {
        "success": True,
        "message": f"{integration_type.value} connection test successful",
        "latency_ms": 150
    }

@router.delete("/{integration_type}")
async def disconnect_integration(integration_type: IntegrationType, tenant_id: int = 1):
    """Disconnect/disable an integration"""
    return {
        "success": True,
        "message": f"{integration_type.value} integration disconnected"
    }

@router.post("/send-notification", response_model=NotificationResponse)
async def send_notification(request: NotificationRequest, tenant_id: int = 1):
    """Send notification through specified channel"""
    
    # In production, this would actually send the notification
    # For now, return mock success
    
    if request.channel == IntegrationType.TELEGRAM:
        # Would use python-telegram-bot or aiogram
        return NotificationResponse(
            success=True,
            message_id=f"tg_{datetime.utcnow().timestamp()}"
        )
    
    elif request.channel == IntegrationType.WHATSAPP:
        # Would use WhatsApp Business API
        return NotificationResponse(
            success=True,
            message_id=f"wa_{datetime.utcnow().timestamp()}"
        )
    
    elif request.channel == IntegrationType.SMS:
        # Would use Twilio or SMS.ru
        return NotificationResponse(
            success=True,
            message_id=f"sms_{datetime.utcnow().timestamp()}"
        )
    
    elif request.channel == IntegrationType.EMAIL:
        # Would use SMTP or SendGrid
        return NotificationResponse(
            success=True,
            message_id=f"email_{datetime.utcnow().timestamp()}"
        )
    
    return NotificationResponse(
        success=False,
        error="Channel not supported"
    )

@router.post("/webhooks/{integration_type}")
async def handle_webhook(integration_type: IntegrationType, payload: dict):
    """Handle incoming webhooks from integrations"""
    
    # In production, this would process incoming messages/events
    
    if integration_type == IntegrationType.TELEGRAM:
        # Handle Telegram updates (messages, callbacks, etc.)
        return {"ok": True}
    
    elif integration_type == IntegrationType.WHATSAPP:
        # Handle WhatsApp webhook events
        return {"ok": True}
    
    elif integration_type == IntegrationType.INSTAGRAM:
        # Handle Instagram webhook events
        return {"ok": True}
    
    return {"ok": False, "error": "Unknown integration type"}

# Notification templates
@router.get("/templates")
async def list_notification_templates(tenant_id: int = 1):
    """List notification templates"""
    return [
        {
            "id": "appointment_reminder",
            "name": "Напоминание о записи",
            "name_en": "Appointment Reminder",
            "channels": ["telegram", "whatsapp", "sms", "email"],
            "variables": ["client_name", "service_name", "date", "time", "staff_name"],
            "template_ru": "Здравствуйте, {client_name}! Напоминаем о вашей записи на {service_name} {date} в {time}. Мастер: {staff_name}",
            "template_en": "Hello {client_name}! Reminder about your {service_name} appointment on {date} at {time}. Stylist: {staff_name}"
        },
        {
            "id": "appointment_confirmation",
            "name": "Подтверждение записи",
            "name_en": "Appointment Confirmation",
            "channels": ["telegram", "whatsapp", "sms", "email"],
            "variables": ["client_name", "service_name", "date", "time", "address"],
            "template_ru": "Ваша запись подтверждена! {service_name}, {date} в {time}. Адрес: {address}",
            "template_en": "Your appointment is confirmed! {service_name}, {date} at {time}. Address: {address}"
        },
        {
            "id": "appointment_cancelled",
            "name": "Отмена записи",
            "name_en": "Appointment Cancelled",
            "channels": ["telegram", "whatsapp", "sms", "email"],
            "variables": ["client_name", "service_name", "date"],
            "template_ru": "К сожалению, ваша запись на {service_name} {date} была отменена. Свяжитесь с нами для перезаписи.",
            "template_en": "Unfortunately, your {service_name} appointment on {date} has been cancelled. Please contact us to reschedule."
        },
        {
            "id": "birthday_greeting",
            "name": "Поздравление с днём рождения",
            "name_en": "Birthday Greeting",
            "channels": ["telegram", "whatsapp", "email"],
            "variables": ["client_name", "discount"],
            "template_ru": "С днём рождения, {client_name}! 🎂 Дарим вам скидку {discount}% на любую услугу!",
            "template_en": "Happy Birthday, {client_name}! 🎂 We're giving you {discount}% off any service!"
        },
        {
            "id": "reactivation",
            "name": "Реактивация клиента",
            "name_en": "Client Reactivation",
            "channels": ["telegram", "whatsapp", "sms", "email"],
            "variables": ["client_name", "days_since_visit", "discount"],
            "template_ru": "Мы скучаем по вам, {client_name}! Прошло уже {days_since_visit} дней с вашего последнего визита. Скидка {discount}% ждёт вас!",
            "template_en": "We miss you, {client_name}! It's been {days_since_visit} days since your last visit. {discount}% discount awaits you!"
        }
    ]
