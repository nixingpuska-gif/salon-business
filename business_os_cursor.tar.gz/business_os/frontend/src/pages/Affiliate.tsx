import { useState } from 'react'
import { 
  Users, DollarSign, Link2, Copy, Check, TrendingUp,
  Gift, ChevronRight, ExternalLink, Share2
} from 'lucide-react'

export default function Affiliate() {
  const [copied, setCopied] = useState(false)
  
  const referralCode = 'BEAUTYLAB2024'
  const referralLink = `https://business-os.ru/ref/${referralCode}`
  
  const stats = {
    totalReferrals: 12,
    activeReferrals: 8,
    totalEarnings: 240000,
    pendingPayout: 45000,
    conversionRate: 35
  }

  const referrals = [
    { id: 1, name: 'Салон "Красота"', date: '2024-11-15', status: 'active', earnings: 30000 },
    { id: 2, name: 'Beauty Studio', date: '2024-11-20', status: 'active', earnings: 30000 },
    { id: 3, name: 'Nail Art Pro', date: '2024-12-01', status: 'trial', earnings: 0 },
    { id: 4, name: 'Hair Masters', date: '2024-12-05', status: 'active', earnings: 30000 },
  ]

  const copyToClipboard = () => {
    navigator.clipboard.writeText(referralLink)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Share2 className="w-7 h-7 text-primary-600" />
            Партнёрская программа
          </h1>
          <p className="text-gray-600 mt-1">Приглашайте салоны и получайте 30% от их подписки</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700">
          <DollarSign className="w-4 h-4" />
          Запросить выплату
        </button>
      </div>

      {/* Referral Link Card */}
      <div className="bg-gradient-to-r from-primary-600 to-primary-700 rounded-2xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold mb-2">Ваша реферальная ссылка</h2>
            <p className="text-white/70 text-sm mb-4">
              Поделитесь ссылкой с другими салонами и получайте 30% от их подписки навсегда
            </p>
            <div className="flex items-center gap-3">
              <div className="bg-white/10 rounded-lg px-4 py-2 font-mono text-sm">
                {referralLink}
              </div>
              <button
                onClick={copyToClipboard}
                className="flex items-center gap-2 bg-white text-primary-600 px-4 py-2 rounded-lg font-medium hover:bg-gray-100 transition-colors"
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copied ? 'Скопировано!' : 'Копировать'}
              </button>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="w-24 h-24 bg-white rounded-xl flex items-center justify-center">
              <Link2 className="w-12 h-12 text-primary-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <Users className="w-4 h-4" />
            Всего рефералов
          </div>
          <div className="text-2xl font-bold text-gray-900 mt-1">{stats.totalReferrals}</div>
        </div>
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <Check className="w-4 h-4" />
            Активных
          </div>
          <div className="text-2xl font-bold text-green-600 mt-1">{stats.activeReferrals}</div>
        </div>
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <DollarSign className="w-4 h-4" />
            Заработано
          </div>
          <div className="text-2xl font-bold text-gray-900 mt-1">{stats.totalEarnings.toLocaleString()}₽</div>
        </div>
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <Gift className="w-4 h-4" />
            К выплате
          </div>
          <div className="text-2xl font-bold text-primary-600 mt-1">{stats.pendingPayout.toLocaleString()}₽</div>
        </div>
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <TrendingUp className="w-4 h-4" />
            Конверсия
          </div>
          <div className="text-2xl font-bold text-gray-900 mt-1">{stats.conversionRate}%</div>
        </div>
      </div>

      {/* How it works */}
      <div className="bg-white rounded-xl border p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Как это работает</h2>
        <div className="grid md:grid-cols-4 gap-6">
          {[
            { step: 1, title: 'Поделитесь ссылкой', desc: 'Отправьте вашу реферальную ссылку другим салонам' },
            { step: 2, title: 'Салон регистрируется', desc: 'Новый салон начинает 14-дневный бесплатный период' },
            { step: 3, title: 'Оплачивает подписку', desc: 'После триала салон оформляет платную подписку' },
            { step: 4, title: 'Вы получаете 30%', desc: 'Каждый месяц пока салон остаётся клиентом' },
          ].map((item) => (
            <div key={item.step} className="text-center">
              <div className="w-12 h-12 bg-primary-100 text-primary-700 rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-3">
                {item.step}
              </div>
              <h3 className="font-semibold text-gray-900 mb-1">{item.title}</h3>
              <p className="text-sm text-gray-600">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Referrals List */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Ваши рефералы</h2>
        <div className="bg-white rounded-xl border overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Салон</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Дата регистрации</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Статус</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Заработано</th>
                <th className="px-6 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {referrals.map((ref) => (
                <tr key={ref.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="font-medium text-gray-900">{ref.name}</div>
                  </td>
                  <td className="px-6 py-4 text-gray-600">{ref.date}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      ref.status === 'active' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {ref.status === 'active' ? 'Активен' : 'Триал'}
                    </span>
                  </td>
                  <td className="px-6 py-4 font-medium text-gray-900">
                    {ref.earnings.toLocaleString()}₽
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-primary-600 hover:text-primary-700">
                      <ExternalLink className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Promo Materials */}
      <div className="bg-gray-50 rounded-xl p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Промо-материалы</h2>
        <div className="grid md:grid-cols-3 gap-4">
          {[
            { title: 'Баннер для соцсетей', format: 'PNG, 1200x628' },
            { title: 'Презентация', format: 'PDF, 10 слайдов' },
            { title: 'Email-шаблон', format: 'HTML' },
          ].map((material) => (
            <div key={material.title} className="bg-white rounded-lg p-4 border flex items-center justify-between">
              <div>
                <div className="font-medium text-gray-900">{material.title}</div>
                <div className="text-sm text-gray-500">{material.format}</div>
              </div>
              <button className="text-primary-600 hover:text-primary-700">
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
