"""
Business OS - Database Module
Асинхронное подключение к БД с поддержкой SQLite (dev) и PostgreSQL (prod)
"""

from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import declarative_base
from sqlalchemy.pool import StaticPool
from sqlalchemy import text

from app.core.config import settings

# Создание асинхронного движка
# Разные настройки для SQLite и PostgreSQL
if settings.DATABASE_URL.startswith("sqlite"):
    engine = create_async_engine(
        settings.DATABASE_URL,
        echo=settings.DEBUG,
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
else:
    engine = create_async_engine(
        settings.DATABASE_URL,
        pool_size=settings.DATABASE_POOL_SIZE,
        max_overflow=settings.DATABASE_MAX_OVERFLOW,
        echo=settings.DEBUG,
        future=True
    )

# Фабрика сессий
AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False
)

# Базовый класс для моделей
Base = declarative_base()


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Dependency для получения сессии БД"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def init_db():
    """Инициализация базы данных"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def close_db():
    """Закрытие соединений с БД"""
    await engine.dispose()


class TenantSession:
    """
    Контекстный менеджер для работы с данными конкретного тенанта.
    """
    def __init__(self, session: AsyncSession, tenant_id: int):
        self.session = session
        self.tenant_id = tenant_id
    
    async def __aenter__(self):
        if not settings.DATABASE_URL.startswith("sqlite"):
            await self.session.execute(
                text(f"SET app.current_tenant_id = '{self.tenant_id}'")
            )
        return self.session
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if not settings.DATABASE_URL.startswith("sqlite"):
            await self.session.execute(text("RESET app.current_tenant_id"))
        if exc_type is not None:
            await self.session.rollback()
        return False
