# Instagram Configuration Template

## Переменные окружения

Добавьте эти переменные в ваш `.env` файл:

```bash
# Instagram Direct Messages API
INSTAGRAM_PAGE_ID=your_instagram_page_id_here
INSTAGRAM_ACCESS_TOKEN=your_access_token_here
INSTAGRAM_VERIFY_TOKEN=your_verify_token_here
```

## Где получить значения

### 1. INSTAGRAM_PAGE_ID
- Откройте [Meta for Developers](https://developers.facebook.com/apps/)
- Перейдите в ваше приложение → **Messenger** → **Settings**
- В разделе **Instagram** найдите вашу Instagram страницу
- Если страницы нет, нажмите **"Add Instagram Account"** и авторизуйте доступ
- Скопируйте **Instagram Page ID** (числовой ID, например `123456789012345`)

### 2. INSTAGRAM_ACCESS_TOKEN
**Временный токен (для тестирования, действует 24 часа):**
- В разделе **Messenger** → **Settings**
- Найдите вашу Instagram страницу
- Нажмите **"Generate Token"**
- Скопируйте токен (начинается с `EAAG...`)

**Постоянный токен (для продакшена):**
- Перейдите в **Business Settings** → **System Users**
- Создайте System User с правами **Admin**
- Нажмите **"Generate New Token"**
- Выберите ваше приложение
- Выберите разрешения:
  - `pages_messaging`
  - `pages_manage_metadata`
  - `instagram_basic`
  - `instagram_manage_messages`
- Сгенерируйте и скопируйте токен

### 3. INSTAGRAM_VERIFY_TOKEN
- Придумайте случайную строку (минимум 20 символов)
- Пример: `my_instagram_verify_token_xyz789`
- Эта же строка должна быть указана при настройке webhook в Meta Console

## Настройка Webhook

1. В Meta Console перейдите в **Messenger** → **Settings** → **Webhooks**
2. Нажмите **"Add Callback URL"**
3. Заполните:
   - **Callback URL**: `https://ваш-домен.com/webhooks/instagram`
   - **Verify Token**: Ваш `INSTAGRAM_VERIFY_TOKEN`
4. Нажмите **"Verify and Save"**
5. Подпишитесь на события для Instagram:
   - ✅ `messages`
   - ✅ `messaging_postbacks`
   - ✅ `message_reads` (опционально)
   - ✅ `message_deliveries` (опционально)

## Требования

### Instagram Account
- ✅ Должен быть **Business Account** (не Personal)
- ✅ Должен быть связан с **Facebook Page**

### Преобразование в Business Account
1. Откройте Instagram приложение
2. **Settings** → **Account** → **Switch to Professional Account**
3. Выберите **Business**
4. Свяжите с Facebook Page (или создайте новую)

## Проверка

После настройки:
1. Запустите сервер: `npm run start:dev`
2. В Meta Console должна быть зелёная галочка ✅ напротив webhook
3. Отправьте сообщение боту в Instagram Direct
4. Проверьте логи сервера — должно быть сообщение

## Важные ограничения

⚠️ **Бот не может первым инициировать диалог**
- Пользователь должен первым написать боту
- После этого бот может отвечать в течение 24 часов

⚠️ **Временное окно 24 часа**
- Бот может отвечать только в течение 24 часов после последнего сообщения пользователя
- Для сообщений вне окна нужны Message Tags (требуют одобрения)

⚠️ **Верификация для продакшена**
- Без верификации приложения можно общаться только с тестовыми пользователями
- Для продакшена требуется App Review в Meta

Подробная инструкция: **INSTAGRAM-SETUP-GUIDE.md**
