import { Link } from 'react-router-dom'
import { 
  Calendar, Users, TrendingUp, MessageSquare, Shield, Zap,
  Check, Star, ArrowRight, Play, ChevronRight
} from 'lucide-react'

const features = [
  {
    icon: Calendar,
    title: 'Онлайн-запись',
    description: 'Клиенты записываются 24/7 через виджет на вашем сайте или в соцсетях'
  },
  {
    icon: Users,
    title: 'База клиентов',
    description: 'Полная история визитов, предпочтения и автоматическая сегментация'
  },
  {
    icon: TrendingUp,
    title: 'Аналитика',
    description: 'Выручка, загрузка мастеров, популярные услуги — всё в одном месте'
  },
  {
    icon: MessageSquare,
    title: 'Уведомления',
    description: 'Автоматические напоминания через SMS, Telegram и WhatsApp'
  },
  {
    icon: Shield,
    title: 'Безопасность',
    description: 'Данные защищены шифрованием и хранятся в России'
  },
  {
    icon: Zap,
    title: 'Интеграции',
    description: 'Подключение к 1С, Google Calendar, Telegram-боту и другим сервисам'
  },
]

const testimonials = [
  {
    name: 'Анна Петрова',
    role: 'Владелец салона "Beauty Lab"',
    avatar: 'AP',
    text: 'Перешли на Business OS полгода назад. Записи выросли на 40%, а время на администрирование сократилось вдвое.',
    rating: 5
  },
  {
    name: 'Михаил Козлов',
    role: 'Сеть барбершопов "Бородач"',
    avatar: 'МК',
    text: 'Наконец-то нормальная аналитика! Теперь вижу реальную картину по каждому филиалу и мастеру.',
    rating: 5
  },
  {
    name: 'Елена Сидорова',
    role: 'Студия маникюра',
    avatar: 'ЕС',
    text: 'Клиенты в восторге от онлайн-записи. Больше не нужно отвечать на звонки — всё автоматизировано.',
    rating: 5
  },
]

const plans = [
  {
    name: 'Business OS',
    priceRub: 100000,
    priceEur: 1000,
    description: 'Полный доступ к платформе',
    features: [
      'Безлимит клиентов и сотрудников',
      'Онлайн-запись 24/7',
      'CRM и аналитика',
      'Telegram, WhatsApp, Instagram',
      'SMS и Email уведомления',
      'API доступ',
      'Белый лейбл',
      'Персональный менеджер',
      'Обучение команды',
      'Приоритетная поддержка 24/7'
    ],
    popular: true
  },
]

const stats = [
  { value: '5000+', label: 'Салонов' },
  { value: '2M+', label: 'Записей в месяц' },
  { value: '99.9%', label: 'Uptime' },
  { value: '4.9', label: 'Рейтинг' },
]

export default function Landing() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">B</span>
              </div>
              <span className="font-bold text-xl text-gray-900">Business OS</span>
            </div>
            <nav className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-gray-600 hover:text-gray-900">Возможности</a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900">Тарифы</a>
              <a href="#testimonials" className="text-gray-600 hover:text-gray-900">Отзывы</a>
            </nav>
            <div className="flex items-center gap-4">
              <Link to="/login" className="text-gray-600 hover:text-gray-900 font-medium">
                Войти
              </Link>
              <Link to="/register" className="bg-primary-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-primary-700 transition-colors">
                Попробовать бесплатно
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="pt-32 pb-20 bg-gradient-to-b from-primary-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary-100 rounded-full text-primary-700 text-sm font-medium mb-6">
              <Zap className="w-4 h-4" />
              Новое: AI-ассистент для коммуникаций
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 leading-tight">
              Управляйте салоном красоты{' '}
              <span className="text-primary-600">как профессионал</span>
            </h1>
            <p className="mt-6 text-xl text-gray-600 max-w-2xl mx-auto">
              Онлайн-запись, CRM, аналитика и автоматизация в одной платформе. 
              Освободите время для творчества, а рутину доверьте нам.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/register" className="w-full sm:w-auto bg-primary-600 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:bg-primary-700 transition-colors flex items-center justify-center gap-2">
                Начать бесплатно
                <ArrowRight className="w-5 h-5" />
              </Link>
              <button className="w-full sm:w-auto border-2 border-gray-200 text-gray-700 px-8 py-4 rounded-xl font-semibold text-lg hover:border-gray-300 transition-colors flex items-center justify-center gap-2">
                <Play className="w-5 h-5" />
                Смотреть демо
              </button>
            </div>
            <p className="mt-4 text-sm text-gray-500">
              14 дней бесплатно • Без привязки карты • Отмена в любой момент
            </p>
          </div>

          {/* Dashboard Preview */}
          <div className="mt-16 relative">
            <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent z-10 pointer-events-none" />
            <div className="bg-gray-900 rounded-2xl shadow-2xl overflow-hidden border border-gray-800">
              <div className="bg-gray-800 px-4 py-3 flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                <div className="w-3 h-3 rounded-full bg-green-500" />
              </div>
              <div className="p-4 bg-gray-100">
                <img 
                  src="/dashboard-preview.png" 
                  alt="Business OS Dashboard" 
                  className="rounded-lg shadow-lg"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none'
                  }}
                />
                <div className="h-96 bg-gradient-to-br from-primary-50 to-primary-100 rounded-lg flex items-center justify-center">
                  <span className="text-primary-600 font-medium">Превью дашборда</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-4xl font-bold text-white">{stat.value}</div>
                <div className="text-gray-400 mt-1">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold text-gray-900">
              Всё для успешного салона
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Инструменты, которые помогут вам расти и зарабатывать больше
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature) => (
              <div key={feature.title} className="p-6 rounded-2xl border border-gray-100 hover:border-primary-200 hover:shadow-lg transition-all">
                <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold text-gray-900">
              Один тариф — все возможности
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Полный доступ ко всем функциям платформы без ограничений
            </p>
          </div>

          <div className="max-w-lg mx-auto">
            {plans.map((plan) => (
              <div 
                key={plan.name} 
                className="rounded-2xl p-8 bg-primary-600 text-white ring-4 ring-primary-600 ring-offset-4"
              >
                <div className="inline-block px-3 py-1 bg-white/20 rounded-full text-sm font-medium mb-4">
                  Полный доступ
                </div>
                <h3 className="text-2xl font-bold text-white">
                  {plan.name}
                </h3>
                <p className="mt-1 text-white/80">
                  {plan.description}
                </p>
                <div className="mt-6 space-y-2">
                  <div>
                    <span className="text-5xl font-bold text-white">
                      {plan.priceRub.toLocaleString()}
                    </span>
                    <span className="text-white/80"> ₽/мес</span>
                  </div>
                  <div className="text-white/60 text-lg">
                    или {plan.priceEur.toLocaleString()} €/мес для Европы
                  </div>
                </div>
                <ul className="mt-8 space-y-4">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3">
                      <Check className="w-5 h-5 text-white" />
                      <span className="text-white">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link
                  to="/register"
                  className="mt-8 block w-full py-4 rounded-xl font-semibold text-center transition-colors bg-white text-primary-600 hover:bg-gray-100 text-lg"
                >
                  Начать бесплатный период
                </Link>
                <p className="mt-4 text-center text-white/60 text-sm">
                  14 дней бесплатно • Без привязки карты
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold text-gray-900">
              Нам доверяют тысячи салонов
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              Узнайте, что говорят наши клиенты
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div key={testimonial.name} className="bg-white rounded-2xl p-8 border border-gray-100 shadow-sm">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-600 mb-6">"{testimonial.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                    <span className="text-primary-600 font-semibold">{testimonial.avatar}</span>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-500">{testimonial.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-primary-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white">
            Готовы начать?
          </h2>
          <p className="mt-4 text-xl text-white/80">
            Присоединяйтесь к тысячам успешных салонов уже сегодня
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/register" className="w-full sm:w-auto bg-white text-primary-600 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-gray-100 transition-colors flex items-center justify-center gap-2">
              Начать бесплатно
              <ChevronRight className="w-5 h-5" />
            </Link>
            <a href="mailto:hello@business-os.ru" className="text-white/80 hover:text-white font-medium">
              Или свяжитесь с нами →
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">B</span>
                </div>
                <span className="font-bold text-xl text-white">Business OS</span>
              </div>
              <p className="text-gray-400">
                Платформа для управления салонами красоты и сервисным бизнесом
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Продукт</h4>
              <ul className="space-y-2">
                <li><a href="#features" className="text-gray-400 hover:text-white">Возможности</a></li>
                <li><a href="#pricing" className="text-gray-400 hover:text-white">Тарифы</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Интеграции</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">API</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Компания</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white">О нас</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Блог</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Карьера</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Контакты</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">Поддержка</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white">Документация</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">FAQ</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Telegram</a></li>
                <li><a href="mailto:support@business-os.ru" className="text-gray-400 hover:text-white">support@business-os.ru</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-gray-800 flex flex-col md:flex-row items-center justify-between">
            <p className="text-gray-400 text-sm">
              © 2024 Business OS. Все права защищены.
            </p>
            <div className="flex items-center gap-6 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 hover:text-white text-sm">Политика конфиденциальности</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm">Условия использования</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
