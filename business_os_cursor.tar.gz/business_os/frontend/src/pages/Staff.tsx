import { useEffect, useState } from 'react'
import { API_URL } from '../config/api'
import { Plus, Phone, Mail, Star, Calendar, MoreVertical, X } from 'lucide-react'
import clsx from 'clsx'

interface Staff {
  id: number
  first_name: string
  last_name: string | null
  full_name: string
  position: string | null
  phone: string
  email: string | null
  status: string
  role: string
  avg_rating: number
  total_appointments: number
  total_revenue: number
  avatar_url: string | null
}

const statusLabels: Record<string, { label: string; color: string }> = {
  active: { label: 'Активен', color: 'bg-green-100 text-green-700' },
  inactive: { label: 'Неактивен', color: 'bg-gray-100 text-gray-700' },
  vacation: { label: 'В отпуске', color: 'bg-amber-100 text-amber-700' },
  sick: { label: 'На больничном', color: 'bg-red-100 text-red-700' },
}

function formatMoney(amount: number): string {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    minimumFractionDigits: 0,
  }).format(amount)
}

export default function Staff() {
  const [staff, setStaff] = useState<Staff[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddModal, setShowAddModal] = useState(false)
  const [newStaff, setNewStaff] = useState({
    first_name: '',
    last_name: '',
    phone: '',
    email: '',
    position: '',
    role: 'master'
  })

  useEffect(() => {
    fetch(`${API_URL}/api/v1/staff`)
      .then(res => res.json())
      .then(data => {
        setStaff(data.items || [])
        setLoading(false)
      })
      .catch(err => {
        console.error('Error:', err)
        setLoading(false)
      })
  }, [])

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Сотрудники</h1>
          <p className="text-gray-500 mt-1">Управление командой</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="btn-primary flex items-center gap-2"
        >
          <Plus className="w-5 h-5" />
          Добавить сотрудника
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
        </div>
      ) : staff.length === 0 ? (
        <div className="card">
          <div className="text-center py-12">
            <p className="text-gray-500">Сотрудники не найдены</p>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {staff.map((member) => (
            <div key={member.id} className="card">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-primary-100 rounded-full flex items-center justify-center">
                    {member.avatar_url ? (
                      <img src={member.avatar_url} alt={member.full_name} className="w-14 h-14 rounded-full object-cover" />
                    ) : (
                      <span className="text-primary-700 font-semibold text-lg">
                        {(member.full_name || `${member.first_name} ${member.last_name || ''}`).split(' ').map(n => n?.[0] || '').join('').slice(0, 2)}
                      </span>
                    )}
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{member.full_name || `${member.first_name} ${member.last_name || ''}`}</h3>
                    <p className="text-sm text-gray-500">{member.position || member.role || 'Мастер'}</p>
                    <span className={clsx(
                      "inline-block mt-1 px-2 py-0.5 rounded-full text-xs font-medium",
                      statusLabels[member.status]?.color || 'bg-gray-100 text-gray-700'
                    )}>
                      {statusLabels[member.status]?.label || member.status}
                    </span>
                  </div>
                </div>
                <button className="text-gray-400 hover:text-gray-600">
                  <MoreVertical className="w-5 h-5" />
                </button>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-100">
                <div className="flex items-center gap-4 text-sm text-gray-500">
                  {member.phone && (
                    <a href={`tel:${member.phone}`} className="flex items-center gap-1 hover:text-primary-600">
                      <Phone className="w-4 h-4" />
                    </a>
                  )}
                  {member.email && (
                    <a href={`mailto:${member.email}`} className="flex items-center gap-1 hover:text-primary-600">
                      <Mail className="w-4 h-4" />
                    </a>
                  )}
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-amber-500" />
                    <span>{(member.avg_rating || 0).toFixed(1)}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <span>{member.total_appointments}</span>
                  </div>
                </div>
              </div>

              <div className="mt-3 grid grid-cols-2 gap-2 text-center">
                <div className="bg-gray-50 rounded-lg p-2">
                  <div className="text-lg font-semibold text-gray-900">{member.total_appointments}</div>
                  <div className="text-xs text-gray-500">Записей</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-2">
                  <div className="text-lg font-semibold text-gray-900">{formatMoney(member.total_revenue)}</div>
                  <div className="text-xs text-gray-500">Выручка</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Staff Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 m-4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Новый сотрудник</h2>
              <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Имя *</label>
                  <input
                    type="text"
                    value={newStaff.first_name}
                    onChange={(e) => setNewStaff({...newStaff, first_name: e.target.value})}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 bg-white"
                    placeholder="Иван"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Фамилия</label>
                  <input
                    type="text"
                    value={newStaff.last_name}
                    onChange={(e) => setNewStaff({...newStaff, last_name: e.target.value})}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 bg-white"
                    placeholder="Иванов"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Телефон *</label>
                <input
                  type="tel"
                  value={newStaff.phone}
                  onChange={(e) => setNewStaff({...newStaff, phone: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 bg-white"
                  placeholder="+7 (999) 123-45-67"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  value={newStaff.email}
                  onChange={(e) => setNewStaff({...newStaff, email: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 bg-white"
                  placeholder="ivan@example.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Должность</label>
                <input
                  type="text"
                  value={newStaff.position}
                  onChange={(e) => setNewStaff({...newStaff, position: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 bg-white"
                  placeholder="Мастер маникюра"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Роль</label>
                <select
                  value={newStaff.role}
                  onChange={(e) => setNewStaff({...newStaff, role: e.target.value})}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 bg-white"
                >
                  <option value="master">Мастер</option>
                  <option value="admin">Администратор</option>
                  <option value="manager">Менеджер</option>
                </select>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setShowAddModal(false)}
                className="flex-1 px-4 py-2 border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50"
              >
                Отмена
              </button>
              <button
                onClick={() => {
                  // TODO: API call to add staff
                  console.log('Adding staff:', newStaff)
                  setShowAddModal(false)
                  setNewStaff({ first_name: '', last_name: '', phone: '', email: '', position: '', role: 'master' })
                }}
                className="flex-1 btn-primary"
              >
                Добавить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
