import { createContext, useContext, useState, useEffect, ReactNode } from 'react'

type Language = 'ru' | 'en'

interface Translations {
  [key: string]: {
    ru: string
    en: string
  }
}

// Translations dictionary
export const translations: Translations = {
  // Header
  'nav.features': { ru: 'Возможности', en: 'Features' },
  'nav.pricing': { ru: 'Тарифы', en: 'Pricing' },
  'nav.testimonials': { ru: 'Отзывы', en: 'Testimonials' },
  'nav.login': { ru: 'Войти', en: 'Login' },
  'nav.tryFree': { ru: 'Попробовать бесплатно', en: 'Try for Free' },
  
  // Hero
  'hero.badge': { ru: 'Новое: AI-ассистент для коммуникаций', en: 'New: AI Assistant for Communications' },
  'hero.title1': { ru: 'Управляйте салоном красоты', en: 'Manage your beauty salon' },
  'hero.title2': { ru: 'как профессионал', en: 'like a professional' },
  'hero.subtitle': { 
    ru: 'Онлайн-запись, CRM, аналитика и автоматизация в одной платформе. Освободите время для творчества, а рутину доверьте нам.',
    en: 'Online booking, CRM, analytics and automation in one platform. Free up time for creativity, leave the routine to us.'
  },
  'hero.cta': { ru: 'Начать бесплатно', en: 'Start for Free' },
  'hero.demo': { ru: 'Смотреть демо', en: 'Watch Demo' },
  'hero.trial': { ru: '14 дней бесплатно • Без привязки карты • Отмена в любой момент', en: '14 days free • No credit card required • Cancel anytime' },
  
  // Stats
  'stats.salons': { ru: 'Салонов', en: 'Salons' },
  'stats.bookings': { ru: 'Записей в месяц', en: 'Bookings per month' },
  'stats.uptime': { ru: 'Uptime', en: 'Uptime' },
  'stats.rating': { ru: 'Рейтинг', en: 'Rating' },
  
  // Features
  'features.title': { ru: 'Всё для успешного салона', en: 'Everything for a Successful Salon' },
  'features.subtitle': { ru: 'Инструменты, которые помогут вам расти и зарабатывать больше', en: 'Tools that help you grow and earn more' },
  'features.booking.title': { ru: 'Онлайн-запись', en: 'Online Booking' },
  'features.booking.desc': { ru: 'Клиенты записываются 24/7 через виджет на вашем сайте или в соцсетях', en: 'Clients book 24/7 through a widget on your website or social media' },
  'features.crm.title': { ru: 'База клиентов', en: 'Client Database' },
  'features.crm.desc': { ru: 'Полная история визитов, предпочтения и автоматическая сегментация', en: 'Complete visit history, preferences and automatic segmentation' },
  'features.analytics.title': { ru: 'Аналитика', en: 'Analytics' },
  'features.analytics.desc': { ru: 'Выручка, загрузка мастеров, популярные услуги — всё в одном месте', en: 'Revenue, staff utilization, popular services — all in one place' },
  'features.notifications.title': { ru: 'Уведомления', en: 'Notifications' },
  'features.notifications.desc': { ru: 'Автоматические напоминания через SMS, Telegram и WhatsApp', en: 'Automatic reminders via SMS, Telegram and WhatsApp' },
  'features.security.title': { ru: 'Безопасность', en: 'Security' },
  'features.security.desc': { ru: 'Данные защищены шифрованием и хранятся в России', en: 'Data is encrypted and stored securely in Europe' },
  'features.integrations.title': { ru: 'Интеграции', en: 'Integrations' },
  'features.integrations.desc': { ru: 'Подключение к 1С, Google Calendar, Telegram-боту и другим сервисам', en: 'Connect to Google Calendar, Telegram bot and other services' },
  
  // Pricing
  'pricing.title': { ru: 'Простые и понятные тарифы', en: 'Simple and Clear Pricing' },
  'pricing.subtitle': { ru: 'Все функции доступны на любом тарифе. Разница только в количестве сотрудников.', en: 'All features available on any plan. The only difference is the number of staff.' },
  'pricing.perMonth': { ru: '/мес', en: '/mo' },
  'pricing.cta': { ru: 'Начать бесплатный период', en: 'Start Free Trial' },
  'pricing.trial': { ru: '14 дней бесплатно • Без привязки карты', en: '14 days free • No credit card required' },
  
  // Business Plan
  'pricing.business.badge': { ru: 'Для небольших салонов', en: 'For Small Salons' },
  'pricing.business.name': { ru: 'Business', en: 'Business' },
  'pricing.business.desc': { ru: 'До 8 сотрудников', en: 'Up to 8 staff members' },
  'pricing.business.price.ru': { ru: '100,000', en: '100,000' },
  'pricing.business.price.eu': { ru: '1,000 €', en: '€1,000' },
  
  // Enterprise Plan
  'pricing.enterprise.badge': { ru: 'Для сетей и крупных салонов', en: 'For Chains & Large Salons' },
  'pricing.enterprise.name': { ru: 'Enterprise', en: 'Enterprise' },
  'pricing.enterprise.desc': { ru: '9+ сотрудников, безлимит', en: '9+ staff members, unlimited' },
  'pricing.enterprise.price.ru': { ru: '200,000', en: '200,000' },
  'pricing.enterprise.price.eu': { ru: '2,000 €', en: '€2,000' },
  
  // Pricing features (same for both plans)
  'pricing.f1': { ru: 'AI-ассистент для записи', en: 'AI Booking Assistant' },
  'pricing.f2': { ru: 'AI-рекомендации и прогнозы', en: 'AI Recommendations & Forecasts' },
  'pricing.f3': { ru: 'CRM и автосегментация', en: 'CRM & Auto-segmentation' },
  'pricing.f4': { ru: 'Telegram, WhatsApp, Instagram боты', en: 'Telegram, WhatsApp, Instagram bots' },
  'pricing.f5': { ru: 'Программа лояльности и бонусы', en: 'Loyalty Program & Bonuses' },
  'pricing.f6': { ru: 'Мультифилиальность', en: 'Multi-branch Support' },
  'pricing.f7': { ru: 'Белый лейбл', en: 'White Label' },
  'pricing.f8': { ru: 'BI-аналитика и отчёты', en: 'BI Analytics & Reports' },
  'pricing.f9': { ru: 'Геймификация команды', en: 'Team Gamification' },
  'pricing.f10': { ru: 'Приоритетная поддержка 24/7', en: '24/7 Priority Support' },
  
  // Testimonials
  'testimonials.title': { ru: 'Нам доверяют тысячи салонов', en: 'Trusted by Thousands of Salons' },
  'testimonials.subtitle': { ru: 'Узнайте, что говорят наши клиенты', en: 'See what our clients say' },
  
  // CTA
  'cta.title': { ru: 'Готовы начать?', en: 'Ready to Start?' },
  'cta.subtitle': { ru: 'Присоединяйтесь к тысячам успешных салонов уже сегодня', en: 'Join thousands of successful salons today' },
  'cta.button': { ru: 'Начать бесплатно', en: 'Start for Free' },
  'cta.contact': { ru: 'Или свяжитесь с нами →', en: 'Or contact us →' },
  
  // Footer
  'footer.product': { ru: 'Продукт', en: 'Product' },
  'footer.company': { ru: 'Компания', en: 'Company' },
  'footer.support': { ru: 'Поддержка', en: 'Support' },
  'footer.legal': { ru: 'Правовая информация', en: 'Legal' },
  'footer.privacy': { ru: 'Политика конфиденциальности', en: 'Privacy Policy' },
  'footer.terms': { ru: 'Условия использования', en: 'Terms of Service' },
  'footer.about': { ru: 'О нас', en: 'About Us' },
  'footer.blog': { ru: 'Блог', en: 'Blog' },
  'footer.careers': { ru: 'Карьера', en: 'Careers' },
  'footer.contacts': { ru: 'Контакты', en: 'Contacts' },
  'footer.docs': { ru: 'Документация', en: 'Documentation' },
  'footer.faq': { ru: 'FAQ', en: 'FAQ' },
  'footer.integrations': { ru: 'Интеграции', en: 'Integrations' },
  'footer.api': { ru: 'API', en: 'API' },
  'footer.copyright': { ru: '© 2025 Business OS. Все права защищены.', en: '© 2025 Business OS. All rights reserved.' },
  
  // Auth
  'auth.login.title': { ru: 'Войти в аккаунт', en: 'Sign in to your account' },
  'auth.register.title': { ru: 'Создайте аккаунт для вашего салона', en: 'Create an account for your salon' },
  'auth.email': { ru: 'Email', en: 'Email' },
  'auth.password': { ru: 'Пароль', en: 'Password' },
  'auth.confirmPassword': { ru: 'Подтвердите пароль', en: 'Confirm Password' },
  'auth.loginButton': { ru: 'Войти', en: 'Sign In' },
  'auth.registerButton': { ru: 'Продолжить', en: 'Continue' },
  'auth.noAccount': { ru: 'Нет аккаунта?', en: "Don't have an account?" },
  'auth.hasAccount': { ru: 'Уже есть аккаунт?', en: 'Already have an account?' },
  'auth.signUp': { ru: 'Зарегистрируйтесь', en: 'Sign up' },
  'auth.signIn': { ru: 'Войдите', en: 'Sign in' },
  'auth.forgotPassword': { ru: 'Забыли пароль?', en: 'Forgot password?' },
  'auth.trial': { ru: '14 дней бесплатно — без привязки карты', en: '14 days free — no credit card required' },
  
  // Dashboard
  'dashboard.title': { ru: 'Дашборд', en: 'Dashboard' },
  'dashboard.overview': { ru: 'Обзор бизнеса за сегодня', en: 'Business overview for today' },
  'dashboard.revenue': { ru: 'Выручка сегодня', en: "Today's Revenue" },
  'dashboard.appointments': { ru: 'Записей сегодня', en: "Today's Appointments" },
  'dashboard.newClients': { ru: 'Новых клиентов', en: 'New Clients' },
  'dashboard.avgCheck': { ru: 'Средний чек', en: 'Average Check' },
  
  // Navigation
  'nav.dashboard': { ru: 'Дашборд', en: 'Dashboard' },
  'nav.clients': { ru: 'Клиенты', en: 'Clients' },
  'nav.appointments': { ru: 'Записи', en: 'Appointments' },
  'nav.staff': { ru: 'Сотрудники', en: 'Staff' },
  'nav.services': { ru: 'Услуги', en: 'Services' },
  'nav.inventory': { ru: 'Склад', en: 'Inventory' },
  'nav.settings': { ru: 'Настройки', en: 'Settings' },
}

interface LanguageContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    // Check localStorage first
    const saved = localStorage.getItem('language') as Language
    if (saved) return saved
    
    // Check browser language
    const browserLang = navigator.language.toLowerCase()
    if (browserLang.startsWith('ru')) return 'ru'
    
    // Default to English for European audience
    return 'en'
  })

  useEffect(() => {
    localStorage.setItem('language', language)
    document.documentElement.lang = language
  }, [language])

  const t = (key: string): string => {
    const translation = translations[key]
    if (!translation) {
      console.warn(`Translation missing for key: ${key}`)
      return key
    }
    return translation[language]
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  )
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider')
  }
  return context
}
