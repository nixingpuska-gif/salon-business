# 💳 Руководство по интеграции с ЮKassa

## Обзор

Полная интеграция с платёжной системой ЮKassa для автоматизации биллинга подписок на платформе AI-Booking.

### Возможности:
1. **Создание платежей** - генерация ссылок для оплаты
2. **Webhook обработка** - автоматическая активация подписок
3. **Возвраты** - полные и частичные возвраты средств
4. **История транзакций** - учёт всех платежей
5. **Статистика** - аналитика платежей и дохода

---

## Регистрация в ЮKassa

### 1. Создать аккаунт

Перейдите на [yookassa.ru](https://yookassa.ru/) и зарегистрируйтесь как юридическое лицо или ИП.

### 2. Получить учётные данные

После регистрации в личном кабинете:

1. Откройте **Настройки** → **Магазины**
2. Выберите ваш магазин
3. Скопируйте:
   - **shopId** (идентификатор магазина)
   - **Секретный ключ** (Secret Key)

### 3. Настроить Webhook

1. В личном кабинете откройте **Настройки** → **Уведомления**
2. Добавьте URL webhook:
   ```
   https://your-domain.com/payment/webhook
   ```
3. Выберите события:
   - ✅ `payment.succeeded` (успешный платёж)
   - ✅ `payment.canceled` (отменённый платёж)
   - ✅ `refund.succeeded` (успешный возврат)

---

## Конфигурация

### Переменные окружения

Добавьте в `.env`:

```env
# ЮKassa
YOOKASSA_SHOP_ID=123456
YOOKASSA_SECRET_KEY=live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Frontend URL (для редиректа после оплаты)
FRONTEND_URL=https://your-domain.com
```

### Тестовый режим

Для тестирования используйте тестовые учётные данные из личного кабинета ЮKassa (раздел "Тестовые данные").

---

## API Endpoints

### POST /payment/create
Создать платёж для подписки

**Request:**
```json
{
  "businessId": "1",
  "tier": "pro",
  "durationMonths": 1,
  "returnUrl": "https://your-domain.com/payment/success"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "2d8f0e7a-000f-5000-9000-1b8e7e7e7e7e",
    "status": "pending",
    "amount": 2990,
    "currency": "RUB",
    "description": "Подписка Профессиональный на 1 мес.",
    "confirmationUrl": "https://yoomoney.ru/checkout/payments/v2/contract?orderId=...",
    "createdAt": "2024-11-25T12:00:00.000Z",
    "metadata": {
      "tier": "pro",
      "durationMonths": 1
    }
  }
}
```

**Использование:**
1. Создайте платёж через API
2. Перенаправьте пользователя на `confirmationUrl`
3. Пользователь оплачивает
4. ЮKassa отправляет webhook
5. Подписка активируется автоматически

---

### GET /payment/:paymentId
Получить информацию о платеже

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "2d8f0e7a-000f-5000-9000-1b8e7e7e7e7e",
    "status": "succeeded",
    "amount": 2990,
    "currency": "RUB",
    "description": "Подписка Профессиональный на 1 мес.",
    "createdAt": "2024-11-25T12:00:00.000Z",
    "capturedAt": "2024-11-25T12:05:00.000Z",
    "metadata": {
      "tier": "pro",
      "durationMonths": 1
    }
  }
}
```

---

### DELETE /payment/:paymentId/cancel
Отменить платёж

**Response:**
```json
{
  "success": true,
  "message": "Payment cancelled successfully"
}
```

**Примечание:** Можно отменить только платежи в статусе `pending` или `waiting_for_capture`.

---

### POST /payment/:paymentId/refund
Создать возврат

**Request (полный возврат):**
```json
{}
```

**Request (частичный возврат):**
```json
{
  "amount": 1000
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "2d8f0e7a-000f-5000-9000-refund123",
    "status": "succeeded"
  }
}
```

---

### GET /payment/history/:businessId
Получить историю платежей

**Query параметры:**
- `limit` - количество записей (по умолчанию 50)
- `offset` - смещение для пагинации
- `status` - фильтр по статусу (pending, succeeded, canceled, refunded)

**Response:**
```json
{
  "success": true,
  "payments": [
    {
      "id": "2d8f0e7a-000f-5000-9000-1b8e7e7e7e7e",
      "status": "succeeded",
      "amount": 2990,
      "currency": "RUB",
      "description": "Подписка Профессиональный на 1 мес.",
      "createdAt": "2024-11-25T12:00:00.000Z",
      "capturedAt": "2024-11-25T12:05:00.000Z"
    }
  ],
  "total": 15
}
```

---

### GET /payment/stats/:businessId
Получить статистику платежей

**Response:**
```json
{
  "success": true,
  "data": {
    "totalAmount": 29900,
    "successfulPayments": 10,
    "pendingPayments": 2,
    "refundedAmount": 2990
  }
}
```

---

### POST /payment/webhook
Webhook от ЮKassa (автоматический)

**Этот endpoint вызывается ЮKassa автоматически.**

**Request (пример):**
```json
{
  "type": "payment.succeeded",
  "event": "payment.succeeded",
  "object": {
    "id": "2d8f0e7a-000f-5000-9000-1b8e7e7e7e7e",
    "status": "succeeded",
    "amount": {
      "value": "2990.00",
      "currency": "RUB"
    },
    "captured_at": "2024-11-25T12:05:00.000Z",
    "metadata": {
      "businessId": "1",
      "tier": "pro",
      "durationMonths": 1
    }
  }
}
```

**Обработка:**
1. Webhook обрабатывается в `PaymentService.handleWebhook()`
2. Статус платежа обновляется в БД
3. При `payment.succeeded` вызывается `activateSubscriptionAfterPayment()`
4. Подписка создаётся или обновляется через `SubscriptionService`

---

## Статусы платежей

| Статус | Описание |
|--------|----------|
| `pending` | Платёж создан, ожидает оплаты |
| `waiting_for_capture` | Платёж авторизован, ожидает подтверждения |
| `succeeded` | Платёж успешно завершён |
| `canceled` | Платёж отменён |
| `refunded` | Платёж возвращён |

---

## Использование в коде

### Frontend: Создание платежа

```typescript
// 1. Создать платёж
const response = await fetch('/payment/create', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    businessId: '1',
    tier: 'pro',
    durationMonths: 1,
    returnUrl: window.location.origin + '/payment/success',
  }),
});

const { data } = await response.json();

// 2. Перенаправить на страницу оплаты
window.location.href = data.confirmationUrl;
```

### Frontend: Обработка успешной оплаты

```typescript
// На странице /payment/success
const urlParams = new URLSearchParams(window.location.search);
const paymentId = urlParams.get('paymentId');

if (paymentId) {
  // Проверить статус платежа
  const response = await fetch(`/payment/${paymentId}`);
  const { data } = await response.json();

  if (data.status === 'succeeded') {
    // Показать сообщение об успехе
    alert('Подписка успешно активирована!');
  }
}
```

### Backend: Интеграция с другими модулями

```typescript
import { PaymentService } from './payment/payment.service';

@Injectable()
export class MyService {
  constructor(private paymentService: PaymentService) {}

  async getBusinessPayments(businessId: string) {
    const history = await this.paymentService.getPaymentHistory(businessId);
    return history;
  }
}
```

---

## Автоматическая активация подписок

### Как это работает:

1. **Пользователь создаёт платёж:**
   - Frontend вызывает `POST /payment/create`
   - В metadata сохраняется `businessId`, `tier`, `durationMonths`

2. **Пользователь оплачивает:**
   - Перенаправляется на `confirmationUrl`
   - Оплачивает через ЮKassa

3. **ЮKassa отправляет webhook:**
   - `POST /payment/webhook` с событием `payment.succeeded`

4. **Система активирует подписку:**
   - `PaymentController.handleWebhook()` вызывает `activateSubscriptionAfterPayment()`
   - Извлекает `businessId`, `tier`, `durationMonths` из metadata
   - Вызывает `SubscriptionService.createSubscription()` или `updateSubscription()`
   - Подписка активируется автоматически

5. **Пользователь получает доступ:**
   - Feature flags автоматически разрешают доступ к функциям нового тарифа

---

## Тестирование

### Тестовые карты ЮKassa

| Номер карты | Результат |
|-------------|-----------|
| `5555 5555 5555 4477` | Успешный платёж |
| `5555 5555 5555 5599` | Отклонённый платёж |

**CVV:** любой  
**Срок действия:** любая будущая дата  
**Имя:** любое

### Проверка webhook локально

Используйте [ngrok](https://ngrok.com/) для тестирования webhook:

```bash
# Запустить ngrok
ngrok http 3000

# Скопировать URL (например, https://abc123.ngrok.io)
# Добавить в ЮKassa: https://abc123.ngrok.io/payment/webhook
```

---

## Безопасность

### Проверка подлинности webhook

ЮKassa не подписывает webhook цифровой подписью, но рекомендуется:

1. **Проверять IP адреса** ЮKassa (см. документацию)
2. **Проверять платёж через API** после получения webhook
3. **Использовать HTTPS** для webhook URL

### Пример проверки:

```typescript
@Post('webhook')
async handleWebhook(@Req() req: Request, @Body() body: any) {
  // Проверить IP (опционально)
  const allowedIPs = ['185.71.76.0/27', '185.71.77.0/27'];
  const clientIP = req.ip;
  
  // Обработать webhook
  await this.paymentService.handleWebhook(body);
  
  // Дополнительно проверить платёж через API
  if (body.type === 'payment.succeeded') {
    const payment = await this.paymentService.getPayment(body.object.id);
    if (payment.status === 'succeeded') {
      await this.activateSubscription(payment);
    }
  }
  
  return { success: true };
}
```

---

## База данных

### Prisma Schema

Добавьте в `schema.prisma`:

```prisma
model Payment {
  id              String    @id
  businessId      String
  amount          Float
  currency        String    @default("RUB")
  status          String    // pending, succeeded, canceled, refunded
  description     String
  confirmationUrl String?
  capturedAt      DateTime?
  metadata        Json      @default({})
  yookassaData    Json      @default({})
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt

  business        Business  @relation(fields: [businessId], references: [id], onDelete: Cascade)
  refunds         Refund[]

  @@index([businessId])
  @@index([status])
}

model Refund {
  id           String   @id
  paymentId    String
  amount       Float
  status       String   // pending, succeeded, canceled
  yookassaData Json     @default({})
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt

  payment      Payment  @relation(fields: [paymentId], references: [id], onDelete: Cascade)

  @@index([paymentId])
}
```

### Миграция:

```bash
cd backend
npx prisma migrate dev --name add_payments
```

---

## Мониторинг

### Логирование

Все операции логируются через NestJS Logger:

```typescript
this.logger.log('Payment created: 2d8f0e7a... for 2990 RUB');
this.logger.log('Payment succeeded: 2d8f0e7a...');
this.logger.error('Failed to create payment:', error);
```

### Метрики для отслеживания:

- Количество успешных платежей
- Общая сумма платежей
- Количество возвратов
- Процент успешных платежей
- Средний чек

### Получение метрик:

```typescript
const stats = await paymentService.getPaymentStats();
console.log(`Revenue: ${stats.totalAmount} RUB`);
console.log(`Success rate: ${(stats.successfulPayments / (stats.successfulPayments + stats.pendingPayments)) * 100}%`);
```

---

## Частые проблемы

### 1. Webhook не приходит

**Причины:**
- Неправильный URL webhook в настройках ЮKassa
- Сервер недоступен извне
- Firewall блокирует запросы

**Решение:**
- Проверьте URL в личном кабинете ЮKassa
- Используйте ngrok для локального тестирования
- Проверьте логи сервера

### 2. Подписка не активируется

**Причины:**
- Отсутствует metadata в платеже
- Ошибка в SubscriptionService

**Решение:**
- Проверьте, что metadata передаётся при создании платежа
- Проверьте логи webhook обработки
- Убедитесь, что SubscriptionModule импортирован в PaymentModule

### 3. Ошибка "YooKassa credentials not configured"

**Причина:**
- Отсутствуют переменные окружения

**Решение:**
- Добавьте `YOOKASSA_SHOP_ID` и `YOOKASSA_SECRET_KEY` в `.env`
- Перезапустите сервер

---

## Дополнительные функции

### Подписка с автопродлением

```typescript
// При создании подписки установить autoRenew: true
await subscriptionService.createSubscription(
  businessId,
  tier,
  1,
  false, // не trial
);

// Cron job для автопродления
@Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT)
async handleAutoRenew() {
  const expiring = await subscriptionService.checkExpiringSubscriptions(1);
  
  for (const subscription of expiring) {
    // Создать платёж для продления
    await paymentService.createPayment({
      amount: getPlanPrice(subscription.tier),
      description: `Автопродление подписки ${subscription.tier}`,
      businessId: subscription.businessId,
      metadata: {
        tier: subscription.tier,
        durationMonths: 1,
        autoRenew: true,
      },
    });
  }
}
```

### Скидки и промокоды

```typescript
// Добавить поле discount в metadata
const payment = await paymentService.createPayment({
  amount: plan.price * 0.8, // 20% скидка
  description: `Подписка ${plan.name} (скидка 20%)`,
  businessId,
  metadata: {
    tier,
    durationMonths: 1,
    discount: 20,
    promoCode: 'SUMMER2024',
  },
});
```

---

## Полезные ссылки

- **Документация ЮKassa:** https://yookassa.ru/developers
- **API Reference:** https://yookassa.ru/developers/api
- **Тестовые данные:** https://yookassa.ru/developers/payment-acceptance/testing-and-going-live/testing

**Готово!** 🎉 Интеграция с ЮKassa полностью настроена.
