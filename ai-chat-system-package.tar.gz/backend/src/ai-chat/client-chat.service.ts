import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { ConversationContextService } from './conversation-context.service';
import { ScenarioService } from './scenario.service';
import { PrismaService } from '../prisma/prisma.service';
import { LoggerService } from '../monitoring/logger.service';

/**
 * Client Chat Service
 * 
 * AI-чат бот для клиентов:
 * - Работает по настроенным сценариям владельца
 * - Запоминает информацию о клиенте
 * - Не спрашивает уже известную информацию
 * - Помогает с записью, переносом, отменой
 * - Отвечает на вопросы
 */

interface ClientChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

@Injectable()
export class ClientChatService {
  private openai: OpenAI;

  constructor(
    private configService: ConfigService,
    private contextService: ConversationContextService,
    private scenarioService: ScenarioService,
    private prisma: PrismaService,
    private logger: LoggerService,
  ) {
    this.openai = new OpenAI({
      apiKey: this.configService.get<string>('OPENAI_API_KEY'),
    });
    this.logger.setContext('ClientChatService');
  }

  /**
   * Обработать сообщение от клиента
   */
  async processMessage(
    businessId: string,
    message: string,
    channel: string,
    channelUserId: string,
  ): Promise<string> {
    try {
      // Получить или создать контекст
      const context = await this.contextService.getOrCreateContext(
        businessId,
        channel,
        channelUserId,
      );

      // Добавить сообщение пользователя
      await this.contextService.addMessage(context.conversationId, 'user', message);

      // Получить память клиента (если уже есть)
      let clientMemory = null;
      if (context.clientId) {
        clientMemory = await this.contextService.getClientMemory(businessId, context.clientId);
      }

      // Получить информацию о бизнесе
      const business = await this.prisma.business.findUnique({
        where: { id: businessId },
      });

      // Получить активный сценарий
      const scenario = await this.scenarioService.getActiveScenario(businessId);

      // Построить системный промпт
      const systemPrompt = await this.buildClientSystemPrompt(
        business,
        scenario,
        clientMemory,
        context.extractedData,
      );

      // Построить историю сообщений
      const messages: ClientChatMessage[] = [
        { role: 'system', content: systemPrompt },
        ...context.messages.map((m) => ({
          role: m.role,
          content: m.content,
        })),
        { role: 'user', content: message },
      ];

      // Вызвать OpenAI с function calling
      const response = await this.openai.chat.completions.create({
        model: 'gpt-4-turbo-preview',
        messages: messages as any,
        functions: this.getClientFunctions(),
        function_call: 'auto',
        temperature: 0.7,
      });

      const assistantMessage = response.choices[0].message;

      // Если AI вызывает функцию
      if (assistantMessage.function_call) {
        const functionName = assistantMessage.function_call.name;
        const functionArgs = JSON.parse(assistantMessage.function_call.arguments);

        this.logger.log(`Client function call: ${functionName}`, undefined, { args: functionArgs });

        // Выполнить функцию
        const functionResult = await this.executeClientFunction(
          businessId,
          context.conversationId,
          context.clientId,
          functionName,
          functionArgs,
          channel,
          channelUserId,
        );

        // Отправить результат обратно в AI
        const secondResponse = await this.openai.chat.completions.create({
          model: 'gpt-4-turbo-preview',
          messages: [
            ...messages,
            assistantMessage,
            {
              role: 'function',
              name: functionName,
              content: JSON.stringify(functionResult),
            },
          ] as any,
          temperature: 0.7,
        });

        const finalMessage = secondResponse.choices[0].message.content;

        // Сохранить ответ
        await this.contextService.addMessage(
          context.conversationId,
          'assistant',
          finalMessage,
        );

        return finalMessage;
      }

      // Если AI просто отвечает
      const reply = assistantMessage.content;

      // Извлечь информацию из ответа AI
      await this.extractAndSaveClientInfo(
        context.conversationId,
        businessId,
        context.clientId,
        message,
        reply,
        channel,
        channelUserId,
      );

      // Сохранить ответ
      await this.contextService.addMessage(context.conversationId, 'assistant', reply);

      return reply;
    } catch (error) {
      this.logger.logError(error, 'ClientChatService', { businessId, message });
      
      const scenario = await this.scenarioService.getActiveScenario(businessId);
      return scenario?.errorMessage || 'Извините, произошла ошибка. Пожалуйста, попробуйте ещё раз.';
    }
  }

  /**
   * Построить системный промпт для клиентского бота
   */
  private async buildClientSystemPrompt(
    business: any,
    scenario: any,
    clientMemory: any,
    extractedData: any,
  ): Promise<string> {
    let prompt = '';

    // Использовать кастомный промпт из сценария или дефолтный
    if (scenario) {
      prompt = await this.scenarioService.getSystemPromptWithContext(business.id, {
        name: business.name,
        address: business.address,
        phone: business.phone,
        workingHours: business.workingHours,
      });
    } else {
      prompt = `Вы — дружелюбный AI-помощник салона "${business.name}". Помогайте клиентам с записью.`;
    }

    // Добавить информацию о клиенте, если есть
    if (clientMemory) {
      prompt += `\n\nИнформация о клиенте:\n`;
      if (clientMemory.name) prompt += `- Имя: ${clientMemory.name}\n`;
      if (clientMemory.phone) prompt += `- Телефон: ${clientMemory.phone}\n`;
      if (clientMemory.totalBookings > 0) {
        prompt += `- Количество визитов: ${clientMemory.totalBookings}\n`;
      }
      if (clientMemory.preferredServices && clientMemory.preferredServices.length > 0) {
        prompt += `- Предпочитаемые услуги: ${clientMemory.preferredServices.join(', ')}\n`;
      }
      if (clientMemory.lastBookingDate) {
        prompt += `- Последний визит: ${clientMemory.lastBookingDate.toLocaleDateString('ru-RU')}\n`;
      }

      prompt += `\nВАЖНО: Не спрашивайте уже известную информацию. Используйте её для персонализации общения.`;
    }

    // Добавить уже собранные данные в текущем диалоге
    if (extractedData && Object.keys(extractedData).length > 0) {
      prompt += `\n\nУже собранная информация в этом диалоге:\n`;
      if (extractedData.name) prompt += `- Имя: ${extractedData.name}\n`;
      if (extractedData.phone) prompt += `- Телефон: ${extractedData.phone}\n`;
      if (extractedData.email) prompt += `- Email: ${extractedData.email}\n`;
    }

    // Добавить инструкции по сбору данных
    if (scenario && scenario.requiredFields) {
      const missingFields = scenario.requiredFields.filter((field) => {
        const fieldName = field.field === 'custom' ? field.customFieldName : field.field;
        return !extractedData[fieldName] && (!clientMemory || !clientMemory[fieldName]);
      });

      if (missingFields.length > 0) {
        prompt += `\n\nОБЯЗАТЕЛЬНО соберите следующую информацию (если ещё не собрана):\n`;
        missingFields.forEach((field) => {
          prompt += `- ${field.question}\n`;
        });
      }
    }

    return prompt;
  }

  /**
   * Получить список функций для клиентского бота
   */
  private getClientFunctions(): any[] {
    return [
      {
        name: 'get_available_services',
        description: 'Получить список доступных услуг',
        parameters: {
          type: 'object',
          properties: {},
        },
      },
      {
        name: 'get_available_slots',
        description: 'Получить свободные слоты для записи',
        parameters: {
          type: 'object',
          properties: {
            serviceId: {
              type: 'string',
              description: 'ID услуги',
            },
            date: {
              type: 'string',
              description: 'Дата в формате YYYY-MM-DD',
            },
          },
          required: ['serviceId', 'date'],
        },
      },
      {
        name: 'create_booking',
        description: 'Создать запись',
        parameters: {
          type: 'object',
          properties: {
            serviceId: {
              type: 'string',
            },
            dateTime: {
              type: 'string',
              description: 'Дата и время в формате ISO',
            },
            clientName: {
              type: 'string',
            },
            clientPhone: {
              type: 'string',
            },
            clientEmail: {
              type: 'string',
            },
          },
          required: ['serviceId', 'dateTime', 'clientName', 'clientPhone'],
        },
      },
      {
        name: 'get_my_bookings',
        description: 'Получить записи клиента',
        parameters: {
          type: 'object',
          properties: {
            status: {
              type: 'string',
              enum: ['all', 'upcoming', 'past'],
            },
          },
        },
      },
      {
        name: 'cancel_booking',
        description: 'Отменить запись',
        parameters: {
          type: 'object',
          properties: {
            bookingId: {
              type: 'string',
            },
            reason: {
              type: 'string',
            },
          },
          required: ['bookingId'],
        },
      },
      {
        name: 'reschedule_booking',
        description: 'Перенести запись',
        parameters: {
          type: 'object',
          properties: {
            bookingId: {
              type: 'string',
            },
            newDateTime: {
              type: 'string',
              description: 'Новая дата и время в формате ISO',
            },
          },
          required: ['bookingId', 'newDateTime'],
        },
      },
    ];
  }

  /**
   * Выполнить функцию клиентского бота
   */
  private async executeClientFunction(
    businessId: string,
    conversationId: string,
    clientId: string | null,
    functionName: string,
    args: any,
    channel: string,
    channelUserId: string,
  ): Promise<any> {
    switch (functionName) {
      case 'get_available_services':
        return this.getAvailableServices(businessId);

      case 'get_available_slots':
        return this.getAvailableSlots(businessId, args.serviceId, args.date);

      case 'create_booking':
        return this.createBooking(
          businessId,
          conversationId,
          clientId,
          args,
          channel,
          channelUserId,
        );

      case 'get_my_bookings':
        return this.getMyBookings(businessId, clientId, args.status);

      case 'cancel_booking':
        return this.cancelBooking(businessId, clientId, args.bookingId, args.reason);

      case 'reschedule_booking':
        return this.rescheduleBooking(businessId, clientId, args.bookingId, args.newDateTime);

      default:
        return { error: 'Unknown function' };
    }
  }

  /**
   * Получить доступные услуги
   */
  private async getAvailableServices(businessId: string): Promise<any> {
    const services = await this.prisma.service.findMany({
      where: {
        businessId,
        isActive: true,
      },
      orderBy: { displayOrder: 'asc' },
    });

    return services.map((s) => ({
      id: s.id,
      name: s.name,
      duration: s.durationMinutes,
      price: s.price,
      description: s.description,
    }));
  }

  /**
   * Получить свободные слоты
   */
  private async getAvailableSlots(
    businessId: string,
    serviceId: string,
    date: string,
  ): Promise<any> {
    // Упрощённая логика - в реальности нужно учитывать расписание
    const targetDate = new Date(date);
    const slots = [];

    for (let hour = 9; hour < 18; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const slotTime = new Date(targetDate);
        slotTime.setHours(hour, minute, 0, 0);

        // Проверить, не занят ли слот
        const existingBooking = await this.prisma.booking.findFirst({
          where: {
            businessId,
            serviceId,
            dateTime: slotTime,
            status: { in: ['confirmed', 'pending'] },
          },
        });

        if (!existingBooking) {
          slots.push({
            dateTime: slotTime.toISOString(),
            time: `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`,
          });
        }
      }
    }

    return { slots };
  }

  /**
   * Создать запись
   */
  private async createBooking(
    businessId: string,
    conversationId: string,
    clientId: string | null,
    data: any,
    channel: string,
    channelUserId: string,
  ): Promise<any> {
    // Найти или создать клиента
    if (!clientId) {
      const extractedData = {
        name: data.clientName,
        phone: data.clientPhone,
        email: data.clientEmail,
      };

      clientId = await this.contextService.findOrCreateClient(
        businessId,
        extractedData,
        channel,
        channelUserId,
      );

      // Связать диалог с клиентом
      await this.contextService.linkConversationToClient(conversationId, clientId);

      // Сохранить извлечённые данные
      await this.contextService.updateExtractedData(conversationId, extractedData);
    }

    // Получить услугу
    const service = await this.prisma.service.findUnique({
      where: { id: data.serviceId },
    });

    if (!service) {
      return { error: 'Service not found' };
    }

    // Создать запись
    const booking = await this.prisma.booking.create({
      data: {
        businessId,
        clientId,
        serviceId: data.serviceId,
        dateTime: new Date(data.dateTime),
        status: 'confirmed',
        price: service.price,
        source: channel,
      },
      include: {
        service: true,
        client: true,
      },
    });

    // Обновить память клиента
    await this.contextService.updateClientMemory(businessId, clientId, {
      preferredServices: [service.name],
    });

    return {
      success: true,
      booking: {
        id: booking.id,
        date: booking.dateTime.toLocaleDateString('ru-RU'),
        time: booking.dateTime.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
        service: service.name,
        price: service.price,
      },
    };
  }

  /**
   * Получить записи клиента
   */
  private async getMyBookings(
    businessId: string,
    clientId: string | null,
    status: string = 'upcoming',
  ): Promise<any> {
    if (!clientId) {
      return { bookings: [] };
    }

    const where: any = {
      businessId,
      clientId,
    };

    if (status === 'upcoming') {
      where.dateTime = { gte: new Date() };
      where.status = { in: ['confirmed', 'pending'] };
    } else if (status === 'past') {
      where.dateTime = { lt: new Date() };
    }

    const bookings = await this.prisma.booking.findMany({
      where,
      include: { service: true },
      orderBy: { dateTime: status === 'upcoming' ? 'asc' : 'desc' },
      take: 10,
    });

    return {
      bookings: bookings.map((b) => ({
        id: b.id,
        date: b.dateTime.toLocaleDateString('ru-RU'),
        time: b.dateTime.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
        service: b.service.name,
        status: b.status,
        price: b.price,
      })),
    };
  }

  /**
   * Отменить запись
   */
  private async cancelBooking(
    businessId: string,
    clientId: string | null,
    bookingId: string,
    reason?: string,
  ): Promise<any> {
    const booking = await this.prisma.booking.findFirst({
      where: {
        id: bookingId,
        businessId,
        ...(clientId && { clientId }),
      },
    });

    if (!booking) {
      return { error: 'Booking not found' };
    }

    await this.prisma.booking.update({
      where: { id: bookingId },
      data: {
        status: 'cancelled',
        cancellationReason: reason,
        cancelledAt: new Date(),
      },
    });

    return { success: true, message: 'Запись отменена' };
  }

  /**
   * Перенести запись
   */
  private async rescheduleBooking(
    businessId: string,
    clientId: string | null,
    bookingId: string,
    newDateTime: string,
  ): Promise<any> {
    const booking = await this.prisma.booking.findFirst({
      where: {
        id: bookingId,
        businessId,
        ...(clientId && { clientId }),
      },
    });

    if (!booking) {
      return { error: 'Booking not found' };
    }

    await this.prisma.booking.update({
      where: { id: bookingId },
      data: {
        dateTime: new Date(newDateTime),
        updatedAt: new Date(),
      },
    });

    return { success: true, message: 'Запись перенесена' };
  }

  /**
   * Извлечь и сохранить информацию о клиенте
   */
  private async extractAndSaveClientInfo(
    conversationId: string,
    businessId: string,
    clientId: string | null,
    userMessage: string,
    aiResponse: string,
    channel: string,
    channelUserId: string,
  ): Promise<void> {
    // Простое извлечение имени и телефона из сообщения
    const extractedData: any = {};

    // Извлечь имя (простая эвристика)
    const nameMatch = userMessage.match(/зовут\s+([А-ЯЁа-яё]+)/i) ||
                      userMessage.match(/меня\s+([А-ЯЁа-яё]+)/i) ||
                      userMessage.match(/^([А-ЯЁ][а-яё]+)$/);
    if (nameMatch) {
      extractedData.name = nameMatch[1];
    }

    // Извлечь телефон
    const phoneMatch = userMessage.match(/(\+?7|8)[\s-]?\(?(\d{3})\)?[\s-]?(\d{3})[\s-]?(\d{2})[\s-]?(\d{2})/);
    if (phoneMatch) {
      extractedData.phone = `+7${phoneMatch[2]}${phoneMatch[3]}${phoneMatch[4]}${phoneMatch[5]}`;
    }

    // Извлечь email
    const emailMatch = userMessage.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/);
    if (emailMatch) {
      extractedData.email = emailMatch[1];
    }

    if (Object.keys(extractedData).length > 0) {
      // Сохранить в контекст диалога
      await this.contextService.updateExtractedData(conversationId, extractedData);

      // Если клиент уже существует, обновить его данные
      if (clientId) {
        await this.contextService.updateClientMemory(businessId, clientId, extractedData);
      }
    }
  }
}
