import { useState } from 'react'
import { 
  FileText, Download, Calendar, TrendingUp, TrendingDown,
  Users, DollarSign, Clock, Star, ChevronRight, Mail
} from 'lucide-react'

interface WeeklyReport {
  week: string
  revenue: number
  revenueChange: number
  appointments: number
  appointmentsChange: number
  newClients: number
  avgCheck: number
  utilization: number
  aiVerdict: string
  aiRecommendations: string[]
}

export default function Reports() {
  const [selectedPeriod, setSelectedPeriod] = useState('week')
  
  const currentReport: WeeklyReport = {
    week: '9-15 декабря 2024',
    revenue: 487500,
    revenueChange: 12.5,
    appointments: 156,
    appointmentsChange: 8.3,
    newClients: 18,
    avgCheck: 3125,
    utilization: 72,
    aiVerdict: 'Отличная неделя! Выручка выросла на 12.5%, загрузка мастеров оптимальна. Рекомендую сфокусироваться на удержании новых клиентов.',
    aiRecommendations: [
      'Запустить welcome-серию для 18 новых клиентов',
      'Анна Петрова перегружена — рассмотрите найм ещё одного мастера маникюра',
      'Услуга "Массаж лица" показала рост 45% — добавьте в рекомендации',
      'Среда — самый слабый день, запустите акцию "Счастливая среда"'
    ]
  }

  const previousReports = [
    { week: '2-8 декабря', revenue: 433500, change: 5.2 },
    { week: '25 ноя - 1 дек', revenue: 412000, change: -2.1 },
    { week: '18-24 ноября', revenue: 421000, change: 8.7 },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <FileText className="w-7 h-7 text-primary-600" />
            Отчёты
          </h1>
          <p className="text-gray-600 mt-1">Еженедельная аналитика с AI-рекомендациями</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-4 py-2 border rounded-lg hover:bg-gray-50">
            <Mail className="w-4 h-4" />
            Настроить рассылку
          </button>
          <button className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700">
            <Download className="w-4 h-4" />
            Скачать PDF
          </button>
        </div>
      </div>

      {/* Period selector */}
      <div className="flex gap-2">
        {[
          { id: 'week', label: 'Неделя' },
          { id: 'month', label: 'Месяц' },
          { id: 'quarter', label: 'Квартал' },
        ].map((period) => (
          <button
            key={period.id}
            onClick={() => setSelectedPeriod(period.id)}
            className={`px-4 py-2 rounded-lg font-medium transition-colors ${
              selectedPeriod === period.id
                ? 'bg-primary-600 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {period.label}
          </button>
        ))}
      </div>

      {/* Current Report */}
      <div className="bg-white rounded-2xl border overflow-hidden">
        <div className="bg-gradient-to-r from-primary-600 to-primary-700 p-6 text-white">
          <div className="flex items-center gap-2 text-white/80 mb-2">
            <Calendar className="w-4 h-4" />
            {currentReport.week}
          </div>
          <h2 className="text-2xl font-bold">Еженедельный отчёт</h2>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 p-6 border-b">
          <div>
            <div className="flex items-center gap-2 text-gray-600 text-sm">
              <DollarSign className="w-4 h-4" />
              Выручка
            </div>
            <div className="text-2xl font-bold text-gray-900 mt-1">
              {currentReport.revenue.toLocaleString()}₽
            </div>
            <div className={`text-sm flex items-center gap-1 ${currentReport.revenueChange > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {currentReport.revenueChange > 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
              {currentReport.revenueChange > 0 ? '+' : ''}{currentReport.revenueChange}%
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 text-gray-600 text-sm">
              <Calendar className="w-4 h-4" />
              Записей
            </div>
            <div className="text-2xl font-bold text-gray-900 mt-1">{currentReport.appointments}</div>
            <div className={`text-sm flex items-center gap-1 ${currentReport.appointmentsChange > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {currentReport.appointmentsChange > 0 ? '+' : ''}{currentReport.appointmentsChange}%
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2 text-gray-600 text-sm">
              <Users className="w-4 h-4" />
              Новых клиентов
            </div>
            <div className="text-2xl font-bold text-gray-900 mt-1">{currentReport.newClients}</div>
          </div>
          <div>
            <div className="flex items-center gap-2 text-gray-600 text-sm">
              <Star className="w-4 h-4" />
              Средний чек
            </div>
            <div className="text-2xl font-bold text-gray-900 mt-1">{currentReport.avgCheck.toLocaleString()}₽</div>
          </div>
          <div>
            <div className="flex items-center gap-2 text-gray-600 text-sm">
              <Clock className="w-4 h-4" />
              Загрузка
            </div>
            <div className="text-2xl font-bold text-gray-900 mt-1">{currentReport.utilization}%</div>
          </div>
        </div>

        {/* AI Verdict */}
        <div className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-xl flex items-center justify-center flex-shrink-0">
              <span className="text-white text-xl">🤖</span>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">AI-вердикт</h3>
              <p className="text-gray-700">{currentReport.aiVerdict}</p>
            </div>
          </div>
        </div>

        {/* AI Recommendations */}
        <div className="p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Рекомендации на следующую неделю</h3>
          <div className="space-y-3">
            {currentReport.aiRecommendations.map((rec, idx) => (
              <div key={idx} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                <div className="w-6 h-6 bg-primary-100 text-primary-700 rounded-full flex items-center justify-center text-sm font-medium flex-shrink-0">
                  {idx + 1}
                </div>
                <span className="text-gray-700">{rec}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Previous Reports */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Предыдущие отчёты</h2>
        <div className="bg-white rounded-xl border divide-y">
          {previousReports.map((report) => (
            <div key={report.week} className="flex items-center justify-between p-4 hover:bg-gray-50 cursor-pointer">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                  <FileText className="w-5 h-5 text-gray-600" />
                </div>
                <div>
                  <div className="font-medium text-gray-900">{report.week}</div>
                  <div className="text-sm text-gray-500">{report.revenue.toLocaleString()}₽</div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <span className={`text-sm font-medium ${report.change > 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {report.change > 0 ? '+' : ''}{report.change}%
                </span>
                <ChevronRight className="w-5 h-5 text-gray-400" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
