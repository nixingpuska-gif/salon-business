"""Business OS - Partners Endpoints"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db

router = APIRouter()

@router.get("/me")
async def get_partner_info(db: AsyncSession = Depends(get_db)):
    return {"referral_code": "", "balance": 0, "total_earned": 0}

@router.get("/referrals")
async def list_referrals(db: AsyncSession = Depends(get_db)):
    return {"items": [], "total": 0}

@router.post("/withdraw")
async def request_withdrawal(db: AsyncSession = Depends(get_db)):
    raise HTTPException(status_code=501, detail="Not implemented")
