"""
Lead Management API - Управление лидами для владельца платформы
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime
from pydantic import BaseModel
from typing import Optional, List
from enum import Enum

from app.core.database import get_db

router = APIRouter()


class LeadStatus(str, Enum):
    NEW = "new"
    CONTACTED = "contacted"
    DEMO_SCHEDULED = "demo_scheduled"
    DEMO_COMPLETED = "demo_completed"
    TRIAL = "trial"
    NEGOTIATION = "negotiation"
    WON = "won"
    LOST = "lost"


class LeadTemperature(str, Enum):
    HOT = "hot"
    WARM = "warm"
    COLD = "cold"


@router.get("")
async def list_leads(
    status: Optional[str] = None,
    temperature: Optional[str] = None,
    limit: int = Query(50, le=200),
    db: AsyncSession = Depends(get_db)
):
    """Список лидов с AI-скорингом"""
    
    leads = [
        {
            "id": 1, "salon_name": "Beauty Expert", "owner_name": "Мария Иванова",
            "phone": "+7 (999) 123-45-67", "email": "maria@beautyexpert.ru",
            "city": "Москва", "staff_count": 8, "source": "Яндекс.Директ",
            "temperature": "hot", "score": 92, "status": "demo_scheduled",
            "created_at": "2024-12-15", "last_contact": "2024-12-17",
            "next_action": "Демо завтра в 14:00",
            "ai_notes": "Высокий потенциал: 8 мастеров, активно ищет CRM."
        },
        {
            "id": 2, "salon_name": "Nail Studio Pro", "owner_name": "Елена Козлова",
            "phone": "+7 (999) 234-56-78", "email": "elena@nailstudio.ru",
            "city": "Санкт-Петербург", "staff_count": 5, "source": "Instagram",
            "temperature": "warm", "score": 75, "status": "contacted",
            "created_at": "2024-12-14", "last_contact": "2024-12-16",
            "next_action": "Перезвонить в пятницу",
            "ai_notes": "Интересуется AI-функциями. Сомневается в цене."
        },
        {
            "id": 3, "salon_name": "Hair Masters", "owner_name": "Ольга Сидорова",
            "phone": "+7 (999) 345-67-89", "email": "olga@hairmasters.ru",
            "city": "Казань", "staff_count": 12, "source": "Реферал",
            "temperature": "hot", "score": 88, "status": "negotiation",
            "created_at": "2024-12-10", "last_contact": "2024-12-17",
            "next_action": "Отправить договор",
            "ai_notes": "12 мастеров = тариф Enterprise. Готова к подключению."
        },
    ]
    
    return {
        "items": leads,
        "total": len(leads),
        "summary": {"hot": 2, "warm": 1, "cold": 0},
        "pipeline_value": 400000
    }


@router.get("/stats")
async def get_lead_stats(db: AsyncSession = Depends(get_db)):
    """Статистика по лидам"""
    return {
        "new": 12,
        "qualified": 8,
        "demo_scheduled": 5,
        "won": 3,
        "lost": 2,
        "conversion_rate": 25.0,
        "avg_deal_cycle_days": 14
    }


@router.get("/funnel")
async def get_funnel(
    period: str = Query("month"),
    db: AsyncSession = Depends(get_db)
):
    """Воронка продаж"""
    
    return {
        "period": period,
        "stages": [
            {"stage": "Новые заявки", "count": 45, "value": 4500000, "conversion": 60},
            {"stage": "Контакт", "count": 27, "value": 2700000, "conversion": 70},
            {"stage": "Демо назначено", "count": 19, "value": 1900000, "conversion": 80},
            {"stage": "Демо проведено", "count": 15, "value": 1500000, "conversion": 60},
            {"stage": "Переговоры", "count": 9, "value": 900000, "conversion": 55},
            {"stage": "Выиграно", "count": 5, "value": 500000, "conversion": 100},
        ],
        "lost": {"count": 8, "reasons": ["Дорого", "Конкурент", "Отложили"]},
        "ai_insights": [
            "Конверсия демо→переговоры упала на 10%",
            "Лиды из Instagram конвертируются на 25% лучше"
        ]
    }


@router.post("")
async def create_lead(
    salon_name: str,
    owner_name: str,
    phone: str,
    email: str,
    source: str = "manual",
    db: AsyncSession = Depends(get_db)
):
    """Создать лид"""
    return {
        "success": True,
        "lead_id": 4,
        "message": "Лид создан",
        "ai_score": 65,
        "ai_temperature": "warm"
    }


@router.patch("/{lead_id}")
async def update_lead(
    lead_id: int,
    status: Optional[str] = None,
    notes: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Обновить лид"""
    return {
        "success": True,
        "lead_id": lead_id,
        "updated_fields": {"status": status, "notes": notes}
    }


@router.post("/{lead_id}/auto-response")
async def send_auto_response(
    lead_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Отправить автоматический ответ"""
    return {
        "success": True,
        "lead_id": lead_id,
        "message_sent": "Персонализированное сообщение отправлено",
        "channel": "WhatsApp"
    }


@router.get("/{lead_id}/research")
async def get_lead_research(
    lead_id: int,
    db: AsyncSession = Depends(get_db)
):
    """AI-сбор информации о лиде"""
    return {
        "lead_id": lead_id,
        "salon_info": {
            "rating_google": 4.8,
            "reviews_count": 156,
            "instagram_followers": 12500
        },
        "competitive_analysis": {
            "current_crm": "YCLIENTS",
            "pain_points": ["Плохая поддержка", "Нет AI"]
        },
        "talking_points": [
            "Показать AI-ассистент",
            "Упомянуть проблемы конкурента"
        ]
    }
