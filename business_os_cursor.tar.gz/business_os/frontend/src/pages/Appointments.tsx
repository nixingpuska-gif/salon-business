import { useEffect, useState } from 'react'
import { Plus, ChevronLeft, ChevronRight, Clock, User, Scissors } from 'lucide-react'
import clsx from 'clsx'

interface Appointment {
  id: number
  client_id: number
  client_name?: string
  staff_id: number
  staff_name?: string
  service_id: number
  service_name?: string
  date: string
  start_time: string
  end_time: string
  duration_minutes: number
  status: string
  price: number
  final_price: number
}

interface AppointmentStats {
  total: number
  confirmed: number
  pending: number
  cancelled: number
  completed: number
}

const statusStyles: Record<string, { bg: string; text: string; label: string }> = {
  pending: { bg: 'bg-amber-100', text: 'text-amber-700', label: 'Ожидает' },
  confirmed: { bg: 'bg-green-100', text: 'text-green-700', label: 'Подтверждена' },
  in_progress: { bg: 'bg-blue-100', text: 'text-blue-700', label: 'В процессе' },
  completed: { bg: 'bg-gray-100', text: 'text-gray-700', label: 'Завершена' },
  cancelled_by_client: { bg: 'bg-red-100', text: 'text-red-700', label: 'Отменена' },
  cancelled_by_salon: { bg: 'bg-red-100', text: 'text-red-700', label: 'Отменена' },
  no_show: { bg: 'bg-red-100', text: 'text-red-700', label: 'Не пришёл' },
}

const timeSlots = Array.from({ length: 24 }, (_, i) => `${i.toString().padStart(2, '0')}:00`)

export default function Appointments() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [view, setView] = useState<'day' | 'week'>('day')
  const [appointments, setAppointments] = useState<Appointment[]>([])
  const [stats, setStats] = useState<AppointmentStats>({ total: 0, confirmed: 0, pending: 0, cancelled: 0, completed: 0 })
  const [loading, setLoading] = useState(true)

  const formatDateForApi = (date: Date) => {
    return date.toISOString().split('T')[0]
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('ru-RU', { 
      weekday: 'long', 
      day: 'numeric', 
      month: 'long' 
    })
  }

  useEffect(() => {
    const dateStr = formatDateForApi(currentDate)
    setLoading(true)
    
    fetch(`/api/v1/appointments?start_date=${dateStr}&end_date=${dateStr}`)
      .then(res => res.json())
      .then(data => {
        const items = data.items || []
        setAppointments(items)
        
        // Calculate stats
        const newStats = {
          total: items.length,
          confirmed: items.filter((a: Appointment) => a.status === 'confirmed').length,
          pending: items.filter((a: Appointment) => a.status === 'pending').length,
          cancelled: items.filter((a: Appointment) => a.status.includes('cancelled')).length,
          completed: items.filter((a: Appointment) => a.status === 'completed').length,
        }
        setStats(newStats)
        setLoading(false)
      })
      .catch(err => {
        console.error('Error:', err)
        setLoading(false)
      })
  }, [currentDate])

  const prevDay = () => {
    const newDate = new Date(currentDate)
    newDate.setDate(newDate.getDate() - 1)
    setCurrentDate(newDate)
  }

  const nextDay = () => {
    const newDate = new Date(currentDate)
    newDate.setDate(newDate.getDate() + 1)
    setCurrentDate(newDate)
  }

  const parseTime = (timeStr: string): { hours: number; minutes: number } => {
    const [hours, minutes] = timeStr.split(':').map(Number)
    return { hours, minutes }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Записи</h1>
          <p className="text-gray-500 mt-1">Управление расписанием</p>
        </div>
        <button className="btn-primary flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Новая запись
        </button>
      </div>

      {/* Calendar Controls */}
      <div className="card">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={prevDay} className="p-2 hover:bg-gray-100 rounded-lg">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <h2 className="text-lg font-semibold text-gray-900 capitalize">
              {formatDate(currentDate)}
            </h2>
            <button onClick={nextDay} className="p-2 hover:bg-gray-100 rounded-lg">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setView('day')}
              className={clsx(
                "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                view === 'day' ? "bg-primary-100 text-primary-700" : "text-gray-600 hover:bg-gray-100"
              )}
            >
              День
            </button>
            <button
              onClick={() => setView('week')}
              className={clsx(
                "px-4 py-2 rounded-lg text-sm font-medium transition-colors",
                view === 'week' ? "bg-primary-100 text-primary-700" : "text-gray-600 hover:bg-gray-100"
              )}
            >
              Неделя
            </button>
            <button
              onClick={() => setCurrentDate(new Date())}
              className="px-4 py-2 text-sm font-medium text-primary-600 hover:bg-primary-50 rounded-lg"
            >
              Сегодня
            </button>
          </div>
        </div>
      </div>

      {/* Schedule Grid */}
      <div className="card overflow-hidden p-0">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
          </div>
        ) : (
          <div className="grid grid-cols-[80px_1fr] divide-x divide-gray-200">
            {/* Time column */}
            <div className="divide-y divide-gray-100">
              {timeSlots.slice(8, 21).map((time) => (
                <div key={time} className="h-16 px-3 py-2 text-xs text-gray-500">
                  {time}
                </div>
              ))}
            </div>

            {/* Appointments column */}
            <div className="relative">
              {timeSlots.slice(8, 21).map((time) => (
                <div key={time} className="h-16 border-b border-gray-100 hover:bg-gray-50 cursor-pointer" />
              ))}

              {/* Appointments */}
              {appointments.map((apt) => {
                const { hours, minutes } = parseTime(apt.start_time)
                const top = (hours - 8) * 64 + (minutes / 60) * 64
                const height = Math.max((apt.duration_minutes / 60) * 64, 48)
                const style = statusStyles[apt.status] || statusStyles.pending

                return (
                  <div
                    key={apt.id}
                    className={clsx(
                      "absolute left-2 right-2 rounded-lg p-3 cursor-pointer transition-all hover:shadow-md overflow-hidden",
                      style.bg
                    )}
                    style={{ top: `${top}px`, height: `${height}px` }}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className={clsx("font-medium text-sm", style.text)}>
                          {apt.client_name || `Клиент #${apt.client_id}`}
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-xs text-gray-600">
                          <Scissors className="w-3 h-3" />
                          {apt.service_name || `Услуга #${apt.service_id}`}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5 text-xs text-gray-500">
                          <User className="w-3 h-3" />
                          {apt.staff_name || `Мастер #${apt.staff_id}`}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-xs text-gray-500">
                        <Clock className="w-3 h-3" />
                        {apt.start_time.slice(0, 5)}
                      </div>
                    </div>
                  </div>
                )
              })}

              {appointments.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                  Нет записей на этот день
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Today's Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="card text-center">
          <div className="text-3xl font-bold text-gray-900">{stats.total}</div>
          <div className="text-sm text-gray-500 mt-1">Всего записей</div>
        </div>
        <div className="card text-center">
          <div className="text-3xl font-bold text-green-600">{stats.confirmed + stats.completed}</div>
          <div className="text-sm text-gray-500 mt-1">Подтверждено</div>
        </div>
        <div className="card text-center">
          <div className="text-3xl font-bold text-amber-600">{stats.pending}</div>
          <div className="text-sm text-gray-500 mt-1">Ожидают</div>
        </div>
        <div className="card text-center">
          <div className="text-3xl font-bold text-red-600">{stats.cancelled}</div>
          <div className="text-sm text-gray-500 mt-1">Отменено</div>
        </div>
      </div>
    </div>
  )
}
