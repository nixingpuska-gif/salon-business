# 🚀 AI-Booking Platform - Краткая Справка

## Быстрый старт (3 команды)

```bash
# 1. Автоматическая установка
./scripts/setup.sh          # macOS/Linux
scripts\setup.bat            # Windows

# 2. Добавьте API ключи в backend/.env

# 3. Запуск
cd backend && pnpm run start:dev
```

---

## 📋 Основные команды

### Управление Docker

```bash
# Запуск БД
docker compose up -d postgres redis

# Остановка
docker compose down

# Просмотр логов
docker compose logs -f postgres
docker compose logs -f redis

# Полная очистка (удалит данные!)
docker compose down -v
```

### Управление приложением

```bash
cd backend

# Установка зависимостей
pnpm install

# Генерация Prisma Client
npx prisma generate

# Миграции БД
npx prisma migrate dev --name init

# Запуск в режиме разработки
pnpm run start:dev

# Запуск в production режиме
pnpm run build
pnpm run start:prod

# Просмотр БД (Prisma Studio)
npx prisma studio
```

### Работа с БД

```bash
# Создать миграцию
npx prisma migrate dev --name migration_name

# Применить миграции
npx prisma migrate deploy

# Сбросить БД (удалит все данные!)
npx prisma migrate reset

# Заполнить тестовыми данными (если есть seed)
npx prisma db seed
```

---

## 🔑 Необходимые API ключи

### 1. Telegram Bot Tokens

**Как получить:**
1. Откройте @BotFather в Telegram
2. Отправьте `/newbot`
3. Следуйте инструкциям
4. Скопируйте токен

**Куда добавить:**
```env
# backend/.env
TELEGRAM_CLIENT_BOT_TOKEN=1234567890:ABCdef...
TELEGRAM_ADMIN_BOT_TOKEN=0987654321:ZYXwvu...
```

### 2. OpenAI API Key

**Как получить:**
1. Перейдите на https://platform.openai.com/api-keys
2. Войдите или зарегистрируйтесь
3. Создайте новый ключ
4. Пополните баланс ($5 минимум)

**Куда добавить:**
```env
# backend/.env
OPENAI_API_KEY=sk-...
```

### 3. Google Calendar API (опционально)

**Как получить:**
1. Перейдите на https://console.cloud.google.com/
2. Создайте новый проект
3. Включите Google Calendar API
4. Создайте OAuth 2.0 credentials
5. Скопируйте Client ID и Client Secret

**Куда добавить:**
```env
# backend/.env
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_REDIRECT_URI=http://localhost:3000/auth/google/callback
```

---

## 🧪 Тестирование API

### Создание бизнеса

```bash
curl -X POST http://localhost:3000/businesses \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Салон Красоты",
    "businessType": "beauty_salon",
    "phone": "+79991234567",
    "userId": "user-123"
  }'
```

### Добавление услуги

```bash
curl -X POST http://localhost:3000/services \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "BUSINESS_ID_HERE",
    "name": "Маникюр",
    "durationMinutes": 60,
    "price": 1500
  }'
```

### Генерация доступных слотов

```bash
curl -X POST http://localhost:3000/schedules/slots \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "BUSINESS_ID_HERE",
    "date": "2025-11-25",
    "serviceDurationMinutes": 60
  }'
```

### Создание записи

```bash
curl -X POST http://localhost:3000/bookings \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "BUSINESS_ID_HERE",
    "clientId": "CLIENT_ID_HERE",
    "serviceId": "SERVICE_ID_HERE",
    "startTime": "2025-11-25T10:00:00Z",
    "sourceChannel": "telegram"
  }'
```

---

## 🤖 Примеры диалогов с ботами

### Client Bot (для клиентов)

```
Клиент: Привет
Бот: Здравствуйте! Я помогу вам записаться на услугу. Что вас интересует?

Клиент: Хочу записаться на маникюр
Бот: Отлично! На какую дату вы хотите записаться?

Клиент: Завтра в 10 утра
Бот: Проверяю доступность... Слот на 25.11.2025 в 10:00 свободен. Подтвердить запись?

Клиент: Да
Бот: ✅ Запись создана! Вы записаны на маникюр 25.11.2025 в 10:00
```

### Admin Bot (для владельцев)

```
Владелец: Покажи записи на сегодня
Бот: На сегодня 3 записи:
1. 10:00 - Маникюр - Анна Иванова
2. 12:00 - Педикюр - Мария Петрова
3. 15:00 - Маникюр - Ольга Сидорова

Владелец: Добавь услугу: педикюр, 90 минут, 2000 рублей
Бот: ✅ Услуга "Педикюр" добавлена (90 мин, 2000₽)

Владелец: Покажи статистику за ноябрь
Бот: Статистика за ноябрь 2025:
📊 Всего записей: 45
💰 Выручка: 67,500₽
👥 Уникальных клиентов: 28
```

---

## 📊 Структура проекта

```
ai-booking-platform/
├── backend/                    # Backend приложение
│   ├── src/
│   │   ├── business/          # Модуль бизнесов
│   │   ├── client/            # CRM модуль
│   │   ├── service/           # Модуль услуг
│   │   ├── schedule/          # Модуль расписания
│   │   ├── booking/           # Модуль записей
│   │   ├── ai/                # AI Orchestrator
│   │   ├── telegram/          # Telegram боты
│   │   ├── calendar/          # Google Calendar
│   │   └── prisma/            # Prisma ORM
│   ├── prisma/
│   │   └── schema.prisma      # Схема БД
│   ├── .env                   # Переменные окружения
│   └── package.json
├── scripts/
│   ├── setup.sh               # Установка (macOS/Linux)
│   └── setup.bat              # Установка (Windows)
├── docker-compose.yml         # Docker конфигурация
└── README.md
```

---

## 🔧 Troubleshooting

### Порт 3000 занят

```bash
# Измените порт в backend/.env
PORT=3001

# Или остановите процесс
lsof -ti:3000 | xargs kill -9  # macOS/Linux
netstat -ano | findstr :3000   # Windows
```

### Docker не запускается

```bash
# Проверьте статус
docker info

# Запустите Docker Desktop (macOS/Windows)
# Или запустите daemon (Linux)
sudo systemctl start docker
```

### Ошибка подключения к БД

```bash
# Проверьте контейнеры
docker compose ps

# Перезапустите
docker compose restart postgres

# Проверьте логи
docker compose logs postgres
```

### Telegram бот не отвечает

1. Проверьте токен в .env
2. Перезапустите приложение
3. Проверьте логи на ошибки
4. Убедитесь, что нет лишних пробелов в токене

---

## 📚 Полезные ссылки

- **Документация:** См. файлы в корне проекта
- **Prisma Docs:** https://www.prisma.io/docs
- **NestJS Docs:** https://docs.nestjs.com
- **OpenAI API:** https://platform.openai.com/docs
- **Telegram Bot API:** https://core.telegram.org/bots/api

---

## 🆘 Получить помощь

1. Проверьте `INSTALLATION-GUIDE-RU.md`
2. Проверьте `TROUBLESHOOTING` раздел
3. Проверьте логи приложения
4. Проверьте логи Docker: `docker compose logs`

---

## ✅ Чеклист перед запуском

- [ ] Docker Desktop запущен
- [ ] PostgreSQL контейнер работает
- [ ] Redis контейнер работает
- [ ] .env файл настроен
- [ ] TELEGRAM_CLIENT_BOT_TOKEN добавлен
- [ ] TELEGRAM_ADMIN_BOT_TOKEN добавлен
- [ ] OPENAI_API_KEY добавлен (для AI)
- [ ] Зависимости установлены
- [ ] Prisma Client сгенерирован
- [ ] Миграции применены

---

**Версия:** v1.0.0  
**Обновлено:** 23 ноября 2025

🚀 **Готово к работе!**
