import { Controller, Post, Get, Body, Query, Res, HttpStatus, Logger } from '@nestjs/common';
import { Response } from 'express';
import { WhatsAppService } from './whatsapp.service';

@Controller('webhooks/whatsapp')
export class WhatsAppController {
  private readonly logger = new Logger(WhatsAppController.name);

  constructor(private readonly whatsappService: WhatsAppService) {}

  /**
   * GET /webhooks/whatsapp - Верификация webhook от WhatsApp
   */
  @Get()
  verifyWebhook(
    @Query('hub.mode') mode: string,
    @Query('hub.verify_token') token: string,
    @Query('hub.challenge') challenge: string,
    @Res() res: Response,
  ) {
    this.logger.log('Webhook verification request received');
    
    const result = this.whatsappService.verifyWebhook(mode, token, challenge);
    
    if (result) {
      return res.status(HttpStatus.OK).send(result);
    }
    
    return res.status(HttpStatus.FORBIDDEN).send('Verification failed');
  }

  /**
   * POST /webhooks/whatsapp - Получение сообщений от WhatsApp
   */
  @Post()
  async handleWebhook(@Body() body: any, @Res() res: Response) {
    this.logger.log('Webhook received from WhatsApp');
    
    try {
      await this.whatsappService.handleIncomingMessage(body);
      return res.status(HttpStatus.OK).send('EVENT_RECEIVED');
    } catch (error) {
      this.logger.error('Error processing webhook:', error);
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).send('Error processing webhook');
    }
  }
}
