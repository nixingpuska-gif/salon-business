import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { PrismaService } from '../prisma/prisma.service';

/**
 * Content Generator Service
 * 
 * Генерация контента для социальных сетей:
 * - Автоматическое создание постов
 * - Генерация хэштегов
 * - Адаптация контента под платформу
 * - Создание привлекательных описаний
 */
@Injectable()
export class ContentGeneratorService {
  private readonly logger = new Logger(ContentGeneratorService.name);
  private openai: OpenAI;

  constructor(
    private configService: ConfigService,
    private prisma: PrismaService,
  ) {
    const apiKey = this.configService.get<string>('OPENAI_API_KEY');
    if (!apiKey) {
      this.logger.warn('OPENAI_API_KEY not configured, content generation will be disabled');
    } else {
      this.openai = new OpenAI({ apiKey });
      this.logger.log('Content Generator Service initialized');
    }
  }

  /**
   * Сгенерировать пост для Instagram
   */
  async generateInstagramPost(params: {
    businessName: string;
    serviceName: string;
    description?: string;
    tone?: 'professional' | 'friendly' | 'casual' | 'luxury';
    includeHashtags?: boolean;
    includeEmoji?: boolean;
  }): Promise<{
    caption: string;
    hashtags: string[];
  }> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }

    const tone = params.tone || 'friendly';
    const includeHashtags = params.includeHashtags !== false;
    const includeEmoji = params.includeEmoji !== false;

    try {
      this.logger.log(`Generating Instagram post for ${params.serviceName}`);

      const prompt = `Создай привлекательный пост для Instagram для салона "${params.businessName}".

Услуга: ${params.serviceName}
${params.description ? `Описание: ${params.description}` : ''}
Тон: ${tone}
${includeEmoji ? 'Используй эмодзи для привлекательности' : 'Без эмодзи'}

Требования:
- Длина: 100-150 символов (без хэштегов)
- Призыв к действию (записаться, позвонить)
- Подчеркни преимущества услуги
- ${tone === 'professional' ? 'Профессиональный стиль' : ''}
- ${tone === 'friendly' ? 'Дружелюбный и тёплый стиль' : ''}
- ${tone === 'casual' ? 'Непринуждённый разговорный стиль' : ''}
- ${tone === 'luxury' ? 'Премиальный и элегантный стиль' : ''}

${includeHashtags ? 'Добавь 10-15 релевантных хэштегов на русском языке.' : ''}

Верни JSON:
{
  "caption": "текст поста",
  "hashtags": ["хэштег1", "хэштег2", ...]
}`;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 1000,
        temperature: 0.8,
      });

      const content = response.choices[0]?.message?.content || '{}';
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      const result = jsonMatch ? JSON.parse(jsonMatch[0]) : {};

      this.logger.log('Instagram post generated successfully');

      return {
        caption: result.caption || '',
        hashtags: result.hashtags || [],
      };
    } catch (error) {
      this.logger.error('Failed to generate Instagram post:', error);
      throw error;
    }
  }

  /**
   * Сгенерировать пост для Facebook
   */
  async generateFacebookPost(params: {
    businessName: string;
    serviceName: string;
    description?: string;
    tone?: 'professional' | 'friendly' | 'casual' | 'luxury';
    includeEmoji?: boolean;
  }): Promise<string> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }

    const tone = params.tone || 'friendly';
    const includeEmoji = params.includeEmoji !== false;

    try {
      this.logger.log(`Generating Facebook post for ${params.serviceName}`);

      const prompt = `Создай информативный пост для Facebook для салона "${params.businessName}".

Услуга: ${params.serviceName}
${params.description ? `Описание: ${params.description}` : ''}
Тон: ${tone}
${includeEmoji ? 'Используй эмодзи' : 'Без эмодзи'}

Требования:
- Длина: 150-250 символов
- Более подробное описание, чем в Instagram
- Призыв к действию
- Упомяни контакты или способ записи
- ${tone === 'professional' ? 'Профессиональный стиль' : ''}
- ${tone === 'friendly' ? 'Дружелюбный и тёплый стиль' : ''}
- ${tone === 'casual' ? 'Непринуждённый разговорный стиль' : ''}
- ${tone === 'luxury' ? 'Премиальный и элегантный стиль' : ''}

Верни только текст поста, без JSON.`;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 500,
        temperature: 0.8,
      });

      const post = response.choices[0]?.message?.content || '';
      this.logger.log('Facebook post generated successfully');

      return post.trim();
    } catch (error) {
      this.logger.error('Failed to generate Facebook post:', error);
      throw error;
    }
  }

  /**
   * Сгенерировать контент для обеих платформ
   */
  async generateForBothPlatforms(params: {
    businessName: string;
    serviceName: string;
    description?: string;
    tone?: 'professional' | 'friendly' | 'casual' | 'luxury';
  }): Promise<{
    instagram: { caption: string; hashtags: string[] };
    facebook: string;
  }> {
    try {
      const [instagram, facebook] = await Promise.all([
        this.generateInstagramPost(params),
        this.generateFacebookPost(params),
      ]);

      return { instagram, facebook };
    } catch (error) {
      this.logger.error('Failed to generate content for both platforms:', error);
      throw error;
    }
  }

  /**
   * Сгенерировать хэштеги для услуги
   */
  async generateHashtags(
    serviceName: string,
    count: number = 15,
  ): Promise<string[]> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }

    try {
      this.logger.log(`Generating ${count} hashtags for ${serviceName}`);

      const prompt = `Создай ${count} релевантных хэштегов на русском языке для услуги "${serviceName}".

Требования:
- Популярные и часто используемые
- Релевантные услуге
- Разной длины (короткие и длинные)
- Включи общие и специфичные
- Без символа # (только текст)

Верни JSON массив:
["хэштег1", "хэштег2", ...]`;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 500,
        temperature: 0.7,
      });

      const content = response.choices[0]?.message?.content || '[]';
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      const hashtags = jsonMatch ? JSON.parse(jsonMatch[0]) : [];

      this.logger.log(`Generated ${hashtags.length} hashtags`);

      return hashtags;
    } catch (error) {
      this.logger.error('Failed to generate hashtags:', error);
      throw error;
    }
  }

  /**
   * Улучшить существующий текст поста
   */
  async improvePostText(
    text: string,
    platform: 'instagram' | 'facebook',
  ): Promise<string> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }

    try {
      this.logger.log(`Improving post text for ${platform}`);

      const prompt = `Улучши этот текст для ${platform === 'instagram' ? 'Instagram' : 'Facebook'}:

"${text}"

Требования:
- Сделай более привлекательным и цепляющим
- Добавь эмодзи (если их нет)
- Сохрани основную идею
- ${platform === 'instagram' ? 'Сделай короче и динамичнее' : 'Сделай более информативным'}
- Добавь призыв к действию (если его нет)

Верни только улучшенный текст, без дополнительных комментариев.`;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 500,
        temperature: 0.8,
      });

      const improvedText = response.choices[0]?.message?.content || text;
      this.logger.log('Post text improved successfully');

      return improvedText.trim();
    } catch (error) {
      this.logger.error('Failed to improve post text:', error);
      throw error;
    }
  }

  /**
   * Сгенерировать пост о специальном предложении
   */
  async generatePromoPost(params: {
    businessName: string;
    serviceName: string;
    discount?: number;
    validUntil?: Date;
    platform: 'instagram' | 'facebook';
  }): Promise<string> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }

    try {
      this.logger.log(`Generating promo post for ${params.serviceName}`);

      const prompt = `Создай рекламный пост о специальном предложении для ${params.platform === 'instagram' ? 'Instagram' : 'Facebook'}.

Салон: ${params.businessName}
Услуга: ${params.serviceName}
${params.discount ? `Скидка: ${params.discount}%` : 'Специальное предложение'}
${params.validUntil ? `Действует до: ${params.validUntil.toLocaleDateString('ru-RU')}` : ''}

Требования:
- Создай ощущение срочности (ограниченное предложение)
- Подчеркни выгоду для клиента
- Призыв к действию (записаться сейчас)
- Используй эмодзи
- ${params.platform === 'instagram' ? '100-150 символов' : '150-250 символов'}

Верни только текст поста.`;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 500,
        temperature: 0.9,
      });

      const post = response.choices[0]?.message?.content || '';
      this.logger.log('Promo post generated successfully');

      return post.trim();
    } catch (error) {
      this.logger.error('Failed to generate promo post:', error);
      throw error;
    }
  }

  /**
   * Сгенерировать пост "До и После"
   */
  async generateBeforeAfterPost(params: {
    businessName: string;
    serviceName: string;
    platform: 'instagram' | 'facebook';
  }): Promise<string> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }

    try {
      this.logger.log(`Generating before/after post for ${params.serviceName}`);

      const prompt = `Создай пост для фото "До и После" для ${params.platform === 'instagram' ? 'Instagram' : 'Facebook'}.

Салон: ${params.businessName}
Услуга: ${params.serviceName}

Требования:
- Подчеркни трансформацию
- Восхищение результатом
- Призыв записаться
- Используй эмодзи
- ${params.platform === 'instagram' ? '80-120 символов' : '120-200 символов'}

Верни только текст поста.`;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 400,
        temperature: 0.8,
      });

      const post = response.choices[0]?.message?.content || '';
      this.logger.log('Before/after post generated successfully');

      return post.trim();
    } catch (error) {
      this.logger.error('Failed to generate before/after post:', error);
      throw error;
    }
  }
}
