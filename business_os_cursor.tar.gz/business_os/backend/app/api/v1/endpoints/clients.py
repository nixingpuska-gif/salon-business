"""
Business OS - Clients Endpoints
Client management for salons
"""

from datetime import datetime, date
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query, UploadFile, File
from pydantic import BaseModel, EmailStr
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_
from sqlalchemy.orm import selectinload

from app.core.database import get_db
from app.models import Client, ClientSegment, ClientSource

router = APIRouter()


# ==================== SCHEMAS ====================

class ClientCreate(BaseModel):
    """Create client request"""
    first_name: str
    last_name: Optional[str] = None
    phone: str
    email: Optional[EmailStr] = None
    telegram_username: Optional[str] = None
    whatsapp_phone: Optional[str] = None
    instagram_username: Optional[str] = None
    birth_date: Optional[date] = None
    gender: Optional[str] = None
    source: Optional[str] = ClientSource.WALK_IN.value
    source_details: Optional[str] = None
    notes: Optional[str] = None
    tags: Optional[List[str]] = []


class ClientUpdate(BaseModel):
    """Update client request"""
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[EmailStr] = None
    telegram_username: Optional[str] = None
    whatsapp_phone: Optional[str] = None
    instagram_username: Optional[str] = None
    birth_date: Optional[date] = None
    gender: Optional[str] = None
    preferred_channel: Optional[str] = None
    preferred_staff_id: Optional[int] = None
    notes: Optional[str] = None
    tags: Optional[List[str]] = None


class ClientResponse(BaseModel):
    """Client response"""
    id: int
    first_name: str
    last_name: Optional[str] = None
    phone: str
    email: Optional[str] = None
    telegram_username: Optional[str] = None
    whatsapp_phone: Optional[str] = None
    instagram_username: Optional[str] = None
    birth_date: Optional[date] = None
    gender: Optional[str] = None
    segment: Optional[str] = 'new'
    ltv: Optional[float] = 0
    total_spent: Optional[float] = 0
    total_visits: Optional[int] = 0
    avg_check: Optional[float] = 0
    bonus_balance: Optional[int] = 0
    first_visit_at: Optional[datetime] = None
    last_visit_at: Optional[datetime] = None
    days_since_last_visit: Optional[int] = None
    risk_score: Optional[int] = 0
    tags: Optional[List[str]] = []
    is_unsubscribed: Optional[bool] = False
    created_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class ClientListResponse(BaseModel):
    """Paginated client list response"""
    items: List[ClientResponse]
    total: int
    page: int
    page_size: int
    pages: int


class ClientStats(BaseModel):
    """Client statistics"""
    total_clients: int
    new_this_month: int
    active_clients: int
    sleeping_clients: int
    lost_clients: int
    avg_ltv: float
    total_revenue: float


# ==================== ENDPOINTS ====================

@router.get("", response_model=ClientListResponse)
async def list_clients(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    search: Optional[str] = None,
    segment: Optional[str] = None,
    source: Optional[str] = None,
    has_phone: Optional[bool] = None,
    has_email: Optional[bool] = None,
    min_visits: Optional[int] = None,
    max_visits: Optional[int] = None,
    min_ltv: Optional[float] = None,
    last_visit_days: Optional[int] = None,
    sort_by: str = Query("created_at", regex="^(created_at|last_visit_at|ltv|total_visits|first_name)$"),
    sort_order: str = Query("desc", regex="^(asc|desc)$"),
    db: AsyncSession = Depends(get_db),
):
    """
    List clients with filtering and pagination.
    """
    tenant_id = 1  # TODO: Get from auth
    
    # Base query - exclude deleted
    query = select(Client).where(and_(Client.tenant_id == tenant_id, Client.is_deleted == False))
    count_query = select(func.count(Client.id)).where(and_(Client.tenant_id == tenant_id, Client.is_deleted == False))
    
    # Apply filters
    if search:
        search_filter = or_(
            Client.first_name.ilike(f"%{search}%"),
            Client.last_name.ilike(f"%{search}%"),
            Client.phone.ilike(f"%{search}%"),
            Client.email.ilike(f"%{search}%"),
        )
        query = query.where(search_filter)
        count_query = count_query.where(search_filter)
    
    if segment:
        query = query.where(Client.segment == segment)
        count_query = count_query.where(Client.segment == segment)
    
    if source:
        query = query.where(Client.source == source)
        count_query = count_query.where(Client.source == source)
    
    # Get total count
    result = await db.execute(count_query)
    total = result.scalar()
    
    # Apply sorting
    sort_column = getattr(Client, sort_by)
    if sort_order == "desc":
        query = query.order_by(sort_column.desc())
    else:
        query = query.order_by(sort_column.asc())
    
    # Apply pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    # Execute query
    result = await db.execute(query)
    clients = result.scalars().all()
    
    # Calculate pages
    pages = (total + page_size - 1) // page_size if total else 0
    
    return ClientListResponse(
        items=[ClientResponse.model_validate(c) for c in clients],
        total=total or 0,
        page=page,
        page_size=page_size,
        pages=pages,
    )


@router.post("", response_model=ClientResponse, status_code=status.HTTP_201_CREATED)
async def create_client(
    data: ClientCreate,
    db: AsyncSession = Depends(get_db),
):
    """Create new client"""
    tenant_id = 1  # TODO: Get from auth
    
    # Check for duplicate phone
    result = await db.execute(
        select(Client).where(
            and_(Client.tenant_id == tenant_id, Client.phone == data.phone)
        )
    )
    if result.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Client with this phone already exists"
        )
    
    # Create client
    client = Client(
        tenant_id=tenant_id,
        **data.model_dump()
    )
    db.add(client)
    await db.commit()
    await db.refresh(client)
    
    return ClientResponse.model_validate(client)


@router.get("/stats", response_model=ClientStats)
async def get_client_stats(
    db: AsyncSession = Depends(get_db),
):
    """Get client statistics"""
    tenant_id = 1  # TODO: Get from auth
    
    # Total clients
    result = await db.execute(
        select(func.count(Client.id)).where(Client.tenant_id == tenant_id)
    )
    total = result.scalar() or 0
    
    # New this month
    first_of_month = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    result = await db.execute(
        select(func.count(Client.id)).where(
            and_(
                Client.tenant_id == tenant_id,
                Client.created_at >= first_of_month
            )
        )
    )
    new_this_month = result.scalar() or 0
    
    return ClientStats(
        total_clients=total,
        new_this_month=new_this_month,
        active_clients=0,
        sleeping_clients=0,
        lost_clients=0,
        avg_ltv=0,
        total_revenue=0,
    )


@router.get("/{client_id}", response_model=ClientResponse)
async def get_client(
    client_id: int,
    db: AsyncSession = Depends(get_db),
):
    """Get client by ID"""
    tenant_id = 1  # TODO: Get from auth
    
    result = await db.execute(
        select(Client).where(
            and_(Client.id == client_id, Client.tenant_id == tenant_id)
        )
    )
    client = result.scalar_one_or_none()
    
    if not client:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Client not found"
        )
    
    return ClientResponse.model_validate(client)


@router.patch("/{client_id}", response_model=ClientResponse)
async def update_client(
    client_id: int,
    data: ClientUpdate,
    db: AsyncSession = Depends(get_db),
):
    """Update client"""
    tenant_id = 1  # TODO: Get from auth
    
    result = await db.execute(
        select(Client).where(
            and_(Client.id == client_id, Client.tenant_id == tenant_id)
        )
    )
    client = result.scalar_one_or_none()
    
    if not client:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Client not found"
        )
    
    # Update fields
    update_data = data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(client, field, value)
    
    await db.commit()
    await db.refresh(client)
    
    return ClientResponse.model_validate(client)


@router.delete("/{client_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_client(
    client_id: int,
    db: AsyncSession = Depends(get_db),
):
    """Delete client (soft delete)"""
    tenant_id = 1  # TODO: Get from auth
    
    result = await db.execute(
        select(Client).where(
            and_(Client.id == client_id, Client.tenant_id == tenant_id)
        )
    )
    client = result.scalar_one_or_none()
    
    if not client:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Client not found"
        )
    
    # Soft delete
    client.is_deleted = True
    client.deleted_at = datetime.utcnow()
    await db.commit()


@router.post("/import")
async def import_clients(
    file: UploadFile = File(...),
    db: AsyncSession = Depends(get_db),
):
    """Import clients from CSV/Excel file"""
    raise HTTPException(status_code=501, detail="Not implemented")


@router.get("/export")
async def export_clients(
    format: str = Query("csv", regex="^(csv|xlsx)$"),
    db: AsyncSession = Depends(get_db),
):
    """Export clients to CSV/Excel file"""
    raise HTTPException(status_code=501, detail="Not implemented")
