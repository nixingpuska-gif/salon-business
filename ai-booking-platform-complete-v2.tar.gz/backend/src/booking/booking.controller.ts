import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { BookingService } from './booking.service';
import { CreateBookingDto } from './dto/create-booking.dto';
import { RescheduleBookingDto } from './dto/reschedule-booking.dto';
import { CancelBookingDto } from './dto/cancel-booking.dto';

@Controller('bookings')
export class BookingController {
  constructor(private readonly bookingService: BookingService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createBookingDto: CreateBookingDto) {
    return this.bookingService.create({
      ...createBookingDto,
      startTime: new Date(createBookingDto.startTime),
    });
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    return this.bookingService.findOne(id);
  }

  @Get()
  async findByBusiness(
    @Query('businessId') businessId: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('status') status?: string,
    @Query('clientId') clientId?: string,
    @Query('skip') skip?: string,
    @Query('take') take?: string,
  ) {
    return this.bookingService.findByBusiness(businessId, {
      startDate: startDate ? new Date(startDate) : undefined,
      endDate: endDate ? new Date(endDate) : undefined,
      status,
      clientId,
      skip: skip ? parseInt(skip, 10) : undefined,
      take: take ? parseInt(take, 10) : undefined,
    });
  }

  @Put(':id/reschedule')
  async reschedule(
    @Param('id') id: string,
    @Body() rescheduleDto: RescheduleBookingDto,
  ) {
    return this.bookingService.reschedule(
      id,
      new Date(rescheduleDto.newStartTime),
    );
  }

  @Put(':id/cancel')
  async cancel(
    @Param('id') id: string,
    @Body() cancelDto: CancelBookingDto,
  ) {
    return this.bookingService.cancel(id, cancelDto.reason);
  }

  @Put(':id/complete')
  async complete(@Param('id') id: string) {
    return this.bookingService.complete(id);
  }

  @Put(':id/no-show')
  async markNoShow(@Param('id') id: string) {
    return this.bookingService.markNoShow(id);
  }

  @Get('stats/:businessId')
  async getStats(
    @Param('businessId') businessId: string,
    @Query('startDate') startDate: string,
    @Query('endDate') endDate: string,
  ) {
    return this.bookingService.getStats(
      businessId,
      new Date(startDate),
      new Date(endDate),
    );
  }
}
