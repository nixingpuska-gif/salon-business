import { Injectable, Logger, Inject, forwardRef } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bullmq';
import { PrismaService } from '../prisma/prisma.service';
import { WhatsAppService } from '../whatsapp/whatsapp.service';
import { InstagramService } from '../instagram/instagram.service';

/**
 * Notification Service
 * 
 * Управляет автоматическими уведомлениями для клиентов:
 * - Напоминания за 24 часа до записи
 * - Напоминания за 2 часа до записи
 * - Отправка через все каналы (Telegram, WhatsApp, Instagram)
 * - Обработка отмены/переноса записи
 */
@Injectable()
export class NotificationService {
  private readonly logger = new Logger(NotificationService.name);

  constructor(
    @InjectQueue('notifications') private notificationQueue: Queue,
    private prisma: PrismaService,
    @Inject(forwardRef(() => WhatsAppService))
    private whatsappService: WhatsAppService,
    @Inject(forwardRef(() => InstagramService))
    private instagramService: InstagramService,
  ) {
    this.logger.log('Notification Service initialized');
  }

  /**
   * Запланировать напоминания для новой записи
   */
  async scheduleBookingReminders(bookingId: number): Promise<void> {
    try {
      const booking = await this.prisma.booking.findUnique({
        where: { id: bookingId },
        include: {
          client: true,
          service: true,
          business: true,
        },
      });

      if (!booking) {
        this.logger.error(`Booking ${bookingId} not found`);
        return;
      }

      const bookingTime = new Date(booking.startTime);
      const now = new Date();

      // Напоминание за 24 часа
      const reminder24h = new Date(bookingTime.getTime() - 24 * 60 * 60 * 1000);
      if (reminder24h > now) {
        await this.notificationQueue.add(
          'booking-reminder-24h',
          {
            bookingId: booking.id,
            clientId: booking.clientId,
            businessId: booking.businessId,
            serviceId: booking.serviceId,
            startTime: booking.startTime,
            reminderType: '24h',
          },
          {
            delay: reminder24h.getTime() - now.getTime(),
            jobId: `booking-${bookingId}-24h`,
            removeOnComplete: true,
            removeOnFail: false,
          },
        );
        this.logger.log(`Scheduled 24h reminder for booking ${bookingId} at ${reminder24h.toISOString()}`);
      }

      // Напоминание за 2 часа
      const reminder2h = new Date(bookingTime.getTime() - 2 * 60 * 60 * 1000);
      if (reminder2h > now) {
        await this.notificationQueue.add(
          'booking-reminder-2h',
          {
            bookingId: booking.id,
            clientId: booking.clientId,
            businessId: booking.businessId,
            serviceId: booking.serviceId,
            startTime: booking.startTime,
            reminderType: '2h',
          },
          {
            delay: reminder2h.getTime() - now.getTime(),
            jobId: `booking-${bookingId}-2h`,
            removeOnComplete: true,
            removeOnFail: false,
          },
        );
        this.logger.log(`Scheduled 2h reminder for booking ${bookingId} at ${reminder2h.toISOString()}`);
      }
    } catch (error) {
      this.logger.error(`Failed to schedule reminders for booking ${bookingId}:`, error);
      throw error;
    }
  }

  /**
   * Отменить все напоминания для записи
   */
  async cancelBookingReminders(bookingId: number): Promise<void> {
    try {
      // Удаляем запланированные задачи
      await this.notificationQueue.remove(`booking-${bookingId}-24h`);
      await this.notificationQueue.remove(`booking-${bookingId}-2h`);
      
      this.logger.log(`Cancelled reminders for booking ${bookingId}`);
    } catch (error) {
      this.logger.error(`Failed to cancel reminders for booking ${bookingId}:`, error);
    }
  }

  /**
   * Перепланировать напоминания при переносе записи
   */
  async rescheduleBookingReminders(bookingId: number): Promise<void> {
    try {
      // Сначала отменяем старые напоминания
      await this.cancelBookingReminders(bookingId);
      
      // Затем создаём новые
      await this.scheduleBookingReminders(bookingId);
      
      this.logger.log(`Rescheduled reminders for booking ${bookingId}`);
    } catch (error) {
      this.logger.error(`Failed to reschedule reminders for booking ${bookingId}:`, error);
      throw error;
    }
  }

  /**
   * Отправить напоминание клиенту
   */
  async sendBookingReminder(
    bookingId: number,
    reminderType: '24h' | '2h',
  ): Promise<void> {
    try {
      const booking = await this.prisma.booking.findUnique({
        where: { id: bookingId },
        include: {
          client: true,
          service: true,
          business: true,
        },
      });

      if (!booking) {
        this.logger.error(`Booking ${bookingId} not found for reminder`);
        return;
      }

      // Проверяем статус записи
      if (booking.status !== 'CONFIRMED') {
        this.logger.log(`Booking ${bookingId} is not confirmed, skipping reminder`);
        return;
      }

      const message = this.formatReminderMessage(booking, reminderType);
      
      // Отправляем через соответствующий канал
      await this.sendToChannel(booking.client, message);

      this.logger.log(`Sent ${reminderType} reminder for booking ${bookingId} to client ${booking.clientId}`);
    } catch (error) {
      this.logger.error(`Failed to send reminder for booking ${bookingId}:`, error);
      throw error;
    }
  }

  /**
   * Форматирование сообщения напоминания
   */
  private formatReminderMessage(booking: any, reminderType: '24h' | '2h'): string {
    const timeText = reminderType === '24h' ? 'завтра' : 'через 2 часа';
    const date = new Date(booking.startTime);
    const timeStr = date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    const dateStr = date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' });

    return `🔔 Напоминание о записи ${timeText}!

📅 Дата: ${dateStr}
🕐 Время: ${timeStr}
💇 Услуга: ${booking.service.name}
📍 ${booking.business.name}

Если нужно перенести или отменить запись, напишите мне.`;
  }

  /**
   * Отправка сообщения через соответствующий канал
   */
  private async sendToChannel(client: any, message: string): Promise<void> {
    let sent = false;

    // Приоритет 1: Telegram (если есть telegramId)
    if (client.telegramId) {
      try {
        // TODO: Интеграция с Telegram Service
        // await this.telegramService.sendMessage(client.telegramId, message);
        this.logger.log(`Would send to Telegram: ${client.telegramId}`);
        sent = true;
      } catch (error) {
        this.logger.error(`Failed to send to Telegram ${client.telegramId}:`, error);
      }
    }

    // Приоритет 2: WhatsApp (если есть телефон)
    if (!sent && client.phone) {
      try {
        await this.whatsappService.sendMessage(client.phone, message);
        this.logger.log(`Sent to WhatsApp: ${client.phone}`);
        sent = true;
      } catch (error) {
        this.logger.error(`Failed to send to WhatsApp ${client.phone}:`, error);
      }
    }

    // Приоритет 3: Instagram (если есть instagramId)
    if (!sent && client.instagramId) {
      try {
        await this.instagramService.sendMessage(client.instagramId, message);
        this.logger.log(`Sent to Instagram: ${client.instagramId}`);
        sent = true;
      } catch (error) {
        this.logger.error(`Failed to send to Instagram ${client.instagramId}:`, error);
      }
    }

    if (!sent) {
      this.logger.warn(`No channel available for client ${client.id}`);
    }
  }

  /**
   * Получить статистику очереди уведомлений
   */
  async getQueueStats(): Promise<any> {
    try {
      const waiting = await this.notificationQueue.getWaitingCount();
      const active = await this.notificationQueue.getActiveCount();
      const completed = await this.notificationQueue.getCompletedCount();
      const failed = await this.notificationQueue.getFailedCount();
      const delayed = await this.notificationQueue.getDelayedCount();

      return {
        waiting,
        active,
        completed,
        failed,
        delayed,
        total: waiting + active + delayed,
      };
    } catch (error) {
      this.logger.error('Failed to get queue stats:', error);
      return null;
    }
  }

  /**
   * Получить список запланированных напоминаний
   */
  async getScheduledReminders(): Promise<any[]> {
    try {
      const jobs = await this.notificationQueue.getJobs(['delayed', 'waiting']);
      
      return jobs.map(job => ({
        id: job.id,
        name: job.name,
        data: job.data,
        delay: job.opts.delay,
        scheduledFor: new Date(Date.now() + (job.opts.delay || 0)),
      }));
    } catch (error) {
      this.logger.error('Failed to get scheduled reminders:', error);
      return [];
    }
  }
}
