# WhatsApp Configuration Template

## Переменные окружения

Добавьте эти переменные в ваш `.env` файл:

```bash
# WhatsApp Business Cloud API
WHATSAPP_PHONE_NUMBER_ID=your_phone_number_id_here
WHATSAPP_ACCESS_TOKEN=your_access_token_here
WHATSAPP_VERIFY_TOKEN=your_verify_token_here
```

## Где получить значения

### 1. WHATSAPP_PHONE_NUMBER_ID
- Откройте [Meta for Developers](https://developers.facebook.com/apps/)
- Перейдите в ваше приложение → **WhatsApp** → **Getting Started**
- Скопируйте **Phone Number ID** (числовой ID, например `123456789012345`)

### 2. WHATSAPP_ACCESS_TOKEN
**Временный токен (для тестирования, действует 24 часа):**
- В том же разделе **Getting Started**
- Скопируйте **Temporary Access Token** (начинается с `EAAG...`)

**Постоянный токен (для продакшена):**
- Перейдите в **Business Settings** → **System Users**
- Создайте System User с правами **Admin**
- Сгенерируйте токен с разрешениями:
  - `whatsapp_business_messaging`
  - `whatsapp_business_management`

### 3. WHATSAPP_VERIFY_TOKEN
- Придумайте случайную строку (минимум 20 символов)
- Пример: `my_secure_verify_token_abc123xyz789`
- Эта же строка должна быть указана при настройке webhook в Meta Console

## Настройка Webhook

1. В Meta Console перейдите в **WhatsApp** → **Configuration**
2. Нажмите **Edit** в разделе Webhook
3. Заполните:
   - **Callback URL**: `https://ваш-домен.com/webhooks/whatsapp`
   - **Verify Token**: Ваш `WHATSAPP_VERIFY_TOKEN`
4. Нажмите **Verify and Save**
5. Подпишитесь на события:
   - ✅ `messages`
   - ✅ `message_status` (опционально)

## Проверка

После настройки:
1. Запустите сервер: `npm run start:dev`
2. В Meta Console должна быть зелёная галочка ✅ напротив webhook
3. Отправьте тестовое сообщение боту
4. Проверьте логи сервера

Подробная инструкция: **WHATSAPP-SETUP-GUIDE.md**
