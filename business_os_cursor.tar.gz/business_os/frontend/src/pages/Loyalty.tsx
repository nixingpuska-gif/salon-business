import { useState } from 'react'
import { 
  Gift, Star, Users, TrendingUp, Award, 
  CreditCard, Percent, ChevronRight, Plus
} from 'lucide-react'

interface LoyaltyTier {
  name: string
  minPoints: number
  cashback: number
  color: string
  benefits: string[]
}

interface TopClient {
  id: number
  name: string
  tier: string
  points: number
  totalSpent: number
  visits: number
}

export default function Loyalty() {
  const [activeTab, setActiveTab] = useState<'program' | 'clients' | 'certificates'>('program')
  const [stats] = useState({
    totalMembers: 245,
    activeMembers: 180,
    pointsIssued: 2450000,
    pointsRedeemed: 1200000,
    avgRetention: 78
  })

  const tiers: LoyaltyTier[] = [
    { 
      name: 'Bronze', 
      minPoints: 0, 
      cashback: 3, 
      color: 'bg-amber-600',
      benefits: ['Накопление баллов', 'Поздравление с ДР']
    },
    { 
      name: 'Silver', 
      minPoints: 5000, 
      cashback: 5, 
      color: 'bg-gray-400',
      benefits: ['Накопление баллов', 'Приоритетная запись', 'Скидка 5%']
    },
    { 
      name: 'Gold', 
      minPoints: 15000, 
      cashback: 7, 
      color: 'bg-yellow-500',
      benefits: ['Накопление баллов', 'Приоритетная запись', 'Скидка 10%', 'Бесплатная отмена']
    },
    { 
      name: 'Platinum', 
      minPoints: 50000, 
      cashback: 10, 
      color: 'bg-gray-800',
      benefits: ['Все преимущества', 'Персональный менеджер', 'Эксклюзивные акции', 'VIP-обслуживание']
    },
  ]

  const topClients: TopClient[] = [
    { id: 1, name: 'Мария Сидорова', tier: 'Platinum', points: 52000, totalSpent: 520000, visits: 48 },
    { id: 2, name: 'Анна Козлова', tier: 'Gold', points: 28000, totalSpent: 280000, visits: 32 },
    { id: 3, name: 'Елена Петрова', tier: 'Gold', points: 18500, totalSpent: 185000, visits: 24 },
    { id: 4, name: 'Ольга Иванова', tier: 'Silver', points: 12000, totalSpent: 120000, visits: 18 },
    { id: 5, name: 'Татьяна Новикова', tier: 'Silver', points: 8500, totalSpent: 85000, visits: 14 },
  ]

  const certificates = [
    { id: 1, code: 'GIFT-2024-001', value: 5000, balance: 2500, status: 'active', expires: '2025-11-15' },
    { id: 2, code: 'GIFT-2024-002', value: 3000, balance: 0, status: 'used', expires: '2025-10-01' },
    { id: 3, code: 'GIFT-2024-003', value: 10000, balance: 10000, status: 'active', expires: '2025-12-20' },
  ]

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'Platinum': return 'bg-gray-800 text-white'
      case 'Gold': return 'bg-yellow-500 text-white'
      case 'Silver': return 'bg-gray-400 text-white'
      default: return 'bg-amber-600 text-white'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Gift className="w-7 h-7 text-primary-600" />
            Программа лояльности
          </h1>
          <p className="text-gray-600 mt-1">Управление бонусами и сертификатами</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700">
          <Plus className="w-4 h-4" />
          Создать сертификат
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <Users className="w-4 h-4" />
            Участников
          </div>
          <div className="text-2xl font-bold text-gray-900 mt-1">{stats.totalMembers}</div>
          <div className="text-xs text-green-600">+12 за месяц</div>
        </div>
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <Star className="w-4 h-4" />
            Активных
          </div>
          <div className="text-2xl font-bold text-gray-900 mt-1">{stats.activeMembers}</div>
          <div className="text-xs text-gray-500">{Math.round(stats.activeMembers / stats.totalMembers * 100)}% от всех</div>
        </div>
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <Award className="w-4 h-4" />
            Начислено баллов
          </div>
          <div className="text-2xl font-bold text-gray-900 mt-1">{(stats.pointsIssued / 1000).toFixed(0)}K</div>
        </div>
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <CreditCard className="w-4 h-4" />
            Списано баллов
          </div>
          <div className="text-2xl font-bold text-gray-900 mt-1">{(stats.pointsRedeemed / 1000).toFixed(0)}K</div>
        </div>
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <TrendingUp className="w-4 h-4" />
            Удержание
          </div>
          <div className="text-2xl font-bold text-green-600 mt-1">{stats.avgRetention}%</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b">
        <nav className="flex gap-8">
          {[
            { id: 'program', label: 'Уровни программы' },
            { id: 'clients', label: 'Топ клиенты' },
            { id: 'certificates', label: 'Сертификаты' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`pb-4 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab.id
                  ? 'border-primary-600 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {/* Content */}
      {activeTab === 'program' && (
        <div className="grid md:grid-cols-4 gap-4">
          {tiers.map((tier) => (
            <div key={tier.name} className="bg-white rounded-xl border overflow-hidden">
              <div className={`${tier.color} p-4 text-white`}>
                <div className="text-lg font-bold">{tier.name}</div>
                <div className="text-sm opacity-80">от {tier.minPoints.toLocaleString()} баллов</div>
              </div>
              <div className="p-4">
                <div className="flex items-center gap-2 mb-4">
                  <Percent className="w-5 h-5 text-primary-600" />
                  <span className="text-2xl font-bold">{tier.cashback}%</span>
                  <span className="text-gray-500 text-sm">кэшбэк</span>
                </div>
                <ul className="space-y-2">
                  {tier.benefits.map((benefit, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm text-gray-600">
                      <div className="w-1.5 h-1.5 rounded-full bg-primary-600" />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'clients' && (
        <div className="bg-white rounded-xl border overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Клиент</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Уровень</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Баллы</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Потрачено</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Визиты</th>
                <th className="px-6 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {topClients.map((client) => (
                <tr key={client.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="font-medium text-gray-900">{client.name}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTierColor(client.tier)}`}>
                      {client.tier}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-900 font-medium">
                    {client.points.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-gray-600">
                    {client.totalSpent.toLocaleString()}₽
                  </td>
                  <td className="px-6 py-4 text-gray-600">
                    {client.visits}
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-primary-600 hover:text-primary-700">
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'certificates' && (
        <div className="space-y-4">
          <div className="grid md:grid-cols-3 gap-4">
            {[3000, 5000, 10000].map((value) => (
              <div key={value} className="bg-gradient-to-r from-primary-500 to-primary-600 rounded-xl p-6 text-white">
                <div className="text-sm opacity-80">Сертификат</div>
                <div className="text-3xl font-bold mt-1">{value.toLocaleString()}₽</div>
                <button className="mt-4 bg-white/20 hover:bg-white/30 px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                  Создать
                </button>
              </div>
            ))}
          </div>

          <div className="bg-white rounded-xl border overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Код</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Номинал</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Остаток</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Статус</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Действует до</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {certificates.map((cert) => (
                  <tr key={cert.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 font-mono text-sm">{cert.code}</td>
                    <td className="px-6 py-4 font-medium">{cert.value.toLocaleString()}₽</td>
                    <td className="px-6 py-4">{cert.balance.toLocaleString()}₽</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        cert.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {cert.status === 'active' ? 'Активен' : 'Использован'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-600">{cert.expires}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
