import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  SetMetadata,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { FeatureFlagsService, Feature } from './feature-flags.service';

/**
 * Feature Access Guard
 * 
 * Middleware для проверки доступа к функциям на основе подписки
 */

export const FEATURE_KEY = 'feature';
export const RequireFeature = (feature: Feature) =>
  SetMetadata(FEATURE_KEY, feature);

@Injectable()
export class FeatureAccessGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    private featureFlags: FeatureFlagsService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredFeature = this.reflector.getAllAndOverride<Feature>(
      FEATURE_KEY,
      [context.getHandler(), context.getClass()],
    );

    if (!requiredFeature) {
      // Если feature не указан, разрешаем доступ
      return true;
    }

    const request = context.switchToHttp().getRequest();
    const businessId = this.extractBusinessId(request);

    if (!businessId) {
      throw new ForbiddenException('Business ID not provided');
    }

    const hasAccess = await this.featureFlags.hasFeature(
      businessId,
      requiredFeature,
    );

    if (!hasAccess) {
      const subscription = await this.featureFlags.getBusinessSubscription(
        businessId,
      );
      const plan = this.featureFlags.getPlan(subscription.tier);

      throw new ForbiddenException(
        `Feature "${requiredFeature}" is not available on "${plan.name}" plan. Please upgrade your subscription.`,
      );
    }

    return true;
  }

  private extractBusinessId(request: any): string | null {
    // Попробовать извлечь из разных мест
    return (
      request.body?.businessId ||
      request.params?.businessId ||
      request.query?.businessId ||
      request.user?.businessId ||
      null
    );
  }
}
