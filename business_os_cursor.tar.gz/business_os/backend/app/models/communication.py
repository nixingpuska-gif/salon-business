"""
Business OS - Communication Models
Модели для сообщений, уведомлений и отзывов
"""

from datetime import datetime
from typing import Optional
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, BigInteger, 
    DateTime, Numeric, ForeignKey, JSON, Index
)
from sqlalchemy.orm import relationship
import enum

from app.models.base import TenantBaseModel


class MessageChannel(str, enum.Enum):
    """Каналы коммуникации"""
    TELEGRAM = "telegram"
    WHATSAPP = "whatsapp"
    SMS = "sms"
    EMAIL = "email"
    PUSH = "push"
    IN_APP = "in_app"


class MessageType(str, enum.Enum):
    """Типы сообщений"""
    REMINDER = "reminder"  # Напоминание о записи
    CONFIRMATION = "confirmation"  # Подтверждение записи
    FEEDBACK_REQUEST = "feedback_request"  # Запрос отзыва
    PROMO = "promo"  # Акция
    REACTIVATION = "reactivation"  # Реактивация
    BIRTHDAY = "birthday"  # День рождения
    CUSTOM = "custom"  # Кастомное
    SYSTEM = "system"  # Системное


class MessageStatus(str, enum.Enum):
    """Статусы сообщений"""
    PENDING = "pending"
    SENT = "sent"
    DELIVERED = "delivered"
    READ = "read"
    FAILED = "failed"
    CANCELLED = "cancelled"


class Message(TenantBaseModel):
    """
    Исходящее сообщение клиенту.
    """
    __tablename__ = "messages"
    
    # === Получатель ===
    client_id = Column(BigInteger, ForeignKey("clients.id"), nullable=False, index=True)
    
    # === Канал и тип ===
    channel = Column(String(50), nullable=False, index=True)
    message_type = Column(String(50), nullable=False, index=True)
    
    # === Контент ===
    subject = Column(String(255), nullable=True)  # Для email
    content = Column(Text, nullable=False)
    
    # === Шаблон ===
    template_id = Column(BigInteger, nullable=True)
    template_variables = Column(JSON, default=dict)
    
    # === Привязка к записи ===
    appointment_id = Column(BigInteger, nullable=True)
    
    # === Статус ===
    status = Column(String(50), default=MessageStatus.PENDING.value, index=True)
    
    # === Время отправки ===
    scheduled_at = Column(DateTime, nullable=True)  # Запланировано на
    sent_at = Column(DateTime, nullable=True)
    delivered_at = Column(DateTime, nullable=True)
    read_at = Column(DateTime, nullable=True)
    
    # === Ошибка ===
    error_message = Column(Text, nullable=True)
    retry_count = Column(Integer, default=0)
    
    # === Внешние ID ===
    external_id = Column(String(255), nullable=True)  # ID в Telegram/WhatsApp
    
    # === Relationships ===
    client = relationship("Client", back_populates="messages")
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_messages_tenant_client', 'tenant_id', 'client_id'),
        Index('ix_messages_tenant_status', 'tenant_id', 'status'),
        Index('ix_messages_scheduled', 'scheduled_at', 'status'),
    )


class MessageTemplate(TenantBaseModel):
    """
    Шаблон сообщения.
    """
    __tablename__ = "message_templates"
    
    # === Основная информация ===
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # === Тип и канал ===
    message_type = Column(String(50), nullable=False)
    channel = Column(String(50), nullable=False)
    
    # === Контент ===
    subject = Column(String(255), nullable=True)  # Для email
    content = Column(Text, nullable=False)
    # Переменные: {{client_name}}, {{appointment_date}}, {{service_name}}, etc.
    
    # === Настройки ===
    is_active = Column(Boolean, default=True)
    is_default = Column(Boolean, default=False)  # Шаблон по умолчанию для типа
    
    # === Язык ===
    language = Column(String(5), default="ru")
    
    # === Статистика ===
    times_used = Column(Integer, default=0)
    avg_open_rate = Column(Numeric(5, 2), nullable=True)
    avg_click_rate = Column(Numeric(5, 2), nullable=True)


class Conversation(TenantBaseModel):
    """
    Диалог с клиентом.
    Для отслеживания переписки в мессенджерах.
    """
    __tablename__ = "conversations"
    
    client_id = Column(BigInteger, ForeignKey("clients.id"), nullable=False, index=True)
    
    # === Канал ===
    channel = Column(String(50), nullable=False)
    
    # === Внешние ID ===
    external_chat_id = Column(String(255), nullable=True, index=True)
    
    # === Статус ===
    status = Column(String(50), default="active")  # active, closed, escalated
    
    # === AI-обработка ===
    is_ai_handled = Column(Boolean, default=True)  # Обрабатывается AI
    escalated_at = Column(DateTime, nullable=True)
    escalated_to_id = Column(BigInteger, nullable=True)  # ID админа
    escalation_reason = Column(String(255), nullable=True)
    
    # === Последнее сообщение ===
    last_message_at = Column(DateTime, nullable=True)
    last_message_from = Column(String(20), nullable=True)  # client, bot, admin
    unread_count = Column(Integer, default=0)
    
    # === Relationships ===
    messages = relationship("ConversationMessage", back_populates="conversation", lazy="dynamic")


class ConversationMessage(TenantBaseModel):
    """
    Сообщение в диалоге.
    """
    __tablename__ = "conversation_messages"
    
    conversation_id = Column(BigInteger, ForeignKey("conversations.id"), nullable=False, index=True)
    
    # === Отправитель ===
    sender_type = Column(String(20), nullable=False)  # client, bot, admin
    sender_id = Column(BigInteger, nullable=True)  # ID админа если sender_type=admin
    
    # === Контент ===
    content = Column(Text, nullable=False)
    content_type = Column(String(20), default="text")  # text, image, voice, file
    
    # === Медиа ===
    media_url = Column(String(500), nullable=True)
    media_type = Column(String(50), nullable=True)
    
    # === AI-анализ ===
    ai_intent = Column(String(100), nullable=True)  # Определённое намерение
    ai_sentiment = Column(String(20), nullable=True)  # positive, negative, neutral
    ai_confidence = Column(Numeric(5, 2), nullable=True)
    ai_suggested_response = Column(Text, nullable=True)
    
    # === Статус ===
    is_read = Column(Boolean, default=False)
    read_at = Column(DateTime, nullable=True)
    
    # === Relationships ===
    conversation = relationship("Conversation", back_populates="messages")
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_conversation_messages_conversation', 'conversation_id', 'created_at'),
    )


class Review(TenantBaseModel):
    """
    Отзыв клиента.
    """
    __tablename__ = "reviews"
    
    # === Привязки ===
    client_id = Column(BigInteger, ForeignKey("clients.id"), nullable=False, index=True)
    appointment_id = Column(BigInteger, ForeignKey("appointments.id"), nullable=True)
    staff_id = Column(BigInteger, nullable=True, index=True)
    service_id = Column(BigInteger, nullable=True)
    branch_id = Column(BigInteger, nullable=True)
    
    # === Оценка ===
    rating = Column(Integer, nullable=False)  # 1-5
    
    # === Детальные оценки ===
    rating_service = Column(Integer, nullable=True)  # Качество услуги
    rating_staff = Column(Integer, nullable=True)  # Работа мастера
    rating_cleanliness = Column(Integer, nullable=True)  # Чистота
    rating_value = Column(Integer, nullable=True)  # Соотношение цена/качество
    
    # === Текст отзыва ===
    comment = Column(Text, nullable=True)
    
    # === Голосовой отзыв ===
    voice_url = Column(String(500), nullable=True)
    voice_transcription = Column(Text, nullable=True)
    
    # === Фото ===
    photos = Column(JSON, default=list)  # ["url1", "url2"]
    
    # === AI-анализ ===
    ai_sentiment = Column(String(20), nullable=True)  # positive, negative, neutral
    ai_topics = Column(JSON, default=list)  # ["качество", "время ожидания"]
    ai_summary = Column(Text, nullable=True)
    is_critical = Column(Boolean, default=False)  # Критический отзыв
    
    # === Источник ===
    source = Column(String(50), default="internal")  # internal, google, yandex, 2gis
    external_review_id = Column(String(255), nullable=True)
    
    # === Ответ ===
    response = Column(Text, nullable=True)
    responded_at = Column(DateTime, nullable=True)
    responded_by_id = Column(BigInteger, nullable=True)
    
    # === Публикация ===
    is_public = Column(Boolean, default=True)  # Показывать публично
    is_featured = Column(Boolean, default=False)  # Избранный отзыв
    
    # === Запрос публичного отзыва ===
    public_review_requested = Column(Boolean, default=False)
    public_review_url = Column(String(500), nullable=True)  # Ссылка на Яндекс/Google
    
    # === Relationships ===
    client = relationship("Client", back_populates="reviews")
    appointment = relationship("Appointment", back_populates="review")
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_reviews_tenant_rating', 'tenant_id', 'rating'),
        Index('ix_reviews_tenant_staff', 'tenant_id', 'staff_id'),
    )


class Notification(TenantBaseModel):
    """
    Внутреннее уведомление для владельца/сотрудника.
    """
    __tablename__ = "notifications"
    
    # === Получатель ===
    user_id = Column(BigInteger, nullable=True)  # Для владельца
    staff_id = Column(BigInteger, nullable=True)  # Для сотрудника
    
    # === Тип ===
    notification_type = Column(String(50), nullable=False)
    # new_appointment, cancelled_appointment, new_review, critical_review,
    # low_stock, payment_received, goal_achieved, etc.
    
    # === Приоритет ===
    priority = Column(String(20), default="normal")  # low, normal, high, critical
    
    # === Контент ===
    title = Column(String(255), nullable=False)
    body = Column(Text, nullable=True)
    
    # === Ссылка ===
    action_url = Column(String(500), nullable=True)
    action_type = Column(String(50), nullable=True)  # appointment, client, review, etc.
    action_id = Column(BigInteger, nullable=True)
    
    # === Статус ===
    is_read = Column(Boolean, default=False)
    read_at = Column(DateTime, nullable=True)
    
    # === Каналы отправки ===
    sent_channels = Column(JSON, default=list)  # ["push", "telegram", "email"]
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_notifications_user_read', 'user_id', 'is_read'),
        Index('ix_notifications_staff_read', 'staff_id', 'is_read'),
    )


class Alert(TenantBaseModel):
    """
    Критический алерт.
    Для резонансных событий, требующих немедленного внимания.
    """
    __tablename__ = "alerts"
    
    # === Тип алерта ===
    alert_type = Column(String(50), nullable=False)
    # conflict, complaint, vip_issue, fraud_suspicion, critical_review, etc.
    
    # === Приоритет ===
    priority = Column(String(20), default="high")  # high, critical
    
    # === Контент ===
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    
    # === Связанные сущности ===
    related_type = Column(String(50), nullable=True)  # client, appointment, review, staff
    related_id = Column(BigInteger, nullable=True)
    
    # === Статус ===
    status = Column(String(50), default="open")  # open, in_progress, resolved, dismissed
    
    # === Обработка ===
    assigned_to_id = Column(BigInteger, nullable=True)
    resolved_at = Column(DateTime, nullable=True)
    resolved_by_id = Column(BigInteger, nullable=True)
    resolution_notes = Column(Text, nullable=True)
    
    # === Время реакции ===
    first_response_at = Column(DateTime, nullable=True)
    response_time_minutes = Column(Integer, nullable=True)
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_alerts_tenant_status', 'tenant_id', 'status'),
        Index('ix_alerts_tenant_priority', 'tenant_id', 'priority'),
    )
