import { useState, useEffect } from 'react'
import { useQuery, useMutation } from '@tanstack/react-query'
import { apiClient, handleApiError } from '@utils/api'

export interface User {
  id: string
  email: string
  name: string
  role: 'admin' | 'staff' | 'owner'
  avatar?: string
  createdAt: string
}

export interface LoginCredentials {
  email: string
  password: string
}

export interface AuthResponse {
  user: User
  token: string
}

/**
 * useAuth Hook
 * Manages authentication state and provides auth methods
 */
export function useAuth() {
  const [token, setToken] = useState<string | null>(
    localStorage.getItem('auth_token')
  )

  // Fetch current user
  const { data: user, isLoading, error } = useQuery<User>({
    queryKey: ['auth', 'me'],
    queryFn: async () => {
      if (!token) throw new Error('No token')
      const response = await apiClient.get('/auth/me')
      return response.data
    },
    enabled: !!token,
    retry: false,
  })

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginCredentials) => {
      const response = await apiClient.post<AuthResponse>('/auth/login', credentials)
      return response.data
    },
    onSuccess: (data) => {
      localStorage.setItem('auth_token', data.token)
      setToken(data.token)
    },
    onError: (error) => {
      const apiError = handleApiError(error)
      throw new Error(apiError.message)
    },
  })

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiClient.post('/auth/logout')
    },
    onSuccess: () => {
      localStorage.removeItem('auth_token')
      setToken(null)
    },
  })

  // Register mutation
  const registerMutation = useMutation({
    mutationFn: async (credentials: LoginCredentials & { name: string }) => {
      const response = await apiClient.post<AuthResponse>('/auth/register', credentials)
      return response.data
    },
    onSuccess: (data) => {
      localStorage.setItem('auth_token', data.token)
      setToken(data.token)
    },
  })

  return {
    user: user || null,
    token,
    isLoading,
    isAuthenticated: !!user,
    error: error ? handleApiError(error) : null,
    login: loginMutation.mutate,
    logout: logoutMutation.mutate,
    register: registerMutation.mutate,
    isLoggingIn: loginMutation.isPending,
    isLoggingOut: logoutMutation.isPending,
  }
}
