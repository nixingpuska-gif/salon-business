# 🚀 AI Chat System - Quick Start

## Быстрый старт за 5 минут

### 1. Установка зависимостей

```bash
cd backend
npm install openai
```

### 2. Настройка .env

```env
OPENAI_API_KEY=sk-...
DATABASE_URL=postgresql://...
REDIS_HOST=localhost
REDIS_PORT=6379
```

### 3. Создать сценарий по умолчанию

```bash
curl -X POST http://localhost:3000/ai-chat/scenarios/YOUR_BUSINESS_ID/default \
  -H "Content-Type: application/json" \
  -d '{"template": "friendly"}'
```

### 4. Тестирование клиентского бота

```bash
curl -X POST http://localhost:3000/ai-chat/client/message \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "YOUR_BUSINESS_ID",
    "message": "Хочу записаться на маникюр",
    "channel": "whatsapp",
    "channelUserId": "+79991234567"
  }'
```

**Ответ:**
```json
{
  "reply": "Привет! 👋 Рада помочь с записью! На какую дату ты хотела бы записаться?"
}
```

### 5. Тестирование админ-бота

```bash
curl -X POST http://localhost:3000/ai-chat/admin/message \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "YOUR_BUSINESS_ID",
    "userId": "YOUR_USER_ID",
    "message": "Покажи статистику за неделю",
    "channel": "telegram",
    "channelUserId": "123456789"
  }'
```

**Ответ:**
```json
{
  "reply": "За последнюю неделю:\n- Записей: 45\n- Новых клиентов: 12\n- Доход: 67,500 ₽"
}
```

---

## Основные endpoints

### Клиентский чат
```
POST /ai-chat/client/message
```

### Админ-чат
```
POST /ai-chat/admin/message
```

### Управление сценариями
```
GET    /ai-chat/scenarios/:businessId
POST   /ai-chat/scenarios/:businessId
PUT    /ai-chat/scenarios/:businessId/:scenarioId
DELETE /ai-chat/scenarios/:businessId/:scenarioId
POST   /ai-chat/scenarios/:businessId/:scenarioId/activate
```

### Статистика
```
GET /ai-chat/conversations/:businessId/stats
GET /ai-chat/memory/:businessId/client/:clientId
```

---

## Кастомизация сценария (Pro уровень)

### Изменить тон общения

```bash
curl -X PUT http://localhost:3000/ai-chat/scenarios/BUSINESS_ID/SCENARIO_ID \
  -H "Content-Type: application/json" \
  -d '{
    "tone": "formal",
    "welcomeMessage": "Добрый день! Чем могу Вам помочь?"
  }'
```

### Добавить обязательные вопросы

```bash
curl -X PUT http://localhost:3000/ai-chat/scenarios/BUSINESS_ID/SCENARIO_ID \
  -H "Content-Type: application/json" \
  -d '{
    "requiredFields": [
      {
        "field": "name",
        "question": "Как Вас зовут?",
        "order": 1
      },
      {
        "field": "phone",
        "question": "Укажите номер телефона",
        "validation": "phone",
        "order": 2
      },
      {
        "field": "email",
        "question": "Ваш email для чека",
        "order": 3
      }
    ]
  }'
```

### Изменить системный промпт

```bash
curl -X PUT http://localhost:3000/ai-chat/scenarios/BUSINESS_ID/SCENARIO_ID \
  -H "Content-Type: application/json" \
  -d '{
    "systemPrompt": "Вы — эксперт по красоте. Всегда предлагайте дополнительные услуги. Будьте проактивны."
  }'
```

---

## Интеграция с каналами

### WhatsApp

```typescript
import { ClientChatService } from './ai-chat/client-chat.service';

async handleWhatsAppMessage(from: string, message: string) {
  const reply = await this.clientChatService.processMessage(
    this.businessId,
    message,
    'whatsapp',
    from,
  );
  
  await this.whatsappService.sendMessage(from, reply);
}
```

### Instagram

```typescript
async handleInstagramMessage(senderId: string, message: string) {
  const reply = await this.clientChatService.processMessage(
    this.businessId,
    message,
    'instagram',
    senderId,
  );
  
  await this.instagramService.sendMessage(senderId, reply);
}
```

### Telegram

```typescript
async handleTelegramMessage(chatId: number, message: string) {
  const reply = await this.clientChatService.processMessage(
    this.businessId,
    message,
    'telegram',
    chatId.toString(),
  );
  
  await this.telegramService.sendMessage(chatId, reply);
}
```

---

## Примеры диалогов

### Пример 1: Первая запись клиента

```
Клиент: Хочу записаться на маникюр
Бот: Отлично! Как тебя зовут?
Клиент: Анна
Бот: Приятно познакомиться, Анна! Укажи номер телефона
Клиент: +79991234567
Бот: На какую дату хочешь записаться?
Клиент: На завтра в 18:00
Бот: Отлично! 🎉 Ты записана на 26 ноября в 18:00. Маникюр — будет супер! ✨
```

### Пример 2: Повторная запись

```
Клиент: Хочу записаться
Бот: Привет, Анна! 👋 На маникюр, как обычно?
Клиент: Да, на пятницу в 18:00
Бот: Готово! Записала тебя на 29 ноября в 18:00. До встречи! 💅
```

*(Бот помнит клиента и её предпочтения)*

### Пример 3: Админ запрашивает статистику

```
Админ: Покажи записи на сегодня
Бот: Сегодня 5 записей:
1. 10:00 - Анна - Маникюр
2. 12:00 - Мария - Педикюр
3. 14:00 - Ольга - Маникюр + Педикюр
4. 16:00 - Елена - Массаж
5. 18:00 - Ирина - Маникюр
```

### Пример 4: Админ настраивает бота

```
Админ: Измени приветствие на более формальное
Бот: Готово! Изменил приветствие на: "Добрый день! Чем могу Вам помочь?"
```

---

## Доступные шаблоны

### 1. Friendly (Дружелюбный) — рекомендуется
```json
{
  "template": "friendly"
}
```
Тон: Тёплый, дружеский, с эмодзи  
Использование: Молодёжные салоны, студии

### 2. Formal (Формальный)
```json
{
  "template": "formal"
}
```
Тон: Вежливый, на "Вы", деловой  
Использование: Премиум-салоны, медицинские центры

### 3. Professional (Профессиональный)
```json
{
  "template": "professional"
}
```
Тон: Профессиональный, но тёплый  
Использование: Универсальный вариант

---

## Функции AI

### Для клиентов:
- ✅ Просмотр услуг
- ✅ Поиск свободных слотов
- ✅ Создание записи
- ✅ Просмотр своих записей
- ✅ Отмена записи
- ✅ Перенос записи

### Для админов:
- ✅ Статистика (записи, клиенты, доход)
- ✅ Просмотр записей
- ✅ Просмотр клиентов
- ✅ Настройка сценариев
- ✅ Управление услугами
- ✅ Создание услуг

---

## Память контекста

### Что запоминается:
- ✅ Имя клиента
- ✅ Телефон
- ✅ Email
- ✅ Предпочитаемые услуги
- ✅ Предпочитаемое время
- ✅ История записей
- ✅ История диалогов

### Как работает:
1. Первый контакт → собирает информацию
2. Повторный контакт → узнаёт клиента
3. НЕ спрашивает уже известную информацию

---

## Стоимость

**OpenAI GPT-4 Turbo:**
- Средний диалог: ~$0.011
- 1000 диалогов/месяц: ~$11

---

## Troubleshooting

### Бот не отвечает
```bash
# Проверить OpenAI API key
echo $OPENAI_API_KEY

# Проверить логи
tail -f logs/combined.log | grep "ClientChatService"
```

### Бот не запоминает клиента
```bash
# Проверить БД
curl http://localhost:3000/ai-chat/memory/BUSINESS_ID/CLIENT_ID
```

### Function calling не работает
```bash
# Проверить логи function calls
tail -f logs/combined.log | grep "function call"
```

---

## Следующие шаги

1. ✅ Создать сценарий по умолчанию
2. ✅ Протестировать клиентский бот
3. ✅ Протестировать админ-бот
4. ⚙️ Настроить промпты под свой бизнес
5. 🔗 Интегрировать с каналами (WhatsApp, Instagram, Telegram)
6. 📊 Мониторить статистику диалогов

---

## Полная документация

См. `AI-CHAT-SYSTEM-GUIDE.md` для подробной информации.

---

**Готово! Ваш AI-бот готов к работе! 🤖✨**
