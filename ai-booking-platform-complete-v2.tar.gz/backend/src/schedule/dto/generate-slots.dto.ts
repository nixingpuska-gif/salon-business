import { IsString, IsNotEmpty, IsDateString, IsNumber, IsOptional, Min } from 'class-validator';

export class GenerateSlotsDto {
  @IsString()
  @IsNotEmpty()
  businessId: string;

  @IsDateString()
  @IsNotEmpty()
  date: string;

  @IsNumber()
  @Min(1)
  serviceDurationMinutes: number;

  @IsNumber()
  @IsOptional()
  @Min(1)
  slotIntervalMinutes?: number;
}
