import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

/**
 * Feature Flags Service
 * 
 * Управление доступом к функциям на основе подписки:
 * - Проверка доступа к функциям
 * - Управление лимитами
 * - Тарифные планы
 */

export enum SubscriptionTier {
  FREE = 'free',
  BASIC = 'basic',
  PRO = 'pro',
  ENTERPRISE = 'enterprise',
}

export enum Feature {
  // Базовые функции
  BASIC_BOOKING = 'basic_booking',
  CLIENT_MANAGEMENT = 'client_management',
  SERVICE_MANAGEMENT = 'service_management',
  
  // Каналы коммуникации
  TELEGRAM_BOT = 'telegram_bot',
  WHATSAPP_BUSINESS = 'whatsapp_business',
  INSTAGRAM_DIRECT = 'instagram_direct',
  
  // Уведомления
  BOOKING_REMINDERS = 'booking_reminders',
  CUSTOM_NOTIFICATIONS = 'custom_notifications',
  
  // Автоматизация
  OCR_IMPORT = 'ocr_import',
  SMM_POSTING = 'smm_posting',
  AI_ASSISTANT = 'ai_assistant',
  
  // Аналитика
  BASIC_ANALYTICS = 'basic_analytics',
  ADVANCED_ANALYTICS = 'advanced_analytics',
  CUSTOM_REPORTS = 'custom_reports',
  
  // Интеграции
  GOOGLE_CALENDAR_SYNC = 'google_calendar_sync',
  PAYMENT_PROCESSING = 'payment_processing',
  API_ACCESS = 'api_access',
  
  // Дополнительно
  MULTI_LOCATION = 'multi_location',
  TEAM_MANAGEMENT = 'team_management',
  WHITE_LABEL = 'white_label',
  PRIORITY_SUPPORT = 'priority_support',
}

interface SubscriptionLimits {
  maxBookingsPerMonth: number;
  maxClients: number;
  maxServices: number;
  maxStaff: number;
  maxLocations: number;
  maxSMMPostsPerMonth: number;
  maxOCRImportsPerMonth: number;
  maxNotificationsPerMonth: number;
}

interface SubscriptionPlan {
  tier: SubscriptionTier;
  name: string;
  price: number; // в рублях/месяц
  features: Feature[];
  limits: SubscriptionLimits;
}

@Injectable()
export class FeatureFlagsService {
  private readonly logger = new Logger(FeatureFlagsService.name);

  // Определение тарифных планов
  private readonly plans: Record<SubscriptionTier, SubscriptionPlan> = {
    [SubscriptionTier.FREE]: {
      tier: SubscriptionTier.FREE,
      name: 'Бесплатный',
      price: 0,
      features: [
        Feature.BASIC_BOOKING,
        Feature.CLIENT_MANAGEMENT,
        Feature.SERVICE_MANAGEMENT,
        Feature.TELEGRAM_BOT,
        Feature.BASIC_ANALYTICS,
      ],
      limits: {
        maxBookingsPerMonth: 50,
        maxClients: 100,
        maxServices: 5,
        maxStaff: 1,
        maxLocations: 1,
        maxSMMPostsPerMonth: 0,
        maxOCRImportsPerMonth: 0,
        maxNotificationsPerMonth: 50,
      },
    },
    [SubscriptionTier.BASIC]: {
      tier: SubscriptionTier.BASIC,
      name: 'Базовый',
      price: 990,
      features: [
        Feature.BASIC_BOOKING,
        Feature.CLIENT_MANAGEMENT,
        Feature.SERVICE_MANAGEMENT,
        Feature.TELEGRAM_BOT,
        Feature.WHATSAPP_BUSINESS,
        Feature.BOOKING_REMINDERS,
        Feature.BASIC_ANALYTICS,
        Feature.GOOGLE_CALENDAR_SYNC,
      ],
      limits: {
        maxBookingsPerMonth: 200,
        maxClients: 500,
        maxServices: 20,
        maxStaff: 3,
        maxLocations: 1,
        maxSMMPostsPerMonth: 10,
        maxOCRImportsPerMonth: 10,
        maxNotificationsPerMonth: 200,
      },
    },
    [SubscriptionTier.PRO]: {
      tier: SubscriptionTier.PRO,
      name: 'Профессиональный',
      price: 2990,
      features: [
        Feature.BASIC_BOOKING,
        Feature.CLIENT_MANAGEMENT,
        Feature.SERVICE_MANAGEMENT,
        Feature.TELEGRAM_BOT,
        Feature.WHATSAPP_BUSINESS,
        Feature.INSTAGRAM_DIRECT,
        Feature.BOOKING_REMINDERS,
        Feature.CUSTOM_NOTIFICATIONS,
        Feature.OCR_IMPORT,
        Feature.SMM_POSTING,
        Feature.AI_ASSISTANT,
        Feature.BASIC_ANALYTICS,
        Feature.ADVANCED_ANALYTICS,
        Feature.GOOGLE_CALENDAR_SYNC,
        Feature.PAYMENT_PROCESSING,
        Feature.MULTI_LOCATION,
        Feature.TEAM_MANAGEMENT,
      ],
      limits: {
        maxBookingsPerMonth: 1000,
        maxClients: 5000,
        maxServices: 100,
        maxStaff: 10,
        maxLocations: 3,
        maxSMMPostsPerMonth: 50,
        maxOCRImportsPerMonth: 50,
        maxNotificationsPerMonth: 1000,
      },
    },
    [SubscriptionTier.ENTERPRISE]: {
      tier: SubscriptionTier.ENTERPRISE,
      name: 'Корпоративный',
      price: 9990,
      features: Object.values(Feature), // Все функции
      limits: {
        maxBookingsPerMonth: -1, // Безлимит
        maxClients: -1,
        maxServices: -1,
        maxStaff: -1,
        maxLocations: -1,
        maxSMMPostsPerMonth: -1,
        maxOCRImportsPerMonth: -1,
        maxNotificationsPerMonth: -1,
      },
    },
  };

  constructor(private prisma: PrismaService) {
    this.logger.log('Feature Flags Service initialized');
  }

  /**
   * Получить план подписки
   */
  getPlan(tier: SubscriptionTier): SubscriptionPlan {
    return this.plans[tier];
  }

  /**
   * Получить все планы
   */
  getAllPlans(): SubscriptionPlan[] {
    return Object.values(this.plans);
  }

  /**
   * Проверить доступ к функции
   */
  async hasFeature(
    businessId: string,
    feature: Feature,
  ): Promise<boolean> {
    try {
      const subscription = await this.getBusinessSubscription(businessId);
      const plan = this.getPlan(subscription.tier);
      return plan.features.includes(feature);
    } catch (error) {
      this.logger.error(`Failed to check feature access: ${error.message}`);
      return false;
    }
  }

  /**
   * Проверить лимит
   */
  async checkLimit(
    businessId: string,
    limitType: keyof SubscriptionLimits,
    currentValue: number,
  ): Promise<{ allowed: boolean; limit: number; current: number }> {
    try {
      const subscription = await this.getBusinessSubscription(businessId);
      const plan = this.getPlan(subscription.tier);
      const limit = plan.limits[limitType];

      // -1 означает безлимит
      const allowed = limit === -1 || currentValue < limit;

      return {
        allowed,
        limit,
        current: currentValue,
      };
    } catch (error) {
      this.logger.error(`Failed to check limit: ${error.message}`);
      return { allowed: false, limit: 0, current: currentValue };
    }
  }

  /**
   * Получить подписку бизнеса
   */
  async getBusinessSubscription(businessId: string): Promise<{
    tier: SubscriptionTier;
    validUntil: Date;
    isActive: boolean;
  }> {
    const business = await this.prisma.business.findUnique({
      where: { id: businessId },
      select: {
        subscriptionTier: true,
        subscriptionValidUntil: true,
      },
    });

    if (!business) {
      throw new Error('Business not found');
    }

    const tier = (business.subscriptionTier as SubscriptionTier) || SubscriptionTier.FREE;
    const validUntil = business.subscriptionValidUntil || new Date();
    const isActive = validUntil > new Date();

    return { tier, validUntil, isActive };
  }

  /**
   * Обновить подписку
   */
  async updateSubscription(
    businessId: string,
    tier: SubscriptionTier,
    validUntil: Date,
  ): Promise<void> {
    await this.prisma.business.update({
      where: { id: businessId },
      data: {
        subscriptionTier: tier,
        subscriptionValidUntil: validUntil,
      },
    });

    this.logger.log(
      `Subscription updated for business ${businessId}: ${tier} until ${validUntil.toISOString()}`,
    );
  }

  /**
   * Получить использование лимитов
   */
  async getUsageStats(
    businessId: string,
    month: Date = new Date(),
  ): Promise<{
    bookings: number;
    clients: number;
    services: number;
    staff: number;
    locations: number;
    smmPosts: number;
    ocrImports: number;
    notifications: number;
  }> {
    const startOfMonth = new Date(month.getFullYear(), month.getMonth(), 1);
    const endOfMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0);

    const [
      bookingsCount,
      clientsCount,
      servicesCount,
      staffCount,
      locationsCount,
      smmPostsCount,
      // ocrImportsCount,
      // notificationsCount,
    ] = await Promise.all([
      // Записи за месяц
      this.prisma.booking.count({
        where: {
          businessId,
          createdAt: { gte: startOfMonth, lte: endOfMonth },
        },
      }),
      // Всего клиентов
      this.prisma.client.count({
        where: { businessId },
      }),
      // Всего услуг
      this.prisma.service.count({
        where: { businessId, isActive: true },
      }),
      // Всего сотрудников
      this.prisma.staff.count({
        where: { businessId, isActive: true },
      }),
      // Всего локаций
      this.prisma.location.count({
        where: { businessId, isActive: true },
      }),
      // SMM посты за месяц
      this.prisma.socialMediaPost.count({
        where: {
          businessId,
          publishedAt: { gte: startOfMonth, lte: endOfMonth },
        },
      }),
    ]);

    return {
      bookings: bookingsCount,
      clients: clientsCount,
      services: servicesCount,
      staff: staffCount,
      locations: locationsCount,
      smmPosts: smmPostsCount,
      ocrImports: 0, // TODO: добавить трекинг OCR импортов
      notifications: 0, // TODO: добавить трекинг уведомлений
    };
  }

  /**
   * Проверить, можно ли выполнить действие
   */
  async canPerformAction(
    businessId: string,
    action: {
      feature?: Feature;
      limitType?: keyof SubscriptionLimits;
    },
  ): Promise<{
    allowed: boolean;
    reason?: string;
  }> {
    // Проверка подписки
    const subscription = await this.getBusinessSubscription(businessId);
    if (!subscription.isActive) {
      return {
        allowed: false,
        reason: 'Подписка истекла. Продлите подписку для продолжения работы.',
      };
    }

    // Проверка доступа к функции
    if (action.feature) {
      const hasAccess = await this.hasFeature(businessId, action.feature);
      if (!hasAccess) {
        const plan = this.getPlan(subscription.tier);
        return {
          allowed: false,
          reason: `Функция недоступна на тарифе "${plan.name}". Обновите подписку.`,
        };
      }
    }

    // Проверка лимита
    if (action.limitType) {
      const usage = await this.getUsageStats(businessId);
      const currentValue = usage[action.limitType as keyof typeof usage] || 0;
      const limitCheck = await this.checkLimit(
        businessId,
        action.limitType,
        currentValue,
      );

      if (!limitCheck.allowed) {
        return {
          allowed: false,
          reason: `Достигнут лимит: ${limitCheck.current}/${limitCheck.limit}. Обновите подписку.`,
        };
      }
    }

    return { allowed: true };
  }

  /**
   * Получить рекомендуемый план для upgrade
   */
  async getRecommendedUpgrade(businessId: string): Promise<{
    currentTier: SubscriptionTier;
    recommendedTier: SubscriptionTier;
    reasons: string[];
  }> {
    const subscription = await this.getBusinessSubscription(businessId);
    const usage = await this.getUsageStats(businessId);
    const currentPlan = this.getPlan(subscription.tier);

    const reasons: string[] = [];

    // Проверка лимитов
    if (
      currentPlan.limits.maxBookingsPerMonth !== -1 &&
      usage.bookings > currentPlan.limits.maxBookingsPerMonth * 0.8
    ) {
      reasons.push(
        `Использовано ${Math.round((usage.bookings / currentPlan.limits.maxBookingsPerMonth) * 100)}% лимита записей`,
      );
    }

    if (
      currentPlan.limits.maxClients !== -1 &&
      usage.clients > currentPlan.limits.maxClients * 0.8
    ) {
      reasons.push(
        `Использовано ${Math.round((usage.clients / currentPlan.limits.maxClients) * 100)}% лимита клиентов`,
      );
    }

    // Рекомендация upgrade
    let recommendedTier = subscription.tier;
    if (reasons.length > 0) {
      const tiers = [
        SubscriptionTier.FREE,
        SubscriptionTier.BASIC,
        SubscriptionTier.PRO,
        SubscriptionTier.ENTERPRISE,
      ];
      const currentIndex = tiers.indexOf(subscription.tier);
      if (currentIndex < tiers.length - 1) {
        recommendedTier = tiers[currentIndex + 1];
      }
    }

    return {
      currentTier: subscription.tier,
      recommendedTier,
      reasons,
    };
  }
}
