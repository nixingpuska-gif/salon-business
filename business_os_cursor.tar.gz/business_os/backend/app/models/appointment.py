"""
Business OS - Appointment Models
Модели записей на услуги
"""

from datetime import datetime, date, time
from typing import Optional
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, BigInteger, 
    DateTime, Date, Time, Numeric, ForeignKey, JSON, Index
)
from sqlalchemy.orm import relationship
import enum

from app.models.base import TenantBaseModel


class AppointmentStatus(str, enum.Enum):
    """Статусы записи"""
    PENDING = "pending"  # Ожидает подтверждения
    CONFIRMED = "confirmed"  # Подтверждена
    IN_PROGRESS = "in_progress"  # В процессе
    COMPLETED = "completed"  # Завершена
    CANCELLED_BY_CLIENT = "cancelled_by_client"  # Отменена клиентом
    CANCELLED_BY_SALON = "cancelled_by_salon"  # Отменена салоном
    NO_SHOW = "no_show"  # Не пришёл
    RESCHEDULED = "rescheduled"  # Перенесена


class AppointmentSource(str, enum.Enum):
    """Источник записи"""
    ADMIN = "admin"  # Администратор
    ONLINE = "online"  # Онлайн-запись на сайте
    TELEGRAM = "telegram"  # Через Telegram бота
    WHATSAPP = "whatsapp"  # Через WhatsApp
    INSTAGRAM = "instagram"  # Через Instagram
    PHONE = "phone"  # По телефону
    WALK_IN = "walk_in"  # Пришёл без записи


class Appointment(TenantBaseModel):
    """
    Запись на услугу.
    Основная сущность для управления расписанием.
    """
    __tablename__ = "appointments"
    
    # === Привязки ===
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=False, index=True)
    client_id = Column(BigInteger, ForeignKey("clients.id"), nullable=False, index=True)
    staff_id = Column(BigInteger, ForeignKey("staff.id"), nullable=False, index=True)
    service_id = Column(BigInteger, ForeignKey("services.id"), nullable=False, index=True)
    
    # === Дата и время ===
    date = Column(Date, nullable=False, index=True)
    start_time = Column(Time, nullable=False)
    end_time = Column(Time, nullable=False)
    duration_minutes = Column(Integer, nullable=False)
    
    # === Статус ===
    status = Column(String(50), default=AppointmentStatus.PENDING.value, index=True)
    
    # === Источник записи ===
    source = Column(String(50), default=AppointmentSource.ADMIN.value)
    
    # === Цена ===
    price = Column(Numeric(10, 2), nullable=False)
    discount_amount = Column(Numeric(10, 2), default=0)
    final_price = Column(Numeric(10, 2), nullable=False)
    
    # === Акция/промокод ===
    promotion_id = Column(BigInteger, nullable=True)
    promo_code = Column(String(50), nullable=True)
    
    # === Подтверждение ===
    confirmation_sent_at = Column(DateTime, nullable=True)
    confirmed_at = Column(DateTime, nullable=True)
    confirmation_method = Column(String(50), nullable=True)  # telegram, whatsapp, phone
    
    # === Напоминания ===
    reminders_sent = Column(JSON, default=list)
    # [{"sent_at": "2024-01-01T10:00:00", "channel": "telegram", "type": "24h"}]
    
    # === Отмена/перенос ===
    cancelled_at = Column(DateTime, nullable=True)
    cancellation_reason = Column(Text, nullable=True)
    cancelled_by = Column(String(50), nullable=True)  # client, admin, staff
    
    rescheduled_from_id = Column(BigInteger, nullable=True)  # ID предыдущей записи
    reschedule_count = Column(Integer, default=0)
    
    # === Завершение ===
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    actual_duration_minutes = Column(Integer, nullable=True)
    
    # === Заметки ===
    client_notes = Column(Text, nullable=True)  # Заметки от клиента
    staff_notes = Column(Text, nullable=True)  # Заметки от мастера
    admin_notes = Column(Text, nullable=True)  # Заметки администратора
    
    # === Дополнительные услуги ===
    additional_services = Column(JSON, default=list)
    # [{"service_id": 2, "price": 500, "name": "Снятие покрытия"}]
    
    # === Расходники ===
    consumables_used = Column(JSON, default=list)
    # [{"item_id": 1, "quantity": 0.5, "cost": 150}]
    
    # === Оплата ===
    is_paid = Column(Boolean, default=False)
    payment_id = Column(BigInteger, nullable=True)
    
    # === Отзыв ===
    review_requested_at = Column(DateTime, nullable=True)
    review_id = Column(BigInteger, nullable=True)
    
    # === Интеграция с календарём ===
    google_event_id = Column(String(255), nullable=True)
    
    # === Метаданные ===
    extra_data = Column(JSON, default=dict)
    
    # === Relationships ===
    branch = relationship("Branch")
    client = relationship("Client", back_populates="appointments")
    staff = relationship("Staff", back_populates="appointments")
    service = relationship("Service", back_populates="appointments")
    payment = relationship("Payment", back_populates="appointment", uselist=False)
    review = relationship("Review", back_populates="appointment", uselist=False)
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_appointments_tenant_date', 'tenant_id', 'date'),
        Index('ix_appointments_tenant_staff_date', 'tenant_id', 'staff_id', 'date'),
        Index('ix_appointments_tenant_client', 'tenant_id', 'client_id'),
        Index('ix_appointments_tenant_status', 'tenant_id', 'status'),
    )


class AppointmentHistory(TenantBaseModel):
    """
    История изменений записи.
    Для аудита и отслеживания.
    """
    __tablename__ = "appointment_history"
    
    appointment_id = Column(BigInteger, ForeignKey("appointments.id"), nullable=False, index=True)
    
    # === Действие ===
    action = Column(String(50), nullable=False)  # created, updated, cancelled, completed, etc.
    
    # === Кто изменил ===
    changed_by_type = Column(String(20), nullable=True)  # user, staff, client, system
    changed_by_id = Column(BigInteger, nullable=True)
    
    # === Изменения ===
    old_values = Column(JSON, nullable=True)
    new_values = Column(JSON, nullable=True)
    
    # === Комментарий ===
    comment = Column(Text, nullable=True)


class WaitingList(TenantBaseModel):
    """
    Лист ожидания.
    Клиенты, которые хотят записаться на занятое время.
    """
    __tablename__ = "waiting_list"
    
    # === Привязки ===
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=False)
    client_id = Column(BigInteger, ForeignKey("clients.id"), nullable=False, index=True)
    service_id = Column(BigInteger, ForeignKey("services.id"), nullable=True)
    staff_id = Column(BigInteger, ForeignKey("staff.id"), nullable=True)
    
    # === Желаемое время ===
    desired_date = Column(Date, nullable=False)
    desired_time_from = Column(Time, nullable=True)
    desired_time_to = Column(Time, nullable=True)
    
    # === Гибкость ===
    flexible_date = Column(Boolean, default=False)  # Готов на другую дату
    flexible_staff = Column(Boolean, default=False)  # Готов к другому мастеру
    
    # === Статус ===
    is_notified = Column(Boolean, default=False)  # Уведомлён о свободном слоте
    notified_at = Column(DateTime, nullable=True)
    
    is_booked = Column(Boolean, default=False)  # Записался
    booked_appointment_id = Column(BigInteger, nullable=True)
    
    # === Срок действия ===
    expires_at = Column(DateTime, nullable=True)


class RecurringAppointment(TenantBaseModel):
    """
    Повторяющиеся записи.
    Для клиентов с регулярным графиком.
    """
    __tablename__ = "recurring_appointments"
    
    # === Привязки ===
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=False)
    client_id = Column(BigInteger, ForeignKey("clients.id"), nullable=False, index=True)
    staff_id = Column(BigInteger, ForeignKey("staff.id"), nullable=False)
    service_id = Column(BigInteger, ForeignKey("services.id"), nullable=False)
    
    # === Расписание ===
    day_of_week = Column(Integer, nullable=True)  # 0-6 (Пн-Вс)
    time = Column(Time, nullable=False)
    
    # === Периодичность ===
    frequency = Column(String(20), nullable=False)  # weekly, biweekly, monthly
    interval = Column(Integer, default=1)  # Каждые N недель/месяцев
    
    # === Период действия ===
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=True)
    
    # === Статус ===
    is_active = Column(Boolean, default=True)
    
    # === Статистика ===
    total_created = Column(Integer, default=0)
    total_completed = Column(Integer, default=0)
    total_cancelled = Column(Integer, default=0)
