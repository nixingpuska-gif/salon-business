import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../prisma/prisma.service';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';

/**
 * Payment Service (YooKassa Integration)
 * 
 * Интеграция с платёжной системой ЮKassa:
 * - Создание платежей
 * - Проверка статуса
 * - Обработка webhook
 * - Возвраты
 */

export enum PaymentStatus {
  PENDING = 'pending',
  WAITING_FOR_CAPTURE = 'waiting_for_capture',
  SUCCEEDED = 'succeeded',
  CANCELED = 'canceled',
  REFUNDED = 'refunded',
}

export interface CreatePaymentParams {
  amount: number; // в рублях
  description: string;
  businessId: string;
  metadata?: Record<string, any>;
  returnUrl?: string;
}

export interface PaymentInfo {
  id: string;
  status: PaymentStatus;
  amount: number;
  currency: string;
  description: string;
  confirmationUrl?: string;
  createdAt: Date;
  capturedAt?: Date;
  metadata?: Record<string, any>;
}

@Injectable()
export class PaymentService {
  private readonly logger = new Logger(PaymentService.name);
  private readonly apiUrl = 'https://api.yookassa.ru/v3';
  private readonly shopId: string;
  private readonly secretKey: string;

  constructor(
    private prisma: PrismaService,
    private configService: ConfigService,
  ) {
    this.shopId = this.configService.get<string>('YOOKASSA_SHOP_ID') || '';
    this.secretKey = this.configService.get<string>('YOOKASSA_SECRET_KEY') || '';

    if (!this.shopId || !this.secretKey) {
      this.logger.warn('YooKassa credentials not configured');
    } else {
      this.logger.log('Payment Service initialized with YooKassa');
    }
  }

  /**
   * Создать платёж
   */
  async createPayment(params: CreatePaymentParams): Promise<PaymentInfo> {
    try {
      if (!this.shopId || !this.secretKey) {
        throw new Error('YooKassa credentials not configured');
      }

      const idempotenceKey = uuidv4();

      // Создать платёж в YooKassa
      const response = await axios.post(
        `${this.apiUrl}/payments`,
        {
          amount: {
            value: params.amount.toFixed(2),
            currency: 'RUB',
          },
          description: params.description,
          confirmation: {
            type: 'redirect',
            return_url:
              params.returnUrl ||
              this.configService.get<string>('FRONTEND_URL') + '/payment/success',
          },
          capture: true, // Автоматическое подтверждение
          metadata: {
            businessId: params.businessId,
            ...params.metadata,
          },
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Idempotence-Key': idempotenceKey,
          },
          auth: {
            username: this.shopId,
            password: this.secretKey,
          },
        },
      );

      const payment = response.data;

      // Сохранить в БД
      await this.prisma.payment.create({
        data: {
          id: payment.id,
          businessId: params.businessId,
          amount: params.amount,
          currency: 'RUB',
          status: this.mapYooKassaStatus(payment.status),
          description: params.description,
          confirmationUrl: payment.confirmation?.confirmation_url,
          metadata: params.metadata || {},
          yookassaData: payment,
        },
      });

      this.logger.log(`Payment created: ${payment.id} for ${params.amount} RUB`);

      return {
        id: payment.id,
        status: this.mapYooKassaStatus(payment.status),
        amount: params.amount,
        currency: 'RUB',
        description: params.description,
        confirmationUrl: payment.confirmation?.confirmation_url,
        createdAt: new Date(payment.created_at),
        metadata: params.metadata,
      };
    } catch (error) {
      this.logger.error('Failed to create payment:', error);
      throw new Error(`Failed to create payment: ${error.message}`);
    }
  }

  /**
   * Получить информацию о платеже
   */
  async getPayment(paymentId: string): Promise<PaymentInfo> {
    try {
      if (!this.shopId || !this.secretKey) {
        throw new Error('YooKassa credentials not configured');
      }

      const response = await axios.get(`${this.apiUrl}/payments/${paymentId}`, {
        auth: {
          username: this.shopId,
          password: this.secretKey,
        },
      });

      const payment = response.data;

      // Обновить в БД
      await this.prisma.payment.update({
        where: { id: paymentId },
        data: {
          status: this.mapYooKassaStatus(payment.status),
          capturedAt: payment.captured_at ? new Date(payment.captured_at) : null,
          yookassaData: payment,
        },
      });

      return {
        id: payment.id,
        status: this.mapYooKassaStatus(payment.status),
        amount: parseFloat(payment.amount.value),
        currency: payment.amount.currency,
        description: payment.description,
        confirmationUrl: payment.confirmation?.confirmation_url,
        createdAt: new Date(payment.created_at),
        capturedAt: payment.captured_at ? new Date(payment.captured_at) : undefined,
        metadata: payment.metadata,
      };
    } catch (error) {
      this.logger.error(`Failed to get payment ${paymentId}:`, error);
      throw new Error(`Failed to get payment: ${error.message}`);
    }
  }

  /**
   * Отменить платёж
   */
  async cancelPayment(paymentId: string): Promise<void> {
    try {
      if (!this.shopId || !this.secretKey) {
        throw new Error('YooKassa credentials not configured');
      }

      const idempotenceKey = uuidv4();

      await axios.post(
        `${this.apiUrl}/payments/${paymentId}/cancel`,
        {},
        {
          headers: {
            'Idempotence-Key': idempotenceKey,
          },
          auth: {
            username: this.shopId,
            password: this.secretKey,
          },
        },
      );

      // Обновить в БД
      await this.prisma.payment.update({
        where: { id: paymentId },
        data: {
          status: PaymentStatus.CANCELED,
        },
      });

      this.logger.log(`Payment cancelled: ${paymentId}`);
    } catch (error) {
      this.logger.error(`Failed to cancel payment ${paymentId}:`, error);
      throw new Error(`Failed to cancel payment: ${error.message}`);
    }
  }

  /**
   * Создать возврат
   */
  async createRefund(
    paymentId: string,
    amount?: number,
  ): Promise<{ id: string; status: string }> {
    try {
      if (!this.shopId || !this.secretKey) {
        throw new Error('YooKassa credentials not configured');
      }

      const payment = await this.prisma.payment.findUnique({
        where: { id: paymentId },
      });

      if (!payment) {
        throw new Error('Payment not found');
      }

      const refundAmount = amount || payment.amount;
      const idempotenceKey = uuidv4();

      const response = await axios.post(
        `${this.apiUrl}/refunds`,
        {
          payment_id: paymentId,
          amount: {
            value: refundAmount.toFixed(2),
            currency: 'RUB',
          },
        },
        {
          headers: {
            'Content-Type': 'application/json',
            'Idempotence-Key': idempotenceKey,
          },
          auth: {
            username: this.shopId,
            password: this.secretKey,
          },
        },
      );

      const refund = response.data;

      // Создать запись о возврате
      await this.prisma.refund.create({
        data: {
          id: refund.id,
          paymentId,
          amount: refundAmount,
          status: refund.status,
          yookassaData: refund,
        },
      });

      // Обновить статус платежа
      if (refundAmount === payment.amount) {
        await this.prisma.payment.update({
          where: { id: paymentId },
          data: {
            status: PaymentStatus.REFUNDED,
          },
        });
      }

      this.logger.log(`Refund created: ${refund.id} for payment ${paymentId}`);

      return {
        id: refund.id,
        status: refund.status,
      };
    } catch (error) {
      this.logger.error(`Failed to create refund for ${paymentId}:`, error);
      throw new Error(`Failed to create refund: ${error.message}`);
    }
  }

  /**
   * Обработать webhook от YooKassa
   */
  async handleWebhook(event: any): Promise<void> {
    try {
      const { type, object } = event;

      this.logger.log(`Received webhook: ${type} for payment ${object.id}`);

      if (type === 'payment.succeeded') {
        await this.handlePaymentSucceeded(object);
      } else if (type === 'payment.canceled') {
        await this.handlePaymentCanceled(object);
      } else if (type === 'refund.succeeded') {
        await this.handleRefundSucceeded(object);
      }
    } catch (error) {
      this.logger.error('Failed to handle webhook:', error);
      throw error;
    }
  }

  /**
   * Обработать успешный платёж
   */
  private async handlePaymentSucceeded(payment: any): Promise<void> {
    const paymentId = payment.id;

    // Обновить статус в БД
    await this.prisma.payment.update({
      where: { id: paymentId },
      data: {
        status: PaymentStatus.SUCCEEDED,
        capturedAt: new Date(payment.captured_at),
        yookassaData: payment,
      },
    });

    this.logger.log(`Payment succeeded: ${paymentId}`);

    // Событие для активации подписки будет обработано в PaymentController
  }

  /**
   * Обработать отменённый платёж
   */
  private async handlePaymentCanceled(payment: any): Promise<void> {
    const paymentId = payment.id;

    await this.prisma.payment.update({
      where: { id: paymentId },
      data: {
        status: PaymentStatus.CANCELED,
        yookassaData: payment,
      },
    });

    this.logger.log(`Payment canceled: ${paymentId}`);
  }

  /**
   * Обработать успешный возврат
   */
  private async handleRefundSucceeded(refund: any): Promise<void> {
    const refundId = refund.id;

    await this.prisma.refund.update({
      where: { id: refundId },
      data: {
        status: 'succeeded',
        yookassaData: refund,
      },
    });

    this.logger.log(`Refund succeeded: ${refundId}`);
  }

  /**
   * Получить историю платежей бизнеса
   */
  async getPaymentHistory(
    businessId: string,
    params?: {
      limit?: number;
      offset?: number;
      status?: PaymentStatus;
    },
  ): Promise<{
    payments: PaymentInfo[];
    total: number;
  }> {
    const where: any = { businessId };

    if (params?.status) {
      where.status = params.status;
    }

    const [payments, total] = await Promise.all([
      this.prisma.payment.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: params?.limit || 50,
        skip: params?.offset || 0,
      }),
      this.prisma.payment.count({ where }),
    ]);

    return {
      payments: payments.map((p) => ({
        id: p.id,
        status: p.status as PaymentStatus,
        amount: p.amount,
        currency: p.currency,
        description: p.description,
        confirmationUrl: p.confirmationUrl,
        createdAt: p.createdAt,
        capturedAt: p.capturedAt,
        metadata: p.metadata as Record<string, any>,
      })),
      total,
    };
  }

  /**
   * Получить статистику платежей
   */
  async getPaymentStats(businessId?: string): Promise<{
    totalAmount: number;
    successfulPayments: number;
    pendingPayments: number;
    refundedAmount: number;
  }> {
    const where: any = businessId ? { businessId } : {};

    const [successful, pending, refunded] = await Promise.all([
      this.prisma.payment.aggregate({
        where: { ...where, status: PaymentStatus.SUCCEEDED },
        _sum: { amount: true },
        _count: true,
      }),
      this.prisma.payment.count({
        where: { ...where, status: PaymentStatus.PENDING },
      }),
      this.prisma.refund.aggregate({
        where: {
          payment: businessId ? { businessId } : undefined,
          status: 'succeeded',
        },
        _sum: { amount: true },
      }),
    ]);

    return {
      totalAmount: successful._sum.amount || 0,
      successfulPayments: successful._count,
      pendingPayments: pending,
      refundedAmount: refunded._sum.amount || 0,
    };
  }

  /**
   * Маппинг статуса YooKassa в внутренний статус
   */
  private mapYooKassaStatus(status: string): PaymentStatus {
    const mapping: Record<string, PaymentStatus> = {
      pending: PaymentStatus.PENDING,
      waiting_for_capture: PaymentStatus.WAITING_FOR_CAPTURE,
      succeeded: PaymentStatus.SUCCEEDED,
      canceled: PaymentStatus.CANCELED,
    };

    return mapping[status] || PaymentStatus.PENDING;
  }
}
