# AI-Booking Platform: Architecture & Technology Stack Proposal

## Executive Summary

This document outlines the architecture and technology choices for an AI-first SaaS booking platform targeting service professionals in Russia, with plans for international expansion.

**Key Differentiators:**
- Dual AI bots (client-facing + entrepreneur assistant)
- Natural language understanding for all interactions
- Automated SMM with content generation
- Multi-channel support (Telegram, WhatsApp, Instagram)
- Intelligent appointment import from notebooks/notes

---

## 1. Technology Stack Selection

### Recommended Stack (Node.js-based)

**Backend Framework:** Node.js + NestJS

**Rationale:**
- **NestJS** provides enterprise-grade architecture with dependency injection, modularity, and TypeScript support
- Built-in support for microservices pattern (future scalability)
- Excellent integration with Telegram Bot API, WhatsApp Business API
- Strong ecosystem for queue management (BullMQ)
- TypeScript ensures type safety across the entire codebase
- Faster development cycle for MVP compared to Python alternatives

**Database:** PostgreSQL 15+

**Rationale:**
- ACID compliance for booking transactions
- JSON/JSONB support for flexible metadata storage
- Row-level security for multi-tenant isolation
- Excellent performance for time-based queries (scheduling)
- Native timezone support (critical for Russian market)

**Queue System:** Redis + BullMQ

**Rationale:**
- Native TypeScript support
- Advanced scheduling capabilities (cron, delayed jobs)
- Built-in retry mechanisms
- Dashboard for monitoring (Bull Board)
- Perfect for reminders, scheduled posts, OCR processing

**Object Storage:** MinIO (S3-compatible)

**Rationale:**
- Self-hosted option for Russian data residency requirements (ФЗ-152)
- S3-compatible API (easy migration to AWS/Yandex Cloud later)
- Stores photos from notebooks, client work photos, generated content

**AI Integration:** OpenAI API (GPT-4) + Local LLM fallback

**Rationale:**
- GPT-4 for complex intent detection and natural conversation
- Function calling for structured tool invocation
- Fallback to local LLM (Ollama + Llama 3) for cost optimization
- Abstraction layer allows switching providers

**Additional Technologies:**

| Component | Technology | Purpose |
|-----------|-----------|---------|
| ORM | Prisma | Type-safe database access, migrations |
| Validation | class-validator + class-transformer | DTO validation |
| API Documentation | Swagger/OpenAPI | Auto-generated API docs |
| Testing | Jest + Supertest | Unit & integration tests |
| Calendar Integration | Google Calendar API + CalDAV | Sync appointments |
| OCR | Tesseract.js + GPT-4 Vision | Extract appointments from photos |
| Telegram Bots | node-telegram-bot-api / Grammy | Bot framework |
| WhatsApp | WhatsApp Business API (official) | Client communication |
| Instagram | Meta Graph API | Direct messages + posting |
| Logging | Winston + ELK Stack (future) | Centralized logging |
| Monitoring | Prometheus + Grafana (future) | Metrics & alerts |

---

## 2. System Architecture

### 2.1 High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         CLIENT LAYER                             │
├─────────────────────────────────────────────────────────────────┤
│  Telegram Client Bot  │  WhatsApp Bot  │  Instagram Direct     │
│  Telegram Admin Bot   │  Web Panel (future)                     │
└─────────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      CHANNEL GATEWAY                             │
├─────────────────────────────────────────────────────────────────┤
│  • Message normalization                                         │
│  • Channel abstraction                                           │
│  • ChannelUIAdapter (buttons/quick replies)                      │
└─────────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      AI ORCHESTRATOR                             │
├─────────────────────────────────────────────────────────────────┤
│  • Client AI Agent (booking, questions, support)                │
│  • Admin AI Agent (management, analytics, SMM)                  │
│  • Intent detection & entity extraction                          │
│  • Function calling / Tool invocation                            │
│  • Conversation context management                               │
└─────────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      CORE BACKEND (NestJS)                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ Auth &       │  │ Client CRM   │  │ Scheduling   │          │
│  │ Business     │  │ Service      │  │ Service      │          │
│  │ Service      │  │              │  │              │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ Booking      │  │ Calendar     │  │ Notification │          │
│  │ Service      │  │ Integration  │  │ Service      │          │
│  │              │  │ Service      │  │              │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ Import       │  │ Content &    │  │ Analytics    │          │
│  │ Service      │  │ SMM Service  │  │ Service      │          │
│  │ (OCR+Parse)  │  │              │  │              │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      DATA LAYER                                  │
├─────────────────────────────────────────────────────────────────┤
│  PostgreSQL (Multi-tenant)  │  Redis (Cache + Queue)            │
│  MinIO (Object Storage)     │                                    │
└─────────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                   BACKGROUND WORKERS                             │
├─────────────────────────────────────────────────────────────────┤
│  • Reminder Worker (24h, 2h before appointment)                 │
│  • SMM Autopilot Worker (scheduled posts)                       │
│  • Calendar Sync Worker (bidirectional sync)                    │
│  • OCR Processing Worker (async image processing)               │
└─────────────────────────────────────────────────────────────────┘
```

### 2.2 Module Breakdown

#### Channel Gateway Module

**Responsibilities:**
- Receive webhooks from Telegram, WhatsApp, Instagram
- Normalize messages into unified format:
  ```typescript
  interface NormalizedMessage {
    channel: 'telegram' | 'whatsapp' | 'instagram';
    userId: string;
    chatId: string;
    text?: string;
    attachments?: Attachment[];
    metadata: Record<string, any>;
    timestamp: Date;
  }
  ```
- Route messages to appropriate AI agent (client vs admin)
- Handle channel-specific authentication

#### ChannelUIAdapter Module

**Responsibilities:**
- Convert abstract UI structures to channel-specific formats
- Abstract UI format:
  ```typescript
  interface UIChoices {
    type: 'choices';
    question: string;
    options: Array<{ id: string; label: string }>;
  }
  
  interface UIConfirmation {
    type: 'confirmation';
    message: string;
    confirmLabel?: string;
    cancelLabel?: string;
  }
  ```
- Render for each channel:
  - **Telegram:** Inline keyboards
  - **WhatsApp:** Quick replies / List messages
  - **Instagram:** Quick replies
  - **Fallback:** Numbered text list

#### AI Orchestrator Module

**Responsibilities:**
- Manage two AI agents:
  - **Client AI:** Handles BOOK, RESCHEDULE, CANCEL, ASK_PRICE, ASK_ADDRESS, FAQ
  - **Admin AI:** Handles schedule management, service management, analytics, import, SMM
- Intent detection using GPT-4 with function calling
- Context management (conversation history, user profile, business settings)
- Tool/function invocation:
  ```typescript
  const tools = [
    { name: 'getAvailableSlots', params: ['businessId', 'serviceId', 'date'] },
    { name: 'createBooking', params: ['clientId', 'slotId', 'serviceId'] },
    { name: 'rescheduleBooking', params: ['bookingId', 'newSlotId'] },
    { name: 'cancelBooking', params: ['bookingId'] },
    { name: 'importFromText', params: ['text'] },
    { name: 'generateContentPlan', params: ['topics', 'frequency', 'duration'] },
    // ... more tools
  ];
  ```

#### Core Services

**Auth & Business Service:**
- Multi-tenant business management
- User authentication (mастера/admins)
- Tariff/subscription management
- Channel credentials storage (encrypted)

**Client CRM Service:**
- Client profiles (name, phone, preferences)
- Communication history
- Notes and tags
- Loyalty tracking (future)

**Scheduling Service:**
- Business working hours configuration
- Break times, holidays, vacations
- Slot generation algorithm:
  ```typescript
  generateSlots(
    businessId: string,
    dateRange: DateRange,
    serviceDuration: number
  ): Slot[]
  ```
- Conflict detection

**Booking Service:**
- Create/update/cancel bookings
- Status management (pending, confirmed, completed, cancelled, no-show)
- Booking history
- Integration with Calendar Service

**Calendar Integration Service:**
- Google Calendar OAuth flow
- Bidirectional sync:
  - Platform → Calendar (create/update/delete events)
  - Calendar → Platform (import external events, block slots)
- CalDAV support for other calendars

**Notification Service:**
- Queue reminders (24h, 2h before)
- Send via appropriate channel
- Track delivery status
- Configurable reminder templates

**Import Service:**
- Text parsing:
  ```
  Input: "12.05 12:00 Анна маникюр\n12.05 15:00 Ольга педикюр"
  Output: [
    { date: '2025-05-12', time: '12:00', clientName: 'Анна', service: 'маникюр' },
    { date: '2025-05-12', time: '15:00', clientName: 'Ольга', service: 'педикюр' }
  ]
  ```
- OCR processing:
  - Tesseract.js for text extraction
  - GPT-4 Vision for structured parsing
  - Preview & confirmation flow

**Content & SMM Service:**
- Content plan generation (AI-powered)
- Post generation from photos + AI text
- Publishing to Instagram (Graph API) and Telegram
- Post scheduling
- Modes: "with confirmation" vs "autopilot"
- Basic analytics (views, likes, comments)

**Analytics Service:**
- Booking statistics (count, revenue, average check)
- Client retention metrics
- SMM performance
- Simple reports (weekly, monthly)

---

## 3. Data Flow Examples

### 3.1 Client Booking Flow

```
1. Client sends: "Хочу записаться на маникюр в субботу"
   ↓
2. Channel Gateway normalizes message
   ↓
3. AI Orchestrator (Client Agent):
   - Detects intent: BOOK
   - Extracts entities: { service: 'маникюр', date: 'saturday' }
   - Calls: getAvailableSlots(businessId, 'маникюр', nextSaturday)
   ↓
4. Scheduling Service:
   - Generates available slots for Saturday
   - Returns: [{ id: 'slot_1', time: '10:00' }, { id: 'slot_2', time: '12:00' }, ...]
   ↓
5. AI Orchestrator:
   - Formats response with ChannelUIAdapter
   - Sends: "На субботу есть свободные окошки:" + buttons [10:00, 12:00, 14:00]
   ↓
6. Client clicks: "12:00"
   ↓
7. AI Orchestrator:
   - Calls: createBooking(clientId, 'slot_1', 'маникюр')
   ↓
8. Booking Service:
   - Creates booking in DB
   - Calls Calendar Service to create event
   - Calls Notification Service to queue reminders
   ↓
9. AI Orchestrator:
   - Sends confirmation: "Отлично! Вы записаны на маникюр в субботу 12.05 в 12:00. Адрес: ..."
```

### 3.2 Admin Import Flow

```
1. Admin sends: "Хочу импортировать записи из блокнота"
   ↓
2. AI Orchestrator (Admin Agent):
   - Detects intent: IMPORT_INIT
   - Sends: "У Вас записи в бумажном блокноте или в заметках?"
   - Buttons: [Фото блокнота, Текст из заметок]
   ↓
3. Admin selects: "Текст из заметок"
   ↓
4. AI Orchestrator:
   - Sends: "Отправьте текст с записями (каждая запись с новой строки)"
   ↓
5. Admin sends:
   "12.05 12:00 Анна маникюр
    12.05 15:00 Ольга педикюр
    14.05 18:30 Иван тренировка"
   ↓
6. AI Orchestrator:
   - Calls: importFromText(text)
   ↓
7. Import Service:
   - Parses each line using GPT-4
   - Returns structured data
   ↓
8. AI Orchestrator:
   - Shows preview: "Найдено 3 записи:" + formatted list
   - Buttons: [Подтвердить, Редактировать]
   ↓
9. Admin clicks: "Подтвердить"
   ↓
10. Import Service:
    - Creates bookings in DB
    - Creates calendar events
    - Creates/updates client profiles
    ↓
11. AI Orchestrator:
    - Sends: "Готово! Импортировано 3 записи."
```

### 3.3 SMM Autopilot Flow

```
1. Admin sends: "Сделай контент-план на месяц, 3 поста в неделю про уход за волосами"
   ↓
2. AI Orchestrator (Admin Agent):
   - Detects intent: SMM_CONTENT_PLAN
   - Calls: generateContentPlan({ topics: ['уход за волосами'], frequency: 3, duration: '1 month' })
   ↓
3. Content & SMM Service:
   - Uses GPT-4 to generate 12 post ideas
   - Saves to content_plan table
   - Returns preview
   ↓
4. AI Orchestrator:
   - Sends: "Готово! Вот план на месяц:" + list of posts
   - Asks: "Включить автопилот? Посты будут публиковаться автоматически."
   - Buttons: [Да, автопилот, Нет, с подтверждением]
   ↓
5. Admin clicks: "Да, автопилот"
   ↓
6. Content & SMM Service:
   - Sets autopilot mode = true
   - Schedules posts in BullMQ
   ↓
7. Background Worker (cron):
   - At scheduled time, generates post text + image
   - Publishes to Instagram + Telegram channel
   - Updates post status
```

---

## 4. Multi-Tenancy Strategy

**Approach:** Shared database with `businessId` column in all tables

**Rationale:**
- Simpler for MVP
- Cost-effective
- Easy to migrate to schema-per-tenant later if needed

**Implementation:**
- All queries filtered by `businessId`
- Prisma middleware to auto-inject `businessId`
- Row-level security in PostgreSQL as additional safety layer

**Example:**
```typescript
// Prisma middleware
prisma.$use(async (params, next) => {
  if (params.model && params.action === 'findMany') {
    params.args.where = {
      ...params.args.where,
      businessId: getCurrentBusinessId(),
    };
  }
  return next(params);
});
```

---

## 5. Security Considerations

**Data Residency (ФЗ-152 compliance):**
- Host in Russian data centers (Yandex Cloud, VK Cloud, or self-hosted)
- Store personal data (client names, phones) encrypted at rest
- Audit logging for all data access

**API Security:**
- JWT-based authentication for admin web API
- Webhook signature verification (Telegram, WhatsApp, Instagram)
- Rate limiting per business (prevent abuse)

**Channel Credentials:**
- Encrypt bot tokens, API keys in database (using `pgcrypto`)
- Environment variables for platform-level secrets

**Business Isolation:**
- Strict `businessId` filtering
- No cross-business data leakage
- Separate storage buckets per business (MinIO)

---

## 6. Scalability Plan

**MVP (Phase 1):**
- Monolithic NestJS app
- Single PostgreSQL instance
- Single Redis instance
- Handles ~100 businesses, ~10,000 bookings/month

**Growth (Phase 2 - $1M ARR):**
- Horizontal scaling: multiple NestJS instances behind load balancer
- PostgreSQL read replicas
- Redis cluster
- CDN for static assets (photos)

**International Expansion (Phase 3):**
- Multi-region deployment
- Database sharding by region
- Localization layer (i18n)
- Support for multiple languages in AI agents

---

## 7. Cost Optimization

**AI Costs:**
- Use GPT-4-mini for simple intents (cheaper)
- Cache common responses (FAQ)
- Fallback to local LLM (Llama 3) for non-critical tasks
- Estimate: ~$0.50 per business per month (100 messages)

**Infrastructure:**
- Start with single VPS (8GB RAM, 4 vCPU) - ~$40/month
- PostgreSQL + Redis + MinIO on same server
- Scale vertically first, then horizontally

**Monitoring:**
- Track AI token usage per business
- Alert on anomalies (spam, abuse)

---

## 8. Why This Stack Wins

| Requirement | Solution | Benefit |
|-------------|----------|---------|
| Fast MVP | NestJS + Prisma + TypeScript | Rapid development, type safety |
| Multi-channel | Channel Gateway abstraction | Easy to add VK, Viber, etc. |
| AI-first | OpenAI function calling + tools | Natural conversations, structured actions |
| Scalability | Modular architecture, queue system | Horizontal scaling ready |
| Russian market | Self-hosted option, ФЗ-152 compliance | Legal compliance |
| Cost-effective | Local LLM fallback, efficient caching | Lower operational costs |
| Developer experience | TypeScript end-to-end, auto-generated API docs | Easier to maintain, onboard developers |

---

## Next Steps

1. **Phase 2:** Design detailed data model (PostgreSQL schema)
2. **Phase 3:** Implement core backend services
3. **Phase 4:** Integrate Google Calendar
4. **Phase 5:** Build Telegram bots
5. **Phase 6:** Implement AI Orchestrator
6. **Phase 7:** Add import functionality
7. **Phase 8:** Build SMM module
8. **Phase 9:** Set up notification queue
9. **Phase 10:** Create deployment configs
10. **Phase 11:** Deliver complete MVP

---

**Document Version:** 1.0  
**Last Updated:** 2025-11-23
