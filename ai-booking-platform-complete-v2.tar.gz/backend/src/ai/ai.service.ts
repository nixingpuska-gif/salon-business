import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { NormalizedMessage, UIResponse, UIChoices } from '../channel-gateway/channel-gateway.service';
import { BusinessService } from '../business/business.service';
import { ClientService } from '../client/client.service';
import { ServiceService } from '../service/service.service';
import { ScheduleService } from '../schedule/schedule.service';
import { BookingService } from '../booking/booking.service';
import { clientTools } from './tools/client-tools';
import { adminTools } from './tools/admin-tools';
import { startOfDay, endOfDay, parseISO } from 'date-fns';

@Injectable()
export class AIService {
  private openai: OpenAI;
  private readonly logger = new Logger(AIService.name);

  constructor(
    private config: ConfigService,
    private businessService: BusinessService,
    private clientService: ClientService,
    private serviceService: ServiceService,
    private scheduleService: ScheduleService,
    private bookingService: BookingService,
  ) {
    const apiKey = this.config.get<string>('OPENAI_API_KEY');
    if (!apiKey) {
      this.logger.warn('OPENAI_API_KEY not set, AI features will be disabled');
    } else {
      this.openai = new OpenAI({ apiKey });
    }
  }

  /**
   * Handle client message with GPT-4
   */
  async handleClientMessage(message: NormalizedMessage, businessId: string): Promise<UIResponse> {
    if (!this.openai) {
      return {
        text: 'AI функции временно недоступны. Пожалуйста, свяжитесь с администратором.',
        ui: null,
      };
    }

    try {
      const systemPrompt = `Ты - AI-ассистент для записи клиентов на услуги.

Твоя задача:
1. Понять, что хочет клиент (записаться, перенести, отменить, узнать цену)
2. Использовать доступные функции для выполнения запроса
3. Общаться дружелюбно и профессионально на русском языке

Контекст:
- ID бизнеса: \${businessId}
- Канал: \${message.channel}
- ID пользователя: \${message.userId}

Доступные действия:
- Показать список услуг
- Показать доступные слоты для записи
- Создать запись
- Показать записи клиента
- Перенести запись
- Отменить запись
- Узнать цену услуги

Всегда спрашивай подтверждение перед созданием, переносом или отменой записи.`;

      const completion = await this.openai.chat.completions.create({
        model: 'gpt-4-turbo-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: message.text || 'Привет' },
        ],
        tools: clientTools,
        tool_choice: 'auto',
      });

      const responseMessage = completion.choices[0].message;

      // If AI wants to call a function
      if (responseMessage.tool_calls && responseMessage.tool_calls.length > 0) {
        const toolCall = responseMessage.tool_calls[0];
        const functionName = toolCall.function.name;
        const functionArgs = JSON.parse(toolCall.function.arguments);

        this.logger.log(`AI calling function: \${functionName}`, functionArgs);

        // Execute the function
        const functionResult = await this.executeClientFunction(
          functionName,
          functionArgs,
          message,
        );

        // Get final response from AI with function result
        const finalCompletion = await this.openai.chat.completions.create({
          model: 'gpt-4-turbo-preview',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: message.text || 'Привет' },
            responseMessage,
            {
              role: 'tool',
              tool_call_id: toolCall.id,
              content: JSON.stringify(functionResult),
            },
          ],
        });

        return {
          text: finalCompletion.choices[0].message.content || 'Готово!',
          ui: null,
        };
      }

      // No function call, just return AI response
      return {
        text: responseMessage.content || 'Чем могу помочь?',
        ui: null,
      };
    } catch (error) {
      this.logger.error('Error in handleClientMessage:', error);
      return {
        text: 'Извините, произошла ошибка. Попробуйте переформулировать запрос.',
        ui: null,
      };
    }
  }

  /**
   * Handle admin message with GPT-4
   */
  async handleAdminMessage(message: NormalizedMessage, userId: string): Promise<UIResponse> {
    if (!this.openai) {
      return {
        text: 'AI функции временно недоступны. Пожалуйста, настройте OPENAI_API_KEY.',
        ui: null,
      };
    }

    try {
      // Get user's businesses
      const businesses = await this.businessService.findByUser(userId);
      const businessId = businesses[0]?.id;

      if (!businessId) {
        return {
          text: 'У вас пока нет бизнеса. Давайте создадим его! Как называется ваш бизнес?',
          ui: null,
        };
      }

      const systemPrompt = `Ты - AI-ассистент для управления бизнесом в сфере услуг.

Твоя задача:
1. Помогать владельцу бизнеса управлять расписанием, услугами, записями
2. Использовать доступные функции для выполнения запросов
3. Общаться профессионально и эффективно на русском языке

Контекст:
- ID бизнеса: \${businessId}
- ID пользователя: \${userId}

Доступные действия:
- Создать услугу
- Настроить рабочие часы
- Добавить перерыв
- Добавить отпуск
- Посмотреть записи на сегодня
- Получить статистику
- Найти клиентов
- Добавить заметку о клиенте

Будь проактивным и предлагай полезные действия.`;

      const completion = await this.openai.chat.completions.create({
        model: 'gpt-4-turbo-preview',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: message.text || 'Привет' },
        ],
        tools: adminTools,
        tool_choice: 'auto',
      });

      const responseMessage = completion.choices[0].message;

      // If AI wants to call a function
      if (responseMessage.tool_calls && responseMessage.tool_calls.length > 0) {
        const toolCall = responseMessage.tool_calls[0];
        const functionName = toolCall.function.name;
        const functionArgs = JSON.parse(toolCall.function.arguments);

        this.logger.log(`Admin AI calling function: \${functionName}`, functionArgs);

        // Execute the function
        const functionResult = await this.executeAdminFunction(
          functionName,
          functionArgs,
          businessId,
        );

        // Get final response from AI with function result
        const finalCompletion = await this.openai.chat.completions.create({
          model: 'gpt-4-turbo-preview',
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: message.text || 'Привет' },
            responseMessage,
            {
              role: 'tool',
              tool_call_id: toolCall.id,
              content: JSON.stringify(functionResult),
            },
          ],
        });

        return {
          text: finalCompletion.choices[0].message.content || 'Готово!',
          ui: null,
        };
      }

      // No function call, just return AI response
      return {
        text: responseMessage.content || 'Чем могу помочь?',
        ui: null,
      };
    } catch (error) {
      this.logger.error('Error in handleAdminMessage:', error);
      return {
        text: 'Извините, произошла ошибка. Попробуйте переформулировать запрос.',
        ui: null,
      };
    }
  }

  /**
   * Execute client function
   */
  private async executeClientFunction(
    functionName: string,
    args: any,
    message: NormalizedMessage,
  ): Promise<any> {
    switch (functionName) {
      case 'get_available_services':
        return this.serviceService.findByBusiness(args.businessId);

      case 'get_available_slots': {
        const service = await this.serviceService.findOne(args.serviceId);
        const slots = await this.scheduleService.generateSlots(
          args.businessId,
          parseISO(args.date),
          service.durationMinutes,
        );
        return slots;
      }

      case 'create_booking': {
        // Find or create client
        const client = await this.clientService.findOrCreate(args.businessId, {
          phone: args.clientPhone,
          firstName: args.clientName,
          telegramId: message.channel === 'telegram' ? BigInt(message.userId) : undefined,
        });

        const booking = await this.bookingService.create({
          businessId: args.businessId,
          clientId: client.id,
          serviceId: args.serviceId,
          startTime: new Date(args.startTime),
          sourceChannel: message.channel,
        });

        return booking;
      }

      case 'get_client_bookings': {
        const client = await this.clientService.findOrCreate(args.businessId, {
          phone: args.clientPhone,
        });
        return this.bookingService.findByClient(client.id);
      }

      case 'reschedule_booking':
        return this.bookingService.reschedule(args.bookingId, new Date(args.newStartTime));

      case 'cancel_booking':
        return this.bookingService.cancel(args.bookingId, args.reason);

      case 'get_service_price': {
        const service = await this.serviceService.findOne(args.serviceId);
        return { price: service.price, name: service.name };
      }

      default:
        throw new Error(`Unknown function: \${functionName}`);
    }
  }

  /**
   * Execute admin function
   */
  private async executeAdminFunction(
    functionName: string,
    args: any,
    businessId: string,
  ): Promise<any> {
    switch (functionName) {
      case 'create_service':
        return this.serviceService.create(args.businessId || businessId, args);

      case 'set_working_hours':
        return this.scheduleService.createWorkingHours(args.businessId || businessId, args);

      case 'add_break':
        return this.scheduleService.createBreak(args.businessId || businessId, args);

      case 'add_vacation':
        return this.scheduleService.createVacation(args.businessId || businessId, {
          startDate: parseISO(args.startDate),
          endDate: parseISO(args.endDate),
          type: args.type,
        });

      case 'get_bookings_today': {
        const today = new Date();
        return this.bookingService.findByBusiness(args.businessId || businessId, {
          startDate: startOfDay(today),
          endDate: endOfDay(today),
        });
      }

      case 'get_bookings_stats':
        return this.bookingService.getStats(
          args.businessId || businessId,
          parseISO(args.startDate),
          parseISO(args.endDate),
        );

      case 'search_clients':
        return this.clientService.findByBusiness(args.businessId || businessId, {
          search: args.search,
        });

      case 'add_client_note':
        await this.clientService.addNote(
          args.clientId,
          args.businessId || businessId,
          args.note,
        );
        return { success: true };

      default:
        throw new Error(`Unknown function: \${functionName}`);
    }
  }
}
