import { Processor, WorkerHost } from '@nestjs/bull';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { NotificationService } from './notification.service';

/**
 * Notification Processor
 * 
 * Обрабатывает задачи из очереди уведомлений:
 * - booking-reminder-24h: напоминание за 24 часа
 * - booking-reminder-2h: напоминание за 2 часа
 */
@Processor('notifications')
export class NotificationProcessor extends WorkerHost {
  private readonly logger = new Logger(NotificationProcessor.name);

  constructor(private notificationService: NotificationService) {
    super();
    this.logger.log('Notification Processor initialized');
  }

  /**
   * Обработка задач из очереди
   */
  async process(job: Job): Promise<any> {
    this.logger.log(`Processing job ${job.id} of type ${job.name}`);

    try {
      switch (job.name) {
        case 'booking-reminder-24h':
          return await this.handleBookingReminder24h(job);
        
        case 'booking-reminder-2h':
          return await this.handleBookingReminder2h(job);
        
        default:
          this.logger.warn(`Unknown job type: ${job.name}`);
          return { success: false, error: 'Unknown job type' };
      }
    } catch (error) {
      this.logger.error(`Failed to process job ${job.id}:`, error);
      throw error;
    }
  }

  /**
   * Обработка напоминания за 24 часа
   */
  private async handleBookingReminder24h(job: Job): Promise<any> {
    const { bookingId, reminderType } = job.data;

    this.logger.log(`Sending 24h reminder for booking ${bookingId}`);

    try {
      await this.notificationService.sendBookingReminder(bookingId, '24h');
      
      return {
        success: true,
        bookingId,
        reminderType,
        sentAt: new Date().toISOString(),
      };
    } catch (error) {
      this.logger.error(`Failed to send 24h reminder for booking ${bookingId}:`, error);
      throw error;
    }
  }

  /**
   * Обработка напоминания за 2 часа
   */
  private async handleBookingReminder2h(job: Job): Promise<any> {
    const { bookingId, reminderType } = job.data;

    this.logger.log(`Sending 2h reminder for booking ${bookingId}`);

    try {
      await this.notificationService.sendBookingReminder(bookingId, '2h');
      
      return {
        success: true,
        bookingId,
        reminderType,
        sentAt: new Date().toISOString(),
      };
    } catch (error) {
      this.logger.error(`Failed to send 2h reminder for booking ${bookingId}:`, error);
      throw error;
    }
  }
}
