import { Controller, Get, Query, HttpStatus, HttpException } from '@nestjs/common';
import { MetricsService } from './metrics.service';
import { HealthService } from './health.service';
import { AuditService, AuditAction } from './audit.service';

/**
 * Monitoring Controller
 * 
 * API endpoints для мониторинга:
 * - /metrics - Prometheus метрики
 * - /health - Health check
 * - /health/live - Liveness probe
 * - /health/ready - Readiness probe
 * - /audit/logs - Аудит логи
 * - /audit/stats - Статистика аудита
 */

@Controller()
export class MonitoringController {
  constructor(
    private metricsService: MetricsService,
    private healthService: HealthService,
    private auditService: AuditService,
  ) {}

  /**
   * GET /metrics - Prometheus метрики
   */
  @Get('metrics')
  async getMetrics() {
    const metrics = await this.metricsService.getMetrics();
    return metrics;
  }

  /**
   * GET /health - Полный health check
   */
  @Get('health')
  async getHealth() {
    const health = await this.healthService.getHealthStatus();
    
    const statusCode = health.status === 'healthy' 
      ? HttpStatus.OK 
      : health.status === 'degraded'
      ? HttpStatus.OK
      : HttpStatus.SERVICE_UNAVAILABLE;

    return {
      statusCode,
      ...health,
    };
  }

  /**
   * GET /health/live - Liveness probe (для Kubernetes)
   */
  @Get('health/live')
  async getLiveness() {
    const isAlive = await this.healthService.checkLiveness();
    
    if (!isAlive) {
      throw new HttpException('Service is not alive', HttpStatus.SERVICE_UNAVAILABLE);
    }

    return {
      status: 'alive',
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * GET /health/ready - Readiness probe (для Kubernetes)
   */
  @Get('health/ready')
  async getReadiness() {
    const isReady = await this.healthService.checkReadiness();
    
    if (!isReady) {
      throw new HttpException('Service is not ready', HttpStatus.SERVICE_UNAVAILABLE);
    }

    return {
      status: 'ready',
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * GET /audit/logs - Получить аудит логи
   */
  @Get('audit/logs')
  async getAuditLogs(
    @Query('userId') userId?: string,
    @Query('businessId') businessId?: string,
    @Query('action') action?: AuditAction,
    @Query('resourceType') resourceType?: string,
    @Query('resourceId') resourceId?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string,
  ) {
    try {
      const result = await this.auditService.getLogs({
        userId,
        businessId,
        action,
        resourceType,
        resourceId,
        startDate: startDate ? new Date(startDate) : undefined,
        endDate: endDate ? new Date(endDate) : undefined,
        limit: limit ? parseInt(limit) : undefined,
        offset: offset ? parseInt(offset) : undefined,
      });

      return {
        success: true,
        ...result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get audit logs',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /audit/stats - Получить статистику аудита
   */
  @Get('audit/stats')
  async getAuditStats(
    @Query('businessId') businessId?: string,
    @Query('startDate') startDate?: string,
    @Query('endDate') endDate?: string,
  ) {
    try {
      const stats = await this.auditService.getStats({
        businessId,
        startDate: startDate ? new Date(startDate) : undefined,
        endDate: endDate ? new Date(endDate) : undefined,
      });

      return {
        success: true,
        data: stats,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get audit stats',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /monitoring/dashboard - Получить данные для dashboard
   */
  @Get('monitoring/dashboard')
  async getDashboard() {
    try {
      const [health, metrics] = await Promise.all([
        this.healthService.getHealthStatus(),
        this.metricsService.getCurrentMetrics(),
      ]);

      return {
        success: true,
        data: {
          health,
          metrics,
          timestamp: new Date().toISOString(),
        },
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get dashboard data',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
