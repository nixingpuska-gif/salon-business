import { useState, useEffect } from 'react'
import { 
  Brain, TrendingUp, AlertTriangle, Users, 
  Calendar, DollarSign, MessageSquare, Target, Zap,
  ChevronRight, RefreshCw
} from 'lucide-react'

interface AIInsight {
  id: number
  type: 'warning' | 'opportunity' | 'success' | 'info'
  title: string
  description: string
  action: string
  impact: string
  priority: 'high' | 'medium' | 'low'
}

interface Prediction {
  metric: string
  current: number
  predicted: number
  change: number
  confidence: number
}

export default function AIInsights() {
  const [insights, setInsights] = useState<AIInsight[]>([])
  const [predictions, setPredictions] = useState<Prediction[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulated AI insights
    setInsights([
      {
        id: 1,
        type: 'warning',
        title: '32 клиента под угрозой ухода',
        description: 'Клиенты из сегмента "Под угрозой" не были 45-60 дней. Потенциальная потеря: 640,000₽',
        action: 'Запустить реактивационную кампанию',
        impact: '+640,000₽ потенциальный возврат',
        priority: 'high'
      },
      {
        id: 2,
        type: 'opportunity',
        title: 'Оптимальное время для акции',
        description: 'На следующей неделе загрузка мастеров упадёт до 45%. Идеальное время для промо-акции.',
        action: 'Создать акцию на услуги',
        impact: '+15% загрузка',
        priority: 'high'
      },
      {
        id: 3,
        type: 'success',
        title: 'Анна Петрова — топ-мастер месяца',
        description: 'Выручка +25% к прошлому месяцу, средний чек 4,500₽, 98% положительных отзывов',
        action: 'Поощрить бонусом',
        impact: 'Мотивация команды',
        priority: 'medium'
      },
      {
        id: 4,
        type: 'warning',
        title: 'Заканчивается гель-лак OPI',
        description: 'Остаток 3 шт., хватит на 2 дня. AI рекомендует заказать 20 шт.',
        action: 'Создать заказ поставщику',
        impact: 'Избежать простоя',
        priority: 'high'
      },
      {
        id: 5,
        type: 'info',
        title: 'Тренд: рост спроса на массаж',
        description: 'За последний месяц запросы на массаж выросли на 40%. Рассмотрите расширение.',
        action: 'Добавить мастера массажа',
        impact: '+120,000₽/мес потенциал',
        priority: 'medium'
      },
    ])

    setPredictions([
      { metric: 'Выручка следующей недели', current: 450000, predicted: 520000, change: 15.5, confidence: 87 },
      { metric: 'Новых клиентов', current: 12, predicted: 18, change: 50, confidence: 72 },
      { metric: 'Загрузка мастеров', current: 68, predicted: 75, change: 10.3, confidence: 91 },
      { metric: 'Средний чек', current: 3200, predicted: 3400, change: 6.25, confidence: 85 },
    ])

    setLoading(false)
  }, [])

  const getTypeStyles = (type: string) => {
    switch (type) {
      case 'warning': return 'bg-amber-50 border-amber-200 text-amber-800'
      case 'opportunity': return 'bg-blue-50 border-blue-200 text-blue-800'
      case 'success': return 'bg-green-50 border-green-200 text-green-800'
      default: return 'bg-gray-50 border-gray-200 text-gray-800'
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'warning': return <AlertTriangle className="w-5 h-5 text-amber-600" />
      case 'opportunity': return <Target className="w-5 h-5 text-blue-600" />
      case 'success': return <TrendingUp className="w-5 h-5 text-green-600" />
      default: return <Zap className="w-5 h-5 text-gray-600" />
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="w-8 h-8 animate-spin text-primary-600" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            <Brain className="w-7 h-7 text-primary-600" />
            AI-Инсайты
          </h1>
          <p className="text-gray-600 mt-1">Умные рекомендации для роста вашего бизнеса</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700">
          <RefreshCw className="w-4 h-4" />
          Обновить анализ
        </button>
      </div>

      {/* AI Predictions */}
      <div className="bg-gradient-to-r from-primary-600 to-primary-700 rounded-2xl p-6 text-white">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          AI-Прогноз на следующую неделю
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {predictions.map((pred) => (
            <div key={pred.metric} className="bg-white/10 rounded-xl p-4">
              <div className="text-white/70 text-sm">{pred.metric}</div>
              <div className="text-2xl font-bold mt-1">
                {pred.metric.includes('Выручка') || pred.metric.includes('чек') 
                  ? `${pred.predicted.toLocaleString()}₽` 
                  : pred.metric.includes('Загрузка') 
                    ? `${pred.predicted}%`
                    : pred.predicted}
              </div>
              <div className="flex items-center gap-2 mt-2">
                <span className={`text-sm ${pred.change > 0 ? 'text-green-300' : 'text-red-300'}`}>
                  {pred.change > 0 ? '+' : ''}{pred.change}%
                </span>
                <span className="text-white/50 text-xs">
                  точность {pred.confidence}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Priority Insights */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          Требуют внимания ({insights.filter(i => i.priority === 'high').length})
        </h2>
        <div className="space-y-4">
          {insights.filter(i => i.priority === 'high').map((insight) => (
            <div 
              key={insight.id} 
              className={`rounded-xl border-2 p-5 ${getTypeStyles(insight.type)}`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  {getTypeIcon(insight.type)}
                  <div>
                    <h3 className="font-semibold">{insight.title}</h3>
                    <p className="text-sm mt-1 opacity-80">{insight.description}</p>
                    <div className="flex items-center gap-4 mt-3">
                      <span className="text-xs font-medium bg-white/50 px-2 py-1 rounded">
                        {insight.impact}
                      </span>
                    </div>
                  </div>
                </div>
                <button className="flex items-center gap-1 px-4 py-2 bg-white rounded-lg text-sm font-medium hover:bg-gray-50 transition-colors">
                  {insight.action}
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Other Insights */}
      <div>
        <h2 className="text-lg font-semibold text-gray-900 mb-4">
          Другие рекомендации
        </h2>
        <div className="grid md:grid-cols-2 gap-4">
          {insights.filter(i => i.priority !== 'high').map((insight) => (
            <div 
              key={insight.id} 
              className={`rounded-xl border p-4 ${getTypeStyles(insight.type)}`}
            >
              <div className="flex items-start gap-3">
                {getTypeIcon(insight.type)}
                <div className="flex-1">
                  <h3 className="font-semibold text-sm">{insight.title}</h3>
                  <p className="text-xs mt-1 opacity-80">{insight.description}</p>
                  <button className="mt-3 text-xs font-medium flex items-center gap-1 hover:underline">
                    {insight.action}
                    <ChevronRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <Users className="w-4 h-4" />
            Клиентов в риске
          </div>
          <div className="text-2xl font-bold text-amber-600 mt-1">32</div>
        </div>
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <Calendar className="w-4 h-4" />
            Свободных слотов
          </div>
          <div className="text-2xl font-bold text-blue-600 mt-1">18</div>
        </div>
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <DollarSign className="w-4 h-4" />
            Упущенная выручка
          </div>
          <div className="text-2xl font-bold text-red-600 mt-1">85,000₽</div>
        </div>
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center gap-2 text-gray-600 text-sm">
            <MessageSquare className="w-4 h-4" />
            Без ответа
          </div>
          <div className="text-2xl font-bold text-orange-600 mt-1">5</div>
        </div>
      </div>
    </div>
  )
}
