import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  Query,
  HttpStatus,
  HttpException,
  Headers,
  RawBodyRequest,
  Req,
} from '@nestjs/common';
import { PaymentService, PaymentStatus } from './payment.service';
import { SubscriptionService } from '../subscription/subscription.service';
import { SubscriptionTier } from '../feature-flags/feature-flags.service';

/**
 * Payment Controller
 * 
 * API endpoints для работы с платежами
 */
@Controller('payment')
export class PaymentController {
  constructor(
    private paymentService: PaymentService,
    private subscriptionService: SubscriptionService,
  ) {}

  /**
   * POST /payment/create - Создать платёж
   */
  @Post('create')
  async createPayment(
    @Body()
    body: {
      businessId: string;
      tier: SubscriptionTier;
      durationMonths?: number;
      returnUrl?: string;
    },
  ) {
    try {
      const durationMonths = body.durationMonths || 1;

      // Получить цену тарифа
      const plan = await this.getSubscriptionPlan(body.tier);
      const amount = plan.price * durationMonths;

      if (amount === 0) {
        throw new Error('Cannot create payment for free plan');
      }

      // Создать платёж
      const payment = await this.paymentService.createPayment({
        amount,
        description: `Подписка ${plan.name} на ${durationMonths} мес.`,
        businessId: body.businessId,
        metadata: {
          tier: body.tier,
          durationMonths,
        },
        returnUrl: body.returnUrl,
      });

      return {
        success: true,
        data: payment,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to create payment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /payment/:paymentId - Получить информацию о платеже
   */
  @Get(':paymentId')
  async getPayment(@Param('paymentId') paymentId: string) {
    try {
      const payment = await this.paymentService.getPayment(paymentId);

      return {
        success: true,
        data: payment,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get payment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * DELETE /payment/:paymentId/cancel - Отменить платёж
   */
  @Delete(':paymentId/cancel')
  async cancelPayment(@Param('paymentId') paymentId: string) {
    try {
      await this.paymentService.cancelPayment(paymentId);

      return {
        success: true,
        message: 'Payment cancelled successfully',
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to cancel payment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /payment/:paymentId/refund - Создать возврат
   */
  @Post(':paymentId/refund')
  async createRefund(
    @Param('paymentId') paymentId: string,
    @Body() body: { amount?: number },
  ) {
    try {
      const refund = await this.paymentService.createRefund(
        paymentId,
        body.amount,
      );

      return {
        success: true,
        data: refund,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to create refund',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /payment/history/:businessId - Получить историю платежей
   */
  @Get('history/:businessId')
  async getPaymentHistory(
    @Param('businessId') businessId: string,
    @Query('limit') limit?: string,
    @Query('offset') offset?: string,
    @Query('status') status?: PaymentStatus,
  ) {
    try {
      const history = await this.paymentService.getPaymentHistory(businessId, {
        limit: limit ? parseInt(limit) : undefined,
        offset: offset ? parseInt(offset) : undefined,
        status,
      });

      return {
        success: true,
        ...history,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get payment history',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /payment/stats/:businessId - Получить статистику платежей
   */
  @Get('stats/:businessId')
  async getPaymentStats(@Param('businessId') businessId: string) {
    try {
      const stats = await this.paymentService.getPaymentStats(businessId);

      return {
        success: true,
        data: stats,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get payment stats',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /payment/webhook - Webhook от YooKassa
   */
  @Post('webhook')
  async handleWebhook(@Req() req: RawBodyRequest<Request>, @Body() body: any) {
    try {
      // Обработать webhook
      await this.paymentService.handleWebhook(body);

      // Если платёж успешен, активировать подписку
      if (body.type === 'payment.succeeded') {
        await this.activateSubscriptionAfterPayment(body.object);
      }

      return { success: true };
    } catch (error) {
      console.error('Webhook error:', error);
      throw new HttpException(
        'Webhook processing failed',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * Активировать подписку после успешного платежа
   */
  private async activateSubscriptionAfterPayment(payment: any): Promise<void> {
    try {
      const { businessId, tier, durationMonths } = payment.metadata;

      if (!businessId || !tier) {
        throw new Error('Missing metadata in payment');
      }

      // Создать или обновить подписку
      const currentSubscription = await this.subscriptionService.getCurrentSubscription(
        businessId,
      );

      if (currentSubscription) {
        // Если есть активная подписка, обновить
        await this.subscriptionService.updateSubscription(
          businessId,
          tier as SubscriptionTier,
          durationMonths || 1,
        );
      } else {
        // Создать новую подписку
        await this.subscriptionService.createSubscription(
          businessId,
          tier as SubscriptionTier,
          durationMonths || 1,
          false,
        );
      }

      console.log(
        `Subscription activated for business ${businessId}: ${tier} for ${durationMonths} months`,
      );
    } catch (error) {
      console.error('Failed to activate subscription:', error);
      throw error;
    }
  }

  /**
   * Получить информацию о тарифном плане
   */
  private async getSubscriptionPlan(
    tier: SubscriptionTier,
  ): Promise<{ name: string; price: number }> {
    // Импортируем FeatureFlagsService через DI
    const plans = {
      [SubscriptionTier.FREE]: { name: 'Бесплатный', price: 0 },
      [SubscriptionTier.BASIC]: { name: 'Базовый', price: 990 },
      [SubscriptionTier.PRO]: { name: 'Профессиональный', price: 2990 },
      [SubscriptionTier.ENTERPRISE]: { name: 'Корпоративный', price: 9990 },
    };

    return plans[tier];
  }
}
