import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';
import { PrismaService } from '../prisma/prisma.service';

/**
 * SMM Service
 * 
 * Автоматический постинг в социальные сети:
 * - Instagram (через Meta Graph API)
 * - Facebook (через Meta Graph API)
 * - Планирование постов
 * - Публикация изображений и видео
 * - Аналитика постов
 */
@Injectable()
export class SMMService {
  private readonly logger = new Logger(SMMService.name);
  private readonly graphApiUrl = 'https://graph.facebook.com/v21.0';

  constructor(
    private configService: ConfigService,
    private prisma: PrismaService,
  ) {
    this.logger.log('SMM Service initialized');
  }

  /**
   * Опубликовать пост в Instagram
   */
  async postToInstagram(params: {
    imageUrl: string;
    caption: string;
    accessToken?: string;
    instagramAccountId?: string;
  }): Promise<any> {
    const accessToken =
      params.accessToken ||
      this.configService.get<string>('INSTAGRAM_ACCESS_TOKEN');
    const accountId =
      params.instagramAccountId ||
      this.configService.get<string>('INSTAGRAM_ACCOUNT_ID');

    if (!accessToken || !accountId) {
      throw new Error('Instagram credentials not configured');
    }

    try {
      this.logger.log('Creating Instagram media container...');

      // Шаг 1: Создать media container
      const containerResponse = await axios.post(
        `${this.graphApiUrl}/${accountId}/media`,
        {
          image_url: params.imageUrl,
          caption: params.caption,
          access_token: accessToken,
        },
      );

      const containerId = containerResponse.data.id;
      this.logger.log(`Media container created: ${containerId}`);

      // Шаг 2: Опубликовать media container
      const publishResponse = await axios.post(
        `${this.graphApiUrl}/${accountId}/media_publish`,
        {
          creation_id: containerId,
          access_token: accessToken,
        },
      );

      const postId = publishResponse.data.id;
      this.logger.log(`Instagram post published: ${postId}`);

      return {
        success: true,
        postId,
        platform: 'instagram',
        url: `https://www.instagram.com/p/${postId}`,
      };
    } catch (error) {
      this.logger.error('Failed to post to Instagram:', error.response?.data || error);
      throw error;
    }
  }

  /**
   * Опубликовать пост в Facebook
   */
  async postToFacebook(params: {
    message: string;
    imageUrl?: string;
    accessToken?: string;
    pageId?: string;
  }): Promise<any> {
    const accessToken =
      params.accessToken ||
      this.configService.get<string>('FACEBOOK_PAGE_ACCESS_TOKEN');
    const pageId =
      params.pageId || this.configService.get<string>('FACEBOOK_PAGE_ID');

    if (!accessToken || !pageId) {
      throw new Error('Facebook credentials not configured');
    }

    try {
      this.logger.log('Publishing Facebook post...');

      const postData: any = {
        message: params.message,
        access_token: accessToken,
      };

      if (params.imageUrl) {
        postData.url = params.imageUrl;
      }

      const endpoint = params.imageUrl
        ? `${this.graphApiUrl}/${pageId}/photos`
        : `${this.graphApiUrl}/${pageId}/feed`;

      const response = await axios.post(endpoint, postData);

      const postId = response.data.id || response.data.post_id;
      this.logger.log(`Facebook post published: ${postId}`);

      return {
        success: true,
        postId,
        platform: 'facebook',
        url: `https://www.facebook.com/${postId}`,
      };
    } catch (error) {
      this.logger.error('Failed to post to Facebook:', error.response?.data || error);
      throw error;
    }
  }

  /**
   * Опубликовать в обе платформы одновременно
   */
  async postToBoth(params: {
    imageUrl: string;
    caption: string;
    message: string;
  }): Promise<{
    instagram: any;
    facebook: any;
  }> {
    try {
      const [instagram, facebook] = await Promise.allSettled([
        this.postToInstagram({
          imageUrl: params.imageUrl,
          caption: params.caption,
        }),
        this.postToFacebook({
          message: params.message,
          imageUrl: params.imageUrl,
        }),
      ]);

      return {
        instagram:
          instagram.status === 'fulfilled'
            ? instagram.value
            : { success: false, error: instagram.reason },
        facebook:
          facebook.status === 'fulfilled'
            ? facebook.value
            : { success: false, error: facebook.reason },
      };
    } catch (error) {
      this.logger.error('Failed to post to both platforms:', error);
      throw error;
    }
  }

  /**
   * Получить статистику поста в Instagram
   */
  async getInstagramPostInsights(
    postId: string,
    accessToken?: string,
  ): Promise<any> {
    const token =
      accessToken ||
      this.configService.get<string>('INSTAGRAM_ACCESS_TOKEN');

    if (!token) {
      throw new Error('Instagram access token not configured');
    }

    try {
      const response = await axios.get(
        `${this.graphApiUrl}/${postId}/insights`,
        {
          params: {
            metric: 'impressions,reach,engagement,saved,likes,comments,shares',
            access_token: token,
          },
        },
      );

      return response.data.data;
    } catch (error) {
      this.logger.error('Failed to get Instagram insights:', error.response?.data || error);
      throw error;
    }
  }

  /**
   * Получить статистику поста в Facebook
   */
  async getFacebookPostInsights(
    postId: string,
    accessToken?: string,
  ): Promise<any> {
    const token =
      accessToken ||
      this.configService.get<string>('FACEBOOK_PAGE_ACCESS_TOKEN');

    if (!token) {
      throw new Error('Facebook access token not configured');
    }

    try {
      const response = await axios.get(`${this.graphApiUrl}/${postId}`, {
        params: {
          fields:
            'likes.summary(true),comments.summary(true),shares,reactions.summary(true)',
          access_token: token,
        },
      });

      return {
        likes: response.data.likes?.summary?.total_count || 0,
        comments: response.data.comments?.summary?.total_count || 0,
        shares: response.data.shares?.count || 0,
        reactions: response.data.reactions?.summary?.total_count || 0,
      };
    } catch (error) {
      this.logger.error('Failed to get Facebook insights:', error.response?.data || error);
      throw error;
    }
  }

  /**
   * Сохранить запись о посте в БД
   */
  async savePost(data: {
    businessId: string;
    platform: 'instagram' | 'facebook' | 'both';
    postId: string;
    content: string;
    imageUrl?: string;
    scheduledAt?: Date;
  }): Promise<any> {
    try {
      const post = await this.prisma.socialMediaPost.create({
        data: {
          businessId: data.businessId,
          platform: data.platform,
          postId: data.postId,
          content: data.content,
          imageUrl: data.imageUrl,
          status: 'published',
          publishedAt: new Date(),
          scheduledAt: data.scheduledAt,
        },
      });

      this.logger.log(`Post saved to database: ${post.id}`);
      return post;
    } catch (error) {
      this.logger.error('Failed to save post to database:', error);
      throw error;
    }
  }

  /**
   * Получить историю постов
   */
  async getPostHistory(
    businessId: string,
    params?: {
      platform?: 'instagram' | 'facebook' | 'both';
      limit?: number;
      offset?: number;
    },
  ): Promise<any[]> {
    try {
      const where: any = { businessId };

      if (params?.platform) {
        where.platform = params.platform;
      }

      const posts = await this.prisma.socialMediaPost.findMany({
        where,
        orderBy: { publishedAt: 'desc' },
        take: params?.limit || 50,
        skip: params?.offset || 0,
      });

      return posts;
    } catch (error) {
      this.logger.error('Failed to get post history:', error);
      throw error;
    }
  }

  /**
   * Удалить пост из Instagram
   */
  async deleteInstagramPost(
    postId: string,
    accessToken?: string,
  ): Promise<boolean> {
    const token =
      accessToken ||
      this.configService.get<string>('INSTAGRAM_ACCESS_TOKEN');

    if (!token) {
      throw new Error('Instagram access token not configured');
    }

    try {
      await axios.delete(`${this.graphApiUrl}/${postId}`, {
        params: { access_token: token },
      });

      this.logger.log(`Instagram post deleted: ${postId}`);
      return true;
    } catch (error) {
      this.logger.error('Failed to delete Instagram post:', error.response?.data || error);
      throw error;
    }
  }

  /**
   * Удалить пост из Facebook
   */
  async deleteFacebookPost(
    postId: string,
    accessToken?: string,
  ): Promise<boolean> {
    const token =
      accessToken ||
      this.configService.get<string>('FACEBOOK_PAGE_ACCESS_TOKEN');

    if (!token) {
      throw new Error('Facebook access token not configured');
    }

    try {
      await axios.delete(`${this.graphApiUrl}/${postId}`, {
        params: { access_token: token },
      });

      this.logger.log(`Facebook post deleted: ${postId}`);
      return true;
    } catch (error) {
      this.logger.error('Failed to delete Facebook post:', error.response?.data || error);
      throw error;
    }
  }
}
