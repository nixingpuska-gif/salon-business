#!/bin/bash
cd /home/ubuntu/ai-booking-platform/backend

# Remove all auto-generated service files to replace with full implementations
rm -f src/business/business.service.ts
rm -f src/client/client.service.ts
rm -f src/service/service.service.ts
rm -f src/schedule/schedule.service.ts
rm -f src/booking/booking.service.ts

echo "Removed auto-generated service files. Ready for manual implementation."
