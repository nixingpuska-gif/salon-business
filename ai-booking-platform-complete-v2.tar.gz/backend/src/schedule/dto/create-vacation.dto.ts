import { IsString, IsNotEmpty, IsDateString, IsOptional, IsIn } from 'class-validator';

export class CreateVacationDto {
  @IsString()
  @IsNotEmpty()
  businessId: string;

  @IsDateString()
  @IsNotEmpty()
  startDate: string;

  @IsDateString()
  @IsNotEmpty()
  endDate: string;

  @IsString()
  @IsOptional()
  @IsIn(['vacation', 'holiday'])
  type?: 'vacation' | 'holiday';
}
