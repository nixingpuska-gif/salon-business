import { Injectable, LoggerService as NestLoggerService } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as winston from 'winston';
import * as path from 'path';

/**
 * Logger Service
 * 
 * Структурированное логирование с Winston:
 * - Разные уровни логов (error, warn, info, debug)
 * - Запись в файлы и консоль
 * - JSON формат для парсинга
 * - Ротация логов
 * - Контекст для трейсинга
 */

@Injectable()
export class LoggerService implements NestLoggerService {
  private logger: winston.Logger;
  private context?: string;

  constructor(private configService: ConfigService) {
    const logDir = this.configService.get<string>('LOG_DIR') || './logs';
    const logLevel = this.configService.get<string>('LOG_LEVEL') || 'info';
    const nodeEnv = this.configService.get<string>('NODE_ENV') || 'development';

    // Формат для консоли (development)
    const consoleFormat = winston.format.combine(
      winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
      winston.format.colorize(),
      winston.format.printf(({ timestamp, level, message, context, ...meta }) => {
        const contextStr = context ? `[${context}]` : '';
        const metaStr = Object.keys(meta).length ? JSON.stringify(meta) : '';
        return `${timestamp} ${level} ${contextStr} ${message} ${metaStr}`;
      }),
    );

    // Формат для файлов (production)
    const fileFormat = winston.format.combine(
      winston.format.timestamp(),
      winston.format.errors({ stack: true }),
      winston.format.json(),
    );

    // Транспорты
    const transports: winston.transport[] = [];

    // Консоль (всегда)
    transports.push(
      new winston.transports.Console({
        format: nodeEnv === 'production' ? fileFormat : consoleFormat,
      }),
    );

    // Файлы (production)
    if (nodeEnv === 'production') {
      // Все логи
      transports.push(
        new winston.transports.File({
          filename: path.join(logDir, 'combined.log'),
          format: fileFormat,
          maxsize: 10 * 1024 * 1024, // 10MB
          maxFiles: 10,
        }),
      );

      // Только ошибки
      transports.push(
        new winston.transports.File({
          filename: path.join(logDir, 'error.log'),
          level: 'error',
          format: fileFormat,
          maxsize: 10 * 1024 * 1024, // 10MB
          maxFiles: 10,
        }),
      );
    }

    this.logger = winston.createLogger({
      level: logLevel,
      transports,
      exitOnError: false,
    });
  }

  /**
   * Установить контекст для логов
   */
  setContext(context: string) {
    this.context = context;
  }

  /**
   * Log level: info
   */
  log(message: string, context?: string, meta?: Record<string, any>) {
    this.logger.info(message, {
      context: context || this.context,
      ...meta,
    });
  }

  /**
   * Log level: error
   */
  error(message: string, trace?: string, context?: string, meta?: Record<string, any>) {
    this.logger.error(message, {
      context: context || this.context,
      trace,
      ...meta,
    });
  }

  /**
   * Log level: warn
   */
  warn(message: string, context?: string, meta?: Record<string, any>) {
    this.logger.warn(message, {
      context: context || this.context,
      ...meta,
    });
  }

  /**
   * Log level: debug
   */
  debug(message: string, context?: string, meta?: Record<string, any>) {
    this.logger.debug(message, {
      context: context || this.context,
      ...meta,
    });
  }

  /**
   * Log level: verbose
   */
  verbose(message: string, context?: string, meta?: Record<string, any>) {
    this.logger.verbose(message, {
      context: context || this.context,
      ...meta,
    });
  }

  /**
   * Логирование HTTP запросов
   */
  logRequest(req: any, res: any, responseTime: number) {
    const { method, originalUrl, ip, headers } = req;
    const { statusCode } = res;

    this.logger.info('HTTP Request', {
      context: 'HTTP',
      method,
      url: originalUrl,
      statusCode,
      responseTime: `${responseTime}ms`,
      ip,
      userAgent: headers['user-agent'],
    });
  }

  /**
   * Логирование ошибок с полным стеком
   */
  logError(error: Error, context?: string, meta?: Record<string, any>) {
    this.logger.error(error.message, {
      context: context || this.context || 'Error',
      stack: error.stack,
      name: error.name,
      ...meta,
    });
  }

  /**
   * Логирование бизнес-событий
   */
  logEvent(event: string, data: Record<string, any>, context?: string) {
    this.logger.info(`Event: ${event}`, {
      context: context || this.context || 'Event',
      event,
      ...data,
    });
  }

  /**
   * Логирование метрик
   */
  logMetric(metric: string, value: number, unit?: string, meta?: Record<string, any>) {
    this.logger.info(`Metric: ${metric}`, {
      context: 'Metric',
      metric,
      value,
      unit,
      ...meta,
    });
  }

  /**
   * Логирование аудита (критические операции)
   */
  logAudit(action: string, userId: string, data: Record<string, any>) {
    this.logger.info(`Audit: ${action}`, {
      context: 'Audit',
      action,
      userId,
      timestamp: new Date().toISOString(),
      ...data,
    });
  }
}
