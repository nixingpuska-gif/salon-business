import { Controller, Get, Post, Delete, Param, HttpStatus, HttpException } from '@nestjs/common';
import { NotificationService } from './notification.service';

/**
 * Notification Controller
 * 
 * API endpoints для управления уведомлениями:
 * - Получение статистики очереди
 * - Просмотр запланированных напоминаний
 * - Ручное планирование/отмена напоминаний
 */
@Controller('notifications')
export class NotificationController {
  constructor(private notificationService: NotificationService) {}

  /**
   * GET /notifications/stats - Статистика очереди
   */
  @Get('stats')
  async getQueueStats() {
    try {
      const stats = await this.notificationService.getQueueStats();
      return {
        success: true,
        data: stats,
      };
    } catch (error) {
      throw new HttpException(
        'Failed to get queue stats',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /notifications/scheduled - Список запланированных напоминаний
   */
  @Get('scheduled')
  async getScheduledReminders() {
    try {
      const reminders = await this.notificationService.getScheduledReminders();
      return {
        success: true,
        count: reminders.length,
        data: reminders,
      };
    } catch (error) {
      throw new HttpException(
        'Failed to get scheduled reminders',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /notifications/booking/:id/schedule - Запланировать напоминания для записи
   */
  @Post('booking/:id/schedule')
  async scheduleReminders(@Param('id') bookingId: string) {
    try {
      await this.notificationService.scheduleBookingReminders(parseInt(bookingId));
      return {
        success: true,
        message: `Reminders scheduled for booking ${bookingId}`,
      };
    } catch (error) {
      throw new HttpException(
        'Failed to schedule reminders',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * DELETE /notifications/booking/:id/cancel - Отменить напоминания для записи
   */
  @Delete('booking/:id/cancel')
  async cancelReminders(@Param('id') bookingId: string) {
    try {
      await this.notificationService.cancelBookingReminders(parseInt(bookingId));
      return {
        success: true,
        message: `Reminders cancelled for booking ${bookingId}`,
      };
    } catch (error) {
      throw new HttpException(
        'Failed to cancel reminders',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /notifications/booking/:id/reschedule - Перепланировать напоминания
   */
  @Post('booking/:id/reschedule')
  async rescheduleReminders(@Param('id') bookingId: string) {
    try {
      await this.notificationService.rescheduleBookingReminders(parseInt(bookingId));
      return {
        success: true,
        message: `Reminders rescheduled for booking ${bookingId}`,
      };
    } catch (error) {
      throw new HttpException(
        'Failed to reschedule reminders',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
