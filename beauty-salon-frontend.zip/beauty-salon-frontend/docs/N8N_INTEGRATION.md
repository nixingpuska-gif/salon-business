# n8n Integration Guide

Complete guide for integrating the Beauty Salon Suite frontend with n8n workflow automation.

## 📋 Table of Contents
1. [Setup](#setup)
2. [Webhook Configuration](#webhook-configuration)
3. [Workflow Examples](#workflow-examples)
4. [Event Types](#event-types)
5. [Error Handling](#error-handling)
6. [Best Practices](#best-practices)

## Setup

### 1. Install n8n
```bash
npm install -g n8n
n8n start
```

n8n will be available at `http://localhost:5678`

### 2. Configure Frontend
Update `.env` file:
```env
VITE_N8N_URL=http://localhost:5678
VITE_N8N_WEBHOOK_URL=http://localhost:5678/webhook/beauty-salon
```

### 3. Create Webhook in n8n
1. Open n8n dashboard
2. Create new workflow
3. Add "Webhook" trigger node
4. Set method to POST
5. Copy webhook URL
6. Update `VITE_N8N_WEBHOOK_URL` with the URL

## Webhook Configuration

### Webhook Structure
```javascript
POST http://localhost:5678/webhook/beauty-salon

Headers:
{
  "Content-Type": "application/json",
  "Authorization": "Bearer YOUR_TOKEN"
}

Body:
{
  "event": "appointment.created",
  "timestamp": "2024-01-03T12:00:00Z",
  "data": {
    // Event-specific data
  }
}
```

### Sending Events from Frontend
```typescript
// src/utils/n8n.ts
import { apiClient } from './api'

export const sendN8nEvent = async (
  event: string,
  data: any
) => {
  try {
    await fetch(import.meta.env.VITE_N8N_WEBHOOK_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        event,
        timestamp: new Date().toISOString(),
        data,
      }),
    })
  } catch (error) {
    console.error('Failed to send n8n event:', error)
  }
}
```

## Workflow Examples

### Example 1: Appointment Created Workflow

**Trigger**: Webhook (appointment.created)

**Nodes**:
1. **Webhook** - Receive appointment data
2. **Split** - Extract appointment details
3. **Email** - Send confirmation to client
4. **Email** - Send notification to staff
5. **Calendar** - Add to Google Calendar
6. **Database** - Log event to database

**Configuration**:
```json
{
  "event": "appointment.created",
  "data": {
    "appointmentId": "apt_123",
    "clientId": "cli_456",
    "clientEmail": "client@example.com",
    "serviceId": "srv_789",
    "staffId": "stf_012",
    "startTime": "2024-01-10T14:00:00Z",
    "endTime": "2024-01-10T15:00:00Z"
  }
}
```

### Example 2: Service Updated Workflow

**Trigger**: Webhook (service.updated)

**Nodes**:
1. **Webhook** - Receive service update
2. **Conditional** - Check if price changed
3. **Email** - Notify clients of price change
4. **Slack** - Post update to staff channel
5. **Database** - Update service cache

**Configuration**:
```json
{
  "event": "service.updated",
  "data": {
    "serviceId": "srv_123",
    "name": "Haircut",
    "price": 45.00,
    "duration": 30,
    "changes": ["price"]
  }
}
```

### Example 3: Staff Member Added Workflow

**Trigger**: Webhook (staff.created)

**Nodes**:
1. **Webhook** - Receive staff data
2. **Email** - Send welcome email
3. **Slack** - Announce new staff member
4. **Database** - Create staff profile
5. **Calendar** - Create calendar account

**Configuration**:
```json
{
  "event": "staff.created",
  "data": {
    "staffId": "stf_123",
    "name": "John Doe",
    "email": "john@salon.com",
    "phone": "+1234567890",
    "role": "stylist"
  }
}
```

## Event Types

### Appointment Events

#### appointment.created
Triggered when a new appointment is created.

**Data**:
```typescript
{
  appointmentId: string
  clientId: string
  clientEmail: string
  clientPhone: string
  serviceId: string
  staffId: string
  startTime: ISO8601
  endTime: ISO8601
  notes?: string
  status: 'scheduled' | 'confirmed' | 'cancelled'
}
```

#### appointment.updated
Triggered when appointment is modified.

**Data**:
```typescript
{
  appointmentId: string
  changes: string[] // ['startTime', 'staffId', etc.]
  oldData: object
  newData: object
}
```

#### appointment.cancelled
Triggered when appointment is cancelled.

**Data**:
```typescript
{
  appointmentId: string
  clientId: string
  clientEmail: string
  reason?: string
  refundAmount?: number
}
```

### Service Events

#### service.created
Triggered when a new service is created.

**Data**:
```typescript
{
  serviceId: string
  name: string
  description: string
  price: number
  duration: number // in minutes
  category: string
}
```

#### service.updated
Triggered when service is modified.

**Data**:
```typescript
{
  serviceId: string
  changes: string[] // ['price', 'duration', etc.]
  oldData: object
  newData: object
}
```

#### service.deleted
Triggered when service is deleted.

**Data**:
```typescript
{
  serviceId: string
  name: string
  affectedAppointments: number
}
```

### Staff Events

#### staff.created
Triggered when new staff member is added.

**Data**:
```typescript
{
  staffId: string
  name: string
  email: string
  phone: string
  role: 'stylist' | 'manager' | 'admin'
  startDate: ISO8601
}
```

#### staff.updated
Triggered when staff member is modified.

**Data**:
```typescript
{
  staffId: string
  changes: string[] // ['email', 'phone', etc.]
  oldData: object
  newData: object
}
```

#### staff.deleted
Triggered when staff member is removed.

**Data**:
```typescript
{
  staffId: string
  name: string
  reassignedAppointments: number
}
```

## Error Handling

### Retry Logic
```typescript
// n8n Workflow Configuration
{
  "retryConfig": {
    "maxRetries": 3,
    "retryDelay": 5000, // 5 seconds
    "exponentialBackoff": true
  }
}
```

### Error Notification
```typescript
// In n8n workflow, add error handler:
{
  "onError": {
    "sendEmail": true,
    "emailTo": "admin@salon.com",
    "subject": "n8n Workflow Error",
    "includeErrorDetails": true
  }
}
```

### Frontend Error Handling
```typescript
// src/utils/n8n.ts
export const sendN8nEvent = async (
  event: string,
  data: any
) => {
  try {
    const response = await fetch(
      import.meta.env.VITE_N8N_WEBHOOK_URL,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event,
          timestamp: new Date().toISOString(),
          data,
        }),
      }
    )

    if (!response.ok) {
      throw new Error(`n8n webhook failed: ${response.statusText}`)
    }

    return await response.json()
  } catch (error) {
    console.error('n8n event failed:', error)
    // Optionally queue event for retry
    queueEventForRetry(event, data)
  }
}
```

## Best Practices

### 1. Event Naming
- Use lowercase with dots: `appointment.created`
- Be specific: `appointment.cancelled` not `appointment.deleted`
- Include entity and action: `{entity}.{action}`

### 2. Data Structure
- Include unique IDs for all entities
- Use ISO8601 for timestamps
- Include all relevant context
- Keep payload under 1MB

### 3. Webhook Security
- Use authentication tokens
- Validate webhook signatures
- Implement rate limiting
- Use HTTPS in production

### 4. Error Handling
- Implement retry logic with exponential backoff
- Log all webhook calls
- Set up error notifications
- Monitor webhook health

### 5. Performance
- Use async/await for non-blocking calls
- Batch events when possible
- Implement caching for frequently accessed data
- Monitor n8n performance

### 6. Testing
```bash
# Test webhook with curl
curl -X POST http://localhost:5678/webhook/beauty-salon \
  -H "Content-Type: application/json" \
  -d '{
    "event": "appointment.created",
    "timestamp": "2024-01-03T12:00:00Z",
    "data": {
      "appointmentId": "test_123",
      "clientEmail": "test@example.com"
    }
  }'
```

## Monitoring

### n8n Logs
```bash
# View n8n logs
tail -f ~/.n8n/logs/n8n.log
```

### Frontend Event Logging
```typescript
// src/utils/n8n.ts
const logEvent = (event: string, status: 'success' | 'error', data: any) => {
  console.log(`[n8n] ${event} - ${status}`, data)
  // Send to analytics/logging service
}
```

### Metrics to Track
- Webhook response time
- Success/failure rate
- Event queue depth
- Retry attempts
- Error types

## Troubleshooting

### Webhook Not Triggering
1. Check webhook URL is correct
2. Verify n8n is running
3. Check firewall/network settings
4. Review n8n logs

### Events Not Processing
1. Check n8n workflow is active
2. Verify data structure matches expectations
3. Check for errors in n8n workflow
4. Review webhook logs

### Performance Issues
1. Optimize n8n workflow nodes
2. Implement caching
3. Use async processing
4. Monitor resource usage

## Resources

- [n8n Documentation](https://docs.n8n.io/)
- [Webhook Best Practices](https://docs.n8n.io/integrations/webhooks/)
- [Error Handling Guide](https://docs.n8n.io/workflows/error-handling/)
- [Performance Optimization](https://docs.n8n.io/workflows/performance/)

---

**Last Updated**: January 3, 2024  
**Version**: 1.0.0
