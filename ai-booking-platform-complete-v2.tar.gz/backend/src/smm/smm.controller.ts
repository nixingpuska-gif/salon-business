import {
  Controller,
  Post,
  Get,
  Delete,
  Body,
  Param,
  Query,
  HttpStatus,
  HttpException,
} from '@nestjs/common';
import { SMMService } from './smm.service';
import { ContentGeneratorService } from './content-generator.service';

/**
 * SMM Controller
 * 
 * API endpoints для SMM функций:
 * - Публикация постов в Instagram/Facebook
 * - Генерация контента
 * - Статистика постов
 * - История публикаций
 */
@Controller('smm')
export class SMMController {
  constructor(
    private smmService: SMMService,
    private contentGenerator: ContentGeneratorService,
  ) {}

  /**
   * POST /smm/post/instagram - Опубликовать в Instagram
   */
  @Post('post/instagram')
  async postToInstagram(
    @Body()
    body: {
      imageUrl: string;
      caption: string;
      businessId?: string;
    },
  ) {
    try {
      const result = await this.smmService.postToInstagram({
        imageUrl: body.imageUrl,
        caption: body.caption,
      });

      // Сохранить в БД
      if (body.businessId) {
        await this.smmService.savePost({
          businessId: body.businessId,
          platform: 'instagram',
          postId: result.postId,
          content: body.caption,
          imageUrl: body.imageUrl,
        });
      }

      return {
        success: true,
        data: result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to post to Instagram',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /smm/post/facebook - Опубликовать в Facebook
   */
  @Post('post/facebook')
  async postToFacebook(
    @Body()
    body: {
      message: string;
      imageUrl?: string;
      businessId?: string;
    },
  ) {
    try {
      const result = await this.smmService.postToFacebook({
        message: body.message,
        imageUrl: body.imageUrl,
      });

      // Сохранить в БД
      if (body.businessId) {
        await this.smmService.savePost({
          businessId: body.businessId,
          platform: 'facebook',
          postId: result.postId,
          content: body.message,
          imageUrl: body.imageUrl,
        });
      }

      return {
        success: true,
        data: result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to post to Facebook',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /smm/post/both - Опубликовать в обе платформы
   */
  @Post('post/both')
  async postToBoth(
    @Body()
    body: {
      imageUrl: string;
      caption: string;
      message: string;
      businessId?: string;
    },
  ) {
    try {
      const result = await this.smmService.postToBoth({
        imageUrl: body.imageUrl,
        caption: body.caption,
        message: body.message,
      });

      // Сохранить в БД
      if (body.businessId) {
        if (result.instagram.success) {
          await this.smmService.savePost({
            businessId: body.businessId,
            platform: 'instagram',
            postId: result.instagram.postId,
            content: body.caption,
            imageUrl: body.imageUrl,
          });
        }

        if (result.facebook.success) {
          await this.smmService.savePost({
            businessId: body.businessId,
            platform: 'facebook',
            postId: result.facebook.postId,
            content: body.message,
            imageUrl: body.imageUrl,
          });
        }
      }

      return {
        success: true,
        data: result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to post to both platforms',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /smm/generate/instagram - Сгенерировать пост для Instagram
   */
  @Post('generate/instagram')
  async generateInstagramPost(
    @Body()
    body: {
      businessName: string;
      serviceName: string;
      description?: string;
      tone?: 'professional' | 'friendly' | 'casual' | 'luxury';
    },
  ) {
    try {
      const result = await this.contentGenerator.generateInstagramPost(body);

      return {
        success: true,
        data: result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to generate Instagram post',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /smm/generate/facebook - Сгенерировать пост для Facebook
   */
  @Post('generate/facebook')
  async generateFacebookPost(
    @Body()
    body: {
      businessName: string;
      serviceName: string;
      description?: string;
      tone?: 'professional' | 'friendly' | 'casual' | 'luxury';
    },
  ) {
    try {
      const result = await this.contentGenerator.generateFacebookPost(body);

      return {
        success: true,
        text: result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to generate Facebook post',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /smm/generate/both - Сгенерировать для обеих платформ
   */
  @Post('generate/both')
  async generateForBoth(
    @Body()
    body: {
      businessName: string;
      serviceName: string;
      description?: string;
      tone?: 'professional' | 'friendly' | 'casual' | 'luxury';
    },
  ) {
    try {
      const result = await this.contentGenerator.generateForBothPlatforms(body);

      return {
        success: true,
        data: result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to generate content',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /smm/generate/hashtags - Сгенерировать хэштеги
   */
  @Post('generate/hashtags')
  async generateHashtags(
    @Body() body: { serviceName: string; count?: number },
  ) {
    try {
      const hashtags = await this.contentGenerator.generateHashtags(
        body.serviceName,
        body.count,
      );

      return {
        success: true,
        data: hashtags,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to generate hashtags',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /smm/generate/promo - Сгенерировать рекламный пост
   */
  @Post('generate/promo')
  async generatePromoPost(
    @Body()
    body: {
      businessName: string;
      serviceName: string;
      discount?: number;
      validUntil?: string;
      platform: 'instagram' | 'facebook';
    },
  ) {
    try {
      const result = await this.contentGenerator.generatePromoPost({
        businessName: body.businessName,
        serviceName: body.serviceName,
        discount: body.discount,
        validUntil: body.validUntil ? new Date(body.validUntil) : undefined,
        platform: body.platform,
      });

      return {
        success: true,
        text: result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to generate promo post',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /smm/improve - Улучшить текст поста
   */
  @Post('improve')
  async improvePostText(
    @Body() body: { text: string; platform: 'instagram' | 'facebook' },
  ) {
    try {
      const result = await this.contentGenerator.improvePostText(
        body.text,
        body.platform,
      );

      return {
        success: true,
        text: result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to improve post text',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /smm/history/:businessId - История постов
   */
  @Get('history/:businessId')
  async getPostHistory(
    @Param('businessId') businessId: string,
    @Query('platform') platform?: 'instagram' | 'facebook' | 'both',
    @Query('limit') limit?: string,
    @Query('offset') offset?: string,
  ) {
    try {
      const posts = await this.smmService.getPostHistory(businessId, {
        platform,
        limit: limit ? parseInt(limit) : undefined,
        offset: offset ? parseInt(offset) : undefined,
      });

      return {
        success: true,
        count: posts.length,
        data: posts,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get post history',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /smm/insights/instagram/:postId - Статистика Instagram поста
   */
  @Get('insights/instagram/:postId')
  async getInstagramInsights(@Param('postId') postId: string) {
    try {
      const insights = await this.smmService.getInstagramPostInsights(postId);

      return {
        success: true,
        data: insights,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get Instagram insights',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /smm/insights/facebook/:postId - Статистика Facebook поста
   */
  @Get('insights/facebook/:postId')
  async getFacebookInsights(@Param('postId') postId: string) {
    try {
      const insights = await this.smmService.getFacebookPostInsights(postId);

      return {
        success: true,
        data: insights,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get Facebook insights',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * DELETE /smm/post/instagram/:postId - Удалить Instagram пост
   */
  @Delete('post/instagram/:postId')
  async deleteInstagramPost(@Param('postId') postId: string) {
    try {
      await this.smmService.deleteInstagramPost(postId);

      return {
        success: true,
        message: 'Post deleted successfully',
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to delete Instagram post',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * DELETE /smm/post/facebook/:postId - Удалить Facebook пост
   */
  @Delete('post/facebook/:postId')
  async deleteFacebookPost(@Param('postId') postId: string) {
    try {
      await this.smmService.deleteFacebookPost(postId);

      return {
        success: true,
        message: 'Post deleted successfully',
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to delete Facebook post',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
