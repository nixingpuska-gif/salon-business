import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { google, calendar_v3 } from 'googleapis';
import { PrismaService } from '../prisma/prisma.service';
import { addMinutes } from 'date-fns';

@Injectable()
export class CalendarService {
  private readonly logger = new Logger(CalendarService.name);

  constructor(
    private config: ConfigService,
    private prisma: PrismaService,
  ) {}

  /**
   * Sync booking to Google Calendar
   */
  async syncBookingToCalendar(bookingId: string): Promise<void> {
    try {
      const booking = await this.prisma.booking.findUnique({
        where: { id: bookingId },
        include: {
          client: true,
          service: true,
          business: true,
        },
      });

      if (!booking) {
        throw new Error('Booking not found');
      }

      const integration = await this.prisma.integration.findFirst({
        where: {
          businessId: booking.businessId,
          type: 'google_calendar',
          enabled: true,
        },
      });

      if (!integration || !integration.credentials) {
        this.logger.warn(`Google Calendar not configured for business \${booking.businessId}`);
        return;
      }

      const credentials = integration.credentials as any;
      
      const auth = new google.auth.OAuth2(
        this.config.get('GOOGLE_CLIENT_ID'),
        this.config.get('GOOGLE_CLIENT_SECRET'),
        this.config.get('GOOGLE_REDIRECT_URI'),
      );
      auth.setCredentials(credentials);

      const calendar = google.calendar({ version: 'v3', auth });

      const endTime = addMinutes(booking.startTime, booking.service.durationMinutes);

      const event: calendar_v3.Schema\$Event = {
        summary: `\${booking.service.name} - \${booking.client.firstName || 'Клиент'}`,
        description: `Запись через AI Booking Platform\\n\\nКлиент: \${booking.client.firstName} \${booking.client.lastName || ''}\\nТелефон: \${booking.client.phone}\\nУслуга: \${booking.service.name}\\nСтоимость: \${booking.service.price || 0}₽`,
        start: {
          dateTime: booking.startTime.toISOString(),
          timeZone: 'Europe/Moscow',
        },
        end: {
          dateTime: endTime.toISOString(),
          timeZone: 'Europe/Moscow',
        },
        attendees: booking.client.email
          ? [{ email: booking.client.email }]
          : undefined,
        reminders: {
          useDefault: false,
          overrides: [
            { method: 'popup', minutes: 60 },
            { method: 'popup', minutes: 1440 },
          ],
        },
      };

      if (booking.metadata && (booking.metadata as any).googleEventId) {
        await calendar.events.update({
          calendarId: 'primary',
          eventId: (booking.metadata as any).googleEventId,
          requestBody: event,
        });
        this.logger.log(`Updated Google Calendar event for booking \${bookingId}`);
      } else {
        const response = await calendar.events.insert({
          calendarId: 'primary',
          requestBody: event,
        });

        await this.prisma.booking.update({
          where: { id: bookingId },
          data: {
            metadata: {
              ...(booking.metadata as any),
              googleEventId: response.data.id,
            },
          },
        });

        this.logger.log(`Created Google Calendar event for booking \${bookingId}`);
      }
    } catch (error) {
      this.logger.error(`Error syncing booking \${bookingId} to Google Calendar:`, error);
      throw error;
    }
  }

  async deleteCalendarEvent(bookingId: string): Promise<void> {
    try {
      const booking = await this.prisma.booking.findUnique({
        where: { id: bookingId },
        include: { business: true },
      });

      if (!booking || !booking.metadata || !(booking.metadata as any).googleEventId) {
        return;
      }

      const integration = await this.prisma.integration.findFirst({
        where: {
          businessId: booking.businessId,
          type: 'google_calendar',
          enabled: true,
        },
      });

      if (!integration || !integration.credentials) {
        return;
      }

      const credentials = integration.credentials as any;
      
      const auth = new google.auth.OAuth2(
        this.config.get('GOOGLE_CLIENT_ID'),
        this.config.get('GOOGLE_CLIENT_SECRET'),
        this.config.get('GOOGLE_REDIRECT_URI'),
      );
      auth.setCredentials(credentials);

      const calendar = google.calendar({ version: 'v3', auth });

      await calendar.events.delete({
        calendarId: 'primary',
        eventId: (booking.metadata as any).googleEventId,
      });

      this.logger.log(`Deleted Google Calendar event for booking \${bookingId}`);
    } catch (error) {
      this.logger.error(`Error deleting calendar event for booking \${bookingId}:`, error);
    }
  }

  getAuthUrl(businessId: string): string {
    const auth = new google.auth.OAuth2(
      this.config.get('GOOGLE_CLIENT_ID'),
      this.config.get('GOOGLE_CLIENT_SECRET'),
      this.config.get('GOOGLE_REDIRECT_URI'),
    );

    const scopes = [
      'https://www.googleapis.com/auth/calendar',
      'https://www.googleapis.com/auth/calendar.events',
    ];

    return auth.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      state: businessId,
    });
  }

  async handleOAuthCallback(code: string, businessId: string): Promise<void> {
    try {
      const auth = new google.auth.OAuth2(
        this.config.get('GOOGLE_CLIENT_ID'),
        this.config.get('GOOGLE_CLIENT_SECRET'),
        this.config.get('GOOGLE_REDIRECT_URI'),
      );

      const { tokens } = await auth.getToken(code);
      auth.setCredentials(tokens);

      await this.prisma.integration.upsert({
        where: {
          businessId_type: {
            businessId,
            type: 'google_calendar',
          },
        },
        create: {
          businessId,
          type: 'google_calendar',
          enabled: true,
          credentials: tokens,
        },
        update: {
          enabled: true,
          credentials: tokens,
        },
      });

      this.logger.log(`Google Calendar connected for business \${businessId}`);
    } catch (error) {
      this.logger.error('Error handling OAuth callback:', error);
      throw error;
    }
  }

  async disconnect(businessId: string): Promise<void> {
    await this.prisma.integration.updateMany({
      where: {
        businessId,
        type: 'google_calendar',
      },
      data: {
        enabled: false,
      },
    });

    this.logger.log(`Google Calendar disconnected for business \${businessId}`);
  }
}
