# 🚀 Быстрый старт: Instagram Direct Messages API

## За 10 минут до первого сообщения

### Шаг 1: Подготовьте Instagram Business Account (2 минуты)

1. Откройте Instagram приложение
2. **Settings** → **Account** → **Switch to Professional Account**
3. Выберите **Business**
4. Свяжите с Facebook Page (или создайте новую)

### Шаг 2: Создайте приложение в Meta (3 минуты)

1. Откройте [developers.facebook.com](https://developers.facebook.com/)
2. **My Apps** → **Create App** → Тип: **Business**
3. Добавьте продукт **Messenger**
4. В разделе **Instagram** → **Add Instagram Account**
5. Авторизуйте доступ к вашему Instagram Business Account

### Шаг 3: Получите учетные данные (2 минуты)

1. В **Messenger** → **Settings** найдите вашу Instagram страницу
2. Скопируйте **Instagram Page ID** → `INSTAGRAM_PAGE_ID`
3. Нажмите **Generate Token** → скопируйте токен → `INSTAGRAM_ACCESS_TOKEN`
4. Придумайте случайную строку → `INSTAGRAM_VERIFY_TOKEN`

### Шаг 4: Настройте переменные окружения (30 секунд)

Добавьте в `backend/.env`:
```bash
INSTAGRAM_PAGE_ID=123456789012345
INSTAGRAM_ACCESS_TOKEN=EAAGxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
INSTAGRAM_VERIFY_TOKEN=my_instagram_token_12345
```

### Шаг 5: Запустите сервер (30 секунд)

```bash
cd backend
npm install  # если ещё не установлено
npm run start:dev
```

### Шаг 6: Настройте Webhook (2 минуты)

1. В Meta Console: **Messenger** → **Settings** → **Webhooks**
2. **Add Callback URL**:
   - **Callback URL**: `https://ваш-домен.com/webhooks/instagram`
   - **Verify Token**: Ваш `INSTAGRAM_VERIFY_TOKEN`
3. **Verify and Save**
4. Подпишитесь на события:
   - ✅ `messages`
   - ✅ `messaging_postbacks`

### Шаг 7: Тестируйте! (1 минута)

1. Откройте Instagram приложение
2. Найдите ваш Business аккаунт
3. Отправьте сообщение в Direct: **"Привет"**
4. Бот должен ответить
5. Проверьте логи сервера

## ✅ Готово!

Теперь ваш бот работает в Instagram Direct. 

**Что дальше?**
- Интегрируйте с AI Orchestrator (см. `INSTAGRAM-IMPLEMENTATION-SUMMARY.md`)
- Настройте Quick Replies для удобного выбора
- Верифицируйте приложение для снятия лимитов

**Полная документация**: `INSTAGRAM-SETUP-GUIDE.md`

---

## 🔧 Быстрое решение проблем

**Webhook не проходит верификацию?**
- Проверьте, что сервер доступен по HTTPS
- Убедитесь, что `INSTAGRAM_VERIFY_TOKEN` совпадает
- Проверьте endpoint: `GET /webhooks/instagram`

**Бот не отвечает?**
- Убедитесь, что Instagram аккаунт — **Business**, а не Personal
- Проверьте, что Instagram связан с Facebook Page
- Посмотрите логи: `npm run start:dev`
- Убедитесь, что webhook подписан на `messages`

**Ошибка "Invalid OAuth access token"?**
- Токен истёк — создайте постоянный токен через System Users
- Проверьте разрешения: `pages_messaging`, `instagram_manage_messages`

**Сообщения не доставляются?**
- Пользователь должен **первым** написать боту
- Можно отвечать только в течение **24 часов** после сообщения
- Проверьте, что `INSTAGRAM_PAGE_ID` правильный

---

## ⚠️ Важные ограничения

- 🚫 Бот **не может** первым инициировать диалог
- ⏰ Можно отвечать только в течение **24 часов** после сообщения пользователя
- 🏢 Instagram аккаунт должен быть **Business**, а не Personal
- 🔗 Instagram должен быть связан с **Facebook Page**
- ✅ Для продакшена требуется **верификация приложения**

---

## 📊 Что умеет бот

✅ Текстовые сообщения  
✅ Quick Replies (до 13 кнопок)  
✅ Карточки с изображениями и кнопками  
✅ Индикатор "печатает..."  
✅ Отметка "прочитано"  
✅ Отправка изображений  

**Ваши клиенты могут записываться через Instagram! 📸**
