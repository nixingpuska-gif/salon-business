# 📊 Руководство по мониторингу и логированию

## Обзор

Полная система мониторинга и логирования для production-ready платформы AI-Booking.

### Компоненты:
1. **Winston Logger** - структурированное логирование
2. **Prometheus Metrics** - метрики производительности
3. **Health Checks** - проверка состояния системы
4. **Audit Logs** - аудит критических операций

---

## 1. Логирование (Winston)

### LoggerService

Структурированное логирование с разными уровнями:
- **error** - ошибки
- **warn** - предупреждения
- **info** - информационные сообщения
- **debug** - отладочная информация
- **verbose** - подробные логи

### Использование

```typescript
import { LoggerService } from './monitoring/logger.service';

@Injectable()
export class MyService {
  constructor(private logger: LoggerService) {
    this.logger.setContext('MyService');
  }

  async doSomething() {
    this.logger.log('Starting operation');
    
    try {
      // ...
      this.logger.log('Operation completed', undefined, { duration: 123 });
    } catch (error) {
      this.logger.logError(error, 'MyService', { operation: 'doSomething' });
    }
  }
}
```

### Методы

**Базовые:**
- `log(message, context?, meta?)` - info level
- `error(message, trace?, context?, meta?)` - error level
- `warn(message, context?, meta?)` - warn level
- `debug(message, context?, meta?)` - debug level

**Специализированные:**
- `logRequest(req, res, responseTime)` - HTTP запросы
- `logError(error, context?, meta?)` - ошибки с стеком
- `logEvent(event, data, context?)` - бизнес-события
- `logMetric(metric, value, unit?, meta?)` - метрики
- `logAudit(action, userId, data)` - аудит

### Конфигурация

Переменные окружения:

```env
# Директория для логов (production)
LOG_DIR=./logs

# Уровень логирования (error, warn, info, debug, verbose)
LOG_LEVEL=info

# Окружение (development, production)
NODE_ENV=production
```

### Форматы

**Development (консоль):**
```
2024-11-25 12:00:00 INFO [MyService] Operation completed {"duration":123}
```

**Production (JSON файлы):**
```json
{
  "timestamp": "2024-11-25T12:00:00.000Z",
  "level": "info",
  "message": "Operation completed",
  "context": "MyService",
  "duration": 123
}
```

### Ротация логов

В production логи автоматически ротируются:
- **Размер файла:** 10 MB
- **Количество файлов:** 10
- **Файлы:**
  - `logs/combined.log` - все логи
  - `logs/error.log` - только ошибки

---

## 2. Метрики (Prometheus)

### MetricsService

Сбор метрик для Prometheus.

### Типы метрик

**HTTP метрики:**
- `http_requests_total` - количество запросов
- `http_request_duration_seconds` - время ответа
- `http_requests_in_progress` - запросы в процессе

**Бизнес-метрики:**
- `bookings_total` - количество записей
- `bookings_active` - активные записи
- `clients_total` - количество клиентов
- `payments_total` - количество платежей
- `payments_amount_rub` - сумма платежей

**Метрики уведомлений:**
- `notifications_sent_total` - отправленные уведомления
- `notifications_failed_total` - неудачные уведомления

**Метрики очередей:**
- `queue_jobs_active` - активные задачи
- `queue_jobs_completed_total` - завершённые задачи
- `queue_jobs_failed_total` - неудачные задачи
- `queue_job_duration_seconds` - время выполнения

**Метрики API:**
- `api_calls_total` - вызовы внешних API
- `api_calls_failed_total` - неудачные вызовы
- `api_call_duration_seconds` - время вызова

### Использование

```typescript
import { MetricsService } from './monitoring/metrics.service';

@Injectable()
export class MyService {
  constructor(private metrics: MetricsService) {}

  async createBooking() {
    // Записать метрику
    this.metrics.recordBookingCreated('confirmed');
    
    // Обновить gauge
    const activeCount = await this.getActiveBookingsCount();
    this.metrics.setActiveBookings(activeCount);
  }

  async callExternalApi() {
    const start = Date.now();
    let success = true;
    
    try {
      await axios.get('https://api.example.com');
    } catch (error) {
      success = false;
    } finally {
      const duration = Date.now() - start;
      this.metrics.recordApiCall('example', 'GET', duration, success);
    }
  }
}
```

### Endpoints

**GET /metrics** - Prometheus метрики

Пример ответа:
```
# HELP http_requests_total Total number of HTTP requests
# TYPE http_requests_total counter
http_requests_total{method="GET",route="/bookings",status="200"} 1523

# HELP bookings_total Total number of bookings created
# TYPE bookings_total counter
bookings_total{status="confirmed"} 342

# HELP payments_amount_rub Total amount of payments in RUB
# TYPE payments_amount_rub counter
payments_amount_rub{status="succeeded"} 1234567
```

### Интеграция с Prometheus

**prometheus.yml:**
```yaml
scrape_configs:
  - job_name: 'ai-booking'
    scrape_interval: 15s
    static_configs:
      - targets: ['localhost:3000']
    metrics_path: '/metrics'
```

---

## 3. Health Checks

### HealthService

Проверка состояния всех компонентов системы.

### Проверки

- **Database** - PostgreSQL доступность
- **Redis** - Redis доступность
- **WhatsApp** - WhatsApp API
- **Instagram** - Instagram API
- **YooKassa** - YooKassa API
- **Disk** - дисковое пространство
- **Memory** - использование памяти

### Endpoints

#### GET /health - Полный health check

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-11-25T12:00:00.000Z",
  "uptime": 86400,
  "checks": {
    "database": {
      "status": "up",
      "responseTime": 5,
      "message": "Database is accessible"
    },
    "redis": {
      "status": "up",
      "responseTime": 2,
      "message": "Redis is accessible"
    },
    "whatsapp": {
      "status": "up",
      "responseTime": 123,
      "message": "WhatsApp API is accessible",
      "details": {
        "phoneNumber": "+7 (999) 123-45-67"
      }
    },
    "memory": {
      "status": "up",
      "message": "Memory usage: 45.23%",
      "details": {
        "heapUsed": "123.45 MB",
        "heapTotal": "256.00 MB"
      }
    }
  }
}
```

**Статусы:**
- `healthy` - все компоненты работают
- `degraded` - некоторые компоненты недоступны (не критично)
- `unhealthy` - критические компоненты недоступны

#### GET /health/live - Liveness probe

Для Kubernetes. Проверяет, что процесс жив.

**Response:**
```json
{
  "status": "alive",
  "timestamp": "2024-11-25T12:00:00.000Z"
}
```

#### GET /health/ready - Readiness probe

Для Kubernetes. Проверяет, что сервис готов принимать трафик.

**Response:**
```json
{
  "status": "ready",
  "timestamp": "2024-11-25T12:00:00.000Z"
}
```

### Kubernetes Deployment

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ai-booking
spec:
  template:
    spec:
      containers:
      - name: backend
        image: ai-booking:latest
        livenessProbe:
          httpGet:
            path: /health/live
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health/ready
            port: 3000
          initialDelaySeconds: 10
          periodSeconds: 5
```

---

## 4. Аудит логи

### AuditService

Логирование критических операций для аудита и соответствия требованиям.

### Типы событий

**Записи:**
- `booking.created`
- `booking.updated`
- `booking.cancelled`
- `booking.rescheduled`

**Клиенты:**
- `client.created`
- `client.updated`
- `client.deleted`
- `client.data_accessed`

**Платежи:**
- `payment.created`
- `payment.succeeded`
- `payment.cancelled`
- `payment.refunded`

**Подписки:**
- `subscription.created`
- `subscription.updated`
- `subscription.cancelled`
- `subscription.renewed`

**Пользователи:**
- `user.login`
- `user.logout`
- `user.password_changed`
- `user.role_changed`

### Использование

```typescript
import { AuditService } from './monitoring/audit.service';

@Injectable()
export class BookingService {
  constructor(private audit: AuditService) {}

  async createBooking(userId: string, businessId: string, data: any) {
    const booking = await this.prisma.booking.create({ data });

    // Записать аудит лог
    await this.audit.logBookingCreated(
      userId,
      businessId,
      booking.id,
      {
        clientName: data.clientName,
        serviceName: data.serviceName,
        dateTime: data.dateTime,
      },
    );

    return booking;
  }
}
```

### Endpoints

#### GET /audit/logs - Получить аудит логи

**Query параметры:**
- `userId` - фильтр по пользователю
- `businessId` - фильтр по бизнесу
- `action` - фильтр по действию
- `resourceType` - фильтр по типу ресурса
- `resourceId` - фильтр по ID ресурса
- `startDate` - начало периода
- `endDate` - конец периода
- `limit` - количество записей (по умолчанию 100)
- `offset` - смещение для пагинации

**Пример:**
```bash
curl "http://localhost:3000/audit/logs?businessId=1&action=booking.created&limit=50"
```

**Response:**
```json
{
  "success": true,
  "logs": [
    {
      "id": "abc123",
      "action": "booking.created",
      "userId": "user1",
      "businessId": "1",
      "resourceType": "booking",
      "resourceId": "booking123",
      "details": {
        "clientName": "Иван Иванов",
        "serviceName": "Маникюр",
        "dateTime": "2024-11-26T10:00:00Z"
      },
      "ipAddress": "192.168.1.1",
      "userAgent": "Mozilla/5.0...",
      "timestamp": "2024-11-25T12:00:00.000Z"
    }
  ],
  "total": 342
}
```

#### GET /audit/stats - Статистика аудита

**Query параметры:**
- `businessId` - фильтр по бизнесу
- `startDate` - начало периода
- `endDate` - конец периода

**Response:**
```json
{
  "success": true,
  "data": {
    "totalActions": 1523,
    "actionsByType": {
      "booking.created": 342,
      "booking.cancelled": 23,
      "payment.succeeded": 156
    },
    "topUsers": [
      { "userId": "user1", "count": 523 },
      { "userId": "user2", "count": 312 }
    ]
  }
}
```

### База данных

**Prisma Schema:**
```prisma
model AuditLog {
  id           String   @id @default(cuid())
  action       String
  userId       String
  businessId   String?
  resourceType String?
  resourceId   String?
  details      Json     @default({})
  ipAddress    String?
  userAgent    String?
  createdAt    DateTime @default(now())

  @@index([userId])
  @@index([businessId])
  @@index([action])
  @@index([createdAt])
}
```

### Очистка старых логов

```typescript
// Удалить логи старше 90 дней
await auditService.cleanupOldLogs(90);
```

Рекомендуется настроить cron job:
```typescript
@Cron(CronExpression.EVERY_1ST_DAY_OF_MONTH_AT_MIDNIGHT)
async cleanupAuditLogs() {
  await this.auditService.cleanupOldLogs(90);
}
```

---

## 5. Мониторинг Dashboard

### GET /monitoring/dashboard

Получить все данные для dashboard в одном запросе.

**Response:**
```json
{
  "success": true,
  "data": {
    "health": {
      "status": "healthy",
      "uptime": 86400,
      "checks": { ... }
    },
    "metrics": {
      "http_requests_total": [...],
      "bookings_total": [...],
      "payments_amount_rub": [...]
    },
    "timestamp": "2024-11-25T12:00:00.000Z"
  }
}
```

---

## Интеграция с внешними системами

### Grafana

**Datasource (Prometheus):**
1. Добавить Prometheus datasource
2. URL: `http://prometheus:9090`
3. Импортировать dashboard

**Пример запросов:**
```promql
# Количество запросов в секунду
rate(http_requests_total[5m])

# Среднее время ответа
rate(http_request_duration_seconds_sum[5m]) / rate(http_request_duration_seconds_count[5m])

# Количество активных записей
bookings_active

# Доход за последний час
increase(payments_amount_rub{status="succeeded"}[1h])
```

### ELK Stack (Elasticsearch, Logstash, Kibana)

**Logstash config:**
```conf
input {
  file {
    path => "/app/logs/combined.log"
    codec => "json"
  }
}

filter {
  json {
    source => "message"
  }
}

output {
  elasticsearch {
    hosts => ["elasticsearch:9200"]
    index => "ai-booking-%{+YYYY.MM.dd}"
  }
}
```

### Sentry (Error Tracking)

```typescript
import * as Sentry from '@sentry/node';

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV,
});

// В LoggerService
logError(error: Error, context?: string) {
  Sentry.captureException(error, {
    tags: { context },
  });
  
  this.logger.error(error.message, {
    context,
    stack: error.stack,
  });
}
```

---

## Рекомендации

### Production

1. **Логирование:**
   - Используйте `LOG_LEVEL=info` в production
   - Настройте ротацию логов
   - Отправляйте логи в централизованное хранилище (ELK, CloudWatch)

2. **Метрики:**
   - Настройте Prometheus scraping
   - Создайте Grafana dashboards
   - Настройте алерты для критических метрик

3. **Health Checks:**
   - Используйте `/health/live` и `/health/ready` в Kubernetes
   - Настройте мониторинг доступности (Pingdom, UptimeRobot)

4. **Аудит:**
   - Логируйте все критические операции
   - Настройте автоматическую очистку старых логов
   - Регулярно проверяйте аудит логи

### Алерты

**Prometheus Alertmanager:**
```yaml
groups:
  - name: ai-booking
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
        annotations:
          summary: "High error rate detected"
      
      - alert: DatabaseDown
        expr: up{job="ai-booking"} == 0
        annotations:
          summary: "Database is down"
      
      - alert: HighMemoryUsage
        expr: process_resident_memory_bytes > 1e9
        annotations:
          summary: "Memory usage above 1GB"
```

---

## Готово! 🎉

Система мониторинга и логирования полностью настроена и готова к production.
