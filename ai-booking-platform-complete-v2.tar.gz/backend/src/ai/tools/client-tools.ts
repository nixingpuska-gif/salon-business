/**
 * Function calling tools for Client AI Agent
 */

export const clientTools = [
  {
    type: 'function' as const,
    function: {
      name: 'get_available_services',
      description: 'Получить список доступных услуг бизнеса',
      parameters: {
        type: 'object',
        properties: {
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
        },
        required: ['businessId'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'get_available_slots',
      description: 'Получить доступные слоты для записи на определённую дату',
      parameters: {
        type: 'object',
        properties: {
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
          serviceId: {
            type: 'string',
            description: 'ID услуги',
          },
          date: {
            type: 'string',
            description: 'Дата в формате YYYY-MM-DD',
          },
        },
        required: ['businessId', 'serviceId', 'date'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'create_booking',
      description: 'Создать новую запись на услугу',
      parameters: {
        type: 'object',
        properties: {
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
          serviceId: {
            type: 'string',
            description: 'ID услуги',
          },
          startTime: {
            type: 'string',
            description: 'Время начала в формате ISO 8601',
          },
          clientPhone: {
            type: 'string',
            description: 'Телефон клиента',
          },
          clientName: {
            type: 'string',
            description: 'Имя клиента',
          },
        },
        required: ['businessId', 'serviceId', 'startTime', 'clientPhone'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'get_client_bookings',
      description: 'Получить список записей клиента',
      parameters: {
        type: 'object',
        properties: {
          clientPhone: {
            type: 'string',
            description: 'Телефон клиента',
          },
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
        },
        required: ['clientPhone', 'businessId'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'reschedule_booking',
      description: 'Перенести существующую запись на другое время',
      parameters: {
        type: 'object',
        properties: {
          bookingId: {
            type: 'string',
            description: 'ID записи',
          },
          newStartTime: {
            type: 'string',
            description: 'Новое время начала в формате ISO 8601',
          },
        },
        required: ['bookingId', 'newStartTime'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'cancel_booking',
      description: 'Отменить существующую запись',
      parameters: {
        type: 'object',
        properties: {
          bookingId: {
            type: 'string',
            description: 'ID записи',
          },
          reason: {
            type: 'string',
            description: 'Причина отмены (опционально)',
          },
        },
        required: ['bookingId'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'get_service_price',
      description: 'Получить цену конкретной услуги',
      parameters: {
        type: 'object',
        properties: {
          serviceId: {
            type: 'string',
            description: 'ID услуги',
          },
        },
        required: ['serviceId'],
      },
    },
  },
];
