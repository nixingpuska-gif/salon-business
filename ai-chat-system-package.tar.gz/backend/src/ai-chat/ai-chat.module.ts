import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AiChatController } from './ai-chat.controller';
import { AdminChatService } from './admin-chat.service';
import { ClientChatService } from './client-chat.service';
import { ConversationContextService } from './conversation-context.service';
import { ScenarioService } from './scenario.service';
import { PrismaModule } from '../prisma/prisma.module';
import { MonitoringModule } from '../monitoring/monitoring.module';

@Module({
  imports: [
    ConfigModule,
    PrismaModule,
    MonitoringModule,
  ],
  controllers: [AiChatController],
  providers: [
    AdminChatService,
    ClientChatService,
    ConversationContextService,
    ScenarioService,
  ],
  exports: [
    AdminChatService,
    ClientChatService,
    ConversationContextService,
    ScenarioService,
  ],
})
export class AiChatModule {}
