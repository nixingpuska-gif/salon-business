"""
Business OS - Staff Models
Модели сотрудников салонов (мастера, администраторы)
"""

from datetime import datetime, date, time
from typing import Optional
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, BigInteger, 
    DateTime, Date, Time, Numeric, ForeignKey, JSON, Index
)
from sqlalchemy.orm import relationship
import enum

from app.models.base import TenantBaseModel


class StaffRole(str, enum.Enum):
    """Роли сотрудников"""
    MANAGER = "manager"  # Управляющий
    ADMIN = "admin"  # Администратор
    MASTER = "master"  # Мастер
    INTERN = "intern"  # Стажёр


class StaffStatus(str, enum.Enum):
    """Статусы сотрудников"""
    ACTIVE = "active"
    ON_VACATION = "on_vacation"
    SICK_LEAVE = "sick_leave"
    FIRED = "fired"
    SUSPENDED = "suspended"


class Staff(TenantBaseModel):
    """
    Сотрудник салона.
    Мастера, администраторы, управляющие.
    """
    __tablename__ = "staff"
    
    # === Привязка к филиалу ===
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=False, index=True)
    
    # === Основная информация ===
    first_name = Column(String(100), nullable=False)
    last_name = Column(String(100), nullable=True)
    display_name = Column(String(100), nullable=True)  # Имя для клиентов
    
    # === Контакты ===
    phone = Column(String(50), nullable=False)
    email = Column(String(255), nullable=True)
    
    # === Мессенджеры ===
    telegram_id = Column(BigInteger, nullable=True, unique=True)
    telegram_username = Column(String(100), nullable=True)
    
    # === Аутентификация (для Staff App) ===
    password_hash = Column(String(255), nullable=True)
    pin_code = Column(String(10), nullable=True)  # Быстрый вход по PIN
    
    # === Роль и статус ===
    role = Column(String(50), default=StaffRole.MASTER.value, index=True)
    status = Column(String(50), default=StaffStatus.ACTIVE.value, index=True)
    
    # === Профиль ===
    avatar_url = Column(String(500), nullable=True)
    bio = Column(Text, nullable=True)  # Описание для клиентов
    specializations = Column(JSON, default=list)  # ["маникюр", "педикюр"]
    
    # === Трудоустройство ===
    hired_at = Column(Date, nullable=True)
    fired_at = Column(Date, nullable=True)
    position = Column(String(100), nullable=True)  # Должность
    
    # === Зарплата ===
    salary_type = Column(String(20), default="percent")  # fixed, percent, mixed
    salary_fixed = Column(Numeric(10, 2), default=0)  # Фиксированная часть
    salary_percent = Column(Numeric(5, 2), default=40)  # Процент от услуг
    
    # === Рабочий график ===
    working_hours = Column(JSON, default=dict)
    # Пример: {
    #   "monday": {"start": "09:00", "end": "18:00", "breaks": [{"start": "13:00", "end": "14:00"}]},
    #   "tuesday": null,  # Выходной
    #   ...
    # }
    
    # === Интеграция с календарями ===
    google_calendar_id = Column(String(255), nullable=True)
    google_calendar_sync_enabled = Column(Boolean, default=False)
    
    # === Настройки записи ===
    buffer_before_minutes = Column(Integer, default=0)  # Буфер до записи
    buffer_after_minutes = Column(Integer, default=0)  # Буфер после записи
    max_clients_per_day = Column(Integer, nullable=True)  # Лимит клиентов
    accepts_new_clients = Column(Boolean, default=True)
    online_booking_enabled = Column(Boolean, default=True)
    
    # === Статистика ===
    total_clients = Column(Integer, default=0)
    total_appointments = Column(Integer, default=0)
    total_revenue = Column(Numeric(12, 2), default=0)
    avg_rating = Column(Numeric(3, 2), default=0)
    total_reviews = Column(Integer, default=0)
    
    # === KPI ===
    avg_check = Column(Numeric(10, 2), default=0)
    utilization_rate = Column(Numeric(5, 2), default=0)  # % загрузки
    cancellation_rate = Column(Numeric(5, 2), default=0)  # % отмен
    return_rate = Column(Numeric(5, 2), default=0)  # % возвратов клиентов
    
    # === Права доступа ===
    permissions = Column(JSON, default=dict)
    # Пример: {
    #   "can_view_all_appointments": false,
    #   "can_edit_prices": false,
    #   "can_view_reports": false,
    #   "can_manage_clients": false
    # }
    
    # === Уведомления ===
    notification_settings = Column(JSON, default={
        "new_appointment": True,
        "cancelled_appointment": True,
        "reminder_before_work": True,
        "daily_schedule": True
    })
    
    # === Relationships ===
    branch = relationship("Branch", back_populates="staff")
    appointments = relationship("Appointment", back_populates="staff", lazy="dynamic")
    services = relationship("StaffService", back_populates="staff", lazy="dynamic")
    schedules = relationship("StaffSchedule", back_populates="staff", lazy="dynamic")
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_staff_tenant_branch', 'tenant_id', 'branch_id'),
        Index('ix_staff_tenant_role', 'tenant_id', 'role'),
    )
    
    @property
    def full_name(self) -> str:
        if self.last_name:
            return f"{self.first_name} {self.last_name}"
        return self.first_name
    
    @property
    def public_name(self) -> str:
        return self.display_name or self.first_name


class StaffSchedule(TenantBaseModel):
    """
    Расписание сотрудника на конкретные даты.
    Переопределяет стандартный график из working_hours.
    """
    __tablename__ = "staff_schedules"
    
    staff_id = Column(BigInteger, ForeignKey("staff.id"), nullable=False, index=True)
    
    # === Дата ===
    date = Column(Date, nullable=False, index=True)
    
    # === Время работы ===
    is_working = Column(Boolean, default=True)
    start_time = Column(Time, nullable=True)
    end_time = Column(Time, nullable=True)
    
    # === Перерывы ===
    breaks = Column(JSON, default=list)
    # [{"start": "13:00", "end": "14:00", "reason": "Обед"}]
    
    # === Причина изменения ===
    reason = Column(String(255), nullable=True)  # "Отпуск", "Больничный"
    
    # === Relationships ===
    staff = relationship("Staff", back_populates="schedules")
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_staff_schedules_staff_date', 'staff_id', 'date', unique=True),
    )


class StaffService(TenantBaseModel):
    """
    Связь сотрудника с услугами.
    Какие услуги может оказывать мастер и по какой цене.
    """
    __tablename__ = "staff_services"
    
    staff_id = Column(BigInteger, ForeignKey("staff.id"), nullable=False, index=True)
    service_id = Column(BigInteger, ForeignKey("services.id"), nullable=False, index=True)
    
    # === Индивидуальные настройки ===
    custom_price = Column(Numeric(10, 2), nullable=True)  # Своя цена (если отличается)
    custom_duration_minutes = Column(Integer, nullable=True)  # Своя длительность
    
    # === Статистика ===
    total_performed = Column(Integer, default=0)
    avg_rating = Column(Numeric(3, 2), nullable=True)
    
    # === Relationships ===
    staff = relationship("Staff", back_populates="services")
    service = relationship("Service", back_populates="staff_services")
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_staff_services_staff_service', 'staff_id', 'service_id', unique=True),
    )


class StaffVacation(TenantBaseModel):
    """
    Отпуска и отсутствия сотрудников.
    """
    __tablename__ = "staff_vacations"
    
    staff_id = Column(BigInteger, ForeignKey("staff.id"), nullable=False, index=True)
    
    # === Период ===
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    
    # === Тип ===
    type = Column(String(50), nullable=False)  # vacation, sick_leave, day_off, other
    reason = Column(String(255), nullable=True)
    
    # === Статус ===
    is_approved = Column(Boolean, default=False)
    approved_by_id = Column(BigInteger, nullable=True)
    approved_at = Column(DateTime, nullable=True)


class StaffSalary(TenantBaseModel):
    """
    История начислений зарплаты.
    """
    __tablename__ = "staff_salaries"
    
    staff_id = Column(BigInteger, ForeignKey("staff.id"), nullable=False, index=True)
    
    # === Период ===
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    
    # === Начисления ===
    fixed_amount = Column(Numeric(10, 2), default=0)
    percent_amount = Column(Numeric(10, 2), default=0)
    bonus_amount = Column(Numeric(10, 2), default=0)
    penalty_amount = Column(Numeric(10, 2), default=0)
    total_amount = Column(Numeric(10, 2), default=0)
    
    # === Детали ===
    appointments_count = Column(Integer, default=0)
    revenue_generated = Column(Numeric(12, 2), default=0)
    
    # === Выплата ===
    is_paid = Column(Boolean, default=False)
    paid_at = Column(DateTime, nullable=True)
    payment_method = Column(String(50), nullable=True)
