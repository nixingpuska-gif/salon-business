"""
Business OS - Configuration Module
Централизованная конфигурация приложения
"""

from typing import List, Optional
from pydantic_settings import BaseSettings
from pydantic import AnyHttpUrl, field_validator
import secrets


class Settings(BaseSettings):
    # === Application ===
    APP_NAME: str = "Business OS"
    APP_VERSION: str = "1.0.0"
    API_V1_PREFIX: str = "/api/v1"
    DEBUG: bool = False
    ENVIRONMENT: str = "development"
    
    # === Security ===
    SECRET_KEY: str = secrets.token_urlsafe(32)
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7  # 7 days
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30
    ALGORITHM: str = "HS256"
    
    # === Database ===
    DATABASE_URL: str = "sqlite+aiosqlite:///./business_os.db"
    DATABASE_POOL_SIZE: int = 20
    DATABASE_MAX_OVERFLOW: int = 10
    
    # === Redis ===
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # === CORS ===
    CORS_ORIGINS: List[str] = ["*"]
    
    @field_validator("CORS_ORIGINS", mode="before")
    @classmethod
    def assemble_cors_origins(cls, v):
        if isinstance(v, str):
            return [i.strip() for i in v.split(",")]
        return v
    
    # === External Services ===
    # Google Calendar
    GOOGLE_CLIENT_ID: Optional[str] = None
    GOOGLE_CLIENT_SECRET: Optional[str] = None
    
    # Telegram Bot
    TELEGRAM_BOT_TOKEN: Optional[str] = None
    
    # WhatsApp (via Twilio or similar)
    WHATSAPP_API_KEY: Optional[str] = None
    
    # OpenAI for AI features
    OPENAI_API_KEY: Optional[str] = None
    OPENAI_MODEL: str = "gpt-4.1-mini"
    
    # === Email ===
    SMTP_HOST: Optional[str] = None
    SMTP_PORT: int = 587
    SMTP_USER: Optional[str] = None
    SMTP_PASSWORD: Optional[str] = None
    EMAILS_FROM_EMAIL: Optional[str] = None
    EMAILS_FROM_NAME: str = "Business OS"
    
    # === File Storage ===
    UPLOAD_DIR: str = "/var/uploads"
    MAX_UPLOAD_SIZE: int = 10 * 1024 * 1024  # 10MB
    
    # === Multi-tenancy ===
    DEFAULT_TENANT_SCHEMA: str = "public"
    
    # === Rate Limiting ===
    RATE_LIMIT_PER_MINUTE: int = 60
    
    # === Localization ===
    DEFAULT_LANGUAGE: str = "ru"
    SUPPORTED_LANGUAGES: List[str] = ["ru", "en", "de", "uk", "kk"]
    DEFAULT_TIMEZONE: str = "Europe/Moscow"
    DEFAULT_CURRENCY: str = "RUB"
    
    # === Trial ===
    TRIAL_DAYS: int = 14
    
    # === Aliases for compatibility ===
    @property
    def PROJECT_NAME(self) -> str:
        return self.APP_NAME
    
    @property
    def VERSION(self) -> str:
        return self.APP_VERSION
    
    class Config:
        env_file = ".env"
        case_sensitive = True
        extra = "allow"


settings = Settings()
