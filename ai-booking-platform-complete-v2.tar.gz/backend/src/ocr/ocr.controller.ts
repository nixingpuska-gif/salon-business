import {
  Controller,
  Post,
  Get,
  Body,
  Param,
  HttpStatus,
  HttpException,
} from '@nestjs/common';
import { OCRService } from './ocr.service';

/**
 * OCR Controller
 * 
 * API endpoints для OCR функций:
 * - Извлечение записей из изображений
 * - Импорт записей в систему
 * - Анализ изображений
 * - Извлечение текста
 */
@Controller('ocr')
export class OCRController {
  constructor(private ocrService: OCRService) {}

  /**
   * POST /ocr/extract - Извлечь записи из изображения
   */
  @Post('extract')
  async extractBookings(
    @Body() body: { imageUrl: string; businessId: string },
  ) {
    try {
      const bookings = await this.ocrService.extractBookingsFromImage(
        body.imageUrl,
        body.businessId,
      );

      return {
        success: true,
        count: bookings.length,
        data: bookings,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to extract bookings',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /ocr/import - Импортировать записи из изображения
   */
  @Post('import')
  async importBookings(
    @Body() body: { imageUrl: string; businessId: string },
  ) {
    try {
      const result = await this.ocrService.importBookingsFromImage(
        body.imageUrl,
        body.businessId,
      );

      return {
        success: true,
        ...result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to import bookings',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /ocr/analyze - Анализ изображения
   */
  @Post('analyze')
  async analyzeImage(@Body() body: { imageUrl: string }) {
    try {
      const analysis = await this.ocrService.analyzeImage(body.imageUrl);

      return {
        success: true,
        data: analysis,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to analyze image',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /ocr/text - Извлечь текст из изображения
   */
  @Post('text')
  async extractText(@Body() body: { imageUrl: string }) {
    try {
      const text = await this.ocrService.extractTextFromImage(body.imageUrl);

      return {
        success: true,
        text,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to extract text',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
