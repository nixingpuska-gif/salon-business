import { useState } from 'react'
import { 
  Building2, Users, Bell, CreditCard, Globe, 
  Shield, Database, Save, Loader2, Check
} from 'lucide-react'
import clsx from 'clsx'

const tabs = [
  { id: 'general', label: 'Основные', icon: Building2 },
  { id: 'team', label: 'Команда', icon: Users },
  { id: 'notifications', label: 'Уведомления', icon: Bell },
  { id: 'billing', label: 'Подписка', icon: CreditCard },

  { id: 'integrations', label: 'Интеграции', icon: Globe },
  { id: 'security', label: 'Безопасность', icon: Shield },
  { id: 'data', label: 'Данные', icon: Database },
]

const weekDays = [
  { id: 1, label: 'Понедельник', short: 'Пн' },
  { id: 2, label: 'Вторник', short: 'Вт' },
  { id: 3, label: 'Среда', short: 'Ср' },
  { id: 4, label: 'Четверг', short: 'Чт' },
  { id: 5, label: 'Пятница', short: 'Пт' },
  { id: 6, label: 'Суббота', short: 'Сб' },
  { id: 0, label: 'Воскресенье', short: 'Вс' },
]

export default function Settings() {
  const [activeTab, setActiveTab] = useState('general')
  const [loading, setLoading] = useState(false)
  const [saved, setSaved] = useState(false)

  const [salonSettings, setSalonSettings] = useState({
    name: 'Beauty Lab',
    city: 'Москва',
    address: 'ул. Красная, 15',
    phone: '+7 (495) 123-45-67',
    email: 'info@beautylab.ru',
    workingHoursStart: '09:00',
    workingHoursEnd: '21:00',
    workingDays: [1, 2, 3, 4, 5, 6],
  })

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    smsNotifications: true,
    telegramNotifications: false,
    appointmentReminders: true,
    reviewRequests: true,
  })

  const handleSave = async () => {
    setLoading(true)
    setSaved(false)
    await new Promise(resolve => setTimeout(resolve, 1000))
    setSaved(true)
    setLoading(false)
    setTimeout(() => setSaved(false), 3000)
  }

  const toggleWorkingDay = (dayId: number) => {
    setSalonSettings(prev => ({
      ...prev,
      workingDays: prev.workingDays.includes(dayId)
        ? prev.workingDays.filter(d => d !== dayId)
        : [...prev.workingDays, dayId]
    }))
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Настройки</h1>
          <p className="text-gray-500 mt-1">Управление параметрами салона</p>
        </div>
        <button onClick={handleSave} disabled={loading} className="btn-primary flex items-center gap-2">
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : saved ? <Check className="w-5 h-5" /> : <Save className="w-5 h-5" />}
          {saved ? 'Сохранено' : 'Сохранить'}
        </button>
      </div>

      <div className="flex gap-6">
        <div className="w-64 flex-shrink-0">
          <nav className="space-y-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={clsx(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-all",
                  activeTab === tab.id ? "bg-primary-50 text-primary-700" : "text-gray-600 hover:bg-gray-50"
                )}
              >
                <tab.icon className="w-5 h-5" />
                <span className="font-medium">{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="flex-1">
          <div className="card">
            {activeTab === 'general' && (
              <div className="space-y-6">
                <h2 className="text-lg font-semibold text-gray-900">Основные настройки</h2>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Название салона</label>
                    <input type="text" value={salonSettings.name} onChange={(e) => setSalonSettings(prev => ({ ...prev, name: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Город</label>
                    <input type="text" value={salonSettings.city} onChange={(e) => setSalonSettings(prev => ({ ...prev, city: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Адрес</label>
                  <input type="text" value={salonSettings.address} onChange={(e) => setSalonSettings(prev => ({ ...prev, address: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Телефон</label>
                    <input type="tel" value={salonSettings.phone} onChange={(e) => setSalonSettings(prev => ({ ...prev, phone: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input type="email" value={salonSettings.email} onChange={(e) => setSalonSettings(prev => ({ ...prev, email: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" />
                  </div>
                </div>
                <div className="border-t pt-6">
                  <h3 className="text-md font-medium text-gray-900 mb-4">График работы</h3>
                  <div className="mb-4">
                    <label className="block text-sm font-medium text-gray-700 mb-3">Рабочие дни</label>
                    <div className="flex gap-2">
                      {weekDays.map((day) => (
                        <button key={day.id} onClick={() => toggleWorkingDay(day.id)} className={clsx("w-12 h-12 rounded-xl font-medium transition-all", salonSettings.workingDays.includes(day.id) ? "bg-primary-600 text-white" : "bg-gray-100 text-gray-500 hover:bg-gray-200")}>{day.short}</button>
                      ))}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Начало работы</label>
                      <input type="time" value={salonSettings.workingHoursStart} onChange={(e) => setSalonSettings(prev => ({ ...prev, workingHoursStart: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Конец работы</label>
                      <input type="time" value={salonSettings.workingHoursEnd} onChange={(e) => setSalonSettings(prev => ({ ...prev, workingHoursEnd: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="space-y-6">
                <h2 className="text-lg font-semibold text-gray-900">Настройки уведомлений</h2>
                <div className="space-y-4">
                  {[
                    { key: 'emailNotifications', label: 'Email уведомления', desc: 'Получать уведомления на email' },
                    { key: 'smsNotifications', label: 'SMS уведомления', desc: 'Отправлять SMS клиентам' },
                    { key: 'telegramNotifications', label: 'Telegram уведомления', desc: 'Отправлять уведомления в Telegram' },
                    { key: 'appointmentReminders', label: 'Напоминания о записи', desc: 'Автоматические напоминания клиентам' },
                    { key: 'reviewRequests', label: 'Запрос отзывов', desc: 'Запрашивать отзыв после визита' },
                  ].map((item) => (
                    <label key={item.key} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                      <div>
                        <div className="font-medium text-gray-900">{item.label}</div>
                        <div className="text-sm text-gray-500">{item.desc}</div>
                      </div>
                      <input type="checkbox" checked={notificationSettings[item.key as keyof typeof notificationSettings]} onChange={(e) => setNotificationSettings(prev => ({ ...prev, [item.key]: e.target.checked }))} className="w-5 h-5 text-primary-600 border-gray-300 rounded focus:ring-primary-500" />
                    </label>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'billing' && (
              <div className="space-y-6">
                <h2 className="text-lg font-semibold text-gray-900">Подписка и оплата</h2>
                <div className="bg-gradient-to-r from-primary-500 to-primary-600 rounded-2xl p-6 text-white">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm opacity-80">Текущий тариф</div>
                      <div className="text-2xl font-bold mt-1">Business</div>
                      <div className="mt-2 inline-block px-3 py-1 bg-white/20 rounded-full text-sm">Пробный период до 1 января 2025</div>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-bold">100 000 ₽</div>
                      <div className="text-sm opacity-80">в месяц</div>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  {[
                    { name: 'Business', price: '100 000', subtitle: 'До 8 сотрудников', features: ['AI-ассистент для записи', 'AI-рекомендации и прогнозы', 'CRM и автосегментация', 'Telegram, WhatsApp, Instagram боты', 'Программа лояльности и бонусы', 'Мультифилиальность', 'Белый лейбл', 'BI-аналитика и отчёты'], current: true },
                    { name: 'Enterprise', price: '200 000', subtitle: '9+ сотрудников, безлимит', features: ['Всё из Business', 'Безлимит сотрудников', 'Выделенный менеджер', 'Кастомные интеграции', 'SLA 99.9%', 'Приоритетная поддержка 24/7', 'Обучение команды', 'Персональные доработки'] },
                  ].map((plan) => (
                    <div key={plan.name} className={clsx("border rounded-xl p-6", plan.current && "border-2 border-primary-500 relative")}>
                      {plan.current && <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-primary-500 text-white text-xs rounded-full">Текущий тариф</div>}
                      <div className="font-semibold text-gray-900 text-lg">{plan.name}</div>
                      <div className="text-sm text-gray-500">{plan.subtitle}</div>
                      <div className="text-2xl font-bold mt-3 text-gray-900">{plan.price} ₽<span className="text-sm font-normal text-gray-500">/мес</span></div>
                      <div className="text-xs text-gray-400 mt-1">или {plan.name === 'Business' ? '1 000' : '2 000'} €/мес для Европы</div>
                      <ul className="mt-4 space-y-2 text-sm text-gray-600">{plan.features.map(f => <li key={f} className="flex items-start gap-2"><span className="text-primary-500">✓</span> {f}</li>)}</ul>
                      <button className={clsx("w-full mt-4 py-2 rounded-lg font-medium", plan.current ? "bg-primary-600 text-white hover:bg-primary-700" : "border border-gray-200 text-gray-600 hover:bg-gray-50")}>{plan.current ? 'Текущий тариф' : 'Перейти на Enterprise'}</button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'team' && (
              <div className="space-y-6">
                <h2 className="text-lg font-semibold text-gray-900">Управление командой</h2>
                <p className="text-gray-500">Для управления сотрудниками перейдите в раздел <a href="/staff" className="text-primary-600 hover:underline">Сотрудники</a></p>
                <div className="bg-gray-50 rounded-xl p-6">
                  <h3 className="font-medium text-gray-900 mb-4">Роли и права доступа</h3>
                  <div className="space-y-3">
                    {[
                      { role: 'Владелец', desc: 'Полный доступ ко всем функциям', count: 1 },
                      { role: 'Администратор', desc: 'Управление записями и клиентами', count: 0 },
                      { role: 'Мастер', desc: 'Просмотр своего расписания', count: 5 },
                    ].map((item) => (
                      <div key={item.role} className="flex items-center justify-between p-3 bg-white rounded-lg">
                        <div>
                          <div className="font-medium">{item.role}</div>
                          <div className="text-sm text-gray-500">{item.desc}</div>
                        </div>
                        <span className={clsx("px-3 py-1 rounded-full text-sm", item.count > 0 ? "bg-primary-100 text-primary-700" : "bg-gray-100 text-gray-700")}>{item.count} пользователей</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'integrations' && (
              <div className="space-y-6">
                <h2 className="text-lg font-semibold text-gray-900">Интеграции</h2>
                <div className="space-y-4">
                  {[
                    { name: 'Telegram Bot', desc: 'Уведомления и запись через Telegram', color: 'blue', connected: false },
                    { name: 'WhatsApp Business', desc: 'Общение с клиентами через WhatsApp', color: 'green', connected: false },
                    { name: 'Google Calendar', desc: 'Синхронизация расписания', color: 'red', connected: false },
                  ].map((item) => (
                    <div key={item.name} className="flex items-center justify-between p-4 border rounded-xl">
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 bg-${item.color}-100 rounded-xl flex items-center justify-center`}>
                          <Globe className={`w-6 h-6 text-${item.color}-600`} />
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">{item.name}</div>
                          <div className="text-sm text-gray-500">{item.desc}</div>
                        </div>
                      </div>
                      <button className={clsx("px-4 py-2 rounded-lg", item.connected ? "bg-green-100 text-green-700" : "bg-primary-600 text-white hover:bg-primary-700")}>{item.connected ? 'Подключено' : 'Подключить'}</button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="space-y-6">
                <h2 className="text-lg font-semibold text-gray-900">Безопасность</h2>
                <div className="space-y-4">
                  {[
                    { title: 'Двухфакторная аутентификация', desc: 'Дополнительная защита аккаунта', action: 'Включить' },
                    { title: 'Сменить пароль', desc: 'Последнее изменение: никогда', action: 'Изменить' },
                    { title: 'Активные сессии', desc: '1 активная сессия', action: 'Управление' },
                  ].map((item) => (
                    <div key={item.title} className="p-4 border rounded-xl">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-medium text-gray-900">{item.title}</div>
                          <div className="text-sm text-gray-500">{item.desc}</div>
                        </div>
                        <button className="px-4 py-2 border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50">{item.action}</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}


            {activeTab === 'data' && (
              <div className="space-y-6">
                <h2 className="text-lg font-semibold text-gray-900">Управление данными</h2>
                <div className="space-y-4">
                  <div className="p-4 border rounded-xl">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-gray-900">Экспорт данных</div>
                        <div className="text-sm text-gray-500">Скачать все данные в формате CSV</div>
                      </div>
                      <button className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700">Экспортировать</button>
                    </div>
                  </div>
                  <div className="p-4 border rounded-xl">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-gray-900">Импорт клиентов</div>
                        <div className="text-sm text-gray-500">Загрузить клиентов из CSV/Excel</div>
                      </div>
                      <button className="px-4 py-2 border border-gray-200 rounded-lg text-gray-600 hover:bg-gray-50">Импортировать</button>
                    </div>
                  </div>
                  <div className="p-4 border border-red-200 rounded-xl bg-red-50">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium text-red-900">Удалить аккаунт</div>
                        <div className="text-sm text-red-600">Это действие нельзя отменить</div>
                      </div>
                      <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">Удалить</button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
