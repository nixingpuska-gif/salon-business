"""Business OS - Reviews Endpoints"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db

router = APIRouter()

@router.get("")
async def list_reviews(db: AsyncSession = Depends(get_db)):
    return {"items": [], "total": 0}

@router.get("/stats")
async def get_review_stats(db: AsyncSession = Depends(get_db)):
    return {"average_rating": 0, "total_reviews": 0}

@router.post("/{review_id}/respond")
async def respond_to_review(review_id: int, db: AsyncSession = Depends(get_db)):
    raise HTTPException(status_code=501, detail="Not implemented")
