"""
Business OS - Partner & Lead Models
Модели для партнёрской программы и обработки заявок
"""

from datetime import datetime
from typing import Optional
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, BigInteger, 
    DateTime, Numeric, ForeignKey, JSON, Index
)
from sqlalchemy.orm import relationship
import enum

from app.models.base import BaseModel


class PartnerType(str, enum.Enum):
    """Типы партнёров"""
    SALON_OWNER = "salon_owner"  # Владелец салона (реферал)
    SUPPLIER = "supplier"  # Поставщик


class Partner(BaseModel):
    """
    Партнёр (реферал или поставщик).
    """
    __tablename__ = "partners"
    
    # === Привязка к пользователю (если владелец салона) ===
    user_id = Column(BigInteger, ForeignKey("users.id"), nullable=True, unique=True)
    
    # === Тип партнёра ===
    partner_type = Column(String(50), nullable=False)
    
    # === Основная информация ===
    name = Column(String(255), nullable=False)
    company_name = Column(String(255), nullable=True)
    
    # === Контакты ===
    email = Column(String(255), nullable=False)
    phone = Column(String(50), nullable=True)
    
    # === Реферальный код ===
    referral_code = Column(String(50), unique=True, nullable=False, index=True)
    
    # === Комиссии ===
    # Для владельцев салонов: 5% от всех привлечённых
    # Для поставщиков: 25% первая оплата, 15% ежемесячно
    commission_first_percent = Column(Numeric(5, 2), default=5)
    commission_monthly_percent = Column(Numeric(5, 2), default=5)
    
    # === Баланс ===
    balance = Column(Numeric(12, 2), default=0)  # Текущий баланс
    total_earned = Column(Numeric(12, 2), default=0)  # Всего заработано
    total_withdrawn = Column(Numeric(12, 2), default=0)  # Всего выведено
    
    # === Статистика ===
    total_referrals = Column(Integer, default=0)  # Всего привлечено
    active_referrals = Column(Integer, default=0)  # Активных
    
    # === Привлечён партнёром (для владельцев, привлечённых поставщиком) ===
    referred_by_partner_id = Column(BigInteger, ForeignKey("partners.id"), nullable=True)
    
    # === Статус ===
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    
    # === Платёжные реквизиты ===
    payment_details = Column(JSON, default=dict)
    # {"type": "card", "card_number": "****1234", "bank": "Сбербанк"}
    
    # === Relationships ===
    user = relationship("User")
    referrals = relationship("PartnerReferral", back_populates="partner", 
                            foreign_keys="PartnerReferral.partner_id", lazy="dynamic")
    commissions = relationship("PartnerCommission", back_populates="partner", lazy="dynamic")
    withdrawals = relationship("PartnerWithdrawal", back_populates="partner", lazy="dynamic")


class PartnerReferral(BaseModel):
    """
    Привлечённый клиент (салон).
    """
    __tablename__ = "partner_referrals"
    
    # === Партнёр, который привлёк ===
    partner_id = Column(BigInteger, ForeignKey("partners.id"), nullable=False, index=True)
    
    # === Привлечённый тенант ===
    tenant_id = Column(BigInteger, ForeignKey("tenants.id"), nullable=False, unique=True)
    
    # === Если привлечён через поставщика, кто получает 5% ===
    upstream_partner_id = Column(BigInteger, ForeignKey("partners.id"), nullable=True)
    
    # === Статус ===
    status = Column(String(50), default="pending")  # pending, active, churned
    
    # === Даты ===
    registered_at = Column(DateTime, default=datetime.utcnow)
    first_payment_at = Column(DateTime, nullable=True)
    churned_at = Column(DateTime, nullable=True)
    
    # === Статистика ===
    total_payments = Column(Numeric(12, 2), default=0)
    total_commission_paid = Column(Numeric(12, 2), default=0)
    
    # === Relationships ===
    partner = relationship("Partner", back_populates="referrals", 
                          foreign_keys=[partner_id])
    tenant = relationship("Tenant")


class PartnerCommission(BaseModel):
    """
    Начисление комиссии партнёру.
    """
    __tablename__ = "partner_commissions"
    
    partner_id = Column(BigInteger, ForeignKey("partners.id"), nullable=False, index=True)
    referral_id = Column(BigInteger, ForeignKey("partner_referrals.id"), nullable=False)
    
    # === Тип комиссии ===
    commission_type = Column(String(20), nullable=False)  # first, monthly
    
    # === Суммы ===
    payment_amount = Column(Numeric(12, 2), nullable=False)  # Сумма платежа клиента
    commission_percent = Column(Numeric(5, 2), nullable=False)
    commission_amount = Column(Numeric(12, 2), nullable=False)  # Сумма комиссии
    
    # === Период (для monthly) ===
    period_start = Column(DateTime, nullable=True)
    period_end = Column(DateTime, nullable=True)
    
    # === Статус ===
    status = Column(String(50), default="pending")  # pending, approved, paid
    
    # === Relationships ===
    partner = relationship("Partner", back_populates="commissions")


class PartnerWithdrawal(BaseModel):
    """
    Вывод средств партнёром.
    """
    __tablename__ = "partner_withdrawals"
    
    partner_id = Column(BigInteger, ForeignKey("partners.id"), nullable=False, index=True)
    
    # === Сумма ===
    amount = Column(Numeric(12, 2), nullable=False)
    
    # === Способ вывода ===
    withdrawal_method = Column(String(50), nullable=False)  # card, bank_transfer
    payment_details = Column(JSON, nullable=False)
    
    # === Статус ===
    status = Column(String(50), default="pending")  # pending, processing, completed, rejected
    
    # === Обработка ===
    processed_at = Column(DateTime, nullable=True)
    processed_by_id = Column(BigInteger, nullable=True)
    
    # === Комментарий ===
    notes = Column(Text, nullable=True)
    rejection_reason = Column(Text, nullable=True)
    
    # === Relationships ===
    partner = relationship("Partner", back_populates="withdrawals")


# ==================== ЛИДЫ И ВОРОНКА ПРОДАЖ ====================


class LeadSource(str, enum.Enum):
    """Источники лидов"""
    WEBSITE = "website"
    REFERRAL = "referral"
    SUPPLIER = "supplier"
    TELEGRAM = "telegram"
    WHATSAPP = "whatsapp"
    INSTAGRAM = "instagram"
    PHONE = "phone"
    EMAIL = "email"
    OTHER = "other"


class LeadStatus(str, enum.Enum):
    """Статусы лида"""
    NEW = "new"
    QUALIFIED = "qualified"
    DEMO_SCHEDULED = "demo_scheduled"
    DEMO_COMPLETED = "demo_completed"
    NEGOTIATION = "negotiation"
    WON = "won"
    LOST = "lost"
    NURTURING = "nurturing"


class Lead(BaseModel):
    """
    Лид (потенциальный клиент платформы).
    """
    __tablename__ = "leads"
    
    # === Основная информация ===
    salon_name = Column(String(255), nullable=True)
    contact_name = Column(String(255), nullable=False)
    
    # === Контакты ===
    phone = Column(String(50), nullable=True)
    email = Column(String(255), nullable=True)
    telegram_username = Column(String(100), nullable=True)
    whatsapp_phone = Column(String(50), nullable=True)
    
    # === Источник ===
    source = Column(String(50), nullable=False)
    source_details = Column(String(255), nullable=True)  # UTM, реф. код
    
    # === Партнёр (если реферал) ===
    partner_id = Column(BigInteger, ForeignKey("partners.id"), nullable=True)
    referral_code = Column(String(50), nullable=True)
    
    # === Статус ===
    status = Column(String(50), default=LeadStatus.NEW.value)
    
    # === Квалификация ===
    qualification_score = Column(Integer, default=0)  # 0-100
    
    # === Информация о бизнесе ===
    business_type = Column(String(100), nullable=True)  # Тип салона
    staff_count = Column(Integer, nullable=True)
    monthly_revenue = Column(Numeric(12, 2), nullable=True)
    current_crm = Column(String(100), nullable=True)  # Текущая CRM
    
    # === AI-квалификация ===
    ai_score = Column(Integer, nullable=True)
    ai_analysis = Column(JSON, default=dict)
    ai_recommended_action = Column(String(255), nullable=True)
    
    # === Назначение ===
    assigned_to_id = Column(BigInteger, nullable=True)
    
    # === Демо ===
    demo_scheduled_at = Column(DateTime, nullable=True)
    demo_completed_at = Column(DateTime, nullable=True)
    demo_notes = Column(Text, nullable=True)
    
    # === Конверсия ===
    converted_at = Column(DateTime, nullable=True)
    converted_tenant_id = Column(BigInteger, nullable=True)
    
    # === Причина отказа ===
    lost_reason = Column(String(255), nullable=True)
    lost_at = Column(DateTime, nullable=True)
    
    # === Nurturing ===
    nurturing_stage = Column(Integer, default=0)
    next_followup_at = Column(DateTime, nullable=True)
    
    # === Relationships ===
    partner = relationship("Partner")
    activities = relationship("LeadActivity", back_populates="lead", lazy="dynamic")
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_leads_status', 'status'),
        Index('ix_leads_source', 'source'),
    )


class LeadActivity(BaseModel):
    """
    Активность по лиду.
    """
    __tablename__ = "lead_activities"
    
    lead_id = Column(BigInteger, ForeignKey("leads.id"), nullable=False, index=True)
    
    # === Тип активности ===
    activity_type = Column(String(50), nullable=False)
    # call, email, message, demo, note, status_change, ai_action
    
    # === Описание ===
    description = Column(Text, nullable=False)
    
    # === Кто выполнил ===
    performed_by = Column(String(50), nullable=True)  # user_id, "ai", "system"
    
    # === Результат ===
    outcome = Column(String(100), nullable=True)
    
    # === Следующий шаг ===
    next_action = Column(String(255), nullable=True)
    next_action_at = Column(DateTime, nullable=True)
    
    # === Relationships ===
    lead = relationship("Lead", back_populates="activities")


class LeadMessage(BaseModel):
    """
    Сообщение лиду (автоматическое).
    """
    __tablename__ = "lead_messages"
    
    lead_id = Column(BigInteger, ForeignKey("leads.id"), nullable=False, index=True)
    
    # === Канал ===
    channel = Column(String(50), nullable=False)
    
    # === Контент ===
    content = Column(Text, nullable=False)
    
    # === Статус ===
    status = Column(String(50), default="pending")
    sent_at = Column(DateTime, nullable=True)
    delivered_at = Column(DateTime, nullable=True)
    read_at = Column(DateTime, nullable=True)
    
    # === Ответ ===
    replied_at = Column(DateTime, nullable=True)
    reply_content = Column(Text, nullable=True)
    
    # === AI ===
    is_ai_generated = Column(Boolean, default=False)
    ai_template_id = Column(String(100), nullable=True)


class NurturingCampaign(BaseModel):
    """
    Кампания прогрева лидов.
    """
    __tablename__ = "nurturing_campaigns"
    
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # === Условия входа ===
    entry_conditions = Column(JSON, default=dict)
    # {"status": "nurturing", "days_since_lost": 30}
    
    # === Шаги кампании ===
    steps = Column(JSON, default=list)
    # [{"day": 0, "channel": "email", "template": "..."}, ...]
    
    # === Статус ===
    is_active = Column(Boolean, default=True)
    
    # === Статистика ===
    total_enrolled = Column(Integer, default=0)
    total_converted = Column(Integer, default=0)
    conversion_rate = Column(Numeric(5, 2), nullable=True)
