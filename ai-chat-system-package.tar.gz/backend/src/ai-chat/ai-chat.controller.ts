import { Controller, Post, Get, Put, Delete, Body, Param, Query, UseGuards } from '@nestjs/common';
import { AdminChatService } from './admin-chat.service';
import { ClientChatService } from './client-chat.service';
import { ScenarioService } from './scenario.service';
import { ConversationContextService } from './conversation-context.service';

/**
 * AI Chat Controller
 * 
 * API endpoints для AI-чат системы:
 * - Админ-чат (для владельцев)
 * - Клиентский чат (для клиентов)
 * - Управление сценариями
 * - Статистика диалогов
 */

@Controller('ai-chat')
export class AiChatController {
  constructor(
    private adminChatService: AdminChatService,
    private clientChatService: ClientChatService,
    private scenarioService: ScenarioService,
    private contextService: ConversationContextService,
  ) {}

  /**
   * POST /ai-chat/admin/message
   * Отправить сообщение в админ-чат
   */
  @Post('admin/message')
  async sendAdminMessage(
    @Body() body: {
      businessId: string;
      userId: string;
      message: string;
      channel: string;
      channelUserId: string;
    },
  ): Promise<{ reply: string }> {
    const reply = await this.adminChatService.processMessage(
      body.businessId,
      body.userId,
      body.message,
      body.channel,
      body.channelUserId,
    );

    return { reply };
  }

  /**
   * POST /ai-chat/client/message
   * Отправить сообщение в клиентский чат
   */
  @Post('client/message')
  async sendClientMessage(
    @Body() body: {
      businessId: string;
      message: string;
      channel: string;
      channelUserId: string;
    },
  ): Promise<{ reply: string }> {
    const reply = await this.clientChatService.processMessage(
      body.businessId,
      body.message,
      body.channel,
      body.channelUserId,
    );

    return { reply };
  }

  /**
   * GET /ai-chat/scenarios/:businessId
   * Получить все сценарии бизнеса
   */
  @Get('scenarios/:businessId')
  async getScenarios(@Param('businessId') businessId: string) {
    return this.scenarioService.getScenarios(businessId);
  }

  /**
   * GET /ai-chat/scenarios/:businessId/active
   * Получить активный сценарий
   */
  @Get('scenarios/:businessId/active')
  async getActiveScenario(@Param('businessId') businessId: string) {
    return this.scenarioService.getActiveScenario(businessId);
  }

  /**
   * POST /ai-chat/scenarios/:businessId
   * Создать новый сценарий
   */
  @Post('scenarios/:businessId')
  async createScenario(
    @Param('businessId') businessId: string,
    @Body() data: any,
  ) {
    return this.scenarioService.createScenario(businessId, data);
  }

  /**
   * PUT /ai-chat/scenarios/:businessId/:scenarioId
   * Обновить сценарий
   */
  @Put('scenarios/:businessId/:scenarioId')
  async updateScenario(
    @Param('businessId') businessId: string,
    @Param('scenarioId') scenarioId: string,
    @Body() updates: any,
  ) {
    return this.scenarioService.updateScenario(scenarioId, businessId, updates);
  }

  /**
   * DELETE /ai-chat/scenarios/:businessId/:scenarioId
   * Удалить сценарий
   */
  @Delete('scenarios/:businessId/:scenarioId')
  async deleteScenario(
    @Param('businessId') businessId: string,
    @Param('scenarioId') scenarioId: string,
  ) {
    await this.scenarioService.deleteScenario(scenarioId, businessId);
    return { success: true };
  }

  /**
   * POST /ai-chat/scenarios/:businessId/:scenarioId/activate
   * Активировать сценарий
   */
  @Post('scenarios/:businessId/:scenarioId/activate')
  async activateScenario(
    @Param('businessId') businessId: string,
    @Param('scenarioId') scenarioId: string,
  ) {
    await this.scenarioService.activateScenario(scenarioId, businessId);
    return { success: true };
  }

  /**
   * POST /ai-chat/scenarios/:businessId/default
   * Создать сценарий по умолчанию
   */
  @Post('scenarios/:businessId/default')
  async createDefaultScenario(
    @Param('businessId') businessId: string,
    @Body() body: { template?: 'formal' | 'friendly' | 'professional' },
  ) {
    return this.scenarioService.createDefaultScenario(businessId, body.template);
  }

  /**
   * GET /ai-chat/conversations/:businessId/stats
   * Получить статистику диалогов
   */
  @Get('conversations/:businessId/stats')
  async getConversationStats(@Param('businessId') businessId: string) {
    return this.contextService.getConversationStats(businessId);
  }

  /**
   * GET /ai-chat/conversations/:businessId/client/:clientId/history
   * Получить историю диалогов клиента
   */
  @Get('conversations/:businessId/client/:clientId/history')
  async getClientHistory(
    @Param('businessId') businessId: string,
    @Param('clientId') clientId: string,
    @Query('limit') limit?: string,
  ) {
    return this.contextService.getClientConversationHistory(
      businessId,
      clientId,
      limit ? parseInt(limit) : 10,
    );
  }

  /**
   * GET /ai-chat/memory/:businessId/client/:clientId
   * Получить память клиента
   */
  @Get('memory/:businessId/client/:clientId')
  async getClientMemory(
    @Param('businessId') businessId: string,
    @Param('clientId') clientId: string,
  ) {
    return this.contextService.getClientMemory(businessId, clientId);
  }

  /**
   * PUT /ai-chat/memory/:businessId/client/:clientId
   * Обновить память клиента
   */
  @Put('memory/:businessId/client/:clientId')
  async updateClientMemory(
    @Param('businessId') businessId: string,
    @Param('clientId') clientId: string,
    @Body() updates: any,
  ) {
    await this.contextService.updateClientMemory(businessId, clientId, updates);
    return { success: true };
  }

  /**
   * POST /ai-chat/conversations/:conversationId/complete
   * Завершить диалог
   */
  @Post('conversations/:conversationId/complete')
  async completeConversation(@Param('conversationId') conversationId: string) {
    await this.contextService.completeConversation(conversationId);
    return { success: true };
  }
}
