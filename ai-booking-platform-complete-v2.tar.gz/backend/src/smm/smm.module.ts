import { Module } from '@nestjs/common';
import { SMMService } from './smm.service';
import { ContentGeneratorService } from './content-generator.service';
import { SMMController } from './smm.controller';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [SMMController],
  providers: [SMMService, ContentGeneratorService],
  exports: [SMMService, ContentGeneratorService],
})
export class SMMModule {}
