#!/bin/bash

# AI-Booking Platform - Automated Setup Script
# For macOS and Linux

set -e

echo "🚀 AI-Booking Platform - Automated Setup"
echo "=========================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Functions
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo -e "ℹ $1"
}

# Check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Step 1: Check Node.js
echo "Step 1: Checking Node.js..."
if command_exists node; then
    NODE_VERSION=$(node --version)
    print_success "Node.js is installed: $NODE_VERSION"
else
    print_error "Node.js is not installed"
    print_info "Please install Node.js 18+ from: https://nodejs.org/"
    exit 1
fi

# Step 2: Check pnpm
echo ""
echo "Step 2: Checking pnpm..."
if command_exists pnpm; then
    PNPM_VERSION=$(pnpm --version)
    print_success "pnpm is installed: $PNPM_VERSION"
else
    print_warning "pnpm is not installed. Installing..."
    npm install -g pnpm
    print_success "pnpm installed successfully"
fi

# Step 3: Check Docker
echo ""
echo "Step 3: Checking Docker..."
if command_exists docker; then
    DOCKER_VERSION=$(docker --version)
    print_success "Docker is installed: $DOCKER_VERSION"
    
    # Check if Docker is running
    if docker info >/dev/null 2>&1; then
        print_success "Docker is running"
    else
        print_error "Docker is not running"
        print_info "Please start Docker Desktop or Docker daemon"
        exit 1
    fi
else
    print_error "Docker is not installed"
    print_info "Please install Docker from: https://www.docker.com/products/docker-desktop/"
    exit 1
fi

# Step 4: Navigate to backend directory
echo ""
echo "Step 4: Setting up backend..."
cd backend

# Step 5: Create .env file if not exists
echo ""
echo "Step 5: Setting up environment variables..."
if [ ! -f .env ]; then
    print_info "Creating .env file from template..."
    cp .env.example .env
    
    # Generate JWT secret
    JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
    ENCRYPTION_KEY=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
    
    # Update .env with generated secrets
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        sed -i '' "s/JWT_SECRET=.*/JWT_SECRET=$JWT_SECRET/" .env
        sed -i '' "s/ENCRYPTION_KEY=.*/ENCRYPTION_KEY=$ENCRYPTION_KEY/" .env
    else
        # Linux
        sed -i "s/JWT_SECRET=.*/JWT_SECRET=$JWT_SECRET/" .env
        sed -i "s/ENCRYPTION_KEY=.*/ENCRYPTION_KEY=$ENCRYPTION_KEY/" .env
    fi
    
    print_success ".env file created with generated secrets"
    print_warning "Please add your TELEGRAM_CLIENT_BOT_TOKEN, TELEGRAM_ADMIN_BOT_TOKEN, and OPENAI_API_KEY to .env"
else
    print_success ".env file already exists"
fi

# Step 6: Start Docker containers
echo ""
echo "Step 6: Starting PostgreSQL and Redis..."
cd ..
docker compose up -d postgres redis

# Wait for PostgreSQL to be ready
print_info "Waiting for PostgreSQL to be ready..."
sleep 5

if docker compose ps | grep -q "postgres.*running"; then
    print_success "PostgreSQL is running"
else
    print_error "PostgreSQL failed to start"
    print_info "Check logs with: docker compose logs postgres"
    exit 1
fi

if docker compose ps | grep -q "redis.*running"; then
    print_success "Redis is running"
else
    print_error "Redis failed to start"
    print_info "Check logs with: docker compose logs redis"
    exit 1
fi

# Step 7: Install dependencies
echo ""
echo "Step 7: Installing dependencies..."
cd backend
pnpm install
print_success "Dependencies installed"

# Step 8: Generate Prisma Client
echo ""
echo "Step 8: Generating Prisma Client..."
npx prisma generate
print_success "Prisma Client generated"

# Step 9: Run migrations
echo ""
echo "Step 9: Running database migrations..."
npx prisma migrate dev --name init
print_success "Database migrations completed"

# Step 10: Final instructions
echo ""
echo "=========================================="
echo -e "${GREEN}✅ Setup completed successfully!${NC}"
echo "=========================================="
echo ""
echo "Next steps:"
echo "1. Edit backend/.env and add your API keys:"
echo "   - TELEGRAM_CLIENT_BOT_TOKEN"
echo "   - TELEGRAM_ADMIN_BOT_TOKEN"
echo "   - OPENAI_API_KEY"
echo ""
echo "2. Start the application:"
echo "   cd backend"
echo "   pnpm run start:dev"
echo ""
echo "3. Open http://localhost:3000 in your browser"
echo ""
echo "📚 For more information, see INSTALLATION-GUIDE-RU.md"
echo ""
