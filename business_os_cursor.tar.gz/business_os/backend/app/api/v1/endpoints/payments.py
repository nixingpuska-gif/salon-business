"""
Business OS - Payments API
Управление платежами
"""

from datetime import datetime, date
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import select, func, and_, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.models.payment import Payment, PaymentItem, Refund
from app.models.appointment import Appointment
from app.models.client import Client

router = APIRouter()


# === Schemas ===

class PaymentItemCreate(BaseModel):
    item_type: str = "service"
    service_id: Optional[int] = None
    product_id: Optional[int] = None
    name: str
    quantity: int = 1
    unit_price: float
    discount_amount: float = 0
    staff_id: Optional[int] = None


class PaymentCreate(BaseModel):
    client_id: int
    appointment_id: Optional[int] = None
    branch_id: int
    payment_method: str = "cash"
    items: List[PaymentItemCreate]
    discount_amount: float = 0
    discount_reason: Optional[str] = None
    tip_amount: float = 0
    notes: Optional[str] = None


class PaymentResponse(BaseModel):
    id: int
    tenant_id: int
    branch_id: int
    client_id: int
    appointment_id: Optional[int]
    payment_number: Optional[str]
    subtotal: float
    discount_amount: float
    tip_amount: float
    total_amount: float
    payment_method: str
    status: str
    paid_at: Optional[datetime]
    notes: Optional[str]
    created_at: datetime
    
    class Config:
        from_attributes = True


class PaymentListResponse(BaseModel):
    items: List[PaymentResponse]
    total: int
    page: int
    page_size: int


class RefundCreate(BaseModel):
    amount: float
    reason: str
    refund_method: Optional[str] = None


class RefundResponse(BaseModel):
    id: int
    payment_id: int
    amount: float
    reason: str
    status: str
    refund_method: Optional[str]
    created_at: datetime
    
    class Config:
        from_attributes = True


class PaymentStats(BaseModel):
    total_revenue: float
    total_payments: int
    avg_payment: float
    cash_amount: float
    card_amount: float
    transfer_amount: float
    tips_amount: float
    refunds_amount: float


# === Endpoints ===

@router.get("", response_model=PaymentListResponse)
async def list_payments(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    client_id: Optional[int] = None,
    branch_id: Optional[int] = None,
    payment_method: Optional[str] = None,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """Получить список платежей"""
    tenant_id = 1
    query = select(Payment).where(Payment.tenant_id == tenant_id, Payment.is_deleted == False)
    
    if date_from:
        query = query.where(Payment.created_at >= datetime.combine(date_from, datetime.min.time()))
    if date_to:
        query = query.where(Payment.created_at <= datetime.combine(date_to, datetime.max.time()))
    if client_id:
        query = query.where(Payment.client_id == client_id)
    if branch_id:
        query = query.where(Payment.branch_id == branch_id)
    if payment_method:
        query = query.where(Payment.payment_method == payment_method)
    if status:
        query = query.where(Payment.status == status)
    
    count_query = select(func.count()).select_from(query.subquery())
    total = (await db.execute(count_query)).scalar() or 0
    
    query = query.order_by(desc(Payment.created_at)).offset((page - 1) * page_size).limit(page_size)
    result = await db.execute(query)
    
    return PaymentListResponse(
        items=[PaymentResponse.model_validate(p) for p in result.scalars().all()],
        total=total, page=page, page_size=page_size
    )


@router.get("/stats", response_model=PaymentStats)
async def get_payment_stats(
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    branch_id: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
):
    """Получить статистику по платежам"""
    tenant_id = 1
    base_filter = and_(Payment.tenant_id == tenant_id, Payment.status == "completed", Payment.is_deleted == False)
    
    if date_from:
        base_filter = and_(base_filter, Payment.created_at >= datetime.combine(date_from, datetime.min.time()))
    if date_to:
        base_filter = and_(base_filter, Payment.created_at <= datetime.combine(date_to, datetime.max.time()))
    if branch_id:
        base_filter = and_(base_filter, Payment.branch_id == branch_id)
    
    revenue = (await db.execute(select(func.sum(Payment.total_amount)).where(base_filter))).scalar() or 0
    total_payments = (await db.execute(select(func.count()).where(base_filter))).scalar() or 0
    cash = (await db.execute(select(func.sum(Payment.total_amount)).where(and_(base_filter, Payment.payment_method == "cash")))).scalar() or 0
    card = (await db.execute(select(func.sum(Payment.total_amount)).where(and_(base_filter, Payment.payment_method == "card")))).scalar() or 0
    transfer = (await db.execute(select(func.sum(Payment.total_amount)).where(and_(base_filter, Payment.payment_method == "transfer")))).scalar() or 0
    tips = (await db.execute(select(func.sum(Payment.tip_amount)).where(base_filter))).scalar() or 0
    
    refund_filter = and_(Refund.tenant_id == tenant_id, Refund.status == "completed", Refund.is_deleted == False)
    refunds = (await db.execute(select(func.sum(Refund.amount)).where(refund_filter))).scalar() or 0
    
    return PaymentStats(
        total_revenue=float(revenue), total_payments=total_payments,
        avg_payment=float(revenue) / total_payments if total_payments > 0 else 0,
        cash_amount=float(cash), card_amount=float(card), transfer_amount=float(transfer),
        tips_amount=float(tips), refunds_amount=float(refunds)
    )


@router.get("/{payment_id}", response_model=PaymentResponse)
async def get_payment(payment_id: int, db: AsyncSession = Depends(get_db)):
    """Получить платёж по ID"""
    tenant_id = 1
    query = select(Payment).where(Payment.id == payment_id, Payment.tenant_id == tenant_id, Payment.is_deleted == False)
    payment = (await db.execute(query)).scalar_one_or_none()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    return PaymentResponse.model_validate(payment)


@router.post("", response_model=PaymentResponse, status_code=201)
async def create_payment(data: PaymentCreate, db: AsyncSession = Depends(get_db)):
    """Создать платёж"""
    tenant_id = 1
    
    subtotal = sum(item.unit_price * item.quantity - item.discount_amount for item in data.items)
    total_amount = subtotal - data.discount_amount + data.tip_amount
    
    count = (await db.execute(select(func.count()).where(Payment.tenant_id == tenant_id))).scalar() or 0
    payment_number = f"PAY-{tenant_id}-{count + 1:06d}"
    
    payment = Payment(
        tenant_id=tenant_id, branch_id=data.branch_id, client_id=data.client_id,
        appointment_id=data.appointment_id, payment_number=payment_number,
        subtotal=subtotal, discount_amount=data.discount_amount, discount_reason=data.discount_reason,
        tip_amount=data.tip_amount, total_amount=total_amount, payment_method=data.payment_method,
        status="completed", paid_at=datetime.utcnow(), notes=data.notes
    )
    db.add(payment)
    await db.flush()
    
    for item_data in data.items:
        total_price = item_data.unit_price * item_data.quantity - item_data.discount_amount
        item = PaymentItem(
            tenant_id=tenant_id, payment_id=payment.id, item_type=item_data.item_type,
            service_id=item_data.service_id, product_id=item_data.product_id, name=item_data.name,
            quantity=item_data.quantity, unit_price=item_data.unit_price,
            discount_amount=item_data.discount_amount, total_price=total_price, staff_id=item_data.staff_id
        )
        db.add(item)
    
    client = (await db.execute(select(Client).where(Client.id == data.client_id))).scalar_one_or_none()
    if client:
        client.total_spent = float(client.total_spent or 0) + total_amount
    
    if data.appointment_id:
        appt = (await db.execute(select(Appointment).where(Appointment.id == data.appointment_id))).scalar_one_or_none()
        if appt:
            appt.is_paid = True
            appt.payment_id = payment.id
    
    await db.commit()
    await db.refresh(payment)
    return PaymentResponse.model_validate(payment)


@router.post("/{payment_id}/refund", response_model=RefundResponse)
async def create_refund(payment_id: int, data: RefundCreate, db: AsyncSession = Depends(get_db)):
    """Создать возврат"""
    tenant_id = 1
    payment = (await db.execute(select(Payment).where(Payment.id == payment_id, Payment.tenant_id == tenant_id, Payment.is_deleted == False))).scalar_one_or_none()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    if data.amount > float(payment.total_amount):
        raise HTTPException(status_code=400, detail="Refund amount exceeds payment amount")
    
    refund = Refund(
        tenant_id=tenant_id, payment_id=payment_id, amount=data.amount,
        reason=data.reason, refund_method=data.refund_method or payment.payment_method, status="completed"
    )
    db.add(refund)
    
    payment.status = "refunded" if data.amount >= float(payment.total_amount) else "partially_refunded"
    
    client = (await db.execute(select(Client).where(Client.id == payment.client_id))).scalar_one_or_none()
    if client:
        client.total_spent = max(0, float(client.total_spent or 0) - data.amount)
    
    await db.commit()
    await db.refresh(refund)
    return RefundResponse.model_validate(refund)


@router.get("/{payment_id}/items")
async def get_payment_items(payment_id: int, db: AsyncSession = Depends(get_db)):
    """Получить позиции платежа"""
    tenant_id = 1
    if not (await db.execute(select(Payment).where(Payment.id == payment_id, Payment.tenant_id == tenant_id))).scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Payment not found")
    
    items = (await db.execute(select(PaymentItem).where(PaymentItem.payment_id == payment_id, PaymentItem.is_deleted == False))).scalars().all()
    return {
        "payment_id": payment_id,
        "items": [{"id": i.id, "item_type": i.item_type, "name": i.name, "quantity": i.quantity,
                   "unit_price": float(i.unit_price), "discount_amount": float(i.discount_amount or 0),
                   "total_price": float(i.total_price), "staff_id": i.staff_id} for i in items]
    }


@router.delete("/{payment_id}", status_code=204)
async def delete_payment(payment_id: int, db: AsyncSession = Depends(get_db)):
    """Удалить платёж"""
    tenant_id = 1
    payment = (await db.execute(select(Payment).where(Payment.id == payment_id, Payment.tenant_id == tenant_id, Payment.is_deleted == False))).scalar_one_or_none()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    payment.is_deleted = True
    payment.deleted_at = datetime.utcnow()
    await db.commit()
