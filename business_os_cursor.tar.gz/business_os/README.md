# Business OS — Операционная система для салонов красоты

Полнофункциональная CRM-система для управления салонами красоты с AI-инсайтами, онлайн-записью и аналитикой.

## 🚀 Быстрый старт

### Требования

- **Python** 3.11+
- **Node.js** 18+ (рекомендуется 22)
- **pnpm** (или npm/yarn)

### 1. Установка зависимостей Backend

```bash
cd backend
pip install -r requirements.txt
```

### 2. Установка зависимостей Frontend

```bash
cd frontend
pnpm install
```

### 3. Инициализация базы данных с демо-данными

```bash
cd backend
python seed_sync.py
```

### 4. Запуск Backend

```bash
cd backend
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### 5. Запуск Frontend

```bash
cd frontend
pnpm dev
```

### 6. Открыть в браузере

- **Frontend**: http://localhost:5173
- **Backend API**: http://localhost:8000
- **API Docs**: http://localhost:8000/docs

## 🔐 Демо-доступ

- **Email**: demo@business-os.ru
- **Пароль**: demo123456

## 📁 Структура проекта

```
business_os/
├── backend/                 # FastAPI Backend
│   ├── app/
│   │   ├── api/v1/         # API endpoints
│   │   │   └── endpoints/  # Модули API
│   │   ├── core/           # Конфигурация, безопасность
│   │   ├── models/         # SQLAlchemy модели
│   │   ├── schemas/        # Pydantic схемы
│   │   └── services/       # Бизнес-логика
│   ├── main.py             # Точка входа
│   ├── requirements.txt    # Python зависимости
│   └── seed_sync.py        # Скрипт заполнения демо-данными
│
├── frontend/               # React + Vite Frontend
│   ├── src/
│   │   ├── components/     # React компоненты
│   │   ├── pages/          # Страницы приложения
│   │   ├── contexts/       # React контексты (Auth, Theme)
│   │   ├── config/         # Конфигурация API
│   │   └── App.tsx         # Главный компонент
│   ├── package.json        # Node.js зависимости
│   └── vite.config.ts      # Конфигурация Vite
│
└── docs/                   # Документация
```

## 🛠 Технологии

### Backend
- **FastAPI** — современный Python веб-фреймворк
- **SQLAlchemy** — ORM для работы с БД
- **SQLite** — база данных (легко заменить на PostgreSQL)
- **Pydantic** — валидация данных
- **JWT** — аутентификация

### Frontend
- **React 18** — UI библиотека
- **TypeScript** — типизация
- **Vite** — сборщик
- **TailwindCSS** — стилизация
- **React Router** — маршрутизация
- **Lucide React** — иконки

## 📋 Модули системы

| Модуль | Описание |
|--------|----------|
| **Дашборд** | Обзор бизнеса, метрики, здоровье бизнеса |
| **AI-инсайты** | Прогнозы, рекомендации, автоматизация |
| **Клиенты** | CRM, сегментация, история визитов |
| **Записи** | Календарь, онлайн-запись |
| **Сотрудники** | Управление командой, загрузка |
| **Услуги** | Каталог услуг, категории, цены |
| **Склад** | Учёт материалов, остатки |
| **Лояльность** | Бонусы, уровни, сертификаты |
| **Отчёты** | Аналитика, AI-вердикт |
| **Настройки** | Параметры салона |

## 🔧 Конфигурация

### Backend (.env)

```env
DATABASE_URL=sqlite:///./business_os.db
SECRET_KEY=your-secret-key-here
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=7
```

### Frontend (.env)

```env
VITE_API_URL=http://localhost:8000
```

## 📝 API Endpoints

### Аутентификация
- `POST /api/v1/auth/login` — вход
- `POST /api/v1/auth/refresh` — обновление токена
- `POST /api/v1/auth/logout` — выход

### Клиенты
- `GET /api/v1/clients` — список клиентов
- `POST /api/v1/clients` — создать клиента
- `GET /api/v1/clients/{id}` — получить клиента
- `PUT /api/v1/clients/{id}` — обновить клиента

### Записи
- `GET /api/v1/appointments` — список записей
- `POST /api/v1/appointments` — создать запись

### Услуги
- `GET /api/v1/services` — список услуг
- `GET /api/v1/service-categories` — категории услуг

### Сотрудники
- `GET /api/v1/staff` — список сотрудников

### Дашборд
- `GET /api/v1/dashboard/overview` — обзор метрик
- `GET /api/v1/dashboard/business-health` — здоровье бизнеса

### AI-инсайты
- `GET /api/v1/ai-insights` — рекомендации AI

### Отчёты
- `GET /api/v1/reports/weekly` — еженедельный отчёт

## 🐛 Устранение проблем

### База данных пустая
```bash
cd backend
rm -f business_os.db
python seed_sync.py
```

### Ошибка CORS
Проверьте, что backend запущен на порту 8000 и frontend настроен на правильный API URL.

### Ошибка авторизации
Убедитесь, что выполнен `seed_sync.py` для создания демо-пользователя.

## 📄 Лицензия

MIT License

## 👥 Контакты

- Email: support@business-os.com
