# Database Schema Design

## Overview

This document defines the PostgreSQL database schema for the AI-booking platform. The schema follows a **multi-tenant** approach with `business_id` as the tenant identifier in most tables.

---

## Entity Relationship Diagram (Textual)

```
businesses (1) ──< (N) users
businesses (1) ──< (N) services
businesses (1) ──< (N) schedules
businesses (1) ──< (N) clients
businesses (1) ──< (N) bookings
businesses (1) ──< (N) channels
businesses (1) ──< (N) content_plans
businesses (1) ──< (N) posts

clients (1) ──< (N) bookings
clients (1) ──< (N) client_notes
clients (1) ──< (N) conversations

services (1) ──< (N) bookings

bookings (1) ──< (N) notifications
```

---

## Schema Definition (PostgreSQL DDL)

### 1. businesses

Stores information about each business (master/studio) using the platform.

```sql
CREATE TABLE businesses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Basic info
    name VARCHAR(255) NOT NULL,
    business_type VARCHAR(100) NOT NULL, -- 'hairdresser', 'nail_tech', 'cosmetologist', 'trainer', etc.
    description TEXT,
    
    -- Contact
    phone VARCHAR(20),
    email VARCHAR(255),
    address TEXT,
    timezone VARCHAR(50) DEFAULT 'Europe/Moscow',
    
    -- Subscription
    subscription_tier VARCHAR(50) DEFAULT 'free', -- 'free', 'basic', 'pro'
    subscription_status VARCHAR(50) DEFAULT 'active', -- 'active', 'suspended', 'cancelled'
    trial_ends_at TIMESTAMP,
    
    -- Settings
    settings JSONB DEFAULT '{}', -- { locale: 'ru', currency: 'RUB', reminderTimes: [24, 2], etc. }
    
    -- Metadata
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    deleted_at TIMESTAMP -- soft delete
);

CREATE INDEX idx_businesses_subscription ON businesses(subscription_status, subscription_tier);
CREATE INDEX idx_businesses_deleted ON businesses(deleted_at) WHERE deleted_at IS NULL;
```

### 2. users

Users who manage businesses (masters, admins). One user can manage multiple businesses.

```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Auth
    telegram_id BIGINT UNIQUE, -- Primary auth method for MVP
    whatsapp_id VARCHAR(100),
    email VARCHAR(255),
    password_hash VARCHAR(255), -- for future web login
    
    -- Profile
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    avatar_url TEXT,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    last_login_at TIMESTAMP
);

CREATE UNIQUE INDEX idx_users_telegram ON users(telegram_id) WHERE telegram_id IS NOT NULL;
CREATE INDEX idx_users_email ON users(email) WHERE email IS NOT NULL;
```

### 3. business_users (join table)

Links users to businesses with roles.

```sql
CREATE TABLE business_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    role VARCHAR(50) DEFAULT 'owner', -- 'owner', 'admin', 'staff'
    
    created_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(business_id, user_id)
);

CREATE INDEX idx_business_users_business ON business_users(business_id);
CREATE INDEX idx_business_users_user ON business_users(user_id);
```

### 4. services

Services offered by each business.

```sql
CREATE TABLE services (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Service details
    name VARCHAR(255) NOT NULL, -- 'Маникюр классический', 'Стрижка мужская', etc.
    description TEXT,
    duration_minutes INTEGER NOT NULL, -- 60, 90, 120, etc.
    price DECIMAL(10, 2), -- in business currency
    
    -- Metadata
    is_active BOOLEAN DEFAULT TRUE,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_services_business ON services(business_id, is_active);
```

### 5. schedules

Defines working hours, breaks, and exceptions for each business.

```sql
CREATE TABLE schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Schedule type
    type VARCHAR(50) NOT NULL, -- 'working_hours', 'break', 'vacation', 'holiday'
    
    -- Recurrence
    recurrence_rule VARCHAR(255), -- RRULE format (e.g., 'FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR')
    
    -- Time range
    start_date DATE NOT NULL,
    end_date DATE, -- NULL for indefinite
    start_time TIME, -- e.g., '09:00' for working_hours
    end_time TIME, -- e.g., '18:00'
    
    -- Days of week (for working_hours)
    days_of_week INTEGER[], -- [1,2,3,4,5] = Mon-Fri (ISO standard)
    
    -- Metadata
    description TEXT, -- e.g., "Отпуск в Сочи"
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_schedules_business ON schedules(business_id, type);
CREATE INDEX idx_schedules_dates ON schedules(start_date, end_date);
```

### 6. clients

End customers who book appointments.

```sql
CREATE TABLE clients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Identity
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    phone VARCHAR(20), -- primary identifier
    email VARCHAR(255),
    
    -- Channel identifiers
    telegram_id BIGINT,
    whatsapp_id VARCHAR(100),
    instagram_id VARCHAR(100),
    
    -- Profile
    avatar_url TEXT,
    preferences JSONB DEFAULT '{}', -- { preferredTime: 'evening', allergies: [], etc. }
    tags TEXT[], -- ['vip', 'regular', 'new']
    
    -- Stats
    total_bookings INTEGER DEFAULT 0,
    total_spent DECIMAL(10, 2) DEFAULT 0,
    last_visit_at TIMESTAMP,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(business_id, phone)
);

CREATE INDEX idx_clients_business ON clients(business_id);
CREATE INDEX idx_clients_telegram ON clients(telegram_id) WHERE telegram_id IS NOT NULL;
CREATE INDEX idx_clients_phone ON clients(business_id, phone);
```

### 7. client_notes

Notes about clients (added by master or AI).

```sql
CREATE TABLE client_notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    note TEXT NOT NULL,
    created_by UUID REFERENCES users(id), -- NULL if created by AI
    
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_client_notes_client ON client_notes(client_id);
```

### 8. bookings

Appointment bookings.

```sql
CREATE TABLE bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    service_id UUID REFERENCES services(id) ON DELETE SET NULL,
    
    -- Appointment details
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    
    -- Status
    status VARCHAR(50) DEFAULT 'confirmed', -- 'pending', 'confirmed', 'completed', 'cancelled', 'no_show'
    
    -- Pricing
    price DECIMAL(10, 2), -- snapshot at booking time
    paid BOOLEAN DEFAULT FALSE,
    
    -- Notes
    client_notes TEXT, -- notes from client
    master_notes TEXT, -- notes from master
    
    -- Source
    source_channel VARCHAR(50), -- 'telegram', 'whatsapp', 'instagram', 'web', 'import'
    
    -- Calendar integration
    calendar_event_id VARCHAR(255), -- Google Calendar event ID
    
    -- Metadata
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    cancelled_at TIMESTAMP,
    cancelled_reason TEXT
);

CREATE INDEX idx_bookings_business ON bookings(business_id, start_time);
CREATE INDEX idx_bookings_client ON bookings(client_id);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_bookings_time_range ON bookings(business_id, start_time, end_time);
```

### 9. channels

Channel credentials and settings for each business.

```sql
CREATE TABLE channels (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Channel type
    type VARCHAR(50) NOT NULL, -- 'telegram_client', 'telegram_admin', 'whatsapp', 'instagram'
    
    -- Credentials (encrypted)
    credentials JSONB NOT NULL, -- { botToken: '...', phoneNumberId: '...', etc. }
    
    -- Settings
    is_active BOOLEAN DEFAULT TRUE,
    settings JSONB DEFAULT '{}', -- channel-specific settings
    
    -- Metadata
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(business_id, type)
);

CREATE INDEX idx_channels_business ON channels(business_id, is_active);
```

### 10. conversations

Tracks conversation history for AI context.

```sql
CREATE TABLE conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    client_id UUID REFERENCES clients(id) ON DELETE CASCADE, -- NULL for admin conversations
    
    -- Conversation type
    type VARCHAR(50) NOT NULL, -- 'client', 'admin'
    channel VARCHAR(50) NOT NULL, -- 'telegram', 'whatsapp', 'instagram'
    
    -- External IDs
    external_chat_id VARCHAR(255) NOT NULL, -- Telegram chat_id, WhatsApp conversation_id, etc.
    
    -- Context
    context JSONB DEFAULT '{}', -- { currentIntent: 'BOOK', extractedEntities: {}, etc. }
    
    -- Metadata
    last_message_at TIMESTAMP DEFAULT NOW(),
    created_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(business_id, channel, external_chat_id)
);

CREATE INDEX idx_conversations_business ON conversations(business_id);
CREATE INDEX idx_conversations_client ON conversations(client_id);
```

### 11. messages

Individual messages in conversations (for AI context and history).

```sql
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    
    -- Message details
    role VARCHAR(50) NOT NULL, -- 'user', 'assistant', 'system'
    content TEXT NOT NULL,
    attachments JSONB, -- [{ type: 'image', url: '...' }]
    
    -- AI metadata
    intent VARCHAR(100), -- detected intent
    entities JSONB, -- extracted entities
    function_calls JSONB, -- functions called by AI
    
    -- Metadata
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_messages_conversation ON messages(conversation_id, created_at DESC);
```

### 12. notifications

Scheduled notifications (reminders, alerts).

```sql
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    booking_id UUID REFERENCES bookings(id) ON DELETE CASCADE,
    client_id UUID NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    
    -- Notification details
    type VARCHAR(50) NOT NULL, -- 'reminder_24h', 'reminder_2h', 'cancellation', 'rescheduled'
    channel VARCHAR(50) NOT NULL, -- 'telegram', 'whatsapp', 'instagram', 'sms'
    
    -- Content
    message TEXT NOT NULL,
    
    -- Scheduling
    scheduled_for TIMESTAMP NOT NULL,
    sent_at TIMESTAMP,
    
    -- Status
    status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'sent', 'failed'
    error_message TEXT,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_notifications_scheduled ON notifications(status, scheduled_for);
CREATE INDEX idx_notifications_business ON notifications(business_id);
```

### 13. content_plans

SMM content plans.

```sql
CREATE TABLE content_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Plan details
    title VARCHAR(255) NOT NULL,
    description TEXT,
    
    -- Schedule
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    posts_per_week INTEGER DEFAULT 3,
    
    -- Topics
    topics TEXT[], -- ['уход за волосами', 'мои работы', 'советы']
    
    -- Autopilot
    autopilot_enabled BOOLEAN DEFAULT FALSE,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_content_plans_business ON content_plans(business_id);
```

### 14. posts

Individual SMM posts.

```sql
CREATE TABLE posts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    content_plan_id UUID REFERENCES content_plans(id) ON DELETE SET NULL,
    
    -- Post content
    title VARCHAR(255),
    content TEXT NOT NULL,
    hashtags TEXT[],
    
    -- Media
    media_urls TEXT[], -- URLs to photos/videos in MinIO
    
    -- Publishing
    platforms VARCHAR(50)[], -- ['instagram', 'telegram']
    scheduled_for TIMESTAMP,
    published_at TIMESTAMP,
    
    -- Status
    status VARCHAR(50) DEFAULT 'draft', -- 'draft', 'scheduled', 'published', 'failed'
    
    -- Approval (if not autopilot)
    requires_approval BOOLEAN DEFAULT TRUE,
    approved_at TIMESTAMP,
    
    -- External IDs
    external_ids JSONB, -- { instagram: 'post_id', telegram: 'message_id' }
    
    -- Analytics
    analytics JSONB DEFAULT '{}', -- { views: 0, likes: 0, comments: 0, shares: 0 }
    
    -- Metadata
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_posts_business ON posts(business_id, status);
CREATE INDEX idx_posts_scheduled ON posts(status, scheduled_for);
```

### 15. calendar_integrations

Calendar integration settings.

```sql
CREATE TABLE calendar_integrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Integration type
    provider VARCHAR(50) NOT NULL, -- 'google', 'caldav', 'outlook'
    
    -- Credentials (encrypted)
    credentials JSONB NOT NULL, -- { accessToken: '...', refreshToken: '...', calendarId: '...' }
    
    -- Settings
    sync_direction VARCHAR(50) DEFAULT 'bidirectional', -- 'one_way', 'bidirectional'
    is_active BOOLEAN DEFAULT TRUE,
    
    -- Sync status
    last_sync_at TIMESTAMP,
    last_sync_status VARCHAR(50), -- 'success', 'failed'
    last_sync_error TEXT,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    
    UNIQUE(business_id, provider)
);

CREATE INDEX idx_calendar_integrations_business ON calendar_integrations(business_id, is_active);
```

### 16. import_batches

Tracks import operations.

```sql
CREATE TABLE import_batches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID NOT NULL REFERENCES businesses(id) ON DELETE CASCADE,
    
    -- Import type
    type VARCHAR(50) NOT NULL, -- 'text', 'ocr'
    
    -- Source
    source_data JSONB, -- { text: '...', imageUrls: [...] }
    
    -- Parsed results
    parsed_data JSONB, -- [{ date, time, clientName, service, raw }]
    
    -- Status
    status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'preview', 'confirmed', 'failed'
    
    -- Results
    bookings_created INTEGER DEFAULT 0,
    clients_created INTEGER DEFAULT 0,
    
    -- Metadata
    created_at TIMESTAMP DEFAULT NOW(),
    confirmed_at TIMESTAMP
);

CREATE INDEX idx_import_batches_business ON import_batches(business_id, status);
```

---

## Indexes Summary

All critical queries are covered by indexes:

- **Business isolation:** All tables with `business_id` have indexes
- **Time-based queries:** Bookings, schedules, notifications indexed by time
- **Client lookups:** Phone, Telegram ID, WhatsApp ID indexed
- **Channel routing:** Conversations indexed by channel + external_chat_id
- **SMM scheduling:** Posts indexed by status + scheduled_for

---

## Multi-Tenancy Implementation

**Prisma Middleware Example:**

```typescript
// Auto-inject businessId in all queries
prisma.$use(async (params, next) => {
  const businessId = getBusinessIdFromContext(); // from request context
  
  if (!businessId) {
    throw new Error('Business context required');
  }
  
  // Add businessId filter to all queries
  if (params.model && MULTI_TENANT_MODELS.includes(params.model)) {
    if (params.action === 'findMany' || params.action === 'findFirst') {
      params.args.where = {
        ...params.args.where,
        businessId,
      };
    }
    
    if (params.action === 'create' || params.action === 'createMany') {
      if (Array.isArray(params.args.data)) {
        params.args.data = params.args.data.map(item => ({
          ...item,
          businessId,
        }));
      } else {
        params.args.data = {
          ...params.args.data,
          businessId,
        };
      }
    }
  }
  
  return next(params);
});
```

---

## Row-Level Security (PostgreSQL)

Additional safety layer:

```sql
-- Enable RLS on all multi-tenant tables
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
-- ... etc.

-- Create policy (example for bookings)
CREATE POLICY business_isolation ON bookings
    USING (business_id = current_setting('app.current_business_id')::uuid);
```

**Set business context in application:**

```typescript
await prisma.$executeRaw`SET app.current_business_id = ${businessId}`;
```

---

## Data Encryption

**Sensitive fields to encrypt:**

- `channels.credentials` (bot tokens, API keys)
- `calendar_integrations.credentials` (OAuth tokens)
- `users.password_hash` (already hashed, but additional encryption layer)

**Implementation:**

```sql
-- Using pgcrypto extension
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Encrypt on insert
INSERT INTO channels (business_id, type, credentials)
VALUES (
    '...',
    'telegram_client',
    pgp_sym_encrypt('{"botToken":"..."}', current_setting('app.encryption_key'))
);

-- Decrypt on select
SELECT 
    id,
    type,
    pgp_sym_decrypt(credentials::bytea, current_setting('app.encryption_key')) as credentials
FROM channels;
```

---

## Sample Data

```sql
-- Insert sample business
INSERT INTO businesses (id, name, business_type, phone, timezone)
VALUES (
    '550e8400-e29b-41d4-a716-446655440000',
    'Салон красоты "Элегант"',
    'nail_tech',
    '+79991234567',
    'Europe/Moscow'
);

-- Insert sample user
INSERT INTO users (id, telegram_id, first_name, last_name)
VALUES (
    '660e8400-e29b-41d4-a716-446655440000',
    123456789,
    'Анна',
    'Иванова'
);

-- Link user to business
INSERT INTO business_users (business_id, user_id, role)
VALUES (
    '550e8400-e29b-41d4-a716-446655440000',
    '660e8400-e29b-41d4-a716-446655440000',
    'owner'
);

-- Insert services
INSERT INTO services (business_id, name, duration_minutes, price)
VALUES 
    ('550e8400-e29b-41d4-a716-446655440000', 'Маникюр классический', 60, 1500),
    ('550e8400-e29b-41d4-a716-446655440000', 'Педикюр', 90, 2000),
    ('550e8400-e29b-41d4-a716-446655440000', 'Наращивание ногтей', 120, 3500);

-- Insert working hours (Mon-Fri 9-18)
INSERT INTO schedules (business_id, type, recurrence_rule, start_date, start_time, end_time, days_of_week)
VALUES (
    '550e8400-e29b-41d4-a716-446655440000',
    'working_hours',
    'FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR',
    '2025-01-01',
    '09:00',
    '18:00',
    ARRAY[1,2,3,4,5]
);
```

---

## Migration Strategy

**Using Prisma Migrate:**

1. Define schema in `schema.prisma`
2. Generate migration: `npx prisma migrate dev --name init`
3. Apply to production: `npx prisma migrate deploy`

**Rollback plan:**

- Keep migrations in version control
- Test migrations on staging first
- Use transactions for data migrations
- Maintain backup before each migration

---

## Next Steps

- **Phase 3:** Implement core backend services using this schema
- **Phase 4:** Add calendar integration tables and logic
- **Phase 5:** Implement channel gateway and bot logic
- Continue through remaining phases...

---

**Document Version:** 1.0  
**Last Updated:** 2025-11-23
