import { Module } from '@nestjs/common';
import { FeatureFlagsService } from './feature-flags.service';
import { FeatureFlagsController } from './feature-flags.controller';
import { FeatureAccessGuard } from './feature-access.guard';
import { PrismaModule } from '../prisma/prisma.module';

@Module({
  imports: [PrismaModule],
  controllers: [FeatureFlagsController],
  providers: [FeatureFlagsService, FeatureAccessGuard],
  exports: [FeatureFlagsService, FeatureAccessGuard],
})
export class FeatureFlagsModule {}
