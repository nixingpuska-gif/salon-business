"""
Business OS - Appointments Endpoints
Appointment management - core booking functionality
"""

from datetime import datetime, date, time, timedelta
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, or_

from app.core.database import get_db
from app.models import Appointment, AppointmentStatus, Client, Staff, Service

router = APIRouter()


# ==================== SCHEMAS ====================

class AppointmentServiceItem(BaseModel):
    service_id: int
    price: Optional[float] = None
    duration_minutes: Optional[int] = None


class AppointmentCreate(BaseModel):
    client_id: int
    staff_id: int
    branch_id: Optional[int] = None
    services: List[AppointmentServiceItem]
    start_time: datetime
    notes: Optional[str] = None
    source: Optional[str] = "manual"


class AppointmentUpdate(BaseModel):
    staff_id: Optional[int] = None
    start_time: Optional[datetime] = None
    notes: Optional[str] = None
    status: Optional[str] = None


class AppointmentResponse(BaseModel):
    id: int
    client_id: int
    staff_id: int
    service_id: int
    branch_id: int
    date: date
    start_time: time
    end_time: time
    duration_minutes: int
    status: str
    price: float
    final_price: float
    source: str = "admin"
    confirmed_at: Optional[datetime] = None
    created_at: datetime
    
    class Config:
        from_attributes = True


class AppointmentListResponse(BaseModel):
    items: List[AppointmentResponse]
    total: int
    page: int
    page_size: int


# ==================== ENDPOINTS ====================

@router.get("", response_model=AppointmentListResponse)
async def list_appointments(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    staff_id: Optional[int] = None,
    client_id: Optional[int] = None,
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """List appointments with filtering"""
    tenant_id = 1
    
    if not start_date:
        start_date = date.today()
    if not end_date:
        end_date = start_date + timedelta(days=1)
    
    query = select(Appointment).where(
        and_(
            Appointment.tenant_id == tenant_id,
            Appointment.is_deleted == False,
            Appointment.date >= start_date,
            Appointment.date <= end_date,
        )
    )
    
    if staff_id:
        query = query.where(Appointment.staff_id == staff_id)
    if client_id:
        query = query.where(Appointment.client_id == client_id)
    if status:
        query = query.where(Appointment.status == status)
    
    count_result = await db.execute(select(func.count()).select_from(query.subquery()))
    total = count_result.scalar() or 0
    
    query = query.order_by(Appointment.start_time.asc())
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)
    
    result = await db.execute(query)
    appointments = result.scalars().all()
    
    return AppointmentListResponse(
        items=[AppointmentResponse.model_validate(a) for a in appointments],
        total=total,
        page=page,
        page_size=page_size,
    )


@router.post("", response_model=AppointmentResponse, status_code=status.HTTP_201_CREATED)
async def create_appointment(
    data: AppointmentCreate,
    db: AsyncSession = Depends(get_db),
):
    """Create new appointment"""
    tenant_id = 1
    
    # Calculate duration and price from services
    total_duration = 0
    total_price = 0
    
    for service_item in data.services:
        result = await db.execute(
            select(Service).where(
                and_(Service.id == service_item.service_id, Service.tenant_id == tenant_id)
            )
        )
        service = result.scalar_one_or_none()
        if service:
            total_duration += service_item.duration_minutes or service.duration_minutes
            total_price += service_item.price or float(service.price)
    
    if total_duration == 0:
        total_duration = 60  # Default 1 hour
    
    end_time = data.start_time + timedelta(minutes=total_duration)
    
    # Check conflicts
    conflict_query = select(Appointment).where(
        and_(
            Appointment.tenant_id == tenant_id,
            Appointment.staff_id == data.staff_id,
            Appointment.status.notin_([AppointmentStatus.CANCELLED.value]),
            or_(
                and_(Appointment.start_time <= data.start_time, Appointment.end_time > data.start_time),
                and_(Appointment.start_time < end_time, Appointment.end_time >= end_time),
            )
        )
    )
    result = await db.execute(conflict_query)
    if result.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Time slot is not available")
    
    appointment = Appointment(
        tenant_id=tenant_id,
        client_id=data.client_id,
        staff_id=data.staff_id,
        branch_id=data.branch_id,
        start_time=data.start_time,
        end_time=end_time,
        duration_minutes=total_duration,
        total_price=total_price,
        notes=data.notes,
        source=data.source,
        status=AppointmentStatus.SCHEDULED.value,
    )
    db.add(appointment)
    await db.commit()
    await db.refresh(appointment)
    
    return AppointmentResponse.model_validate(appointment)


@router.get("/available-slots")
async def get_available_slots(
    staff_id: int,
    date: date,
    duration_minutes: int = 60,
    db: AsyncSession = Depends(get_db),
):
    """Get available time slots"""
    tenant_id = 1
    
    day_start = datetime.combine(date, time(9, 0))
    day_end = datetime.combine(date, time(21, 0))
    
    result = await db.execute(
        select(Appointment).where(
            and_(
                Appointment.tenant_id == tenant_id,
                Appointment.staff_id == staff_id,
                Appointment.start_time >= day_start,
                Appointment.start_time < day_end,
                Appointment.status.notin_([AppointmentStatus.CANCELLED.value])
            )
        ).order_by(Appointment.start_time)
    )
    existing = result.scalars().all()
    
    slots = []
    current = day_start
    
    while current + timedelta(minutes=duration_minutes) <= day_end:
        slot_end = current + timedelta(minutes=duration_minutes)
        is_available = True
        
        for appt in existing:
            if not (slot_end <= appt.start_time or current >= appt.end_time):
                is_available = False
                break
        
        if is_available:
            slots.append({"start_time": current.isoformat(), "end_time": slot_end.isoformat()})
        
        current += timedelta(minutes=30)
    
    return {"slots": slots}


@router.get("/{appointment_id}", response_model=AppointmentResponse)
async def get_appointment(appointment_id: int, db: AsyncSession = Depends(get_db)):
    """Get appointment by ID"""
    tenant_id = 1
    result = await db.execute(
        select(Appointment).where(and_(Appointment.id == appointment_id, Appointment.tenant_id == tenant_id))
    )
    appointment = result.scalar_one_or_none()
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    return AppointmentResponse.model_validate(appointment)


@router.patch("/{appointment_id}", response_model=AppointmentResponse)
async def update_appointment(appointment_id: int, data: AppointmentUpdate, db: AsyncSession = Depends(get_db)):
    """Update appointment"""
    tenant_id = 1
    result = await db.execute(
        select(Appointment).where(and_(Appointment.id == appointment_id, Appointment.tenant_id == tenant_id))
    )
    appointment = result.scalar_one_or_none()
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    update_data = data.model_dump(exclude_unset=True)
    if "start_time" in update_data:
        update_data["end_time"] = update_data["start_time"] + timedelta(minutes=appointment.duration_minutes)
    
    for field, value in update_data.items():
        setattr(appointment, field, value)
    
    await db.commit()
    await db.refresh(appointment)
    return AppointmentResponse.model_validate(appointment)


@router.post("/{appointment_id}/confirm")
async def confirm_appointment(appointment_id: int, db: AsyncSession = Depends(get_db)):
    """Confirm appointment"""
    tenant_id = 1
    result = await db.execute(
        select(Appointment).where(and_(Appointment.id == appointment_id, Appointment.tenant_id == tenant_id))
    )
    appointment = result.scalar_one_or_none()
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    appointment.is_confirmed = True
    appointment.confirmed_at = datetime.utcnow()
    await db.commit()
    return {"message": "Confirmed"}


@router.post("/{appointment_id}/cancel")
async def cancel_appointment(appointment_id: int, reason: Optional[str] = None, db: AsyncSession = Depends(get_db)):
    """Cancel appointment"""
    tenant_id = 1
    result = await db.execute(
        select(Appointment).where(and_(Appointment.id == appointment_id, Appointment.tenant_id == tenant_id))
    )
    appointment = result.scalar_one_or_none()
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    appointment.status = AppointmentStatus.CANCELLED.value
    appointment.cancellation_reason = reason
    appointment.cancelled_at = datetime.utcnow()
    await db.commit()
    return {"message": "Cancelled"}


@router.post("/{appointment_id}/complete")
async def complete_appointment(appointment_id: int, db: AsyncSession = Depends(get_db)):
    """Complete appointment"""
    tenant_id = 1
    result = await db.execute(
        select(Appointment).where(and_(Appointment.id == appointment_id, Appointment.tenant_id == tenant_id))
    )
    appointment = result.scalar_one_or_none()
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    appointment.status = AppointmentStatus.COMPLETED.value
    appointment.completed_at = datetime.utcnow()
    await db.commit()
    return {"message": "Completed"}


@router.post("/{appointment_id}/no-show")
async def mark_no_show(appointment_id: int, db: AsyncSession = Depends(get_db)):
    """Mark as no-show"""
    tenant_id = 1
    result = await db.execute(
        select(Appointment).where(and_(Appointment.id == appointment_id, Appointment.tenant_id == tenant_id))
    )
    appointment = result.scalar_one_or_none()
    if not appointment:
        raise HTTPException(status_code=404, detail="Appointment not found")
    
    appointment.status = AppointmentStatus.NO_SHOW.value
    await db.commit()
    return {"message": "Marked as no-show"}
