# AI-Booking Platform MVP

## 🎯 Project Overview

An **AI-first SaaS booking platform** for service professionals (hairdressers, nail technicians, cosmetologists, trainers) in Russia, with plans for international expansion.

### Key Features

- **Dual AI Bots:**
  - **Client Bot:** Natural language booking, rescheduling, cancellations
  - **Admin Bot:** Business management, analytics, SMM automation

- **Multi-Channel Support:**
  - Telegram (client + admin bots)
  - WhatsApp Business
  - Instagram Direct

- **Smart Scheduling:**
  - Automatic slot generation
  - Conflict detection
  - Google Calendar integration

- **AI-Powered SMM:**
  - Content plan generation
  - Automated post creation
  - Auto-publishing to Instagram + Telegram

- **Intelligent Import:**
  - Import appointments from photos (OCR)
  - Parse text-based notes

---

## 📚 Documentation

| Document | Description |
|----------|-------------|
| [01-architecture-proposal.md](./01-architecture-proposal.md) | Complete system architecture and technology stack |
| [02-database-schema.md](./02-database-schema.md) | PostgreSQL schema with all tables and relationships |
| [03-implementation-guide.md](./03-implementation-guide.md) | Step-by-step implementation guide with code samples |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  Telegram │ WhatsApp │ Instagram │ Web (future)                 │
└────────────────────────┬────────────────────────────────────────┘
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│               Channel Gateway + UI Adapter                       │
└────────────────────────┬────────────────────────────────────────┘
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│          AI Orchestrator (Client AI + Admin AI)                  │
│          - Intent Detection                                      │
│          - Function Calling                                      │
│          - Context Management                                    │
└────────────────────────┬────────────────────────────────────────┘
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Core Backend (NestJS)                         │
│  Business │ CRM │ Scheduling │ Booking │ Calendar │ SMM │ ...   │
└────────────────────────┬────────────────────────────────────────┘
                         ▼
┌─────────────────────────────────────────────────────────────────┐
│  PostgreSQL │ Redis (Queue) │ MinIO (Storage)                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start

### Prerequisites

- Node.js 22+
- PostgreSQL 15+
- Redis 7+
- pnpm (package manager)

### Installation

```bash
# Clone repository
git clone <repository-url>
cd ai-booking-platform

# Install dependencies
cd backend
pnpm install

# Setup environment
cp .env.example .env
# Edit .env with your database credentials and API keys

# Run database migrations
npx prisma migrate dev

# Generate Prisma Client
npx prisma generate

# Start development server
pnpm run start:dev
```

### Docker Setup (Recommended)

```bash
# Start all services
docker-compose up -d

# Run migrations
docker-compose exec backend npx prisma migrate deploy

# View logs
docker-compose logs -f backend
```

---

## 🛠️ Tech Stack

| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Backend** | NestJS + TypeScript | Enterprise-grade Node.js framework |
| **Database** | PostgreSQL 15 | Relational database with JSONB support |
| **ORM** | Prisma | Type-safe database client |
| **Queue** | Redis + BullMQ | Background jobs and scheduling |
| **AI** | OpenAI GPT-4 | Natural language understanding |
| **Bots** | Grammy (Telegram) | Bot framework |
| **Calendar** | Google Calendar API | Appointment synchronization |
| **Storage** | MinIO (S3-compatible) | Object storage for photos |

---

## 📦 Project Structure

```
ai-booking-platform/
├── backend/
│   ├── src/
│   │   ├── prisma/           # Database client
│   │   ├── business/         # Business management
│   │   ├── client/           # Client CRM
│   │   ├── service/          # Service management
│   │   ├── schedule/         # Scheduling & slots
│   │   ├── booking/          # Booking management
│   │   ├── calendar/         # Calendar integration
│   │   ├── telegram/         # Telegram bots
│   │   ├── whatsapp/         # WhatsApp bot
│   │   ├── instagram/        # Instagram bot
│   │   ├── ai/               # AI Orchestrator
│   │   ├── import/           # Import service
│   │   ├── smm/              # SMM automation
│   │   ├── queue/            # Background workers
│   │   └── channel-gateway/  # Channel abstraction
│   ├── prisma/
│   │   └── schema.prisma     # Database schema
│   ├── test/                 # E2E tests
│   └── package.json
├── docs/
│   ├── 01-architecture-proposal.md
│   ├── 02-database-schema.md
│   └── 03-implementation-guide.md
├── docker-compose.yml
└── README.md
```

---

## 🔑 Environment Variables

```env
# Database
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/ai_booking_platform"

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# OpenAI
OPENAI_API_KEY=sk-...

# Telegram
TELEGRAM_CLIENT_BOT_TOKEN=...
TELEGRAM_ADMIN_BOT_TOKEN=...

# WhatsApp Business API
WHATSAPP_PHONE_NUMBER_ID=...
WHATSAPP_ACCESS_TOKEN=...

# Instagram (Meta Graph API)
INSTAGRAM_ACCESS_TOKEN=...

# Google Calendar
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...

# App
PORT=3000
NODE_ENV=development
JWT_SECRET=your-secret-key
ENCRYPTION_KEY=your-encryption-key
```

---

## 🧪 Testing

```bash
# Unit tests
pnpm run test

# E2E tests
pnpm run test:e2e

# Test coverage
pnpm run test:cov
```

---

## 📊 Database Schema

### Core Tables

- **businesses** - Business profiles
- **users** - Platform users (masters/admins)
- **business_users** - User-business relationships
- **services** - Services offered by businesses
- **schedules** - Working hours, breaks, vacations
- **clients** - End customers
- **bookings** - Appointments
- **channels** - Channel credentials (Telegram, WhatsApp, Instagram)
- **conversations** - Chat history for AI context
- **messages** - Individual messages
- **notifications** - Scheduled reminders
- **content_plans** - SMM content plans
- **posts** - Social media posts
- **calendar_integrations** - Google Calendar settings
- **import_batches** - Import operations

See [02-database-schema.md](./02-database-schema.md) for complete schema.

---

## 🤖 AI Capabilities

### Client AI Agent

**Intents:**
- `BOOK` - New appointment
- `RESCHEDULE` - Change appointment time
- `CANCEL` - Cancel appointment
- `ASK_PRICE` - Service pricing
- `ASK_ADDRESS` - Location information
- `FAQ` - General questions

**Tools:**
- `getAvailableSlots` - Fetch free time slots
- `createBooking` - Create appointment
- `rescheduleBooking` - Change appointment
- `cancelBooking` - Cancel appointment

### Admin AI Agent

**Intents:**
- `MANAGE_SCHEDULE` - Update working hours
- `MANAGE_SERVICES` - Add/edit services
- `VIEW_BOOKINGS` - Check appointments
- `IMPORT` - Import existing appointments
- `SMM` - Content generation and posting
- `ANALYTICS` - Business insights

**Tools:**
- `addService` - Create service
- `updateSchedule` - Modify working hours
- `importFromText` - Parse text appointments
- `importFromImages` - OCR + parse photos
- `generateContentPlan` - Create SMM plan
- `generatePost` - Create social media post
- `getAnalytics` - Fetch business metrics

---

## 🌍 Deployment

### Production Checklist

- [ ] Set up PostgreSQL with backups
- [ ] Configure Redis cluster
- [ ] Set up MinIO/S3 for file storage
- [ ] Configure environment variables
- [ ] Set up SSL certificates
- [ ] Configure firewall rules
- [ ] Set up monitoring (Prometheus + Grafana)
- [ ] Configure logging (ELK stack)
- [ ] Set up CI/CD pipeline
- [ ] Configure auto-scaling
- [ ] Set up database replication
- [ ] Configure CDN for static assets

### Recommended Hosting (Russia)

- **Yandex Cloud** - Full compliance with Russian data residency laws
- **VK Cloud** - Alternative Russian cloud provider
- **Self-hosted** - Maximum control and compliance

---

## 📈 Roadmap

### MVP (Weeks 1-4)
- [x] Architecture design
- [x] Database schema
- [ ] Core backend services
- [ ] Telegram bots (client + admin)
- [ ] AI Orchestrator with GPT-4
- [ ] Google Calendar integration
- [ ] Basic import functionality
- [ ] Simple SMM automation
- [ ] Notification queue

### Phase 2 (Months 2-3)
- [ ] WhatsApp Business integration
- [ ] Instagram Direct integration
- [ ] Advanced SMM (autopilot mode)
- [ ] OCR-based import
- [ ] Web admin panel
- [ ] Advanced analytics
- [ ] Payment integration
- [ ] Multi-language support

### Phase 3 (Months 4-6)
- [ ] VK integration
- [ ] Web booking widget
- [ ] Mobile apps (React Native)
- [ ] Advanced AI features (recommendations)
- [ ] Loyalty programs
- [ ] Marketplace (find masters)
- [ ] International expansion

---

## 🤝 Contributing

This is a commercial project. For collaboration inquiries, please contact the project owner.

---

## 📄 License

Proprietary - All rights reserved

---

## 📞 Support

For questions or issues:
- Email: support@ai-booking-platform.com
- Telegram: @ai_booking_support

---

**Built with ❤️ for service professionals in Russia**
