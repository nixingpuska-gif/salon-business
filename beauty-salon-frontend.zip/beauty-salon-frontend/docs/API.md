# API Documentation

Complete API reference for the Beauty Salon Suite backend.

## Base URL
```
http://localhost:3000/api
```

## Authentication

All protected endpoints require a JWT token in the Authorization header:

```
Authorization: Bearer {token}
```

## Response Format

All responses follow this format:

```json
{
  "success": true,
  "data": { /* response data */ },
  "error": null,
  "timestamp": "2024-01-03T12:00:00Z"
}
```

## Endpoints

### Authentication

#### POST /auth/login
Login with email and password.

**Request**:
```json
{
  "email": "admin@salon.ru",
  "password": "password123"
}
```

**Response** (200):
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "usr_123",
      "email": "admin@salon.ru",
      "name": "Admin User",
      "role": "admin"
    },
    "token": "eyJhbGciOiJIUzI1NiIs..."
  }
}
```

#### POST /auth/register
Register a new user.

**Request**:
```json
{
  "email": "user@example.com",
  "password": "password123",
  "name": "John Doe"
}
```

**Response** (201):
```json
{
  "success": true,
  "data": {
    "user": {
      "id": "usr_456",
      "email": "user@example.com",
      "name": "John Doe",
      "role": "user"
    },
    "token": "eyJhbGciOiJIUzI1NiIs..."
  }
}
```

#### GET /auth/me
Get current user (requires auth).

**Response** (200):
```json
{
  "success": true,
  "data": {
    "id": "usr_123",
    "email": "admin@salon.ru",
    "name": "Admin User",
    "role": "admin",
    "createdAt": "2024-01-01T00:00:00Z"
  }
}
```

#### POST /auth/logout
Logout current user (requires auth).

**Response** (200):
```json
{
  "success": true,
  "data": { "message": "Logged out successfully" }
}
```

### Dashboard

#### GET /dashboard/stats
Get dashboard statistics (requires auth).

**Query Parameters**:
- `period` (optional): 'day', 'week', 'month', 'year' (default: 'month')

**Response** (200):
```json
{
  "success": true,
  "data": {
    "totalRevenue": 12500.00,
    "appointmentsCount": 48,
    "clientsCount": 324,
    "staffCount": 12,
    "averageRating": 4.8,
    "occupancyRate": 85.5
  }
}
```

#### GET /dashboard/revenue
Get revenue chart data (requires auth).

**Query Parameters**:
- `period` (optional): 'day', 'week', 'month', 'year'
- `startDate` (optional): ISO8601 date
- `endDate` (optional): ISO8601 date

**Response** (200):
```json
{
  "success": true,
  "data": [
    {
      "date": "2024-01-01",
      "revenue": 500.00,
      "appointments": 5
    }
  ]
}
```

#### GET /dashboard/appointments
Get appointment chart data (requires auth).

**Response** (200):
```json
{
  "success": true,
  "data": [
    {
      "date": "2024-01-01",
      "scheduled": 5,
      "completed": 4,
      "cancelled": 1
    }
  ]
}
```

### Services

#### GET /services
List all services (requires auth).

**Query Parameters**:
- `skip` (optional): Number of records to skip (default: 0)
- `take` (optional): Number of records to take (default: 10)
- `search` (optional): Search by name or description

**Response** (200):
```json
{
  "success": true,
  "data": [
    {
      "id": "srv_123",
      "name": "Haircut",
      "description": "Professional haircut",
      "price": 45.00,
      "duration": 30,
      "category": "hair",
      "createdAt": "2024-01-01T00:00:00Z"
    }
  ],
  "total": 25
}
```

#### POST /services
Create a new service (requires auth, admin role).

**Request**:
```json
{
  "name": "Haircut",
  "description": "Professional haircut",
  "price": 45.00,
  "duration": 30,
  "category": "hair"
}
```

**Response** (201):
```json
{
  "success": true,
  "data": {
    "id": "srv_123",
    "name": "Haircut",
    "description": "Professional haircut",
    "price": 45.00,
    "duration": 30,
    "category": "hair",
    "createdAt": "2024-01-03T12:00:00Z"
  }
}
```

#### GET /services/:id
Get service by ID (requires auth).

**Response** (200):
```json
{
  "success": true,
  "data": {
    "id": "srv_123",
    "name": "Haircut",
    "description": "Professional haircut",
    "price": 45.00,
    "duration": 30,
    "category": "hair",
    "createdAt": "2024-01-01T00:00:00Z"
  }
}
```

#### PUT /services/:id
Update service (requires auth, admin role).

**Request**:
```json
{
  "name": "Premium Haircut",
  "price": 55.00
}
```

**Response** (200):
```json
{
  "success": true,
  "data": {
    "id": "srv_123",
    "name": "Premium Haircut",
    "price": 55.00
  }
}
```

#### DELETE /services/:id
Delete service (requires auth, admin role).

**Response** (200):
```json
{
  "success": true,
  "data": { "message": "Service deleted" }
}
```

### Staff

#### GET /staff
List all staff members (requires auth).

**Query Parameters**:
- `skip` (optional): Number of records to skip
- `take` (optional): Number of records to take
- `role` (optional): Filter by role

**Response** (200):
```json
{
  "success": true,
  "data": [
    {
      "id": "stf_123",
      "name": "John Doe",
      "email": "john@salon.com",
      "phone": "+1234567890",
      "role": "stylist",
      "startDate": "2024-01-01T00:00:00Z"
    }
  ],
  "total": 12
}
```

#### POST /staff
Create new staff member (requires auth, admin role).

**Request**:
```json
{
  "name": "Jane Smith",
  "email": "jane@salon.com",
  "phone": "+1234567890",
  "role": "stylist",
  "startDate": "2024-01-03T00:00:00Z"
}
```

**Response** (201):
```json
{
  "success": true,
  "data": {
    "id": "stf_456",
    "name": "Jane Smith",
    "email": "jane@salon.com",
    "phone": "+1234567890",
    "role": "stylist",
    "startDate": "2024-01-03T00:00:00Z"
  }
}
```

#### PUT /staff/:id
Update staff member (requires auth, admin role).

**Request**:
```json
{
  "phone": "+9876543210"
}
```

**Response** (200):
```json
{
  "success": true,
  "data": {
    "id": "stf_456",
    "phone": "+9876543210"
  }
}
```

#### DELETE /staff/:id
Delete staff member (requires auth, admin role).

**Response** (200):
```json
{
  "success": true,
  "data": { "message": "Staff member deleted" }
}
```

### Appointments

#### GET /appointments
List all appointments (requires auth).

**Query Parameters**:
- `skip` (optional): Number of records to skip
- `take` (optional): Number of records to take
- `status` (optional): Filter by status
- `startDate` (optional): Filter by start date
- `endDate` (optional): Filter by end date

**Response** (200):
```json
{
  "success": true,
  "data": [
    {
      "id": "apt_123",
      "clientId": "cli_456",
      "clientName": "John Client",
      "serviceId": "srv_789",
      "serviceName": "Haircut",
      "staffId": "stf_012",
      "staffName": "Jane Stylist",
      "startTime": "2024-01-10T14:00:00Z",
      "endTime": "2024-01-10T14:30:00Z",
      "status": "scheduled",
      "notes": "Regular haircut",
      "createdAt": "2024-01-03T12:00:00Z"
    }
  ],
  "total": 48
}
```

#### POST /appointments
Create new appointment (requires auth).

**Request**:
```json
{
  "clientId": "cli_456",
  "serviceId": "srv_789",
  "staffId": "stf_012",
  "startTime": "2024-01-10T14:00:00Z",
  "notes": "Regular haircut"
}
```

**Response** (201):
```json
{
  "success": true,
  "data": {
    "id": "apt_123",
    "clientId": "cli_456",
    "serviceId": "srv_789",
    "staffId": "stf_012",
    "startTime": "2024-01-10T14:00:00Z",
    "status": "scheduled",
    "createdAt": "2024-01-03T12:00:00Z"
  }
}
```

#### PUT /appointments/:id
Update appointment (requires auth).

**Request**:
```json
{
  "status": "confirmed",
  "notes": "Updated notes"
}
```

**Response** (200):
```json
{
  "success": true,
  "data": {
    "id": "apt_123",
    "status": "confirmed",
    "notes": "Updated notes"
  }
}
```

#### DELETE /appointments/:id
Cancel appointment (requires auth).

**Response** (200):
```json
{
  "success": true,
  "data": { "message": "Appointment cancelled" }
}
```

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid request parameters",
    "details": [
      {
        "field": "email",
        "message": "Invalid email format"
      }
    ]
  }
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "error": {
    "code": "UNAUTHORIZED",
    "message": "Authentication required"
  }
}
```

### 403 Forbidden
```json
{
  "success": false,
  "error": {
    "code": "FORBIDDEN",
    "message": "Insufficient permissions"
  }
}
```

### 404 Not Found
```json
{
  "success": false,
  "error": {
    "code": "NOT_FOUND",
    "message": "Resource not found"
  }
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "error": {
    "code": "INTERNAL_ERROR",
    "message": "An unexpected error occurred"
  }
}
```

## Rate Limiting

- **Limit**: 100 requests per minute
- **Header**: `X-RateLimit-Remaining`
- **Reset**: `X-RateLimit-Reset`

## Pagination

Use `skip` and `take` parameters for pagination:

```
GET /appointments?skip=0&take=10
```

## Sorting

Use `sort` parameter to sort results:

```
GET /appointments?sort=startTime:desc
```

## Filtering

Use query parameters to filter:

```
GET /appointments?status=scheduled&startDate=2024-01-01
```

---

**Last Updated**: January 3, 2024  
**Version**: 1.0.0
