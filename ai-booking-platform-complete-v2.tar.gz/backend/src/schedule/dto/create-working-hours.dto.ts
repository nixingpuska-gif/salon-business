import { IsArray, IsString, IsNotEmpty, IsOptional, IsDateString } from 'class-validator';

export class CreateWorkingHoursDto {
  @IsString()
  @IsNotEmpty()
  businessId: string;

  @IsArray()
  daysOfWeek: number[];

  @IsString()
  @IsNotEmpty()
  startTime: string; // "09:00"

  @IsString()
  @IsNotEmpty()
  endTime: string; // "18:00"

  @IsDateString()
  @IsOptional()
  startDate?: string;

  @IsDateString()
  @IsOptional()
  endDate?: string;
}
