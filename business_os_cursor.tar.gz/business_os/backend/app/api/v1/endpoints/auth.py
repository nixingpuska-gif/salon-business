"""
Business OS - Authentication Endpoints
Registration, login, token refresh, password reset
"""

from datetime import datetime, timedelta
from typing import Optional
from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.database import get_db
from app.core.security import (
    create_access_token,
    create_refresh_token,
    verify_password,
    get_password_hash,
    verify_token,
)
from app.core.config import settings
from app.models import User, RefreshToken, Tenant, TenantStatus

router = APIRouter()


# ==================== SCHEMAS ====================

class UserRegister(BaseModel):
    """Registration request"""
    email: EmailStr
    password: str
    first_name: str
    last_name: Optional[str] = None
    phone: Optional[str] = None
    salon_name: str
    referral_code: Optional[str] = None


class UserLogin(BaseModel):
    """Login request"""
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    """Token response"""
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class RefreshTokenRequest(BaseModel):
    """Refresh token request"""
    refresh_token: str


class PasswordResetRequest(BaseModel):
    """Password reset request"""
    email: EmailStr


class PasswordResetConfirm(BaseModel):
    """Password reset confirmation"""
    token: str
    new_password: str


class UserResponse(BaseModel):
    """User response"""
    id: int
    email: str
    first_name: str
    last_name: Optional[str]
    role: str
    tenant_id: Optional[int]
    is_verified: bool
    
    class Config:
        from_attributes = True


# ==================== ENDPOINTS ====================

@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(
    data: UserRegister,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    Register new user and create tenant (salon).
    
    - Creates new user account
    - Creates new tenant (salon)
    - Sends verification email
    - Returns access and refresh tokens
    """
    # Check if email already exists
    result = await db.execute(select(User).where(User.email == data.email))
    if result.scalar_one_or_none():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email already registered"
        )
    
    # Check if phone already exists
    if data.phone:
        result = await db.execute(select(User).where(User.phone == data.phone))
        if result.scalar_one_or_none():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Phone already registered"
            )
    
    # Create tenant (salon)
    import re
    slug = re.sub(r'[^a-z0-9]+', '-', data.salon_name.lower()).strip('-')
    # Ensure unique slug
    slug = f"{slug}-{int(datetime.utcnow().timestamp())}"
    
    tenant = Tenant(
        name=data.salon_name,
        slug=slug,
        email=data.email,
        phone=data.phone,
        subscription_status=TenantStatus.TRIAL,
        subscription_expires_at=datetime.utcnow() + timedelta(days=14),
    )
    db.add(tenant)
    await db.flush()  # Get tenant ID
    
    # Create user
    user = User(
        email=data.email,
        phone=data.phone,
        password_hash=get_password_hash(data.password),
        first_name=data.first_name,
        last_name=data.last_name,
        owned_tenant_id=tenant.id,
    )
    db.add(user)
    await db.flush()
    
    # Update tenant owner
    tenant.owner_id = user.id
    
    # Handle referral code
    if data.referral_code:
        # TODO: Process referral
        pass
    
    # Create tokens
    access_token = create_access_token(
        subject=str(user.id),
        tenant_id=tenant.id,
        role="owner",
    )
    refresh_token = create_refresh_token(subject=str(user.id), tenant_id=tenant.id)
    
    # Save refresh token
    token_record = RefreshToken(
        user_id=user.id,
        token_hash=get_password_hash(refresh_token),
        expires_at=datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
    )
    db.add(token_record)
    
    await db.commit()
    
    # Send verification email (background)
    # background_tasks.add_task(send_verification_email, user.email, user.id)
    
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


@router.post("/login", response_model=TokenResponse)
async def login(
    data: UserLogin,
    db: AsyncSession = Depends(get_db)
):
    """
    Login with email and password.
    
    Returns access and refresh tokens.
    """
    # Find user
    result = await db.execute(select(User).where(User.email == data.email))
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )
    
    # Check if account is locked
    if user.locked_until and user.locked_until > datetime.utcnow():
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Account is temporarily locked. Try again later."
        )
    
    # Verify password
    if not verify_password(data.password, user.password_hash):
        # Increment failed attempts
        user.failed_login_attempts += 1
        
        # Lock account after 5 failed attempts
        if user.failed_login_attempts >= 5:
            user.locked_until = datetime.utcnow() + timedelta(minutes=30)
        
        await db.commit()
        
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )
    
    # Check if user is active
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Account is deactivated"
        )
    
    # Reset failed attempts
    user.failed_login_attempts = 0
    user.last_login_at = datetime.utcnow()
    
    # Create tokens
    access_token = create_access_token(
        subject=str(user.id),
        tenant_id=user.owned_tenant_id,
        role=user.role or "owner",
    )
    refresh_token = create_refresh_token(subject=str(user.id), tenant_id=user.owned_tenant_id)
    
    # Save refresh token
    token_record = RefreshToken(
        user_id=user.id,
        token_hash=get_password_hash(refresh_token),
        expires_at=datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
    )
    db.add(token_record)
    
    await db.commit()
    
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    data: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Refresh access token using refresh token.
    """
    # Verify refresh token
    payload = verify_token(data.refresh_token, token_type="refresh")
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token"
        )
    
    user_id = int(payload.get("sub"))
    
    # Get user
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive"
        )
    
    # Create new tokens
    access_token = create_access_token(
        subject=str(user.id),
        tenant_id=user.owned_tenant_id,
        role=user.role or "owner",
    )
    new_refresh_token = create_refresh_token(subject=str(user.id), tenant_id=user.owned_tenant_id)
    
    # Save new refresh token
    token_record = RefreshToken(
        user_id=user.id,
        token_hash=get_password_hash(new_refresh_token),
        expires_at=datetime.utcnow() + timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS),
    )
    db.add(token_record)
    await db.commit()
    
    return TokenResponse(
        access_token=access_token,
        refresh_token=new_refresh_token,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


@router.post("/logout")
async def logout(
    data: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Logout and revoke refresh token.
    """
    # In production, we would find and revoke the specific token
    # For now, just return success
    return {"message": "Successfully logged out"}


@router.post("/password-reset/request")
async def request_password_reset(
    data: PasswordResetRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """
    Request password reset email.
    """
    # Find user
    result = await db.execute(select(User).where(User.email == data.email))
    user = result.scalar_one_or_none()
    
    # Always return success to prevent email enumeration
    if user:
        # TODO: Generate reset token and send email
        # background_tasks.add_task(send_password_reset_email, user.email, reset_token)
        pass
    
    return {"message": "If the email exists, a reset link has been sent"}


@router.post("/password-reset/confirm")
async def confirm_password_reset(
    data: PasswordResetConfirm,
    db: AsyncSession = Depends(get_db)
):
    """
    Confirm password reset with token.
    """
    # TODO: Verify reset token and update password
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Password reset not yet implemented"
    )


@router.get("/me", response_model=UserResponse)
async def get_current_user(
    # current_user: User = Depends(get_current_active_user)
):
    """
    Get current authenticated user.
    """
    # TODO: Implement with proper dependency
    raise HTTPException(
        status_code=status.HTTP_501_NOT_IMPLEMENTED,
        detail="Not yet implemented"
    )
