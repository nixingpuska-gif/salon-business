# 🚀 Быстрый старт: OCR + SMM

## За 10 минут до первого поста

### Шаг 1: Получите OpenAI API Key (2 минуты)

1. Откройте [platform.openai.com](https://platform.openai.com/)
2. **API keys** → **Create new secret key**
3. Скопируйте ключ

### Шаг 2: Настройте переменные окружения (1 минута)

Добавьте в `backend/.env`:
```env
# OpenAI (обязательно для OCR и генерации контента)
OPENAI_API_KEY=sk-...

# Instagram (опционально, для постинга)
INSTAGRAM_ACCESS_TOKEN=EAAGxxxxxx...
INSTAGRAM_ACCOUNT_ID=123456789

# Facebook (опционально, для постинга)
FACEBOOK_PAGE_ACCESS_TOKEN=EAAGxxxxxx...
FACEBOOK_PAGE_ID=987654321
```

### Шаг 3: Запустите сервер (30 секунд)

```bash
cd backend
npm run start:dev
```

Проверьте логи:
```
[OCRService] OCR Service initialized with OpenAI Vision API
[ContentGeneratorService] Content Generator Service initialized
[SMMService] SMM Service initialized
```

---

## 🧪 Тест 1: OCR (Импорт записей)

### Подготовьте тестовое изображение

Создайте скриншот с текстом:
```
Иван Иванов
+79991234567
1 декабря, 14:00
Маникюр
```

Загрузите на любой хостинг изображений или используйте URL.

### Импортируйте записи

```bash
curl -X POST http://localhost:3000/ocr/import \
  -H "Content-Type: application/json" \
  -d '{
    "imageUrl": "https://example.com/screenshot.jpg",
    "businessId": "1"
  }'
```

**Ожидаемый результат:**
```json
{
  "success": true,
  "success": 1,
  "failed": 0,
  "errors": [],
  "imported": [
    {
      "id": 123,
      "clientId": "456",
      "serviceId": "789",
      "startTime": "2024-12-01T14:00:00.000Z"
    }
  ]
}
```

✅ **Готово!** Запись импортирована в систему.

---

## 🧪 Тест 2: Генерация контента

### Сгенерируйте пост для Instagram

```bash
curl -X POST http://localhost:3000/smm/generate/instagram \
  -H "Content-Type: application/json" \
  -d '{
    "businessName": "Салон красоты Мария",
    "serviceName": "Маникюр",
    "tone": "friendly"
  }'
```

**Ожидаемый результат:**
```json
{
  "success": true,
  "data": {
    "caption": "Преобразим ваши ручки! 💅✨ Классический маникюр ждёт вас!",
    "hashtags": [
      "маникюр",
      "гельлак",
      "красота",
      "ногти",
      "салонкрасоты"
    ]
  }
}
```

✅ **Готово!** Контент сгенерирован.

---

## 🧪 Тест 3: Публикация поста (опционально)

⚠️ **Требуется**: Instagram/Facebook токены

### Опубликуйте в Instagram

```bash
curl -X POST http://localhost:3000/smm/post/instagram \
  -H "Content-Type: application/json" \
  -d '{
    "imageUrl": "https://example.com/photo.jpg",
    "caption": "Преобразим ваши ручки! 💅✨ #маникюр #красота",
    "businessId": "1"
  }'
```

**Ожидаемый результат:**
```json
{
  "success": true,
  "data": {
    "postId": "123456789",
    "platform": "instagram",
    "url": "https://www.instagram.com/p/123456789"
  }
}
```

✅ **Готово!** Пост опубликован в Instagram.

---

## 📚 Что дальше?

### Изучите полное руководство
См. **OCR-SMM-GUIDE.md** для всех API endpoints и примеров.

### Получите Instagram/Facebook токены
Если хотите публиковать посты:
1. Откройте [developers.facebook.com](https://developers.facebook.com/)
2. Создайте приложение (Business)
3. Добавьте продукт **Instagram**
4. Получите **Access Token** и **Account ID**

### Интегрируйте с AI-ботом
Добавьте команды в AI Orchestrator:
- "Импортируй записи из изображения"
- "Создай пост для Instagram"
- "Опубликуй в соцсетях"

---

## 🔧 Быстрое решение проблем

### ❌ OCR не работает

**Ошибка**: "OpenAI API key not configured"
```bash
# Проверьте .env
cat backend/.env | grep OPENAI_API_KEY

# Если пусто, добавьте:
echo "OPENAI_API_KEY=sk-..." >> backend/.env
```

### ❌ Генерация контента не работает

**Ошибка**: "Failed to generate Instagram post"
- Проверьте баланс OpenAI аккаунта
- Убедитесь, что API key активен
- Проверьте лимиты: [platform.openai.com/account/limits](https://platform.openai.com/account/limits)

### ❌ Публикация в Instagram не работает

**Ошибка**: "Instagram credentials not configured"
```bash
# Проверьте токены
cat backend/.env | grep INSTAGRAM

# Если пусто, добавьте:
echo "INSTAGRAM_ACCESS_TOKEN=..." >> backend/.env
echo "INSTAGRAM_ACCOUNT_ID=..." >> backend/.env
```

**Ошибка**: "Invalid OAuth access token"
- Токен истёк — создайте новый в Meta for Developers
- Проверьте разрешения: `instagram_basic`, `instagram_content_publish`

---

## 💡 Полезные команды

### Проверить OCR
```bash
# Анализ изображения
curl -X POST http://localhost:3000/ocr/analyze \
  -H "Content-Type: application/json" \
  -d '{"imageUrl": "https://example.com/image.jpg"}'

# Извлечь текст
curl -X POST http://localhost:3000/ocr/text \
  -H "Content-Type: application/json" \
  -d '{"imageUrl": "https://example.com/image.jpg"}'
```

### Проверить SMM
```bash
# Сгенерировать хэштеги
curl -X POST http://localhost:3000/smm/generate/hashtags \
  -H "Content-Type: application/json" \
  -d '{"serviceName": "Маникюр", "count": 10}'

# История постов
curl http://localhost:3000/smm/history/1?platform=instagram&limit=10
```

---

## 📊 Примеры использования

### Пример 1: Импорт + Публикация

```bash
# 1. Импортируйте записи из скриншота
curl -X POST http://localhost:3000/ocr/import \
  -H "Content-Type: application/json" \
  -d '{
    "imageUrl": "https://example.com/screenshot.jpg",
    "businessId": "1"
  }'

# 2. Сгенерируйте пост о новых записях
curl -X POST http://localhost:3000/smm/generate/instagram \
  -H "Content-Type: application/json" \
  -d '{
    "businessName": "Салон красоты Мария",
    "serviceName": "Маникюр",
    "tone": "friendly"
  }'

# 3. Опубликуйте в Instagram
curl -X POST http://localhost:3000/smm/post/instagram \
  -H "Content-Type: application/json" \
  -d '{
    "imageUrl": "https://example.com/photo.jpg",
    "caption": "Новые записи открыты! 💅✨ #маникюр",
    "businessId": "1"
  }'
```

### Пример 2: Рекламная акция

```bash
# Сгенерируйте рекламный пост
curl -X POST http://localhost:3000/smm/generate/promo \
  -H "Content-Type: application/json" \
  -d '{
    "businessName": "Салон красоты Мария",
    "serviceName": "Маникюр",
    "discount": 20,
    "validUntil": "2024-12-31",
    "platform": "instagram"
  }'

# Опубликуйте
curl -X POST http://localhost:3000/smm/post/instagram \
  -H "Content-Type: application/json" \
  -d '{
    "imageUrl": "https://example.com/promo.jpg",
    "caption": "🔥 АКЦИЯ! Скидка 20% на маникюр! #акция #маникюр",
    "businessId": "1"
  }'
```

---

## ✅ Чеклист готовности

- [ ] OpenAI API Key добавлен в `.env`
- [ ] Сервер запущен и логи показывают инициализацию
- [ ] OCR тест пройден (импорт записей)
- [ ] Генерация контента работает
- [ ] (Опционально) Instagram/Facebook токены настроены
- [ ] (Опционально) Публикация поста работает

**Готово!** 🎉 OCR и SMM модули работают.
