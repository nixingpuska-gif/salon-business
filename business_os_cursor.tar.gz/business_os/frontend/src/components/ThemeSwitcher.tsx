import { Sun, Moon, Monitor } from 'lucide-react'

interface ThemeSwitcherProps {
  variant?: 'icon' | 'dropdown' | 'toggle'
  className?: string
}

export default function ThemeSwitcher({ variant = 'icon', className = '' }: ThemeSwitcherProps) {
  // Always light theme - buttons are decorative only

  if (variant === 'toggle') {
    return (
      <button
        className={`p-2 rounded-lg transition-colors bg-gray-100 text-gray-600 hover:bg-gray-200 ${className}`}
        title="Светлая тема"
      >
        <Sun className="w-5 h-5" />
      </button>
    )
  }

  if (variant === 'dropdown') {
    return (
      <div className={`flex items-center gap-1 p-1 rounded-lg bg-gray-100 ${className}`}>
        <button
          className="p-2 rounded-md transition-colors bg-white shadow text-primary-600"
          title="Светлая тема"
        >
          <Sun className="w-4 h-4" />
        </button>
        <button
          className="p-2 rounded-md transition-colors text-gray-500 hover:text-gray-700"
          title="Тёмная тема"
        >
          <Moon className="w-4 h-4" />
        </button>
        <button
          className="p-2 rounded-md transition-colors text-gray-500 hover:text-gray-700"
          title="Системная тема"
        >
          <Monitor className="w-4 h-4" />
        </button>
      </div>
    )
  }

  // Default: icon variant
  return (
    <button
      className={`p-2 rounded-lg transition-all duration-200 text-gray-600 hover:bg-gray-100 ${className}`}
      title="Светлая тема"
    >
      <Sun className="w-5 h-5" />
    </button>
  )
}
