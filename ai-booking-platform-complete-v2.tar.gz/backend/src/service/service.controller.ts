import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ServiceService } from './service.service';
import { CreateServiceDto } from './dto/create-service.dto';
import { UpdateServiceDto } from './dto/update-service.dto';

@Controller('services')
export class ServiceController {
  constructor(private readonly serviceService: ServiceService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createServiceDto: CreateServiceDto) {
    return this.serviceService.create(
      createServiceDto.businessId,
      createServiceDto,
    );
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    return this.serviceService.findOne(id);
  }

  @Get()
  async findByBusiness(
    @Query('businessId') businessId: string,
    @Query('includeInactive') includeInactive?: string,
  ) {
    return this.serviceService.findByBusiness(
      businessId,
      includeInactive === 'true',
    );
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() updateServiceDto: UpdateServiceDto,
  ) {
    return this.serviceService.update(id, updateServiceDto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  async delete(@Param('id') id: string) {
    await this.serviceService.delete(id);
  }

  @Post('reorder')
  @HttpCode(HttpStatus.OK)
  async reorder(
    @Body() body: { businessId: string; serviceIds: string[] },
  ) {
    await this.serviceService.reorder(body.businessId, body.serviceIds);
    return { message: 'Services reordered successfully' };
  }
}
