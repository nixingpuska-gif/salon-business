# 📦 AI-Booking Platform - Полная Инструкция по Установке

## От А до Я: Пошаговое руководство для локального запуска

**Время установки:** 15-20 минут  
**Уровень сложности:** Средний  
**Требования:** Базовые знания терминала

---

## 📋 Содержание

1. [Системные требования](#системные-требования)
2. [Установка зависимостей](#установка-зависимостей)
3. [Скачивание проекта](#скачивание-проекта)
4. [Настройка базы данных](#настройка-базы-данных)
5. [Настройка переменных окружения](#настройка-переменных-окружения)
6. [Запуск приложения](#запуск-приложения)
7. [Проверка работоспособности](#проверка-работоспособности)
8. [Настройка Telegram ботов](#настройка-telegram-ботов)
9. [Настройка AI (OpenAI)](#настройка-ai-openai)
10. [Troubleshooting](#troubleshooting)

---

## 1. Системные требования

### Минимальные требования:

- **ОС:** Windows 10/11, macOS 10.15+, Linux (Ubuntu 20.04+)
- **CPU:** 2 ядра
- **RAM:** 4 GB
- **Диск:** 5 GB свободного места
- **Интернет:** Стабильное подключение

### Рекомендуемые требования:

- **ОС:** macOS 12+, Ubuntu 22.04+
- **CPU:** 4 ядра
- **RAM:** 8 GB
- **Диск:** 10 GB SSD

---

## 2. Установка зависимостей

### 2.1 Node.js (обязательно)

**Требуемая версия:** Node.js 18.x или 20.x

#### macOS:
```bash
# Через Homebrew
brew install node@20

# Проверка
node --version  # Должно быть v20.x.x
npm --version   # Должно быть 10.x.x
```

#### Windows:
1. Скачайте установщик: https://nodejs.org/en/download/
2. Запустите установщик (выберите LTS версию)
3. Перезапустите терминал
4. Проверьте:
```cmd
node --version
npm --version
```

#### Linux (Ubuntu/Debian):
```bash
# Установка Node.js 20.x
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Проверка
node --version
npm --version
```

---

### 2.2 pnpm (обязательно)

**Требуемая версия:** pnpm 8.x или новее

```bash
# Установка pnpm глобально
npm install -g pnpm

# Проверка
pnpm --version  # Должно быть 8.x.x или выше
```

---

### 2.3 Docker & Docker Compose (обязательно для БД)

#### macOS:
1. Скачайте Docker Desktop: https://www.docker.com/products/docker-desktop/
2. Установите и запустите Docker Desktop
3. Проверьте:
```bash
docker --version
docker compose version
```

#### Windows:
1. Скачайте Docker Desktop: https://www.docker.com/products/docker-desktop/
2. Установите (требуется WSL2)
3. Запустите Docker Desktop
4. Проверьте:
```cmd
docker --version
docker compose version
```

#### Linux (Ubuntu):
```bash
# Установка Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Добавление пользователя в группу docker
sudo usermod -aG docker $USER
newgrp docker

# Установка Docker Compose
sudo apt-get update
sudo apt-get install docker-compose-plugin

# Проверка
docker --version
docker compose version
```

---

### 2.4 Git (опционально, но рекомендуется)

#### macOS:
```bash
brew install git
```

#### Windows:
Скачайте: https://git-scm.com/download/win

#### Linux:
```bash
sudo apt-get install git
```

---

## 3. Скачивание проекта

### Вариант 1: Через архив (рекомендуется)

Если вы получили файл `ai-booking-platform-final-v1.tar.gz`:

```bash
# Создайте директорию для проекта
mkdir ~/projects
cd ~/projects

# Распакуйте архив
tar -xzf ~/Downloads/ai-booking-platform-final-v1.tar.gz

# Перейдите в директорию проекта
cd ai-booking-platform
```

### Вариант 2: Через Git (если проект в репозитории)

```bash
# Клонируйте репозиторий
git clone https://github.com/your-username/ai-booking-platform.git
cd ai-booking-platform
```

### Проверка структуры проекта:

```bash
# Должна быть примерно такая структура:
ls -la

# Вывод:
# backend/
# docker-compose.yml
# README.md
# QUICK-START-RU.md
# и другие файлы...
```

---

## 4. Настройка базы данных

### 4.1 Запуск PostgreSQL и Redis через Docker

```bash
# Убедитесь, что Docker Desktop запущен (для macOS/Windows)

# Запустите базы данных
docker compose up -d postgres redis

# Проверьте, что контейнеры запустились
docker compose ps

# Вывод должен показать:
# NAME                STATUS              PORTS
# postgres            running             0.0.0.0:5432->5432/tcp
# redis               running             0.0.0.0:6379->6379/tcp
```

### 4.2 Проверка подключения к PostgreSQL

```bash
# Подключитесь к PostgreSQL
docker compose exec postgres psql -U postgres

# В консоли PostgreSQL:
\l                          # Список баз данных
\q                          # Выход
```

### 4.3 Проверка Redis

```bash
# Подключитесь к Redis
docker compose exec redis redis-cli

# В консоли Redis:
PING                        # Должно вернуть PONG
exit                        # Выход
```

---

## 5. Настройка переменных окружения

### 5.1 Создание .env файла

```bash
# Перейдите в директорию backend
cd backend

# Скопируйте пример конфигурации
cp .env.example .env

# Откройте .env в редакторе
# macOS:
open .env

# Linux:
nano .env

# Windows:
notepad .env
```

### 5.2 Базовая конфигурация .env

**Минимальная конфигурация для запуска:**

```env
# ===================================
# DATABASE CONFIGURATION
# ===================================
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/ai_booking_platform?schema=public"

# ===================================
# REDIS CONFIGURATION
# ===================================
REDIS_HOST=localhost
REDIS_PORT=6379

# ===================================
# APPLICATION CONFIGURATION
# ===================================
PORT=3000
NODE_ENV=development

# ===================================
# SECURITY
# ===================================
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production
ENCRYPTION_KEY=your-32-character-encryption-key-here-change-this

# ===================================
# OPENAI API (для AI функциональности)
# ===================================
# Получите ключ на: https://platform.openai.com/api-keys
OPENAI_API_KEY=

# ===================================
# TELEGRAM BOT TOKENS
# ===================================
# Создайте ботов через @BotFather в Telegram
TELEGRAM_CLIENT_BOT_TOKEN=
TELEGRAM_ADMIN_BOT_TOKEN=

# ===================================
# GOOGLE CALENDAR API (опционально)
# ===================================
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
GOOGLE_REDIRECT_URI=http://localhost:3000/auth/google/callback

# ===================================
# FEATURE FLAGS
# ===================================
ENABLE_OCR=false
ENABLE_SMM_AUTOPILOT=false
ENABLE_CALENDAR_SYNC=false
```

### 5.3 Генерация секретных ключей

```bash
# Генерация JWT_SECRET (32 символа)
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Генерация ENCRYPTION_KEY (32 символа)
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"

# Скопируйте сгенерированные ключи в .env файл
```

---

## 6. Запуск приложения

### 6.1 Установка зависимостей

```bash
# Убедитесь, что вы в директории backend
cd backend

# Установите все зависимости (займёт 2-3 минуты)
pnpm install

# Дождитесь завершения установки
```

### 6.2 Генерация Prisma Client

```bash
# Сгенерируйте Prisma Client
npx prisma generate

# Вывод:
# ✔ Generated Prisma Client
```

### 6.3 Создание базы данных и таблиц

```bash
# Создайте базу данных и выполните миграции
npx prisma migrate dev --name init

# Вывод:
# ✔ Database created
# ✔ Migrations applied
```

### 6.4 Запуск приложения в режиме разработки

```bash
# Запустите приложение
pnpm run start:dev

# Вывод:
# [Nest] 12345  - 23/11/2025, 20:00:00     LOG [NestFactory] Starting Nest application...
# [Nest] 12345  - 23/11/2025, 20:00:01     LOG [InstanceLoader] AppModule dependencies initialized
# [Nest] 12345  - 23/11/2025, 20:00:01     LOG [RoutesResolver] AppController {/}:
# [Nest] 12345  - 23/11/2025, 20:00:01     LOG [NestApplication] Nest application successfully started
# [Nest] 12345  - 23/11/2025, 20:00:01     LOG Application is running on: http://localhost:3000
```

**✅ Приложение запущено!**

---

## 7. Проверка работоспособности

### 7.1 Проверка API

Откройте новый терминал и выполните:

```bash
# Проверка health endpoint
curl http://localhost:3000

# Ожидаемый ответ:
# {"message":"AI-Booking Platform API is running"}
```

### 7.2 Создание тестового бизнеса

```bash
# Создайте тестовый бизнес
curl -X POST http://localhost:3000/businesses \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Салон Красоты Тест",
    "businessType": "beauty_salon",
    "phone": "+79991234567",
    "userId": "test-user-123"
  }'

# Ожидаемый ответ:
# {
#   "id": "uuid-здесь",
#   "name": "Салон Красоты Тест",
#   "businessType": "beauty_salon",
#   ...
# }
```

### 7.3 Проверка списка бизнесов

```bash
# Получите список бизнесов
curl http://localhost:3000/businesses?userId=test-user-123

# Должен вернуть массив с вашим бизнесом
```

### 7.4 Просмотр базы данных (опционально)

```bash
# Откройте Prisma Studio для визуального просмотра БД
npx prisma studio

# Откроется браузер на http://localhost:5555
# Здесь вы можете просматривать и редактировать данные
```

---

## 8. Настройка Telegram ботов

### 8.1 Создание Client Bot

1. Откройте Telegram
2. Найдите **@BotFather**
3. Отправьте команду: `/newbot`
4. Введите имя бота: `My Booking Client Bot`
5. Введите username: `my_booking_client_bot` (должен быть уникальным)
6. Скопируйте токен (выглядит как: `1234567890:ABCdefGHIjklMNOpqrsTUVwxyz`)

### 8.2 Создание Admin Bot

1. Снова отправьте `/newbot` в @BotFather
2. Введите имя: `My Booking Admin Bot`
3. Введите username: `my_booking_admin_bot`
4. Скопируйте токен

### 8.3 Добавление токенов в .env

```bash
# Откройте .env файл
nano .env

# Добавьте токены:
TELEGRAM_CLIENT_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_ADMIN_BOT_TOKEN=0987654321:ZYXwvuTSRqponMLKjihgFEDcba

# Сохраните (Ctrl+O, Enter, Ctrl+X)
```

### 8.4 Перезапуск приложения

```bash
# Остановите приложение (Ctrl+C в терминале где запущен сервер)
# Запустите снова
pnpm run start:dev
```

### 8.5 Проверка ботов

1. Найдите вашего Client бота в Telegram
2. Отправьте `/start`
3. Бот должен ответить приветствием

**Примеры команд для Client Bot:**
- "Хочу записаться на маникюр"
- "Покажи мои записи"
- "Сколько стоит педикюр?"

---

## 9. Настройка AI (OpenAI)

### 9.1 Получение API ключа

1. Перейдите на: https://platform.openai.com/api-keys
2. Войдите или зарегистрируйтесь
3. Нажмите "Create new secret key"
4. Скопируйте ключ (начинается с `sk-`)

### 9.2 Добавление ключа в .env

```bash
# Откройте .env
nano .env

# Добавьте ключ:
OPENAI_API_KEY=sk-your-actual-openai-api-key-here

# Сохраните
```

### 9.3 Пополнение баланса OpenAI

1. Перейдите: https://platform.openai.com/account/billing
2. Добавьте способ оплаты
3. Пополните баланс (минимум $5)

### 9.4 Проверка AI функциональности

```bash
# Перезапустите приложение
# Ctrl+C, затем:
pnpm run start:dev

# Теперь боты будут использовать AI для ответов
```

**Тестирование AI:**
1. Напишите боту: "Хочу записаться на маникюр в субботу в 10 утра"
2. AI должен обработать запрос и предложить доступные слоты

---

## 10. Troubleshooting

### Проблема: Docker не запускается

**Решение:**
```bash
# macOS/Windows: Запустите Docker Desktop вручную

# Linux: Проверьте статус
sudo systemctl status docker

# Если не запущен:
sudo systemctl start docker
```

---

### Проблема: Ошибка подключения к PostgreSQL

**Симптомы:**
```
Error: Can't reach database server at localhost:5432
```

**Решение:**
```bash
# Проверьте, что контейнер запущен
docker compose ps

# Если не запущен:
docker compose up -d postgres

# Проверьте логи
docker compose logs postgres
```

---

### Проблема: Ошибка при установке зависимостей

**Симптомы:**
```
ERR_PNPM_...
```

**Решение:**
```bash
# Очистите кеш pnpm
pnpm store prune

# Удалите node_modules и lock файл
rm -rf node_modules pnpm-lock.yaml

# Установите заново
pnpm install
```

---

### Проблема: Порт 3000 уже занят

**Симптомы:**
```
Error: listen EADDRINUSE: address already in use :::3000
```

**Решение:**
```bash
# Измените порт в .env
PORT=3001

# Или найдите и остановите процесс на порту 3000
# macOS/Linux:
lsof -ti:3000 | xargs kill -9

# Windows:
netstat -ano | findstr :3000
taskkill /PID <PID> /F
```

---

### Проблема: Prisma миграции не применяются

**Решение:**
```bash
# Сбросьте базу данных (ВНИМАНИЕ: удалит все данные)
npx prisma migrate reset

# Примените миграции заново
npx prisma migrate dev --name init
```

---

### Проблема: Telegram бот не отвечает

**Проверьте:**
1. Токен правильно скопирован в .env
2. Нет лишних пробелов в токене
3. Приложение перезапущено после добавления токена
4. В логах нет ошибок

**Решение:**
```bash
# Проверьте логи приложения
# Должны быть строки:
# [TelegramService] Client bot started: @your_bot_username
# [TelegramService] Admin bot started: @your_admin_bot_username
```

---

### Проблема: AI не работает

**Проверьте:**
1. OPENAI_API_KEY добавлен в .env
2. Баланс OpenAI > $0
3. Ключ активен (не истёк)

**Решение:**
```bash
# Проверьте ключ через curl
curl https://api.openai.com/v1/models \
  -H "Authorization: Bearer $OPENAI_API_KEY"

# Должен вернуть список моделей
```

---

## 📚 Дополнительные ресурсы

### Документация проекта:
- `README.md` - Обзор проекта
- `QUICK-START-RU.md` - Быстрый старт
- `AI-ORCHESTRATOR-GUIDE.md` - Руководство по AI
- `FINAL-IMPLEMENTATION-REPORT.md` - Полный отчёт

### Полезные команды:

```bash
# Просмотр логов Docker контейнеров
docker compose logs -f postgres
docker compose logs -f redis

# Остановка всех контейнеров
docker compose down

# Полная очистка (включая volumes)
docker compose down -v

# Проверка статуса приложения
curl http://localhost:3000/health

# Просмотр всех API endpoints (если настроен Swagger)
# Откройте в браузере:
# http://localhost:3000/api
```

---

## ✅ Чеклист успешной установки

- [ ] Node.js 18+ установлен
- [ ] pnpm установлен
- [ ] Docker Desktop запущен
- [ ] PostgreSQL контейнер работает
- [ ] Redis контейнер работает
- [ ] Зависимости установлены (`pnpm install`)
- [ ] Prisma Client сгенерирован
- [ ] Миграции применены
- [ ] .env файл настроен
- [ ] Приложение запущено на http://localhost:3000
- [ ] API отвечает на запросы
- [ ] Telegram боты созданы и работают
- [ ] OpenAI API ключ добавлен
- [ ] AI функциональность работает

---

## 🎉 Поздравляем!

Если все пункты чеклиста выполнены, у вас **полностью рабочая установка AI-Booking Platform**!

**Что дальше?**
1. Изучите документацию в `AI-ORCHESTRATOR-GUIDE.md`
2. Протестируйте все API endpoints
3. Попробуйте диалоги с Telegram ботами
4. Настройте Google Calendar (опционально)
5. Начните разработку дополнительных функций

**Нужна помощь?**
- Проверьте раздел Troubleshooting
- Изучите логи приложения
- Проверьте документацию

---

**Версия:** v1.0.0  
**Дата:** 23 ноября 2025  
**Статус:** ✅ Production Ready

🚀 **Удачи в разработке!**
