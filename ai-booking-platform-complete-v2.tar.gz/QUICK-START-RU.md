# 🚀 Быстрый старт AI-Booking Platform

## Что уже реализовано

✅ **Core Backend (100%)**
- Business, Client, Service, Schedule, Booking модули
- REST API с 30+ endpoints
- Prisma ORM + PostgreSQL
- Валидация данных (class-validator)

✅ **Telegram Bots (100%)**
- Client Bot (для клиентов)
- Admin Bot (для владельцев бизнеса)
- Channel Gateway (унификация каналов)

⏳ **AI Orchestrator (Stub)**
- Интерфейсы готовы
- GPT-4 integration - следующий этап

---

## Шаг 1: Установка зависимостей

```bash
cd /home/ubuntu/ai-booking-platform/backend
pnpm install
```

---

## Шаг 2: Настройка окружения

Создайте файл `.env` на основе `.env.example`:

```bash
cp .env.example .env
```

Отредактируйте `.env`:

```env
# Database
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/booking_platform"

# Telegram Bots (получите токены у @BotFather)
TELEGRAM_CLIENT_BOT_TOKEN="your-client-bot-token"
TELEGRAM_ADMIN_BOT_TOKEN="your-admin-bot-token"

# OpenAI (для AI Orchestrator - следующий этап)
OPENAI_API_KEY="your-openai-api-key"

# App
PORT=3000
NODE_ENV=development
```

---

## Шаг 3: Запуск базы данных

Из корня проекта:

```bash
docker-compose up -d postgres redis
```

Проверка:
```bash
docker-compose ps
```

---

## Шаг 4: Миграции базы данных

```bash
cd backend
npx prisma migrate dev --name init
```

Это создаст все 16 таблиц:
- Business
- BusinessUser
- Client
- ClientNote
- Service
- Schedule
- Booking
- Integration
- Notification
- NotificationTemplate
- SMMPost
- SMMContent
- ImportJob
- ImportedAppointment
- Conversation
- Message

---

## Шаг 5: Генерация Prisma Client

```bash
npx prisma generate
```

---

## Шаг 6: Запуск приложения

### Development mode (с hot reload):
```bash
pnpm run start:dev
```

### Production mode:
```bash
pnpm run build
pnpm run start:prod
```

Приложение запустится на `http://localhost:3000`

---

## Шаг 7: Проверка работы

### Проверка API:

```bash
# Health check
curl http://localhost:3000

# Создание бизнеса
curl -X POST http://localhost:3000/businesses \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Салон Красоты Элегант",
    "businessType": "nail_tech",
    "phone": "+79991234567",
    "email": "info@elegant.ru",
    "userId": "user-123"
  }'
```

### Проверка Telegram ботов:

1. Откройте Telegram
2. Найдите вашего Client Bot по username
3. Отправьте `/start`
4. Должен прийти ответ: "Добро пожаловать! Я помогу Вам записаться на услуги..."

---

## Основные API Endpoints

### Business
- `POST /businesses` - Создать бизнес
- `GET /businesses/:id` - Получить бизнес
- `GET /businesses?userId=xxx` - Список бизнесов пользователя
- `PUT /businesses/:id` - Обновить бизнес
- `DELETE /businesses/:id` - Удалить бизнес

### Client (CRM)
- `POST /clients` - Создать/найти клиента
- `GET /clients/:id` - Получить клиента с историей
- `GET /clients?businessId=xxx&search=xxx` - Поиск клиентов
- `PUT /clients/:id` - Обновить клиента
- `POST /clients/:id/notes` - Добавить заметку

### Service
- `POST /services` - Создать услугу
- `GET /services?businessId=xxx` - Список услуг
- `PUT /services/:id` - Обновить услугу
- `POST /services/reorder` - Изменить порядок

### Schedule
- `POST /schedules/working-hours` - Настроить рабочие часы
- `POST /schedules/breaks` - Добавить перерыв
- `POST /schedules/vacations` - Добавить отпуск
- `POST /schedules/slots` - **Сгенерировать доступные слоты**

### Booking
- `POST /bookings` - Создать запись
- `GET /bookings?businessId=xxx&startDate=xxx&endDate=xxx` - Список записей
- `PUT /bookings/:id/reschedule` - Перенести запись
- `PUT /bookings/:id/cancel` - Отменить запись
- `PUT /bookings/:id/complete` - Завершить запись
- `GET /bookings/stats/:businessId` - Статистика

---

## Пример полного workflow

### 1. Создание бизнеса

```bash
curl -X POST http://localhost:3000/businesses \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Салон Элегант",
    "businessType": "nail_tech",
    "phone": "+79991234567",
    "userId": "user-123"
  }'
```

Ответ:
```json
{
  "id": "550e8400-e29b-41d4-a716-446655440000",
  "name": "Салон Элегант",
  "businessType": "nail_tech",
  ...
}
```

### 2. Добавление услуг

```bash
curl -X POST http://localhost:3000/services \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "550e8400-e29b-41d4-a716-446655440000",
    "name": "Маникюр классический",
    "durationMinutes": 60,
    "price": 1500
  }'
```

### 3. Настройка рабочих часов

```bash
curl -X POST http://localhost:3000/schedules/working-hours \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "550e8400-e29b-41d4-a716-446655440000",
    "daysOfWeek": [1, 2, 3, 4, 5],
    "startTime": "09:00",
    "endTime": "18:00"
  }'
```

### 4. Генерация доступных слотов

```bash
curl -X POST http://localhost:3000/schedules/slots \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "550e8400-e29b-41d4-a716-446655440000",
    "date": "2025-11-25",
    "serviceDurationMinutes": 60,
    "slotIntervalMinutes": 30
  }'
```

Ответ:
```json
[
  {
    "id": "slot_0900",
    "startTime": "2025-11-25T09:00:00.000Z",
    "endTime": "2025-11-25T10:00:00.000Z",
    "available": true
  },
  {
    "id": "slot_0930",
    "startTime": "2025-11-25T09:30:00.000Z",
    "endTime": "2025-11-25T10:30:00.000Z",
    "available": true
  },
  ...
]
```

### 5. Создание клиента

```bash
curl -X POST http://localhost:3000/clients \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "550e8400-e29b-41d4-a716-446655440000",
    "phone": "+79161234567",
    "firstName": "Анна",
    "lastName": "Иванова"
  }'
```

### 6. Создание записи

```bash
curl -X POST http://localhost:3000/bookings \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "550e8400-e29b-41d4-a716-446655440000",
    "clientId": "client-uuid",
    "serviceId": "service-uuid",
    "startTime": "2025-11-25T09:00:00Z",
    "sourceChannel": "telegram"
  }'
```

---

## Работа с Prisma Studio (GUI для БД)

```bash
cd backend
npx prisma studio
```

Откроется в браузере на `http://localhost:5555`

Здесь можно:
- Просматривать все таблицы
- Редактировать данные
- Создавать записи вручную

---

## Структура проекта

```
backend/
├── src/
│   ├── business/           # Управление бизнесами
│   ├── client/             # CRM клиентов
│   ├── service/            # Управление услугами
│   ├── schedule/           # Расписание + генерация слотов
│   ├── booking/            # Управление записями
│   ├── channel-gateway/    # Унификация каналов
│   ├── ai/                 # AI Orchestrator (stub)
│   ├── telegram/           # Telegram боты
│   ├── prisma/             # Prisma service
│   └── app.module.ts       # Главный модуль
│
├── prisma/
│   └── schema.prisma       # Схема БД (16 таблиц)
│
├── .env                    # Конфигурация
├── docker-compose.yml      # PostgreSQL + Redis
└── package.json
```

---

## Следующие шаги

### Этап 1, Фаза 3: AI Orchestrator
1. Установить OpenAI SDK
2. Реализовать GPT-4 function calling
3. Создать Client AI Agent
4. Создать Admin AI Agent
5. Интегрировать с Telegram ботами

### Этап 1, Фаза 4: Google Calendar
1. Настроить OAuth
2. Создать Calendar Service
3. Синхронизация событий

### Этап 2: Import, SMM, Notifications
1. Import Service (OCR)
2. SMM Service (генерация контента)
3. BullMQ (очереди)
4. Notification Service (напоминания)

---

## Полезные команды

```bash
# Проверка статуса Docker
docker-compose ps

# Логи приложения
pnpm run start:dev

# Логи PostgreSQL
docker-compose logs -f postgres

# Остановка всех сервисов
docker-compose down

# Пересоздание БД
docker-compose down -v
docker-compose up -d postgres
npx prisma migrate dev --name init

# Форматирование кода
pnpm run format

# Линтинг
pnpm run lint
```

---

## Troubleshooting

### Ошибка подключения к БД
```bash
# Проверьте, что PostgreSQL запущен
docker-compose ps

# Проверьте DATABASE_URL в .env
cat .env | grep DATABASE_URL
```

### Telegram бот не отвечает
```bash
# Проверьте токены в .env
cat .env | grep TELEGRAM

# Проверьте логи приложения
# Должно быть: "Client bot started successfully"
# Должно быть: "Admin bot started successfully"
```

### Prisma ошибки
```bash
# Пересоздайте Prisma Client
npx prisma generate

# Проверьте миграции
npx prisma migrate status
```

---

## Документация

- [Архитектура](./01-architecture-proposal.md)
- [Схема БД](./02-database-schema.md)
- [Руководство по реализации](./03-implementation-guide.md)
- [Статус реализации](./IMPLEMENTATION-STATUS.md)
- [Чеклист доставки](./DELIVERY-CHECKLIST.md)

---

**Готово к разработке!** 🎉

Если нужна помощь, смотрите документацию или пишите в issues.
