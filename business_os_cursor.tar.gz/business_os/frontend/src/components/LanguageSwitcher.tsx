import { useLanguage } from '../contexts/LanguageContext'
import { Globe } from 'lucide-react'

export default function LanguageSwitcher({ className = '' }: { className?: string }) {
  const { language, setLanguage } = useLanguage()

  return (
    <div className={`flex items-center gap-1 ${className}`}>
      <Globe className="w-4 h-4 text-gray-500" />
      <button
        onClick={() => setLanguage('ru')}
        className={`px-2 py-1 text-sm rounded transition-colors ${
          language === 'ru' 
            ? 'bg-primary-100 text-primary-700 font-medium' 
            : 'text-gray-500 hover:text-gray-700'
        }`}
      >
        RU
      </button>
      <span className="text-gray-300">|</span>
      <button
        onClick={() => setLanguage('en')}
        className={`px-2 py-1 text-sm rounded transition-colors ${
          language === 'en' 
            ? 'bg-primary-100 text-primary-700 font-medium' 
            : 'text-gray-500 hover:text-gray-700'
        }`}
      >
        EN
      </button>
    </div>
  )
}
