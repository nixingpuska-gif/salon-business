"""
Business OS - API v1 Router
Main router that includes all API endpoints
"""

from fastapi import APIRouter

from app.api.v1.endpoints import (
    auth,
    users,
    tenants,
    branches,
    clients,
    staff,
    services,
    appointments,
    payments,
    inventory,
    messages,
    reviews,
    reports,
    partners,
    leads,
    webhooks,
    dashboard,
    onboarding,
    billing,
    integrations,
    analytics,
    money_dashboard,
    ai_assistant,
    retention,
    affiliate,
)

api_router = APIRouter()

# Authentication
api_router.include_router(
    auth.router,
    prefix="/auth",
    tags=["Authentication"]
)

# Users (platform users - owners)
api_router.include_router(
    users.router,
    prefix="/users",
    tags=["Users"]
)

# Tenants (salons)
api_router.include_router(
    tenants.router,
    prefix="/tenants",
    tags=["Tenants"]
)

# Branches
api_router.include_router(
    branches.router,
    prefix="/branches",
    tags=["Branches"]
)

# Clients
api_router.include_router(
    clients.router,
    prefix="/clients",
    tags=["Clients"]
)

# Staff
api_router.include_router(
    staff.router,
    prefix="/staff",
    tags=["Staff"]
)

# Services
api_router.include_router(
    services.router,
    prefix="/services",
    tags=["Services"]
)

# Appointments
api_router.include_router(
    appointments.router,
    prefix="/appointments",
    tags=["Appointments"]
)

# Payments
api_router.include_router(
    payments.router,
    prefix="/payments",
    tags=["Payments"]
)

# Inventory
api_router.include_router(
    inventory.router,
    prefix="/inventory",
    tags=["Inventory"]
)

# Messages & Communication
api_router.include_router(
    messages.router,
    prefix="/messages",
    tags=["Messages"]
)

# Reviews
api_router.include_router(
    reviews.router,
    prefix="/reviews",
    tags=["Reviews"]
)

# Reports & Analytics
api_router.include_router(
    reports.router,
    prefix="/reports",
    tags=["Reports"]
)

# Partners
api_router.include_router(
    partners.router,
    prefix="/partners",
    tags=["Partners"]
)

# Leads (for platform admin)
api_router.include_router(
    leads.router,
    prefix="/leads",
    tags=["Leads"]
)

# Dashboard (Money Dashboard)
api_router.include_router(
    dashboard.router,
    prefix="/dashboard",
    tags=["Dashboard"]
)

# Webhooks (Telegram, WhatsApp, etc.)
api_router.include_router(
    webhooks.router,
    prefix="/webhooks",
    tags=["Webhooks"]
)

# Onboarding
api_router.include_router(
    onboarding.router,
    prefix="/onboarding",
    tags=["Onboarding"]
)

# Billing
api_router.include_router(
    billing.router,
    prefix="/billing",
    tags=["Billing"]
)

# Integrations (Telegram, WhatsApp, Instagram, SMS, Email)
api_router.include_router(
    integrations.router,
    prefix="/integrations",
    tags=["Integrations"]
)

# Analytics (LTV, Margins, Forecasts)
api_router.include_router(
    analytics.router,
    prefix="/analytics",
    tags=["Analytics"]
)

# Money Dashboard
api_router.include_router(
    money_dashboard.router,
    prefix="/money-dashboard",
    tags=["Money Dashboard"]
)

# AI Assistant
api_router.include_router(
    ai_assistant.router,
    prefix="/ai",
    tags=["AI Assistant"]
)

# Retention & Loyalty
api_router.include_router(
    retention.router,
    prefix="/retention",
    tags=["Retention"]
)

# Affiliate Program
api_router.include_router(
    affiliate.router,
    prefix="/affiliate",
    tags=["Affiliate"]
)
