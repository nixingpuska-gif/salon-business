import { Outlet, NavLink } from 'react-router-dom'
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  UserCircle, 
  Scissors, 
  Package, 
  Settings,
  Bell,
  Search,
  Menu,
  Plug,
  Brain,
  Gift,
  FileText,
  Share2,
  LogOut
} from 'lucide-react'
import { useState } from 'react'
import clsx from 'clsx'
import ThemeSwitcher from './ThemeSwitcher'
import { useAuth } from '../contexts/AuthContext'

const navigation = [
  { name: 'Дашборд', href: '/app/dashboard', icon: LayoutDashboard },
  { name: 'AI-инсайты', href: '/app/ai-insights', icon: Brain },
  { name: 'Клиенты', href: '/app/clients', icon: Users },
  { name: 'Записи', href: '/app/appointments', icon: Calendar },
  { name: 'Сотрудники', href: '/app/staff', icon: UserCircle },
  { name: 'Услуги', href: '/app/services', icon: Scissors },
  { name: 'Склад', href: '/app/inventory', icon: Package },
  { name: 'Лояльность', href: '/app/loyalty', icon: Gift },
  { name: 'Интеграции', href: '/app/integrations', icon: Plug },
  { name: 'Отчёты', href: '/app/reports', icon: FileText },
  { name: 'Партнёрка', href: '/app/affiliate', icon: Share2 },
  { name: 'Настройки', href: '/app/settings', icon: Settings },
]

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const { logout } = useAuth()

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-900 transition-colors duration-200">
      {/* Sidebar */}
      <aside className={clsx(
        "fixed inset-y-0 left-0 z-50 bg-white dark:bg-slate-800 border-r border-gray-200 dark:border-slate-700 transition-all duration-300",
        sidebarOpen ? "w-64" : "w-20"
      )}>
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-gray-200 dark:border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">B</span>
            </div>
            {sidebarOpen && (
              <span className="font-semibold text-gray-900 dark:text-white">Business OS</span>
            )}
          </div>
        </div>

        {/* Navigation */}
        <nav className="p-4 space-y-1 overflow-y-auto max-h-[calc(100vh-8rem)]">
          {navigation.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              className={({ isActive }) => clsx(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors",
                isActive 
                  ? "bg-primary-50 dark:bg-primary-900/30 text-primary-700 dark:text-primary-400" 
                  : "text-gray-600 dark:text-slate-400 hover:bg-gray-100 dark:hover:bg-slate-700"
              )}
            >
              <item.icon className="w-5 h-5 flex-shrink-0" />
              {sidebarOpen && <span className="font-medium">{item.name}</span>}
            </NavLink>
          ))}
        </nav>

        {/* Bottom actions */}
        <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200 dark:border-slate-700 bg-white dark:bg-slate-800">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-slate-300 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700"
            >
              <Menu className="w-5 h-5" />
            </button>
            {sidebarOpen && (
              <button
                onClick={logout}
                className="p-2 text-gray-400 hover:text-red-600 dark:hover:text-red-400 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700"
                title="Выйти"
              >
                <LogOut className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className={clsx(
        "transition-all duration-300",
        sidebarOpen ? "ml-64" : "ml-20"
      )}>
        {/* Header */}
        <header className="h-16 bg-white dark:bg-slate-800 border-b border-gray-200 dark:border-slate-700 flex items-center justify-between px-6">
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 dark:text-slate-500" />
              <input
                type="text"
                placeholder="Поиск..."
                className="pl-10 pr-4 py-2 bg-gray-100 dark:bg-slate-700 rounded-lg w-64 focus:outline-none focus:ring-2 focus:ring-primary-500 text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-slate-500"
              />
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <ThemeSwitcher variant="dropdown" />
            
            <button className="relative p-2 text-gray-400 hover:text-gray-600 dark:hover:text-slate-300 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-700">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>
            
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-primary-100 dark:bg-primary-900/50 rounded-full flex items-center justify-center">
                <span className="text-primary-700 dark:text-primary-400 font-medium text-sm">А</span>
              </div>
              <div className="text-sm">
                <div className="font-medium text-gray-900 dark:text-white">Администратор</div>
                <div className="text-gray-500 dark:text-slate-400 text-xs">Beauty Lab</div>
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="p-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}
