"""
Retention & Feedback API - Возврат клиентов, отзывы, программа лояльности
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timedelta
from pydantic import BaseModel
from typing import Optional, List
from enum import Enum

from app.core.database import get_db

router = APIRouter()


class CampaignType(str, Enum):
    REACTIVATION = "reactivation"
    BIRTHDAY = "birthday"
    LOYALTY_REWARD = "loyalty_reward"
    FEEDBACK_REQUEST = "feedback_request"
    PROMO = "promo"


class Campaign(BaseModel):
    id: int
    name: str
    type: CampaignType
    target_segment: str
    target_count: int
    sent_count: int
    opened_count: int
    converted_count: int
    revenue_generated: float
    status: str


class FeedbackItem(BaseModel):
    id: int
    client_name: str
    rating: int
    comment: Optional[str]
    sentiment: str  # positive, neutral, negative
    service: str
    master: str
    date: str
    responded: bool
    ai_analysis: Optional[str]


class LoyaltyProgram(BaseModel):
    client_id: int
    client_name: str
    points_balance: int
    points_earned_total: int
    points_spent_total: int
    current_tier: str  # bronze, silver, gold, platinum
    next_tier: Optional[str]
    points_to_next_tier: int
    cashback_percent: float
    benefits: List[str]


# ============ RETENTION ============

@router.get("/segments")
async def get_client_segments(
    tenant_id: int = Query(...),
    db: AsyncSession = Depends(get_db)
):
    """Автоматическая сегментация клиентов"""
    
    return {
        "segments": [
            {
                "id": "vip",
                "name": "VIP",
                "description": "Потратили >50,000₽, визиты >10",
                "count": 25,
                "total_ltv": 1500000,
                "avg_check": 4500,
                "actions": ["Персональные приглашения", "Эксклюзивные акции"]
            },
            {
                "id": "loyal",
                "name": "Постоянные",
                "description": "Визиты >5, последний <45 дней",
                "count": 85,
                "total_ltv": 2550000,
                "avg_check": 3000,
                "actions": ["Программа лояльности", "Бонусы за рекомендации"]
            },
            {
                "id": "at_risk",
                "name": "Под угрозой",
                "description": "Были активны, но не были 45-60 дней",
                "count": 32,
                "total_ltv": 640000,
                "avg_check": 2500,
                "actions": ["Срочная реактивация", "Звонок от мастера"]
            },
            {
                "id": "sleeping",
                "name": "Спящие",
                "description": "Не были 60-90 дней",
                "count": 48,
                "total_ltv": 720000,
                "avg_check": 2200,
                "actions": ["Реактивационная рассылка", "Скидка 15%"]
            },
            {
                "id": "lost",
                "name": "Потерянные",
                "description": "Не были >90 дней",
                "count": 65,
                "total_ltv": 650000,
                "avg_check": 2000,
                "actions": ["Агрессивная реактивация", "Скидка 25%"]
            },
            {
                "id": "new",
                "name": "Новые",
                "description": "1-2 визита за последние 30 дней",
                "count": 40,
                "total_ltv": 200000,
                "avg_check": 2500,
                "actions": ["Приветственный бонус", "Второй визит со скидкой"]
            }
        ],
        "total_clients": 295,
        "ai_recommendation": "Сфокусируйтесь на сегменте 'Под угрозой' — 32 клиента с высоким LTV могут уйти. Потенциальная потеря: 640,000₽"
    }


@router.get("/campaigns")
async def get_campaigns(
    tenant_id: int = Query(...),
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Список кампаний по возврату клиентов"""
    
    campaigns = [
        Campaign(
            id=1, name="Реактивация спящих", type=CampaignType.REACTIVATION,
            target_segment="sleeping", target_count=48, sent_count=48,
            opened_count=35, converted_count=12, revenue_generated=36000,
            status="completed"
        ),
        Campaign(
            id=2, name="Дни рождения декабрь", type=CampaignType.BIRTHDAY,
            target_segment="birthday_december", target_count=15, sent_count=15,
            opened_count=14, converted_count=8, revenue_generated=32000,
            status="active"
        ),
        Campaign(
            id=3, name="Новогодняя акция", type=CampaignType.PROMO,
            target_segment="all_active", target_count=200, sent_count=0,
            opened_count=0, converted_count=0, revenue_generated=0,
            status="scheduled"
        ),
    ]
    
    return {
        "items": [c.dict() for c in campaigns],
        "total_revenue": sum(c.revenue_generated for c in campaigns),
        "avg_conversion": 25.0
    }


@router.post("/campaigns/create")
async def create_campaign(
    name: str,
    type: CampaignType,
    segment: str,
    message_template: str,
    discount_percent: Optional[int] = None,
    db: AsyncSession = Depends(get_db)
):
    """Создать новую кампанию"""
    
    return {
        "success": True,
        "campaign_id": 4,
        "estimated_reach": 50,
        "estimated_revenue": 75000,
        "message": "Кампания создана и запланирована на завтра 10:00"
    }


# ============ FEEDBACK ============

@router.get("/feedback")
async def get_feedback(
    tenant_id: int = Query(...),
    rating: Optional[int] = None,
    sentiment: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Список отзывов с AI-анализом"""
    
    feedbacks = [
        FeedbackItem(
            id=1, client_name="Мария С.", rating=5,
            comment="Анна — лучший мастер! Всегда идеальный маникюр",
            sentiment="positive", service="Маникюр с покрытием",
            master="Анна Петрова", date="2024-12-17", responded=True,
            ai_analysis="Лояльный клиент, высоко ценит мастера. Рекомендация: предложить VIP-статус"
        ),
        FeedbackItem(
            id=2, client_name="Ольга В.", rating=4,
            comment="Хорошо, но пришлось подождать 15 минут",
            sentiment="neutral", service="Стрижка",
            master="Елена Козлова", date="2024-12-16", responded=False,
            ai_analysis="Проблема с пунктуальностью. Рекомендация: извиниться и предложить бонус"
        ),
        FeedbackItem(
            id=3, client_name="Анна К.", rating=2,
            comment="Покрытие слезло через 3 дня, очень разочарована",
            sentiment="negative", service="Маникюр с покрытием",
            master="Татьяна Новикова", date="2024-12-15", responded=False,
            ai_analysis="⚠️ КРИТИЧНО: Жалоба на качество. Срочно связаться, предложить бесплатную переделку"
        ),
    ]
    
    return {
        "items": [f.dict() for f in feedbacks],
        "summary": {
            "total": len(feedbacks),
            "avg_rating": 3.7,
            "positive": 1,
            "neutral": 1,
            "negative": 1,
            "unresponded": 2
        },
        "ai_insights": [
            "⚠️ 1 негативный отзыв требует срочного ответа",
            "📊 Средний рейтинг снизился на 0.2 за неделю",
            "👤 Татьяна Новикова получила 2 жалобы за месяц — требуется внимание"
        ]
    }


@router.post("/feedback/{feedback_id}/respond")
async def respond_to_feedback(
    feedback_id: int,
    response: str,
    offer_compensation: bool = False,
    db: AsyncSession = Depends(get_db)
):
    """Ответить на отзыв"""
    
    return {
        "success": True,
        "feedback_id": feedback_id,
        "response_sent": True,
        "compensation_offered": offer_compensation,
        "message": "Ответ отправлен клиенту в Telegram"
    }


# ============ LOYALTY ============

@router.get("/loyalty/program")
async def get_loyalty_program(
    tenant_id: int = Query(...),
    db: AsyncSession = Depends(get_db)
):
    """Настройки программы лояльности"""
    
    return {
        "enabled": True,
        "points_per_ruble": 1,  # 1 балл за 1₽
        "point_value": 0.1,  # 1 балл = 0.1₽
        "tiers": [
            {"name": "Bronze", "min_points": 0, "cashback": 3, "benefits": ["Накопление баллов"]},
            {"name": "Silver", "min_points": 5000, "cashback": 5, "benefits": ["Накопление баллов", "Приоритетная запись"]},
            {"name": "Gold", "min_points": 15000, "cashback": 7, "benefits": ["Накопление баллов", "Приоритетная запись", "Бесплатная отмена"]},
            {"name": "Platinum", "min_points": 50000, "cashback": 10, "benefits": ["Все преимущества", "Персональный менеджер", "Эксклюзивные акции"]},
        ],
        "referral_bonus": 500,  # баллов за приведённого друга
        "birthday_bonus": 1000,
    }


@router.get("/loyalty/client/{client_id}")
async def get_client_loyalty(
    client_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Лояльность конкретного клиента"""
    
    return LoyaltyProgram(
        client_id=client_id,
        client_name="Мария Сидорова",
        points_balance=12500,
        points_earned_total=18000,
        points_spent_total=5500,
        current_tier="Silver",
        next_tier="Gold",
        points_to_next_tier=2500,
        cashback_percent=5,
        benefits=["Накопление баллов", "Приоритетная запись"]
    ).dict()


@router.get("/certificates")
async def get_certificates(
    tenant_id: int = Query(...),
    db: AsyncSession = Depends(get_db)
):
    """Подарочные сертификаты"""
    
    return {
        "templates": [
            {"id": 1, "name": "Сертификат 3,000₽", "value": 3000, "price": 3000, "validity_days": 365},
            {"id": 2, "name": "Сертификат 5,000₽", "value": 5000, "price": 5000, "validity_days": 365},
            {"id": 3, "name": "Сертификат 10,000₽", "value": 10000, "price": 9500, "validity_days": 365},
        ],
        "issued": [
            {"code": "GIFT-2024-001", "value": 5000, "balance": 2500, "issued_date": "2024-11-15", "expires": "2025-11-15", "status": "active"},
            {"code": "GIFT-2024-002", "value": 3000, "balance": 0, "issued_date": "2024-10-01", "expires": "2025-10-01", "status": "used"},
        ],
        "stats": {
            "total_issued": 45,
            "total_value": 180000,
            "redeemed_value": 120000,
            "outstanding_value": 60000
        }
    }
