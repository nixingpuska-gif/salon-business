"""
Business OS - Payment Models
Модели платежей и финансовых операций
"""

from datetime import datetime, date
from typing import Optional
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, BigInteger, 
    DateTime, Date, Numeric, ForeignKey, JSON, Index
)
from sqlalchemy.orm import relationship
import enum

from app.models.base import TenantBaseModel


class PaymentStatus(str, enum.Enum):
    """Статусы платежа"""
    PENDING = "pending"
    COMPLETED = "completed"
    PARTIAL = "partial"
    REFUNDED = "refunded"
    FAILED = "failed"
    CANCELLED = "cancelled"


class PaymentMethod(str, enum.Enum):
    """Способы оплаты"""
    CASH = "cash"
    CARD = "card"
    TRANSFER = "transfer"
    SBP = "sbp"
    BONUS = "bonus"
    MIXED = "mixed"
    ONLINE = "online"


class Payment(TenantBaseModel):
    """
    Платёж.
    Основная финансовая сущность.
    """
    __tablename__ = "payments"
    
    # === Привязки ===
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=False, index=True)
    client_id = Column(BigInteger, ForeignKey("clients.id"), nullable=False, index=True)
    appointment_id = Column(BigInteger, ForeignKey("appointments.id"), nullable=True, index=True)
    staff_id = Column(BigInteger, nullable=True)  # Кто принял оплату
    
    # === Суммы ===
    amount = Column(Numeric(10, 2), nullable=False)  # Общая сумма
    service_amount = Column(Numeric(10, 2), default=0)  # За услуги
    product_amount = Column(Numeric(10, 2), default=0)  # За товары
    tip_amount = Column(Numeric(10, 2), default=0)  # Чаевые
    
    # === Скидки ===
    discount_amount = Column(Numeric(10, 2), default=0)
    discount_reason = Column(String(255), nullable=True)
    promotion_id = Column(BigInteger, nullable=True)
    
    # === Бонусы ===
    bonus_used = Column(Integer, default=0)  # Списано бонусов (в копейках)
    bonus_earned = Column(Integer, default=0)  # Начислено бонусов
    
    # === Итого к оплате ===
    final_amount = Column(Numeric(10, 2), nullable=False)
    
    # === Способ оплаты ===
    payment_method = Column(String(50), default=PaymentMethod.CASH.value)
    
    # === Для смешанной оплаты ===
    payment_details = Column(JSON, default=dict)
    # {"cash": 1000, "card": 2000, "bonus": 500}
    
    # === Статус ===
    status = Column(String(50), default=PaymentStatus.COMPLETED.value, index=True)
    
    # === Дата ===
    paid_at = Column(DateTime, default=datetime.utcnow)
    
    # === Онлайн-оплата ===
    external_payment_id = Column(String(255), nullable=True)  # ID в платёжной системе
    payment_provider = Column(String(50), nullable=True)  # yookassa, stripe, etc.
    
    # === Чек ===
    receipt_number = Column(String(100), nullable=True)
    receipt_url = Column(String(500), nullable=True)
    fiscal_receipt_id = Column(String(255), nullable=True)  # ID фискального чека
    
    # === Комментарий ===
    notes = Column(Text, nullable=True)
    
    # === Relationships ===
    client = relationship("Client", back_populates="payments")
    appointment = relationship("Appointment", back_populates="payment")
    items = relationship("PaymentItem", back_populates="payment", lazy="dynamic")
    refunds = relationship("Refund", back_populates="payment", lazy="dynamic")
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_payments_tenant_date', 'tenant_id', 'paid_at'),
        Index('ix_payments_tenant_client', 'tenant_id', 'client_id'),
        Index('ix_payments_tenant_branch', 'tenant_id', 'branch_id'),
    )


class PaymentItem(TenantBaseModel):
    """
    Позиция в платеже.
    Детализация: какие услуги/товары оплачены.
    """
    __tablename__ = "payment_items"
    
    payment_id = Column(BigInteger, ForeignKey("payments.id"), nullable=False, index=True)
    
    # === Тип позиции ===
    item_type = Column(String(20), nullable=False)  # service, product, tip
    
    # === Привязка к сущности ===
    service_id = Column(BigInteger, nullable=True)
    product_id = Column(BigInteger, nullable=True)
    
    # === Описание ===
    name = Column(String(255), nullable=False)
    quantity = Column(Integer, default=1)
    
    # === Цена ===
    unit_price = Column(Numeric(10, 2), nullable=False)
    discount_amount = Column(Numeric(10, 2), default=0)
    total_price = Column(Numeric(10, 2), nullable=False)
    
    # === Мастер (для услуг) ===
    staff_id = Column(BigInteger, nullable=True)
    
    # === Relationships ===
    payment = relationship("Payment", back_populates="items")


class Refund(TenantBaseModel):
    """
    Возврат средств.
    """
    __tablename__ = "refunds"
    
    payment_id = Column(BigInteger, ForeignKey("payments.id"), nullable=False, index=True)
    
    # === Сумма возврата ===
    amount = Column(Numeric(10, 2), nullable=False)
    
    # === Причина ===
    reason = Column(Text, nullable=False)
    
    # === Кто оформил ===
    processed_by_id = Column(BigInteger, nullable=True)
    
    # === Статус ===
    status = Column(String(50), default="completed")
    
    # === Способ возврата ===
    refund_method = Column(String(50), nullable=True)  # cash, card, bonus
    
    # === Внешний ID ===
    external_refund_id = Column(String(255), nullable=True)
    
    # === Relationships ===
    payment = relationship("Payment", back_populates="refunds")


class CashRegister(TenantBaseModel):
    """
    Кассовая смена.
    Для учёта наличных.
    """
    __tablename__ = "cash_registers"
    
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=False, index=True)
    
    # === Смена ===
    opened_at = Column(DateTime, nullable=False)
    closed_at = Column(DateTime, nullable=True)
    
    # === Кто открыл/закрыл ===
    opened_by_id = Column(BigInteger, nullable=False)
    closed_by_id = Column(BigInteger, nullable=True)
    
    # === Суммы ===
    opening_balance = Column(Numeric(10, 2), default=0)
    closing_balance = Column(Numeric(10, 2), nullable=True)
    
    # === Операции за смену ===
    total_cash_in = Column(Numeric(10, 2), default=0)
    total_cash_out = Column(Numeric(10, 2), default=0)
    total_card = Column(Numeric(10, 2), default=0)
    total_other = Column(Numeric(10, 2), default=0)
    
    # === Расхождение ===
    discrepancy = Column(Numeric(10, 2), nullable=True)
    discrepancy_reason = Column(Text, nullable=True)
    
    # === Статус ===
    is_closed = Column(Boolean, default=False)


class CashOperation(TenantBaseModel):
    """
    Кассовая операция (внесение/изъятие наличных).
    """
    __tablename__ = "cash_operations"
    
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=False, index=True)
    cash_register_id = Column(BigInteger, ForeignKey("cash_registers.id"), nullable=True)
    
    # === Тип операции ===
    operation_type = Column(String(20), nullable=False)  # deposit, withdrawal
    
    # === Сумма ===
    amount = Column(Numeric(10, 2), nullable=False)
    
    # === Причина ===
    reason = Column(String(255), nullable=False)
    notes = Column(Text, nullable=True)
    
    # === Кто выполнил ===
    performed_by_id = Column(BigInteger, nullable=False)


class Expense(TenantBaseModel):
    """
    Расходы салона.
    Для учёта затрат.
    """
    __tablename__ = "expenses"
    
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=True)
    
    # === Категория ===
    category = Column(String(100), nullable=False)
    # rent, utilities, supplies, salary, marketing, equipment, other
    
    # === Описание ===
    description = Column(String(500), nullable=False)
    
    # === Сумма ===
    amount = Column(Numeric(10, 2), nullable=False)
    
    # === Дата ===
    expense_date = Column(Date, nullable=False)
    
    # === Документ ===
    document_url = Column(String(500), nullable=True)
    document_number = Column(String(100), nullable=True)
    
    # === Поставщик ===
    vendor_name = Column(String(255), nullable=True)
    
    # === Статус ===
    is_paid = Column(Boolean, default=True)
    paid_at = Column(DateTime, nullable=True)
    
    # === Периодичность ===
    is_recurring = Column(Boolean, default=False)
    recurring_frequency = Column(String(20), nullable=True)  # monthly, quarterly, yearly


class FinancialReport(TenantBaseModel):
    """
    Финансовые отчёты (кэшированные).
    Для быстрого доступа к агрегированным данным.
    """
    __tablename__ = "financial_reports"
    
    branch_id = Column(BigInteger, nullable=True)  # null = по всем филиалам
    
    # === Период ===
    report_type = Column(String(20), nullable=False)  # daily, weekly, monthly, yearly
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    
    # === Выручка ===
    total_revenue = Column(Numeric(12, 2), default=0)
    service_revenue = Column(Numeric(12, 2), default=0)
    product_revenue = Column(Numeric(12, 2), default=0)
    tip_revenue = Column(Numeric(12, 2), default=0)
    
    # === Расходы ===
    total_expenses = Column(Numeric(12, 2), default=0)
    salary_expenses = Column(Numeric(12, 2), default=0)
    consumable_expenses = Column(Numeric(12, 2), default=0)
    other_expenses = Column(Numeric(12, 2), default=0)
    
    # === Прибыль ===
    gross_profit = Column(Numeric(12, 2), default=0)
    net_profit = Column(Numeric(12, 2), default=0)
    
    # === Метрики ===
    total_appointments = Column(Integer, default=0)
    completed_appointments = Column(Integer, default=0)
    cancelled_appointments = Column(Integer, default=0)
    no_show_appointments = Column(Integer, default=0)
    
    avg_check = Column(Numeric(10, 2), default=0)
    
    new_clients = Column(Integer, default=0)
    returning_clients = Column(Integer, default=0)
    
    # === Потери ===
    lost_revenue_cancellations = Column(Numeric(12, 2), default=0)
    lost_revenue_no_shows = Column(Numeric(12, 2), default=0)
    lost_revenue_empty_slots = Column(Numeric(12, 2), default=0)
    
    # === Детальные данные ===
    details = Column(JSON, default=dict)
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_financial_reports_tenant_period', 'tenant_id', 'report_type', 'period_start'),
    )
