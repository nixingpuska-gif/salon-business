import { useState } from 'react'
import { Plus, Package, Search, AlertTriangle, TrendingDown, ArrowUpRight, ArrowDownRight, Edit2, Trash2 } from 'lucide-react'
import clsx from 'clsx'

interface InventoryItem {
  id: number
  name: string
  sku: string
  category: string
  quantity: number
  unit: string
  minQuantity: number
  price: number
  supplier: string
  lastRestockDate: string
}

interface StockMovement {
  id: number
  itemId: number
  itemName: string
  type: 'in' | 'out'
  quantity: number
  date: string
  note: string
}

const mockItems: InventoryItem[] = [
  { id: 1, name: 'Гель-лак OPI Red', sku: 'GL-001', category: 'Гель-лаки', quantity: 12, unit: 'шт', minQuantity: 5, price: 890, supplier: 'OPI Russia', lastRestockDate: '2024-12-10' },
  { id: 2, name: 'Гель-лак OPI Pink', sku: 'GL-002', category: 'Гель-лаки', quantity: 8, unit: 'шт', minQuantity: 5, price: 890, supplier: 'OPI Russia', lastRestockDate: '2024-12-10' },
  { id: 3, name: 'База для гель-лака', sku: 'GL-BASE', category: 'Базы', quantity: 3, unit: 'шт', minQuantity: 5, price: 1200, supplier: 'OPI Russia', lastRestockDate: '2024-12-05' },
  { id: 4, name: 'Топ для гель-лака', sku: 'GL-TOP', category: 'Топы', quantity: 4, unit: 'шт', minQuantity: 5, price: 1200, supplier: 'OPI Russia', lastRestockDate: '2024-12-05' },
  { id: 5, name: 'Пилка 180/240', sku: 'TOOL-001', category: 'Инструменты', quantity: 50, unit: 'шт', minQuantity: 20, price: 45, supplier: 'Staleks', lastRestockDate: '2024-12-01' },
  { id: 6, name: 'Баф 100/180', sku: 'TOOL-002', category: 'Инструменты', quantity: 30, unit: 'шт', minQuantity: 15, price: 65, supplier: 'Staleks', lastRestockDate: '2024-12-01' },
  { id: 7, name: 'Ватные диски', sku: 'CONS-001', category: 'Расходники', quantity: 200, unit: 'шт', minQuantity: 100, price: 3, supplier: 'Медтехника', lastRestockDate: '2024-12-15' },
  { id: 8, name: 'Жидкость для снятия', sku: 'CONS-002', category: 'Расходники', quantity: 2, unit: 'л', minQuantity: 3, price: 450, supplier: 'OPI Russia', lastRestockDate: '2024-11-20' },
  { id: 9, name: 'Краска для волос L\'Oreal', sku: 'HAIR-001', category: 'Краски', quantity: 15, unit: 'шт', minQuantity: 10, price: 650, supplier: 'L\'Oreal Pro', lastRestockDate: '2024-12-12' },
  { id: 10, name: 'Шампунь профессиональный', sku: 'HAIR-002', category: 'Уход', quantity: 6, unit: 'л', minQuantity: 3, price: 1800, supplier: 'L\'Oreal Pro', lastRestockDate: '2024-12-08' },
]

const mockMovements: StockMovement[] = [
  { id: 1, itemId: 1, itemName: 'Гель-лак OPI Red', type: 'out', quantity: 1, date: '2024-12-17', note: 'Использовано на услуге' },
  { id: 2, itemId: 7, itemName: 'Ватные диски', type: 'out', quantity: 20, date: '2024-12-17', note: 'Ежедневный расход' },
  { id: 3, itemId: 3, itemName: 'База для гель-лака', type: 'in', quantity: 5, date: '2024-12-15', note: 'Поставка от OPI Russia' },
  { id: 4, itemId: 5, itemName: 'Пилка 180/240', type: 'out', quantity: 5, date: '2024-12-16', note: 'Списание' },
]

const categories = ['Все', 'Гель-лаки', 'Базы', 'Топы', 'Инструменты', 'Расходники', 'Краски', 'Уход']

export default function Inventory() {
  const [items] = useState<InventoryItem[]>(mockItems)
  const [movements] = useState<StockMovement[]>(mockMovements)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('Все')
  const [showLowStock, setShowLowStock] = useState(false)
  const [activeTab, setActiveTab] = useState<'items' | 'movements'>('items')
  const [showAddModal, setShowAddModal] = useState(false)
  const [showRestockModal, setShowRestockModal] = useState(false)

  const filteredItems = items.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.sku.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === 'Все' || item.category === selectedCategory
    const matchesLowStock = !showLowStock || item.quantity <= item.minQuantity
    return matchesSearch && matchesCategory && matchesLowStock
  })

  const lowStockCount = items.filter(item => item.quantity <= item.minQuantity).length
  const totalValue = items.reduce((sum, item) => sum + item.quantity * item.price, 0)
  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Склад</h1>
          <p className="text-gray-500 mt-1">Учёт расходников и материалов</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowRestockModal(true)} className="btn-secondary flex items-center gap-2">
            <Package className="w-5 h-5" />
            Приход
          </button>
          <button onClick={() => setShowAddModal(true)} className="btn-primary flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Добавить товар
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="card min-w-0">
          <div className="text-sm text-gray-500 truncate">Всего позиций</div>
          <div className="text-xl md:text-2xl font-bold text-gray-900 mt-1">{items.length}</div>
        </div>
        <div className="card min-w-0">
          <div className="text-sm text-gray-500 truncate">Общее количество</div>
          <div className="text-xl md:text-2xl font-bold text-gray-900 mt-1">{totalItems.toLocaleString()}</div>
        </div>
        <div className="card min-w-0">
          <div className="text-sm text-gray-500 truncate">Стоимость склада</div>
          <div className="text-lg md:text-2xl font-bold text-gray-900 mt-1 whitespace-nowrap">{totalValue.toLocaleString()}&nbsp;₽</div>
        </div>
        <div className="card min-w-0">
          <div className="flex items-center gap-2">
            <div className="text-sm text-gray-500 truncate">Заканчивается</div>
            {lowStockCount > 0 && <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" />}
          </div>
          <div className={clsx("text-xl md:text-2xl font-bold mt-1", lowStockCount > 0 ? "text-amber-600" : "text-gray-900")}>
            {lowStockCount}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-4 border-b">
        <button
          onClick={() => setActiveTab('items')}
          className={clsx(
            "pb-3 px-1 font-medium border-b-2 transition-colors",
            activeTab === 'items' ? "border-primary-600 text-primary-600" : "border-transparent text-gray-500 hover:text-gray-700"
          )}
        >
          Товары
        </button>
        <button
          onClick={() => setActiveTab('movements')}
          className={clsx(
            "pb-3 px-1 font-medium border-b-2 transition-colors",
            activeTab === 'movements' ? "border-primary-600 text-primary-600" : "border-transparent text-gray-500 hover:text-gray-700"
          )}
        >
          Движение товаров
        </button>
      </div>

      {activeTab === 'items' && (
        <>
          {/* Filters */}
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Поиск по названию или артикулу..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>
            <div className="flex gap-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={clsx(
                    "px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                    selectedCategory === cat ? "bg-primary-100 text-primary-700" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                  )}
                >
                  {cat}
                </button>
              ))}
            </div>
            <button
              onClick={() => setShowLowStock(!showLowStock)}
              className={clsx(
                "flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                showLowStock ? "bg-amber-100 text-amber-700" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
              )}
            >
              <TrendingDown className="w-4 h-4" />
              Заканчивается
            </button>
          </div>

          {/* Items Table */}
          <div className="card overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Товар</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Артикул</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Категория</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Количество</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Цена</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Стоимость</th>
                  <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Действия</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filteredItems.map((item) => (
                  <tr key={item.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                          <Package className="w-5 h-5 text-gray-400" />
                        </div>
                        <div>
                          <div className="font-medium text-gray-900">{item.name}</div>
                          <div className="text-sm text-gray-500">{item.supplier}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{item.sku}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-1 bg-gray-100 rounded text-sm text-gray-600">{item.category}</span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className={clsx("font-medium", item.quantity <= item.minQuantity ? "text-amber-600" : "text-gray-900")}>
                        {item.quantity} {item.unit}
                      </div>
                      {item.quantity <= item.minQuantity && (
                        <div className="text-xs text-amber-500 flex items-center justify-end gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          Мин: {item.minQuantity}
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right text-gray-600">{item.price.toLocaleString()} ₽</td>
                    <td className="px-4 py-3 text-right font-medium text-gray-900">{(item.quantity * item.price).toLocaleString()} ₽</td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {activeTab === 'movements' && (
        <div className="card overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Дата</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Товар</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Тип</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Количество</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Примечание</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {movements.map((movement) => (
                <tr key={movement.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3 text-gray-600">{new Date(movement.date).toLocaleDateString('ru-RU')}</td>
                  <td className="px-4 py-3 font-medium text-gray-900">{movement.itemName}</td>
                  <td className="px-4 py-3">
                    <span className={clsx(
                      "inline-flex items-center gap-1 px-2 py-1 rounded text-sm",
                      movement.type === 'in' ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                    )}>
                      {movement.type === 'in' ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                      {movement.type === 'in' ? 'Приход' : 'Расход'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-medium text-gray-900">{movement.quantity}</td>
                  <td className="px-4 py-3 text-gray-500">{movement.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Item Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Добавить товар</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Название</label>
                <input type="text" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" placeholder="Гель-лак OPI" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Артикул</label>
                  <input type="text" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" placeholder="GL-001" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Категория</label>
                  <select className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500">
                    {categories.filter(c => c !== 'Все').map(cat => <option key={cat}>{cat}</option>)}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Количество</label>
                  <input type="number" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" placeholder="10" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Ед. измерения</label>
                  <select className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500">
                    <option>шт</option>
                    <option>л</option>
                    <option>мл</option>
                    <option>кг</option>
                    <option>г</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Мин. остаток</label>
                  <input type="number" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" placeholder="5" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Цена закупки</label>
                  <input type="number" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" placeholder="890" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Поставщик</label>
                  <input type="text" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" placeholder="OPI Russia" />
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowAddModal(false)} className="flex-1 py-3 border border-gray-200 rounded-xl text-gray-600 hover:bg-gray-50">Отмена</button>
              <button onClick={() => setShowAddModal(false)} className="flex-1 py-3 bg-primary-600 text-white rounded-xl hover:bg-primary-700">Добавить</button>
            </div>
          </div>
        </div>
      )}

      {/* Restock Modal */}
      {showRestockModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 w-full max-w-lg">
            <h2 className="text-xl font-bold text-gray-900 mb-6">Оформить приход</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Товар</label>
                <select className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500">
                  {items.map(item => <option key={item.id} value={item.id}>{item.name} ({item.sku})</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Количество</label>
                <input type="number" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" placeholder="10" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Примечание</label>
                <textarea className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500" rows={3} placeholder="Поставка от поставщика..." />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowRestockModal(false)} className="flex-1 py-3 border border-gray-200 rounded-xl text-gray-600 hover:bg-gray-50">Отмена</button>
              <button onClick={() => setShowRestockModal(false)} className="flex-1 py-3 bg-primary-600 text-white rounded-xl hover:bg-primary-700">Оформить</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
