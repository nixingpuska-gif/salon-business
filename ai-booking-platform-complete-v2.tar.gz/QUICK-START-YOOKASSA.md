# 🚀 Quick Start: ЮKassa Биллинг

## За 15 минут

### 1. Зарегистрироваться в ЮKassa

1. Откройте [yookassa.ru](https://yookassa.ru/)
2. Зарегистрируйтесь (ИП или юр. лицо)
3. Пройдите верификацию

### 2. Получить учётные данные

В личном кабинете:
1. **Настройки** → **Магазины**
2. Скопируйте:
   - `shopId` (например, 123456)
   - `Секретный ключ` (например, live_xxx...)

### 3. Настроить Webhook

1. **Настройки** → **Уведомления**
2. Добавьте URL:
   ```
   https://your-domain.com/payment/webhook
   ```
3. Выберите события:
   - ✅ payment.succeeded
   - ✅ payment.canceled
   - ✅ refund.succeeded

### 4. Добавить в `.env`

```env
# ЮKassa
YOOKASSA_SHOP_ID=123456
YOOKASSA_SECRET_KEY=live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Frontend URL
FRONTEND_URL=https://your-domain.com
```

### 5. Обновить Prisma Schema

Добавьте в `schema.prisma`:

```prisma
model Business {
  // ... существующие поля ...
  payments        Payment[]
}

model Payment {
  id              String    @id
  businessId      String
  amount          Float
  currency        String    @default("RUB")
  status          String
  description     String
  confirmationUrl String?
  capturedAt      DateTime?
  metadata        Json      @default({})
  yookassaData    Json      @default({})
  createdAt       DateTime  @default(now())
  updatedAt       DateTime  @updatedAt

  business        Business  @relation(fields: [businessId], references: [id], onDelete: Cascade)
  refunds         Refund[]

  @@index([businessId])
  @@index([status])
}

model Refund {
  id           String   @id
  paymentId    String
  amount       Float
  status       String
  yookassaData Json     @default({})
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt

  payment      Payment  @relation(fields: [paymentId], references: [id], onDelete: Cascade)

  @@index([paymentId])
}
```

### 6. Применить миграцию

```bash
cd backend
npx prisma migrate dev --name add_payments
```

### 7. Установить зависимости

```bash
npm install uuid
npm install --save-dev @types/uuid
```

### 8. Запустить сервер

```bash
npm run start:dev
```

### 9. Проверить API

#### Создать платёж:
```bash
curl -X POST http://localhost:3000/payment/create \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "1",
    "tier": "pro",
    "durationMonths": 1
  }'
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "2d8f0e7a-000f-5000-9000-1b8e7e7e7e7e",
    "confirmationUrl": "https://yoomoney.ru/checkout/payments/v2/contract?orderId=...",
    "amount": 2990,
    "status": "pending"
  }
}
```

#### Получить историю:
```bash
curl http://localhost:3000/payment/history/1
```

---

## Тестирование

### Тестовые карты:

| Номер | Результат |
|-------|-----------|
| `5555 5555 5555 4477` | Успешный платёж |
| `5555 5555 5555 5599` | Отклонённый платёж |

**CVV:** любой  
**Срок:** любая будущая дата

### Локальное тестирование webhook:

```bash
# 1. Установить ngrok
brew install ngrok  # macOS
# или скачать с https://ngrok.com/

# 2. Запустить ngrok
ngrok http 3000

# 3. Скопировать URL (например, https://abc123.ngrok.io)
# 4. Добавить в ЮKassa: https://abc123.ngrok.io/payment/webhook
```

---

## Frontend интеграция

### Создание платежа:

```typescript
// 1. Создать платёж
const response = await fetch('/payment/create', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    businessId: '1',
    tier: 'pro',
    durationMonths: 1,
  }),
});

const { data } = await response.json();

// 2. Перенаправить на оплату
window.location.href = data.confirmationUrl;
```

### Проверка статуса:

```typescript
// После возврата с оплаты
const paymentId = new URLSearchParams(window.location.search).get('paymentId');

const response = await fetch(`/payment/${paymentId}`);
const { data } = await response.json();

if (data.status === 'succeeded') {
  alert('Подписка активирована!');
}
```

---

## Как это работает

1. **Пользователь выбирает тариф** → Frontend вызывает `POST /payment/create`
2. **Система создаёт платёж** → Возвращает `confirmationUrl`
3. **Пользователь оплачивает** → Перенаправляется на ЮKassa
4. **ЮKassa отправляет webhook** → `POST /payment/webhook`
5. **Подписка активируется автоматически** → Через `SubscriptionService`
6. **Пользователь получает доступ** → Feature flags разрешают функции

---

## Цены тарифов

| План | Цена/мес |
|------|----------|
| Free | 0 ₽ |
| Basic | 990 ₽ |
| Pro | 2,990 ₽ |
| Enterprise | 9,990 ₽ |

---

## Готово! 🎉

**Биллинг через ЮKassa работает!**

Подробнее: см. **YOOKASSA-PAYMENT-GUIDE.md**
