# 🔔 Руководство по системе уведомлений (BullMQ)

## Обзор

Система автоматических уведомлений на базе BullMQ для отправки напоминаний клиентам о предстоящих записях через все доступные каналы (Telegram, WhatsApp, Instagram).

---

## Архитектура

### Компоненты

1. **NotificationService** - управление уведомлениями
   - Планирование напоминаний
   - Отмена напоминаний
   - Перепланирование при переносе
   - Отправка через каналы

2. **NotificationProcessor** - обработка задач из очереди
   - Обработка напоминаний за 24ч
   - Обработка напоминаний за 2ч
   - Retry логика при ошибках

3. **NotificationController** - API для управления
   - Статистика очереди
   - Просмотр запланированных задач
   - Ручное управление напоминаниями

4. **BullMQ Queue** - очередь задач
   - Redis для хранения
   - Delayed jobs для отложенной отправки
   - Автоматический retry при ошибках

---

## Как это работает

### 1. Создание записи

```typescript
// Клиент создаёт запись через AI-бота
const booking = await bookingService.create({
  businessId: '1',
  clientId: '123',
  serviceId: '456',
  startTime: new Date('2024-12-01T14:00:00'),
});

// Автоматически планируются 2 напоминания:
// - За 24 часа: 2024-11-30T14:00:00
// - За 2 часа: 2024-12-01T12:00:00
```

### 2. Обработка напоминаний

```
Время наступает → BullMQ запускает задачу → NotificationProcessor обрабатывает
                                                    ↓
                                          NotificationService отправляет
                                                    ↓
                                    Выбор канала (Telegram → WhatsApp → Instagram)
                                                    ↓
                                          Клиент получает сообщение
```

### 3. Перенос записи

```typescript
// Клиент переносит запись
await bookingService.reschedule(bookingId, newStartTime);

// Автоматически:
// 1. Отменяются старые напоминания
// 2. Создаются новые с учётом нового времени
```

### 4. Отмена записи

```typescript
// Клиент отменяет запись
await bookingService.cancel(bookingId);

// Автоматически:
// - Отменяются все запланированные напоминания
```

---

## Настройка

### 1. Установка Redis

#### Docker (рекомендуется)
```bash
docker run -d \
  --name redis \
  -p 6379:6379 \
  redis:7-alpine
```

#### Ubuntu/Debian
```bash
sudo apt update
sudo apt install redis-server
sudo systemctl start redis
sudo systemctl enable redis
```

#### macOS
```bash
brew install redis
brew services start redis
```

### 2. Переменные окружения

Добавьте в `backend/.env`:

```env
# Redis Configuration
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=  # Оставьте пустым для локальной разработки
```

### 3. Проверка подключения

```bash
# Проверка Redis
redis-cli ping
# Должно вернуть: PONG
```

---

## API Endpoints

### GET /notifications/stats
Получить статистику очереди

**Response:**
```json
{
  "success": true,
  "data": {
    "waiting": 5,
    "active": 1,
    "completed": 120,
    "failed": 2,
    "delayed": 10,
    "total": 16
  }
}
```

### GET /notifications/scheduled
Получить список запланированных напоминаний

**Response:**
```json
{
  "success": true,
  "count": 10,
  "data": [
    {
      "id": "booking-123-24h",
      "name": "booking-reminder-24h",
      "data": {
        "bookingId": 123,
        "clientId": "456",
        "reminderType": "24h"
      },
      "delay": 86400000,
      "scheduledFor": "2024-12-01T14:00:00.000Z"
    }
  ]
}
```

### POST /notifications/booking/:id/schedule
Запланировать напоминания для записи

**Response:**
```json
{
  "success": true,
  "message": "Reminders scheduled for booking 123"
}
```

### DELETE /notifications/booking/:id/cancel
Отменить напоминания для записи

**Response:**
```json
{
  "success": true,
  "message": "Reminders cancelled for booking 123"
}
```

### POST /notifications/booking/:id/reschedule
Перепланировать напоминания

**Response:**
```json
{
  "success": true,
  "message": "Reminders rescheduled for booking 123"
}
```

---

## Формат сообщений

### Напоминание за 24 часа

```
🔔 Напоминание о записи завтра!

📅 Дата: 1 декабря
🕐 Время: 14:00
💇 Услуга: Маникюр
📍 Салон красоты "Мария"

Если нужно перенести или отменить запись, напишите мне.
```

### Напоминание за 2 часа

```
🔔 Напоминание о записи через 2 часа!

📅 Дата: 1 декабря
🕐 Время: 14:00
💇 Услуга: Маникюр
📍 Салон красоты "Мария"

Если нужно перенести или отменить запись, напишите мне.
```

---

## Приоритет каналов

Система отправляет напоминание через первый доступный канал:

1. **Telegram** (если есть `telegramId`)
2. **WhatsApp** (если есть `phone`)
3. **Instagram** (если есть `instagramId`)

Если все каналы недоступны — логируется предупреждение.

---

## Обработка ошибок

### Retry логика

BullMQ автоматически повторяет неудачные задачи:

- **Попытки**: 3
- **Задержка**: экспоненциальная (5s, 25s, 125s)
- **Стратегия**: exponential backoff

### Примеры ошибок

#### WhatsApp API недоступен
```
Попытка 1 → Ошибка → Ждём 5 секунд
Попытка 2 → Ошибка → Ждём 25 секунд
Попытка 3 → Ошибка → Задача помечается как failed
```

#### Клиент заблокировал бота
```
Попытка 1 → Ошибка "User blocked bot"
→ Логируем и пропускаем (не повторяем)
```

---

## Мониторинг

### Логи

```bash
# Просмотр логов в реальном времени
npm run start:dev

# Фильтр по NotificationService
npm run start:dev | grep NotificationService

# Фильтр по NotificationProcessor
npm run start:dev | grep NotificationProcessor
```

### Примеры логов

```
[NotificationService] Scheduled 24h reminder for booking 123 at 2024-12-01T14:00:00.000Z
[NotificationService] Scheduled 2h reminder for booking 123 at 2024-12-01T12:00:00.000Z
[NotificationProcessor] Processing job booking-123-24h of type booking-reminder-24h
[NotificationService] Sent to WhatsApp: +79991234567
```

### Redis CLI

```bash
# Подключение к Redis
redis-cli

# Просмотр всех ключей
KEYS bull:notifications:*

# Просмотр delayed jobs
ZRANGE bull:notifications:delayed 0 -1 WITHSCORES

# Просмотр waiting jobs
LRANGE bull:notifications:wait 0 -1

# Просмотр active jobs
LRANGE bull:notifications:active 0 -1
```

---

## Тестирование

### 1. Ручное планирование

```bash
curl -X POST http://localhost:3000/notifications/booking/123/schedule
```

### 2. Проверка статистики

```bash
curl http://localhost:3000/notifications/stats
```

### 3. Просмотр запланированных

```bash
curl http://localhost:3000/notifications/scheduled
```

### 4. Тестовая запись с коротким интервалом

```typescript
// Создать запись через 5 минут
const booking = await bookingService.create({
  startTime: new Date(Date.now() + 5 * 60 * 1000),
  // ...
});

// Напоминание за 2 часа не будет создано (уже прошло)
// Напоминание за 24 часа не будет создано (уже прошло)
// Для теста можно временно изменить интервалы в notification.service.ts
```

---

## Производительность

### Лимиты

- **Concurrent jobs**: 10 (по умолчанию)
- **Rate limit**: Зависит от канала
  - WhatsApp: 80 сообщений/сек
  - Instagram: 200 сообщений/сек
  - Telegram: 30 сообщений/сек

### Оптимизация

```typescript
// В notification.module.ts можно настроить:
BullModule.registerQueue({
  name: 'notifications',
  defaultJobOptions: {
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 5000,
    },
  },
  settings: {
    maxStalledCount: 2,
    stalledInterval: 30000,
  },
});
```

---

## Распространённые проблемы

### ❌ Redis connection refused
**Решение**:
- Убедитесь, что Redis запущен: `redis-cli ping`
- Проверьте `REDIS_HOST` и `REDIS_PORT` в `.env`
- Проверьте firewall: `sudo ufw allow 6379`

### ❌ Jobs не обрабатываются
**Решение**:
- Проверьте, что NotificationProcessor зарегистрирован
- Проверьте логи: `npm run start:dev | grep Processor`
- Проверьте Redis: `redis-cli LRANGE bull:notifications:wait 0 -1`

### ❌ Напоминания не отправляются
**Решение**:
- Проверьте, что у клиента есть хотя бы один канал (telegramId, phone, instagramId)
- Проверьте, что соответствующий сервис (WhatsApp, Instagram) настроен
- Проверьте логи на ошибки отправки

### ❌ Duplicate reminders
**Решение**:
- Используйте `jobId` для предотвращения дубликатов
- Текущая реализация использует `booking-${bookingId}-24h` и `booking-${bookingId}-2h`

---

## Будущие улучшения

### Планируется

- [ ] Настраиваемые интервалы напоминаний (в настройках бизнеса)
- [ ] Кастомные шаблоны сообщений
- [ ] Напоминания за 1 час (для срочных записей)
- [ ] Напоминания мастеру (не только клиенту)
- [ ] Dashboard для мониторинга очереди
- [ ] Webhook для уведомлений о доставке
- [ ] A/B тестирование текстов напоминаний
- [ ] Аналитика эффективности напоминаний (снижение no-show)

---

## Полезные ссылки

- [BullMQ Documentation](https://docs.bullmq.io/)
- [Redis Documentation](https://redis.io/docs/)
- [NestJS Bull Integration](https://docs.nestjs.com/techniques/queues)

---

## Поддержка

Если возникли проблемы:
1. Проверьте логи сервера: `npm run start:dev`
2. Проверьте Redis: `redis-cli ping`
3. Проверьте статистику очереди: `GET /notifications/stats`
4. Проверьте переменные окружения в `.env`

**Готово!** 🎉 Система автоматических уведомлений работает.
