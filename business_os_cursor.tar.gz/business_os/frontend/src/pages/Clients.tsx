import { useEffect, useState } from 'react'
import { API_URL } from '../config/api'
import { Search, Plus, Phone, Mail, MessageCircle, MoreVertical, Upload, X } from 'lucide-react'
import clsx from 'clsx'

interface Client {
  id: number
  first_name: string
  last_name: string | null
  phone: string
  email: string | null
  segment: string
  total_visits: number
  total_spent: number
  last_visit_at: string | null
  bonus_balance: number
}

const segmentLabels: Record<string, { label: string; color: string }> = {
  new: { label: 'Новый', color: 'bg-blue-100 text-blue-700' },
  regular: { label: 'Постоянный', color: 'bg-green-100 text-green-700' },
  vip: { label: 'VIP', color: 'bg-purple-100 text-purple-700' },
  sleeping: { label: 'Спящий', color: 'bg-amber-100 text-amber-700' },
  lost: { label: 'Потерянный', color: 'bg-red-100 text-red-700' },
  at_risk: { label: 'Под угрозой', color: 'bg-orange-100 text-orange-700' },
}

function formatMoney(amount: number): string {
  return new Intl.NumberFormat('ru-RU', {
    style: 'currency',
    currency: 'RUB',
    minimumFractionDigits: 0,
  }).format(amount)
}

function formatDate(dateStr: string | null): string {
  if (!dateStr) return '—'
  return new Date(dateStr).toLocaleDateString('ru-RU')
}

export default function Clients() {
  const [clients, setClients] = useState<Client[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [segmentFilter, setSegmentFilter] = useState<string>('')
  const [showImportModal, setShowImportModal] = useState(false)

  useEffect(() => {
    const params = new URLSearchParams()
    if (search) params.append('search', search)
    if (segmentFilter) params.append('segment', segmentFilter)
    
    fetch(`${API_URL}/api/v1/clients?${params}`)
      .then(res => res.json())
      .then(data => {
        setClients(data.items || [])
        setLoading(false)
      })
      .catch(err => {
        console.error('Error:', err)
        setLoading(false)
      })
  }, [search, segmentFilter])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Клиенты</h1>
          <p className="text-gray-500 mt-1">Управление клиентской базой</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={() => setShowImportModal(true)}
            className="btn-secondary flex items-center gap-2"
          >
            <Upload className="w-5 h-5" />
            Импорт
          </button>
          <button className="btn-primary flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Добавить клиента
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Поиск по имени или телефону..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input pl-10"
            />
          </div>
          <select 
            value={segmentFilter}
            onChange={(e) => setSegmentFilter(e.target.value)}
            className="input w-48"
          >
            <option value="">Все сегменты</option>
            <option value="new">Новые</option>
            <option value="regular">Постоянные</option>
            <option value="vip">VIP</option>
            <option value="sleeping">Спящие</option>
            <option value="lost">Потерянные</option>
            <option value="at_risk">Под угрозой</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="card overflow-hidden p-0">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
          </div>
        ) : clients.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">Клиенты не найдены</p>
          </div>
        ) : (
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Клиент
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Контакты
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Сегмент
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Визиты
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Потрачено
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Последний визит
                </th>
                <th className="px-6 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {clients.map((client) => (
                <tr key={client.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                        <span className="text-primary-700 font-medium">
                          {client.first_name[0]}{client.last_name?.[0] || ''}
                        </span>
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">
                          {client.first_name} {client.last_name || ''}
                        </div>
                        {client.bonus_balance > 0 && (
                          <div className="text-xs text-amber-600">
                            {client.bonus_balance} бонусов
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      <a href={`tel:${client.phone}`} className="text-gray-500 hover:text-primary-600">
                        <Phone className="w-4 h-4" />
                      </a>
                      {client.email && (
                        <a href={`mailto:${client.email}`} className="text-gray-500 hover:text-primary-600">
                          <Mail className="w-4 h-4" />
                        </a>
                      )}
                      <button className="text-gray-500 hover:text-primary-600">
                        <MessageCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={clsx(
                      "px-2 py-1 rounded-full text-xs font-medium",
                      segmentLabels[client.segment]?.color || 'bg-gray-100 text-gray-700'
                    )}>
                      {segmentLabels[client.segment]?.label || client.segment}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-900">
                    {client.total_visits}
                  </td>
                  <td className="px-6 py-4 text-gray-900">
                    {formatMoney(client.total_spent)}
                  </td>
                  <td className="px-6 py-4 text-gray-500">
                    {formatDate(client.last_visit_at)}
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-gray-400 hover:text-gray-600">
                      <MoreVertical className="w-5 h-5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl w-full max-w-lg p-6 m-4">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Импорт клиентов</h2>
              <button onClick={() => setShowImportModal(false)} className="text-gray-400 hover:text-gray-600">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <p className="text-gray-600 mb-6">
              Выберите источник для импорта клиентской базы
            </p>

            <div className="space-y-3">
              <button className="w-full p-4 border-2 border-gray-200 rounded-xl hover:border-primary-500 hover:bg-primary-50 transition-all text-left group">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center">
                    <span className="text-red-600 font-bold text-lg">1С</span>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900 group-hover:text-primary-700">Импорт из 1С</div>
                    <div className="text-sm text-gray-500">Синхронизация с 1С:Предприятие</div>
                  </div>
                </div>
              </button>

              <button className="w-full p-4 border-2 border-gray-200 rounded-xl hover:border-primary-500 hover:bg-primary-50 transition-all text-left group">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <span className="text-blue-600 font-bold text-sm">Б24</span>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900 group-hover:text-primary-700">Импорт из Битрикс24</div>
                    <div className="text-sm text-gray-500">Импорт контактов из CRM Битрикс24</div>
                  </div>
                </div>
              </button>

              <button className="w-full p-4 border-2 border-gray-200 rounded-xl hover:border-primary-500 hover:bg-primary-50 transition-all text-left group">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <span className="text-green-600 font-bold text-sm">AMO</span>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900 group-hover:text-primary-700">Импорт из amoCRM</div>
                    <div className="text-sm text-gray-500">Импорт контактов из amoCRM</div>
                  </div>
                </div>
              </button>

              <button className="w-full p-4 border-2 border-gray-200 rounded-xl hover:border-primary-500 hover:bg-primary-50 transition-all text-left group">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                    <span className="text-purple-600 font-bold text-sm">YCLIENTS</span>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900 group-hover:text-primary-700">Импорт из YCLIENTS</div>
                    <div className="text-sm text-gray-500">Перенос базы из YCLIENTS</div>
                  </div>
                </div>
              </button>

              <button className="w-full p-4 border-2 border-gray-200 rounded-xl hover:border-primary-500 hover:bg-primary-50 transition-all text-left group">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gray-100 rounded-xl flex items-center justify-center">
                    <Upload className="w-6 h-6 text-gray-600" />
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900 group-hover:text-primary-700">Загрузить Excel/CSV</div>
                    <div className="text-sm text-gray-500">Импорт из файла .xlsx или .csv</div>
                  </div>
                </div>
              </button>
            </div>

            <div className="mt-6 pt-4 border-t">
              <p className="text-xs text-gray-400 text-center">
                После импорта вы сможете проверить и отредактировать данные перед сохранением
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
