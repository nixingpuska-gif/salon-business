import { SetMetadata } from '@nestjs/common';

/**
 * Limit Check Decorator
 * 
 * Декоратор для проверки лимитов подписки
 */

export interface LimitCheckConfig {
  limitType: string;
  getCurrentValue: (request: any) => Promise<number> | number;
}

export const LIMIT_CHECK_KEY = 'limitCheck';

export const CheckLimit = (config: LimitCheckConfig) =>
  SetMetadata(LIMIT_CHECK_KEY, config);
