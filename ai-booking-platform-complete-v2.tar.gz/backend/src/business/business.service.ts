import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Business, Prisma } from '@prisma/client';

@Injectable()
export class BusinessService {
  constructor(private prisma: PrismaService) {}

  /**
   * Create a new business
   */
  async create(data: {
    name: string;
    businessType: string;
    phone?: string;
    email?: string;
    address?: string;
    userId: string;
  }): Promise<Business> {
    return this.prisma.business.create({
      data: {
        name: data.name,
        businessType: data.businessType,
        phone: data.phone,
        email: data.email,
        address: data.address,
        businessUsers: {
          create: {
            userId: data.userId,
            role: 'owner',
          },
        },
      },
      include: {
        businessUsers: {
          include: {
            user: true,
          },
        },
      },
    });
  }

  /**
   * Find business by ID
   */
  async findOne(id: string): Promise<Business> {
    const business = await this.prisma.business.findUnique({
      where: { id },
      include: {
        services: {
          where: { isActive: true },
          orderBy: { displayOrder: 'asc' },
        },
        schedules: {
          orderBy: { createdAt: 'desc' },
        },
        businessUsers: {
          include: {
            user: true,
          },
        },
      },
    });

    if (!business) {
      throw new NotFoundException(`Business with ID ${id} not found`);
    }

    return business;
  }

  /**
   * Find all businesses for a specific user
   */
  async findByUser(userId: string): Promise<Business[]> {
    return this.prisma.business.findMany({
      where: {
        businessUsers: {
          some: { userId },
        },
        deletedAt: null,
      },
      include: {
        services: {
          where: { isActive: true },
        },
        _count: {
          select: {
            bookings: true,
            clients: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Update business information
   */
  async update(
    id: string,
    data: Partial<{
      name: string;
      businessType: string;
      phone: string;
      email: string;
      address: string;
      timezone: string;
      settings: Prisma.JsonValue;
    }>,
  ): Promise<Business> {
    const business = await this.findOne(id);

    return this.prisma.business.update({
      where: { id: business.id },
      data,
    });
  }

  /**
   * Soft delete business
   */
  async delete(id: string): Promise<Business> {
    const business = await this.findOne(id);

    return this.prisma.business.update({
      where: { id: business.id },
      data: {
        deletedAt: new Date(),
      },
    });
  }

  /**
   * Update subscription tier
   */
  async updateSubscription(
    id: string,
    tier: string,
    expiresAt?: Date,
  ): Promise<Business> {
    const business = await this.findOne(id);

    return this.prisma.business.update({
      where: { id: business.id },
      data: {
        subscriptionTier: tier,
        subscriptionExpiresAt: expiresAt,
      },
    });
  }

  /**
   * Check if user has access to business
   */
  async hasAccess(businessId: string, userId: string): Promise<boolean> {
    const count = await this.prisma.businessUser.count({
      where: {
        businessId,
        userId,
      },
    });

    return count > 0;
  }

  /**
   * Add user to business
   */
  async addUser(
    businessId: string,
    userId: string,
    role: string = 'staff',
  ): Promise<void> {
    const business = await this.findOne(businessId);

    await this.prisma.businessUser.create({
      data: {
        businessId: business.id,
        userId,
        role,
      },
    });
  }

  /**
   * Remove user from business
   */
  async removeUser(businessId: string, userId: string): Promise<void> {
    await this.prisma.businessUser.deleteMany({
      where: {
        businessId,
        userId,
      },
    });
  }
}
