/**
 * Function calling tools for Admin AI Agent
 */

export const adminTools = [
  {
    type: 'function' as const,
    function: {
      name: 'create_service',
      description: 'Создать новую услугу',
      parameters: {
        type: 'object',
        properties: {
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
          name: {
            type: 'string',
            description: 'Название услуги',
          },
          durationMinutes: {
            type: 'number',
            description: 'Длительность в минутах',
          },
          price: {
            type: 'number',
            description: 'Цена услуги',
          },
          description: {
            type: 'string',
            description: 'Описание услуги (опционально)',
          },
        },
        required: ['businessId', 'name', 'durationMinutes'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'set_working_hours',
      description: 'Настроить рабочие часы',
      parameters: {
        type: 'object',
        properties: {
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
          daysOfWeek: {
            type: 'array',
            items: { type: 'number' },
            description: 'Дни недели (1=Пн, 7=Вс)',
          },
          startTime: {
            type: 'string',
            description: 'Время начала работы (HH:MM)',
          },
          endTime: {
            type: 'string',
            description: 'Время окончания работы (HH:MM)',
          },
        },
        required: ['businessId', 'daysOfWeek', 'startTime', 'endTime'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'add_break',
      description: 'Добавить перерыв в расписание',
      parameters: {
        type: 'object',
        properties: {
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
          daysOfWeek: {
            type: 'array',
            items: { type: 'number' },
            description: 'Дни недели для перерыва',
          },
          startTime: {
            type: 'string',
            description: 'Время начала перерыва (HH:MM)',
          },
          endTime: {
            type: 'string',
            description: 'Время окончания перерыва (HH:MM)',
          },
        },
        required: ['businessId', 'daysOfWeek', 'startTime', 'endTime'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'add_vacation',
      description: 'Добавить отпуск или выходной',
      parameters: {
        type: 'object',
        properties: {
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
          startDate: {
            type: 'string',
            description: 'Дата начала (YYYY-MM-DD)',
          },
          endDate: {
            type: 'string',
            description: 'Дата окончания (YYYY-MM-DD)',
          },
          type: {
            type: 'string',
            enum: ['vacation', 'holiday'],
            description: 'Тип: отпуск или праздник',
          },
        },
        required: ['businessId', 'startDate', 'endDate'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'get_bookings_today',
      description: 'Получить список записей на сегодня',
      parameters: {
        type: 'object',
        properties: {
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
        },
        required: ['businessId'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'get_bookings_stats',
      description: 'Получить статистику по записям за период',
      parameters: {
        type: 'object',
        properties: {
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
          startDate: {
            type: 'string',
            description: 'Дата начала периода (YYYY-MM-DD)',
          },
          endDate: {
            type: 'string',
            description: 'Дата окончания периода (YYYY-MM-DD)',
          },
        },
        required: ['businessId', 'startDate', 'endDate'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'search_clients',
      description: 'Найти клиентов по имени или телефону',
      parameters: {
        type: 'object',
        properties: {
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
          search: {
            type: 'string',
            description: 'Поисковый запрос (имя или телефон)',
          },
        },
        required: ['businessId', 'search'],
      },
    },
  },
  {
    type: 'function' as const,
    function: {
      name: 'add_client_note',
      description: 'Добавить заметку о клиенте',
      parameters: {
        type: 'object',
        properties: {
          clientId: {
            type: 'string',
            description: 'ID клиента',
          },
          businessId: {
            type: 'string',
            description: 'ID бизнеса',
          },
          note: {
            type: 'string',
            description: 'Текст заметки',
          },
        },
        required: ['clientId', 'businessId', 'note'],
      },
    },
  },
];
