"""
Business OS - Dashboard API
Money Dashboard и аналитика
"""

from datetime import datetime, date, timedelta
from typing import List, Optional
from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy import select, func, and_, desc, case
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.models.appointment import Appointment
from app.models.payment import Payment
from app.models.client import Client
from app.models.staff import Staff

router = APIRouter()


# === Schemas ===

class HeroMetrics(BaseModel):
    revenue_today: float
    revenue_week: float
    revenue_month: float
    revenue_today_change: float  # % change vs same day last week
    revenue_week_change: float
    revenue_month_change: float
    appointments_today: int
    appointments_week: int
    new_clients_week: int
    avg_check: float


class MoneyLost(BaseModel):
    cancellations_amount: float
    cancellations_count: int
    no_shows_amount: float
    no_shows_count: int
    empty_slots_hours: float
    empty_slots_amount: float
    total_lost: float


class MoneyRecovered(BaseModel):
    from_reminders: float
    from_reactivation: float
    from_upsells: float
    total_recovered: float


class MoneyPotential(BaseModel):
    sleeping_clients_count: int
    sleeping_clients_potential: float
    overdue_clients_count: int
    overdue_clients_potential: float
    total_potential: float


class StaffUtilization(BaseModel):
    staff_id: int
    staff_name: str
    utilization_percent: float
    revenue: float
    appointments: int
    avg_check: float


class DashboardOverview(BaseModel):
    hero: HeroMetrics
    money_lost: MoneyLost
    money_recovered: MoneyRecovered
    money_potential: MoneyPotential
    health_score: int  # 0-100
    health_status: str  # green, yellow, red
    staff_utilization: List[StaffUtilization]


class RevenueByPeriod(BaseModel):
    date: str
    revenue: float
    appointments: int
    avg_check: float


class TopService(BaseModel):
    service_id: int
    service_name: str
    revenue: float
    count: int
    percent_of_total: float


class ClientSegment(BaseModel):
    segment: str
    count: int
    revenue: float
    avg_ltv: float


# === Endpoints ===

@router.get("/overview", response_model=DashboardOverview)
async def get_dashboard_overview(
    branch_id: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
):
    """Получить обзор дашборда"""
    tenant_id = 1
    today = date.today()
    week_start = today - timedelta(days=today.weekday())
    month_start = today.replace(day=1)
    last_week_same_day = today - timedelta(days=7)
    
    # Base filters
    base_filter = and_(Payment.tenant_id == tenant_id, Payment.status == "completed", Payment.is_deleted == False)
    if branch_id:
        base_filter = and_(base_filter, Payment.branch_id == branch_id)
    
    # Revenue today
    today_filter = and_(base_filter, func.date(Payment.paid_at) == today)
    revenue_today = float((await db.execute(select(func.sum(Payment.final_amount)).where(today_filter))).scalar() or 0)
    
    # Revenue last week same day
    last_week_filter = and_(base_filter, func.date(Payment.paid_at) == last_week_same_day)
    revenue_last_week_same_day = float((await db.execute(select(func.sum(Payment.final_amount)).where(last_week_filter))).scalar() or 0)
    
    # Revenue this week
    week_filter = and_(base_filter, func.date(Payment.paid_at) >= week_start)
    revenue_week = float((await db.execute(select(func.sum(Payment.final_amount)).where(week_filter))).scalar() or 0)
    
    # Revenue this month
    month_filter = and_(base_filter, func.date(Payment.paid_at) >= month_start)
    revenue_month = float((await db.execute(select(func.sum(Payment.final_amount)).where(month_filter))).scalar() or 0)
    
    # Appointments today
    appt_filter = and_(Appointment.tenant_id == tenant_id, Appointment.is_deleted == False)
    if branch_id:
        appt_filter = and_(appt_filter, Appointment.branch_id == branch_id)
    
    appointments_today = (await db.execute(select(func.count()).where(and_(appt_filter, Appointment.date == today)))).scalar() or 0
    appointments_week = (await db.execute(select(func.count()).where(and_(appt_filter, Appointment.date >= week_start)))).scalar() or 0
    
    # New clients this week
    client_filter = and_(Client.tenant_id == tenant_id, Client.is_deleted == False, func.date(Client.created_at) >= week_start)
    new_clients_week = (await db.execute(select(func.count()).where(client_filter))).scalar() or 0
    
    # Average check
    payments_count = (await db.execute(select(func.count()).where(month_filter))).scalar() or 0
    avg_check = revenue_month / payments_count if payments_count > 0 else 0
    
    # Calculate changes
    revenue_today_change = ((revenue_today - revenue_last_week_same_day) / revenue_last_week_same_day * 100) if revenue_last_week_same_day > 0 else 0
    
    hero = HeroMetrics(
        revenue_today=revenue_today,
        revenue_week=revenue_week,
        revenue_month=revenue_month,
        revenue_today_change=round(revenue_today_change, 1),
        revenue_week_change=0,  # TODO: Calculate
        revenue_month_change=0,  # TODO: Calculate
        appointments_today=appointments_today,
        appointments_week=appointments_week,
        new_clients_week=new_clients_week,
        avg_check=round(avg_check, 0)
    )
    
    # Money Lost - Cancellations
    cancel_filter = and_(appt_filter, Appointment.status == "cancelled", Appointment.date >= month_start)
    cancellations_count = (await db.execute(select(func.count()).where(cancel_filter))).scalar() or 0
    cancellations_amount = float((await db.execute(select(func.sum(Appointment.final_price)).where(cancel_filter))).scalar() or 0)
    
    # Money Lost - No Shows
    noshow_filter = and_(appt_filter, Appointment.status == "no_show", Appointment.date >= month_start)
    no_shows_count = (await db.execute(select(func.count()).where(noshow_filter))).scalar() or 0
    no_shows_amount = float((await db.execute(select(func.sum(Appointment.final_price)).where(noshow_filter))).scalar() or 0)
    
    money_lost = MoneyLost(
        cancellations_amount=cancellations_amount,
        cancellations_count=cancellations_count,
        no_shows_amount=no_shows_amount,
        no_shows_count=no_shows_count,
        empty_slots_hours=0,  # TODO: Calculate from schedule
        empty_slots_amount=0,
        total_lost=cancellations_amount + no_shows_amount
    )
    
    money_recovered = MoneyRecovered(
        from_reminders=0,  # TODO: Track from automation
        from_reactivation=0,
        from_upsells=0,
        total_recovered=0
    )
    
    # Money Potential - Sleeping clients (no visit in 60+ days)
    sleeping_date = today - timedelta(days=60)
    sleeping_filter = and_(
        Client.tenant_id == tenant_id,
        Client.is_deleted == False,
        Client.last_visit_at < sleeping_date,
        Client.last_visit_at.isnot(None)
    )
    sleeping_clients = (await db.execute(select(func.count(), func.avg(Client.avg_check)).where(sleeping_filter))).first()
    sleeping_count = sleeping_clients[0] or 0
    sleeping_avg = float(sleeping_clients[1] or 0)
    
    # Overdue clients (past their return cycle)
    overdue_filter = and_(
        Client.tenant_id == tenant_id,
        Client.is_deleted == False,
        Client.next_expected_visit_at < today,
        Client.next_expected_visit_at.isnot(None)
    )
    overdue_clients = (await db.execute(select(func.count(), func.avg(Client.avg_check)).where(overdue_filter))).first()
    overdue_count = overdue_clients[0] or 0
    overdue_avg = float(overdue_clients[1] or 0)
    
    money_potential = MoneyPotential(
        sleeping_clients_count=sleeping_count,
        sleeping_clients_potential=sleeping_count * sleeping_avg,
        overdue_clients_count=overdue_count,
        overdue_clients_potential=overdue_count * overdue_avg,
        total_potential=sleeping_count * sleeping_avg + overdue_count * overdue_avg
    )
    
    # Health Score
    health_score = 70  # Base score
    if cancellations_count > 10:
        health_score -= 10
    if no_shows_count > 5:
        health_score -= 10
    if sleeping_count > 50:
        health_score -= 10
    if revenue_today_change > 0:
        health_score += 10
    
    health_score = max(0, min(100, health_score))
    health_status = "green" if health_score >= 70 else ("yellow" if health_score >= 40 else "red")
    
    # Staff Utilization
    staff_query = select(Staff).where(Staff.tenant_id == tenant_id, Staff.status == 'active', Staff.is_deleted == False)
    staff_list = (await db.execute(staff_query)).scalars().all()
    
    staff_utilization = []
    for staff in staff_list:
        staff_revenue_query = select(func.sum(Appointment.final_price), func.count()).where(
            and_(appt_filter, Appointment.staff_id == staff.id, Appointment.status == "completed", Appointment.date >= month_start)
        )
        result = (await db.execute(staff_revenue_query)).first()
        staff_revenue = float(result[0] or 0)
        staff_appointments = result[1] or 0
        
        staff_utilization.append(StaffUtilization(
            staff_id=staff.id,
            staff_name=staff.full_name,
            utilization_percent=0,  # TODO: Calculate from schedule
            revenue=staff_revenue,
            appointments=staff_appointments,
            avg_check=staff_revenue / staff_appointments if staff_appointments > 0 else 0
        ))
    
    return DashboardOverview(
        hero=hero,
        money_lost=money_lost,
        money_recovered=money_recovered,
        money_potential=money_potential,
        health_score=health_score,
        health_status=health_status,
        staff_utilization=staff_utilization
    )


@router.get("/revenue-chart")
async def get_revenue_chart(
    period: str = Query("month", regex="^(week|month|quarter|year)$"),
    branch_id: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
):
    """Получить данные для графика выручки"""
    tenant_id = 1
    today = date.today()
    
    if period == "week":
        start_date = today - timedelta(days=7)
        group_by = "day"
    elif period == "month":
        start_date = today - timedelta(days=30)
        group_by = "day"
    elif period == "quarter":
        start_date = today - timedelta(days=90)
        group_by = "week"
    else:  # year
        start_date = today - timedelta(days=365)
        group_by = "month"
    
    base_filter = and_(
        Payment.tenant_id == tenant_id,
        Payment.status == "completed",
        Payment.is_deleted == False,
        func.date(Payment.paid_at) >= start_date
    )
    if branch_id:
        base_filter = and_(base_filter, Payment.branch_id == branch_id)
    
    # Group by date
    query = select(
        func.date(Payment.paid_at).label("date"),
        func.sum(Payment.final_amount).label("revenue"),
        func.count().label("count")
    ).where(base_filter).group_by(func.date(Payment.paid_at)).order_by(func.date(Payment.paid_at))
    
    result = await db.execute(query)
    data = []
    for row in result.all():
        data.append({
            "date": row.date.isoformat() if row.date else None,
            "revenue": float(row.revenue or 0),
            "appointments": row.count or 0
        })
    
    return {"period": period, "data": data}


@router.get("/top-services")
async def get_top_services(
    limit: int = Query(10, ge=1, le=50),
    date_from: Optional[date] = None,
    date_to: Optional[date] = None,
    db: AsyncSession = Depends(get_db),
):
    """Получить топ услуг по выручке"""
    tenant_id = 1
    
    if not date_from:
        date_from = date.today() - timedelta(days=30)
    if not date_to:
        date_to = date.today()
    
    # This is a simplified version - in production would join with services table
    query = select(
        Appointment.service_id,
        func.sum(Appointment.final_price).label("revenue"),
        func.count().label("count")
    ).where(
        Appointment.tenant_id == tenant_id,
        Appointment.status == "completed",
        Appointment.is_deleted == False,
        Appointment.date >= date_from,
        Appointment.date <= date_to
    ).group_by(Appointment.service_id).order_by(desc("revenue")).limit(limit)
    
    result = await db.execute(query)
    total_revenue = 0
    services = []
    
    for row in result.all():
        revenue = float(row.revenue or 0)
        total_revenue += revenue
        services.append({
            "service_id": row.service_id,
            "revenue": revenue,
            "count": row.count
        })
    
    # Add percent
    for s in services:
        s["percent_of_total"] = round(s["revenue"] / total_revenue * 100, 1) if total_revenue > 0 else 0
    
    return {"services": services, "total_revenue": total_revenue}


@router.get("/client-segments")
async def get_client_segments(db: AsyncSession = Depends(get_db)):
    """Получить сегментацию клиентов"""
    tenant_id = 1
    today = date.today()
    
    segments = []
    
    # VIP (top 10% by LTV)
    vip_query = select(func.count(), func.sum(Client.total_spent), func.avg(Client.total_spent)).where(
        Client.tenant_id == tenant_id, Client.is_deleted == False, Client.segment == "vip"
    )
    vip = (await db.execute(vip_query)).first()
    segments.append(ClientSegment(segment="VIP", count=vip[0] or 0, revenue=float(vip[1] or 0), avg_ltv=float(vip[2] or 0)))
    
    # Loyal
    loyal_query = select(func.count(), func.sum(Client.total_spent), func.avg(Client.total_spent)).where(
        Client.tenant_id == tenant_id, Client.is_deleted == False, Client.segment == "loyal"
    )
    loyal = (await db.execute(loyal_query)).first()
    segments.append(ClientSegment(segment="Loyal", count=loyal[0] or 0, revenue=float(loyal[1] or 0), avg_ltv=float(loyal[2] or 0)))
    
    # At Risk
    at_risk_query = select(func.count(), func.sum(Client.total_spent), func.avg(Client.total_spent)).where(
        Client.tenant_id == tenant_id, Client.is_deleted == False, Client.churn_risk == "high"
    )
    at_risk = (await db.execute(at_risk_query)).first()
    segments.append(ClientSegment(segment="At Risk", count=at_risk[0] or 0, revenue=float(at_risk[1] or 0), avg_ltv=float(at_risk[2] or 0)))
    
    # New (first visit in last 30 days)
    new_date = today - timedelta(days=30)
    new_query = select(func.count(), func.sum(Client.total_spent), func.avg(Client.total_spent)).where(
        Client.tenant_id == tenant_id, Client.is_deleted == False, Client.first_visit_date >= new_date
    )
    new = (await db.execute(new_query)).first()
    segments.append(ClientSegment(segment="New", count=new[0] or 0, revenue=float(new[1] or 0), avg_ltv=float(new[2] or 0)))
    
    # Sleeping (no visit 60+ days)
    sleeping_date = today - timedelta(days=60)
    sleeping_query = select(func.count(), func.sum(Client.total_spent), func.avg(Client.total_spent)).where(
        Client.tenant_id == tenant_id, Client.is_deleted == False, Client.last_visit_at < sleeping_date
    )
    sleeping = (await db.execute(sleeping_query)).first()
    segments.append(ClientSegment(segment="Sleeping", count=sleeping[0] or 0, revenue=float(sleeping[1] or 0), avg_ltv=float(sleeping[2] or 0)))
    
    return {"segments": [s.model_dump() for s in segments]}


@router.get("/comparison")
async def get_period_comparison(
    period: str = Query("month", regex="^(week|month|quarter)$"),
    db: AsyncSession = Depends(get_db),
):
    """Сравнение текущего периода с предыдущим"""
    tenant_id = 1
    today = date.today()
    
    if period == "week":
        current_start = today - timedelta(days=today.weekday())
        previous_start = current_start - timedelta(days=7)
        previous_end = current_start - timedelta(days=1)
    elif period == "month":
        current_start = today.replace(day=1)
        previous_end = current_start - timedelta(days=1)
        previous_start = previous_end.replace(day=1)
    else:  # quarter
        current_start = today - timedelta(days=90)
        previous_start = current_start - timedelta(days=90)
        previous_end = current_start - timedelta(days=1)
    
    base_filter = and_(Payment.tenant_id == tenant_id, Payment.status == "completed", Payment.is_deleted == False)
    
    # Current period
    current_filter = and_(base_filter, func.date(Payment.paid_at) >= current_start, func.date(Payment.paid_at) <= today)
    current_revenue = float((await db.execute(select(func.sum(Payment.final_amount)).where(current_filter))).scalar() or 0)
    current_count = (await db.execute(select(func.count()).where(current_filter))).scalar() or 0
    
    # Previous period
    previous_filter = and_(base_filter, func.date(Payment.paid_at) >= previous_start, func.date(Payment.paid_at) <= previous_end)
    previous_revenue = float((await db.execute(select(func.sum(Payment.final_amount)).where(previous_filter))).scalar() or 0)
    previous_count = (await db.execute(select(func.count()).where(previous_filter))).scalar() or 0
    
    revenue_change = ((current_revenue - previous_revenue) / previous_revenue * 100) if previous_revenue > 0 else 0
    count_change = ((current_count - previous_count) / previous_count * 100) if previous_count > 0 else 0
    
    return {
        "period": period,
        "current": {
            "start": current_start.isoformat(),
            "end": today.isoformat(),
            "revenue": current_revenue,
            "transactions": current_count,
            "avg_check": current_revenue / current_count if current_count > 0 else 0
        },
        "previous": {
            "start": previous_start.isoformat(),
            "end": previous_end.isoformat(),
            "revenue": previous_revenue,
            "transactions": previous_count,
            "avg_check": previous_revenue / previous_count if previous_count > 0 else 0
        },
        "changes": {
            "revenue_percent": round(revenue_change, 1),
            "transactions_percent": round(count_change, 1)
        }
    }
