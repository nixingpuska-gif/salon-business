"""
Business OS - Models
Все модели данных платформы
"""

# Base models
from app.models.base import BaseModel, TenantBaseModel

# Tenant & Branch
from app.models.tenant import (
    Tenant, TenantStatus, SubscriptionPlan,
    Branch, TenantSettings, Subscription
)

# Users (platform users - owners, admins)
from app.models.user import (
    User, UserRole,
    RefreshToken, PasswordReset, EmailVerification,
    AuditLog
)

# Clients (salon customers)
from app.models.client import (
    Client, ClientSource, ClientSegment,
    ClientNote, ClientBlacklist, ClientMerge
)

# Staff (salon employees)
from app.models.staff import (
    Staff, StaffRole, StaffStatus,
    StaffSchedule, StaffService, StaffVacation, StaffSalary
)

# Services
from app.models.service import (
    ServiceCategory, Service,
    ServiceCombo, ServicePromotion
)

# Appointments
from app.models.appointment import (
    Appointment, AppointmentStatus, AppointmentSource,
    AppointmentHistory, WaitingList, RecurringAppointment
)

# Payments
from app.models.payment import (
    Payment, PaymentStatus, PaymentMethod,
    PaymentItem, Refund,
    CashRegister, CashOperation, Expense,
    FinancialReport
)

# Inventory
from app.models.inventory import (
    InventoryCategory, InventoryItem, InventoryBatch,
    InventorySupply, InventorySupplyItem,
    InventoryConsumption, InventoryAudit, InventoryAuditItem,
    Supplier
)

# Communication
from app.models.communication import (
    Message, MessageChannel, MessageType, MessageStatus,
    MessageTemplate, Conversation, ConversationMessage,
    Review, Notification, Alert
)

# Partners & Leads
from app.models.partner import (
    Partner, PartnerType, PartnerReferral,
    PartnerCommission, PartnerWithdrawal,
    Lead, LeadSource, LeadStatus,
    LeadActivity, LeadMessage, NurturingCampaign
)

__all__ = [
    # Base
    "BaseModel", "TenantBaseModel",
    
    # Tenant
    "Tenant", "TenantStatus", "SubscriptionPlan",
    "Branch", "TenantSettings", "Subscription",
    
    # User
    "User", "UserRole",
    "RefreshToken", "PasswordReset", "EmailVerification",
    "AuditLog",
    
    # Client
    "Client", "ClientSource", "ClientSegment",
    "ClientNote", "ClientBlacklist", "ClientMerge",
    
    # Staff
    "Staff", "StaffRole", "StaffStatus",
    "StaffSchedule", "StaffService", "StaffVacation", "StaffSalary",
    
    # Service
    "ServiceCategory", "Service",
    "ServiceCombo", "ServicePromotion",
    
    # Appointment
    "Appointment", "AppointmentStatus", "AppointmentSource",
    "AppointmentHistory", "WaitingList", "RecurringAppointment",
    
    # Payment
    "Payment", "PaymentStatus", "PaymentMethod",
    "PaymentItem", "Refund",
    "CashRegister", "CashOperation", "Expense",
    "FinancialReport",
    
    # Inventory
    "InventoryCategory", "InventoryItem", "InventoryBatch",
    "InventorySupply", "InventorySupplyItem",
    "InventoryConsumption", "InventoryAudit", "InventoryAuditItem",
    "Supplier",
    
    # Communication
    "Message", "MessageChannel", "MessageType", "MessageStatus",
    "MessageTemplate", "Conversation", "ConversationMessage",
    "Review", "Notification", "Alert",
    
    # Partner
    "Partner", "PartnerType", "PartnerReferral",
    "PartnerCommission", "PartnerWithdrawal",
    "Lead", "LeadSource", "LeadStatus",
    "LeadActivity", "LeadMessage", "NurturingCampaign",
]
