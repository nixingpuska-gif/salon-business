"""
Business OS - Services API
Управление услугами салона
"""

from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from pydantic import BaseModel, Field
from sqlalchemy import select, func, and_, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.models.service import Service, ServiceCategory

router = APIRouter()


# === Schemas ===

class ServiceCategoryCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    sort_order: int = 0
    is_active: bool = True


class ServiceCategoryResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    sort_order: int
    is_active: bool
    
    class Config:
        from_attributes = True


class ServiceCreate(BaseModel):
    category_id: Optional[int] = None
    name: str = Field(..., min_length=1, max_length=200)
    description: Optional[str] = None
    duration_minutes: int = Field(60, ge=5, le=480)
    buffer_before: int = Field(0, ge=0, le=60)
    buffer_after: int = Field(0, ge=0, le=60)
    price: float = Field(..., ge=0)
    price_max: Optional[float] = None
    cost: Optional[float] = None
    is_active: bool = True
    is_online_booking: bool = True
    return_cycle_days: Optional[int] = None


class ServiceUpdate(BaseModel):
    category_id: Optional[int] = None
    name: Optional[str] = None
    description: Optional[str] = None
    duration_minutes: Optional[int] = None
    buffer_before: Optional[int] = None
    buffer_after: Optional[int] = None
    price: Optional[float] = None
    price_max: Optional[float] = None
    cost: Optional[float] = None
    is_active: Optional[bool] = None
    is_online_booking: Optional[bool] = None
    return_cycle_days: Optional[int] = None


class ServiceResponse(BaseModel):
    id: int
    tenant_id: Optional[int] = None
    category_id: Optional[int] = None
    name: str
    description: Optional[str] = None
    duration_minutes: Optional[int] = 60
    buffer_before_minutes: Optional[int] = 0
    buffer_after_minutes: Optional[int] = 0
    price: Optional[float] = 0
    price_from: Optional[float] = None
    price_to: Optional[float] = None
    is_active: Optional[bool] = True
    online_booking_enabled: Optional[bool] = True
    is_popular: Optional[bool] = False
    return_cycle_days: Optional[int] = None
    total_bookings: Optional[int] = 0
    created_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class ServiceListResponse(BaseModel):
    items: List[ServiceResponse]
    total: int


# === Category Endpoints ===

@router.get("/categories", response_model=List[ServiceCategoryResponse])
async def list_categories(
    include_inactive: bool = False,
    db: AsyncSession = Depends(get_db),
):
    """Получить список категорий услуг"""
    tenant_id = 1
    
    query = select(ServiceCategory).where(
        ServiceCategory.tenant_id == tenant_id,
        ServiceCategory.is_deleted == False
    )
    
    if not include_inactive:
        query = query.where(ServiceCategory.is_active == True)
    
    query = query.order_by(ServiceCategory.sort_order, ServiceCategory.name)
    
    result = await db.execute(query)
    categories = result.scalars().all()
    
    return [ServiceCategoryResponse.model_validate(c) for c in categories]


@router.post("/categories", response_model=ServiceCategoryResponse, status_code=201)
async def create_category(
    data: ServiceCategoryCreate,
    db: AsyncSession = Depends(get_db),
):
    """Создать категорию услуг"""
    tenant_id = 1
    
    category = ServiceCategory(
        tenant_id=tenant_id,
        **data.model_dump()
    )
    
    db.add(category)
    await db.commit()
    await db.refresh(category)
    
    return ServiceCategoryResponse.model_validate(category)


@router.put("/categories/{category_id}", response_model=ServiceCategoryResponse)
async def update_category(
    category_id: int,
    data: ServiceCategoryCreate,
    db: AsyncSession = Depends(get_db),
):
    """Обновить категорию"""
    tenant_id = 1
    
    query = select(ServiceCategory).where(
        ServiceCategory.id == category_id,
        ServiceCategory.tenant_id == tenant_id,
        ServiceCategory.is_deleted == False
    )
    
    result = await db.execute(query)
    category = result.scalar_one_or_none()
    
    if not category:
        raise HTTPException(status_code=404, detail="Category not found")
    
    for field, value in data.model_dump().items():
        setattr(category, field, value)
    
    await db.commit()
    await db.refresh(category)
    
    return ServiceCategoryResponse.model_validate(category)


@router.delete("/categories/{category_id}", status_code=204)
async def delete_category(
    category_id: int,
    db: AsyncSession = Depends(get_db),
):
    """Удалить категорию"""
    tenant_id = 1
    
    query = select(ServiceCategory).where(
        ServiceCategory.id == category_id,
        ServiceCategory.tenant_id == tenant_id,
        ServiceCategory.is_deleted == False
    )
    
    result = await db.execute(query)
    category = result.scalar_one_or_none()
    
    if not category:
        raise HTTPException(status_code=404, detail="Category not found")
    
    category.is_deleted = True
    category.deleted_at = datetime.utcnow()
    
    await db.commit()


# === Service Endpoints ===

@router.get("", response_model=ServiceListResponse)
async def list_services(
    category_id: Optional[int] = None,
    is_active: Optional[bool] = None,
    is_online_booking: Optional[bool] = None,
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """Получить список услуг"""
    tenant_id = 1
    
    query = select(Service).where(
        Service.tenant_id == tenant_id,
        Service.is_deleted == False
    )
    
    if category_id:
        query = query.where(Service.category_id == category_id)
    
    if is_active is not None:
        query = query.where(Service.is_active == is_active)
    
    if is_online_booking is not None:
        query = query.where(Service.is_online_booking == is_online_booking)
    
    if search:
        query = query.where(Service.name.ilike(f"%{search}%"))
    
    query = query.order_by(Service.name)
    
    result = await db.execute(query)
    services = result.scalars().all()
    
    return ServiceListResponse(
        items=[ServiceResponse.model_validate(s) for s in services],
        total=len(services)
    )


@router.get("/{service_id}", response_model=ServiceResponse)
async def get_service(
    service_id: int,
    db: AsyncSession = Depends(get_db),
):
    """Получить услугу по ID"""
    tenant_id = 1
    
    query = select(Service).where(
        Service.id == service_id,
        Service.tenant_id == tenant_id,
        Service.is_deleted == False
    )
    
    result = await db.execute(query)
    service = result.scalar_one_or_none()
    
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    
    return ServiceResponse.model_validate(service)


@router.post("", response_model=ServiceResponse, status_code=201)
async def create_service(
    data: ServiceCreate,
    db: AsyncSession = Depends(get_db),
):
    """Создать услугу"""
    tenant_id = 1
    
    # Calculate margin if cost provided
    margin = None
    if data.cost and data.price:
        margin = ((data.price - data.cost) / data.price) * 100
    
    service = Service(
        tenant_id=tenant_id,
        margin=margin,
        **data.model_dump()
    )
    
    db.add(service)
    await db.commit()
    await db.refresh(service)
    
    return ServiceResponse.model_validate(service)


@router.put("/{service_id}", response_model=ServiceResponse)
async def update_service(
    service_id: int,
    data: ServiceUpdate,
    db: AsyncSession = Depends(get_db),
):
    """Обновить услугу"""
    tenant_id = 1
    
    query = select(Service).where(
        Service.id == service_id,
        Service.tenant_id == tenant_id,
        Service.is_deleted == False
    )
    
    result = await db.execute(query)
    service = result.scalar_one_or_none()
    
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    
    update_data = data.model_dump(exclude_unset=True)
    
    for field, value in update_data.items():
        setattr(service, field, value)
    
    # Recalculate margin
    if service.cost and service.price:
        service.margin = ((float(service.price) - float(service.cost)) / float(service.price)) * 100
    
    await db.commit()
    await db.refresh(service)
    
    return ServiceResponse.model_validate(service)


@router.delete("/{service_id}", status_code=204)
async def delete_service(
    service_id: int,
    db: AsyncSession = Depends(get_db),
):
    """Удалить услугу"""
    tenant_id = 1
    
    query = select(Service).where(
        Service.id == service_id,
        Service.tenant_id == tenant_id,
        Service.is_deleted == False
    )
    
    result = await db.execute(query)
    service = result.scalar_one_or_none()
    
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    
    service.is_deleted = True
    service.deleted_at = datetime.utcnow()
    
    await db.commit()


@router.post("/{service_id}/toggle-active", response_model=ServiceResponse)
async def toggle_service_active(
    service_id: int,
    db: AsyncSession = Depends(get_db),
):
    """Переключить активность услуги"""
    tenant_id = 1
    
    query = select(Service).where(
        Service.id == service_id,
        Service.tenant_id == tenant_id,
        Service.is_deleted == False
    )
    
    result = await db.execute(query)
    service = result.scalar_one_or_none()
    
    if not service:
        raise HTTPException(status_code=404, detail="Service not found")
    
    service.is_active = not service.is_active
    
    await db.commit()
    await db.refresh(service)
    
    return ServiceResponse.model_validate(service)
