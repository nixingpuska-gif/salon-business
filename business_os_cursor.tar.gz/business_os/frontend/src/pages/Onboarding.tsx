import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Check, Building2, Users, Scissors, Clock, Loader2, ChevronRight } from 'lucide-react'

const steps = [
  { id: 1, title: 'Информация о салоне', icon: Building2 },
  { id: 2, title: 'Добавьте сотрудников', icon: Users },
  { id: 3, title: 'Настройте услуги', icon: Scissors },
  { id: 4, title: 'График работы', icon: Clock },
]

export default function Onboarding() {
  const navigate = useNavigate()
  const [currentStep, setCurrentStep] = useState(1)
  const [loading, setLoading] = useState(false)

  // Salon info
  const [salonData, setSalonData] = useState({
    address: '',
    city: '',
    phone: '',
    workingHoursStart: '09:00',
    workingHoursEnd: '21:00',
    workingDays: [1, 2, 3, 4, 5, 6], // Mon-Sat
  })

  // Staff
  const [staff, setStaff] = useState<Array<{ name: string; position: string; phone: string }>>([
    { name: '', position: '', phone: '' }
  ])

  // Services (predefined templates)
  const serviceTemplates = [
    { category: 'Парикмахерские услуги', services: ['Стрижка женская', 'Стрижка мужская', 'Окрашивание', 'Укладка'] },
    { category: 'Ногтевой сервис', services: ['Маникюр классический', 'Маникюр с покрытием', 'Педикюр'] },
    { category: 'Косметология', services: ['Чистка лица', 'Пилинг', 'Массаж лица'] },
    { category: 'Массаж', services: ['Массаж спины', 'Общий массаж'] },
  ]
  const [selectedServices, setSelectedServices] = useState<string[]>([])

  const toggleService = (service: string) => {
    setSelectedServices(prev => 
      prev.includes(service) 
        ? prev.filter(s => s !== service)
        : [...prev, service]
    )
  }

  const addStaffMember = () => {
    setStaff(prev => [...prev, { name: '', position: '', phone: '' }])
  }

  const updateStaffMember = (index: number, field: string, value: string) => {
    setStaff(prev => prev.map((s, i) => i === index ? { ...s, [field]: value } : s))
  }

  const removeStaffMember = (index: number) => {
    if (staff.length > 1) {
      setStaff(prev => prev.filter((_, i) => i !== index))
    }
  }

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1)
    }
  }

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1)
    }
  }

  const handleSkip = () => {
    navigate('/dashboard')
  }

  const handleComplete = async () => {
    setLoading(true)
    
    try {
      // Save salon data
      // In production, this would make API calls
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      // Navigate to dashboard
      navigate('/dashboard')
    } catch (error) {
      console.error('Error:', error)
    } finally {
      setLoading(false)
    }
  }

  const weekDays = [
    { id: 1, label: 'Пн' },
    { id: 2, label: 'Вт' },
    { id: 3, label: 'Ср' },
    { id: 4, label: 'Чт' },
    { id: 5, label: 'Пт' },
    { id: 6, label: 'Сб' },
    { id: 0, label: 'Вс' },
  ]

  const toggleWorkingDay = (dayId: number) => {
    setSalonData(prev => ({
      ...prev,
      workingDays: prev.workingDays.includes(dayId)
        ? prev.workingDays.filter(d => d !== dayId)
        : [...prev.workingDays, dayId]
    }))
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-600 rounded-xl flex items-center justify-center">
              <span className="text-white font-bold">B</span>
            </div>
            <span className="font-semibold text-gray-900">Business OS</span>
          </div>
          <button
            onClick={handleSkip}
            className="text-gray-500 hover:text-gray-700 text-sm"
          >
            Пропустить настройку
          </button>
        </div>
      </div>

      {/* Progress */}
      <div className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.id} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                    currentStep > step.id 
                      ? 'bg-green-500 text-white' 
                      : currentStep === step.id 
                        ? 'bg-primary-600 text-white' 
                        : 'bg-gray-100 text-gray-400'
                  }`}>
                    {currentStep > step.id ? (
                      <Check className="w-6 h-6" />
                    ) : (
                      <step.icon className="w-6 h-6" />
                    )}
                  </div>
                  <span className={`mt-2 text-sm ${currentStep >= step.id ? 'text-gray-900' : 'text-gray-400'}`}>
                    {step.title}
                  </span>
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-24 h-1 mx-4 rounded ${currentStep > step.id ? 'bg-green-500' : 'bg-gray-200'}`} />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="bg-white rounded-2xl shadow-sm p-8">
          
          {/* Step 1: Salon Info */}
          {currentStep === 1 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Информация о салоне</h2>
                <p className="text-gray-500 mt-1">Заполните основные данные вашего салона</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Город</label>
                <input
                  type="text"
                  value={salonData.city}
                  onChange={(e) => setSalonData(prev => ({ ...prev, city: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="Москва"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Адрес</label>
                <input
                  type="text"
                  value={salonData.address}
                  onChange={(e) => setSalonData(prev => ({ ...prev, address: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="ул. Пушкина, д. 10"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Телефон салона</label>
                <input
                  type="tel"
                  value={salonData.phone}
                  onChange={(e) => setSalonData(prev => ({ ...prev, phone: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="+7 (495) 123-45-67"
                />
              </div>
            </div>
          )}

          {/* Step 2: Staff */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Добавьте сотрудников</h2>
                <p className="text-gray-500 mt-1">Укажите мастеров, которые работают в вашем салоне</p>
              </div>

              {staff.map((member, index) => (
                <div key={index} className="p-4 bg-gray-50 rounded-xl space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-gray-700">Сотрудник {index + 1}</span>
                    {staff.length > 1 && (
                      <button
                        onClick={() => removeStaffMember(index)}
                        className="text-red-500 hover:text-red-600 text-sm"
                      >
                        Удалить
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      type="text"
                      value={member.name}
                      onChange={(e) => updateStaffMember(index, 'name', e.target.value)}
                      className="px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="Имя Фамилия"
                    />
                    <input
                      type="text"
                      value={member.position}
                      onChange={(e) => updateStaffMember(index, 'position', e.target.value)}
                      className="px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                      placeholder="Должность"
                    />
                  </div>
                  <input
                    type="tel"
                    value={member.phone}
                    onChange={(e) => updateStaffMember(index, 'phone', e.target.value)}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                    placeholder="Телефон"
                  />
                </div>
              ))}

              <button
                onClick={addStaffMember}
                className="w-full py-3 border-2 border-dashed border-gray-300 rounded-xl text-gray-500 hover:border-primary-500 hover:text-primary-600 transition-colors"
              >
                + Добавить ещё сотрудника
              </button>
            </div>
          )}

          {/* Step 3: Services */}
          {currentStep === 3 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Выберите услуги</h2>
                <p className="text-gray-500 mt-1">Отметьте услуги, которые предоставляет ваш салон</p>
              </div>

              {serviceTemplates.map((category) => (
                <div key={category.category} className="space-y-3">
                  <h3 className="font-medium text-gray-900">{category.category}</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {category.services.map((service) => (
                      <button
                        key={service}
                        onClick={() => toggleService(service)}
                        className={`px-4 py-3 rounded-xl text-left transition-all ${
                          selectedServices.includes(service)
                            ? 'bg-primary-100 border-2 border-primary-500 text-primary-700'
                            : 'bg-gray-50 border-2 border-transparent hover:border-gray-200'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          {selectedServices.includes(service) && (
                            <Check className="w-4 h-4 text-primary-600" />
                          )}
                          <span className="text-sm">{service}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              ))}

              <p className="text-sm text-gray-500">
                Выбрано услуг: {selectedServices.length}. Вы сможете настроить цены и время позже.
              </p>
            </div>
          )}

          {/* Step 4: Working Hours */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">График работы</h2>
                <p className="text-gray-500 mt-1">Укажите рабочие дни и часы вашего салона</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">Рабочие дни</label>
                <div className="flex gap-2">
                  {weekDays.map((day) => (
                    <button
                      key={day.id}
                      onClick={() => toggleWorkingDay(day.id)}
                      className={`w-12 h-12 rounded-xl font-medium transition-all ${
                        salonData.workingDays.includes(day.id)
                          ? 'bg-primary-600 text-white'
                          : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                      }`}
                    >
                      {day.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Начало работы</label>
                  <input
                    type="time"
                    value={salonData.workingHoursStart}
                    onChange={(e) => setSalonData(prev => ({ ...prev, workingHoursStart: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Конец работы</label>
                  <input
                    type="time"
                    value={salonData.workingHoursEnd}
                    onChange={(e) => setSalonData(prev => ({ ...prev, workingHoursEnd: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="bg-green-50 rounded-xl p-4">
                <h4 className="font-medium text-green-800 mb-2">🎉 Всё готово!</h4>
                <p className="text-sm text-green-700">
                  После завершения настройки вы сможете начать работу с системой. 
                  Все настройки можно изменить позже в разделе "Настройки".
                </p>
              </div>
            </div>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t">
            {currentStep > 1 ? (
              <button
                onClick={handleBack}
                className="px-6 py-3 text-gray-600 hover:text-gray-900 font-medium"
              >
                Назад
              </button>
            ) : (
              <div />
            )}

            {currentStep < 4 ? (
              <button
                onClick={handleNext}
                className="px-6 py-3 bg-primary-600 text-white rounded-xl font-medium hover:bg-primary-700 flex items-center gap-2"
              >
                Продолжить
                <ChevronRight className="w-5 h-5" />
              </button>
            ) : (
              <button
                onClick={handleComplete}
                disabled={loading}
                className="px-6 py-3 bg-primary-600 text-white rounded-xl font-medium hover:bg-primary-700 flex items-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Сохранение...
                  </>
                ) : (
                  <>
                    Завершить настройку
                    <Check className="w-5 h-5" />
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
