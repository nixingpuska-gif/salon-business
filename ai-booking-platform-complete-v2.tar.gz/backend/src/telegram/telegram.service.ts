import { Injectable, OnModuleInit, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Bot, Context } from 'grammy';
import { AIService } from '../ai/ai.service';
import { ChannelGatewayService } from '../channel-gateway/channel-gateway.service';
import { ClientService } from '../client/client.service';
import { BusinessService } from '../business/business.service';

@Injectable()
export class TelegramService implements OnModuleInit {
  private clientBot: Bot;
  private adminBot: Bot;
  private readonly logger = new Logger(TelegramService.name);

  constructor(
    private config: ConfigService,
    private aiService: AIService,
    private channelGateway: ChannelGatewayService,
    private clientService: ClientService,
    private businessService: BusinessService,
  ) {}

  async onModuleInit() {
    await this.initializeClientBot();
    await this.initializeAdminBot();
  }

  private async initializeClientBot() {
    const token = this.config.get<string>('TELEGRAM_CLIENT_BOT_TOKEN');
    if (!token) {
      this.logger.warn('TELEGRAM_CLIENT_BOT_TOKEN not set, skipping client bot');
      return;
    }

    this.clientBot = new Bot(token);

    // Handle /start command
    this.clientBot.command('start', async (ctx) => {
      await ctx.reply(
        'Добро пожаловать! Я помогу Вам записаться на услуги.\n\n' +
        'Напишите, на какую услугу хотите записаться, например:\n' +
        '"Хочу записаться на маникюр в субботу"'
      );
    });

    // Handle text messages
    this.clientBot.on('message:text', async (ctx) => {
      try {
        const normalized = this.channelGateway.normalizeMessage('telegram', ctx.message);
        
        // TODO: Get businessId from context or configuration
        const businessId = this.config.get<string>('DEFAULT_BUSINESS_ID') || 'demo-business';
        
        const response = await this.aiService.handleClientMessage(normalized, businessId);
        
        if (response.ui) {
          const rendered = this.channelGateway.renderChoices('telegram', response.ui);
          await ctx.reply(rendered.text, { reply_markup: rendered.reply_markup });
        } else {
          await ctx.reply(response.text);
        }
      } catch (error) {
        this.logger.error('Error handling client message:', error);
        await ctx.reply('Извините, произошла ошибка. Попробуйте позже.');
      }
    });

    // Handle callback queries (button clicks)
    this.clientBot.on('callback_query:data', async (ctx) => {
      await ctx.answerCallbackQuery();
      await ctx.reply(`Вы выбрали: ${ctx.callbackQuery.data}`);
    });

    this.clientBot.start();
    this.logger.log('Client bot started successfully');
  }

  private async initializeAdminBot() {
    const token = this.config.get<string>('TELEGRAM_ADMIN_BOT_TOKEN');
    if (!token) {
      this.logger.warn('TELEGRAM_ADMIN_BOT_TOKEN not set, skipping admin bot');
      return;
    }

    this.adminBot = new Bot(token);

    // Handle /start command
    this.adminBot.command('start', async (ctx) => {
      await ctx.reply(
        'Добро пожаловать в админ-панель!\n\n' +
        'Я помогу Вам управлять бизнесом:\n' +
        '• Настроить расписание\n' +
        '• Добавить услуги\n' +
        '• Просмотреть записи\n' +
        '• Импортировать записи\n' +
        '• Управлять SMM\n\n' +
        'Напишите, что хотите сделать.'
      );
    });

    // Handle text messages
    this.adminBot.on('message:text', async (ctx) => {
      try {
        const normalized = this.channelGateway.normalizeMessage('telegram', ctx.message);
        const userId = ctx.from.id.toString();
        
        const response = await this.aiService.handleAdminMessage(normalized, userId);
        
        if (response.ui) {
          const rendered = this.channelGateway.renderChoices('telegram', response.ui);
          await ctx.reply(rendered.text, { reply_markup: rendered.reply_markup });
        } else {
          await ctx.reply(response.text);
        }
      } catch (error) {
        this.logger.error('Error handling admin message:', error);
        await ctx.reply('Извините, произошла ошибка. Попробуйте позже.');
      }
    });

    // Handle callback queries
    this.adminBot.on('callback_query:data', async (ctx) => {
      await ctx.answerCallbackQuery();
      await ctx.reply(`Вы выбрали: ${ctx.callbackQuery.data}`);
    });

    this.adminBot.start();
    this.logger.log('Admin bot started successfully');
  }

  async sendMessage(chatId: string, text: string, isAdmin = false): Promise<void> {
    const bot = isAdmin ? this.adminBot : this.clientBot;
    if (bot) {
      await bot.api.sendMessage(chatId, text);
    }
  }
}
