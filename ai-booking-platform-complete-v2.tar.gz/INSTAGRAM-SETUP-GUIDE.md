# 📸 Руководство по настройке Instagram Direct Messages API

## Обзор

Этот гайд поможет подключить Instagram Direct Messages через Meta Graph API к платформе AI-Booking. После настройки ваши клиенты смогут записываться через Instagram Direct с помощью AI-ассистента.

---

## Шаг 1: Подготовка Instagram Business Account

### 1.1 Требования
- ✅ Instagram Business Account (не Personal)
- ✅ Facebook Page, связанная с Instagram
- ✅ Meta Business Manager

### 1.2 Преобразование в Business Account
1. Откройте Instagram приложение
2. Перейдите в **Settings** → **Account**
3. Нажмите **Switch to Professional Account**
4. Выберите **Business**
5. Свяжите с Facebook Page (или создайте новую)

---

## Шаг 2: Регистрация приложения в Meta for Developers

### 2.1 Создание приложения
1. Перейдите на [developers.facebook.com](https://developers.facebook.com/)
2. Войдите с помощью Facebook аккаунта
3. Нажмите **"My Apps"** → **"Create App"**
4. Выберите тип: **"Business"**
5. Заполните:
   - **App Name**: Название вашего бизнеса
   - **App Contact Email**: Ваш email
   - **Business Account**: Выберите или создайте

### 2.2 Добавление Instagram Product
1. В дашборде приложения найдите **"Messenger"**
2. Нажмите **"Set Up"**
3. Прокрутите до раздела **"Instagram"**

---

## Шаг 3: Получение учетных данных

### 3.1 Instagram Page ID
1. Перейдите в **Messenger** → **Settings**
2. В разделе **Instagram** найдите вашу Instagram страницу
3. Нажмите **"Add Instagram Account"** (если ещё не добавлена)
4. Авторизуйте доступ к Instagram
5. Скопируйте **Instagram Page ID** (числовой ID)
6. Сохраните его — это `INSTAGRAM_PAGE_ID`

### 3.2 Access Token
**Временный токен (для тестирования, 24 часа):**
1. В разделе **Messenger** → **Settings**
2. Найдите вашу Instagram страницу
3. Нажмите **"Generate Token"**
4. Скопируйте токен (начинается с `EAAG...`)

**Постоянный токен (для продакшена):**
1. Перейдите в **Business Settings** → **System Users**
2. Создайте System User с правами **Admin**
3. Нажмите **"Generate New Token"**
4. Выберите приложение
5. Выберите разрешения:
   - `pages_messaging`
   - `pages_manage_metadata`
   - `instagram_basic`
   - `instagram_manage_messages`
6. Сгенерируйте и скопируйте токен
7. Сохраните токен — это `INSTAGRAM_ACCESS_TOKEN`

### 3.3 Verify Token
1. Придумайте случайную строку (минимум 20 символов)
2. Пример: `my_instagram_verify_token_xyz789`
3. Сохраните её — это `INSTAGRAM_VERIFY_TOKEN`

---

## Шаг 4: Настройка Webhook

### 4.1 Подготовка сервера
1. Убедитесь, что ваш бэкенд доступен по HTTPS (Meta требует SSL)
2. Если используете локальную разработку, используйте ngrok:
   ```bash
   ngrok http 3000
   ```
3. Скопируйте публичный URL (например, `https://abc123.ngrok.io`)

### 4.2 Регистрация Webhook в Meta
1. Перейдите в **Messenger** → **Settings**
2. В разделе **Webhooks** нажмите **"Add Callback URL"**
3. Заполните:
   - **Callback URL**: `https://ваш-домен.com/webhooks/instagram`
   - **Verify Token**: Ваш `INSTAGRAM_VERIFY_TOKEN`
4. Нажмите **"Verify and Save"**
5. Подпишитесь на события для Instagram:
   - ✅ `messages` (обязательно)
   - ✅ `messaging_postbacks` (для кнопок)
   - ✅ `message_reads` (опционально)
   - ✅ `message_deliveries` (опционально)

---

## Шаг 5: Настройка переменных окружения

Откройте `.env` файл в папке `backend/` и добавьте:

```env
# Instagram Direct Messages API
INSTAGRAM_PAGE_ID=123456789012345
INSTAGRAM_ACCESS_TOKEN=EAAGxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
INSTAGRAM_VERIFY_TOKEN=my_instagram_verify_token_xyz789
```

---

## Шаг 6: Запуск и тестирование

### 6.1 Установка зависимостей
```bash
cd backend
npm install
```

### 6.2 Запуск сервера
```bash
npm run start:dev
```

### 6.3 Проверка Webhook
1. Перейдите в **Messenger** → **Settings** → **Webhooks**
2. Должна быть зелёная галочка ✅ напротив вашего webhook
3. Если красный крестик ❌ — проверьте:
   - Сервер запущен и доступен по HTTPS
   - `INSTAGRAM_VERIFY_TOKEN` совпадает в `.env` и Meta Console
   - Нет ошибок в логах сервера

### 6.4 Тестирование бота
1. Откройте Instagram приложение
2. Найдите ваш Business аккаунт
3. Отправьте сообщение в Direct: **"Привет"**
4. Бот должен ответить
5. Попробуйте записаться: **"Хочу записаться на маникюр"**
6. Бот проведёт вас через процесс бронирования

---

## Шаг 7: Настройка автоответов (опционально)

### 7.1 Включение автоответов
1. Откройте Instagram приложение
2. Перейдите в **Settings** → **Business** → **Quick Replies**
3. Создайте быстрые ответы для частых вопросов

### 7.2 Away Message
1. В **Settings** → **Business** → **Away Message**
2. Включите автоответ для нерабочих часов
3. Настройте расписание

---

## Шаг 8: Верификация приложения (для продакшена)

⚠️ **Важно**: Без верификации приложения вы можете общаться только с тестовыми пользователями.

### 8.1 Требования для верификации
- Официальный сайт компании
- Privacy Policy URL
- Terms of Service URL
- App Icon (1024x1024 px)
- Описание использования разрешений

### 8.2 Процесс верификации
1. Перейдите в **App Review** → **Permissions and Features**
2. Запросите разрешения:
   - `pages_messaging`
   - `instagram_manage_messages`
3. Заполните форму:
   - Опишите, как используете Instagram Messaging
   - Загрузите скриншоты/видео демонстрации
   - Укажите тестовые инструкции
4. Отправьте на проверку
5. Ожидайте одобрения (обычно 3-7 дней)

### 8.3 После верификации
- Неограниченное количество пользователей
- Доступ к расширенной аналитике
- Возможность использовать в продакшене

---

## Распространённые проблемы

### ❌ Webhook не проходит верификацию
**Решение**:
- Убедитесь, что сервер доступен по HTTPS
- Проверьте, что `INSTAGRAM_VERIFY_TOKEN` совпадает
- Посмотрите логи сервера на наличие ошибок
- Убедитесь, что endpoint `/webhooks/instagram` отвечает на GET запрос

### ❌ Бот не отвечает на сообщения
**Решение**:
- Проверьте, что webhook подписан на событие `messages`
- Убедитесь, что Instagram аккаунт связан с Facebook Page
- Проверьте, что токен действителен (не истёк)
- Посмотрите логи сервера — возможно, ошибка в обработке

### ❌ Ошибка "Invalid OAuth access token"
**Решение**:
- Токен истёк — создайте постоянный токен через System Users
- Убедитесь, что токен имеет правильные разрешения
- Проверьте, что токен привязан к правильной странице

### ❌ Сообщения не доставляются
**Решение**:
- Убедитесь, что Instagram аккаунт — Business, а не Personal
- Проверьте, что пользователь первым написал боту (Instagram не позволяет инициировать диалог)
- Убедитесь, что `INSTAGRAM_PAGE_ID` правильный

### ❌ Ошибка "This message is sent outside of allowed window"
**Решение**:
- Instagram позволяет отвечать только в течение 24 часов после последнего сообщения пользователя
- Для сообщений вне окна используйте Message Tags (требует одобрения)

---

## Лимиты и ограничения

### Временные рамки ответа
- ✅ 24 часа после последнего сообщения пользователя
- ⚠️ После 24 часов нужны Message Tags (требуют одобрения)

### Инициация диалога
- ⚠️ Бот не может первым написать пользователю
- ✅ Пользователь должен первым начать диалог

### Rate Limits
- 200 сообщений в секунду (для большинства аккаунтов)
- 1000 сообщений в секунду (для верифицированных приложений)

### Типы сообщений
- ✅ Текст (до 1000 символов)
- ✅ Quick Replies (до 13 кнопок)
- ✅ Generic Template (до 10 карточек)
- ✅ Изображения, видео, аудио
- ⚠️ Buttons (до 3 кнопок на карточку)

---

## Полезные ссылки

- [Instagram Messaging API Docs](https://developers.facebook.com/docs/messenger-platform/instagram)
- [Graph API Reference](https://developers.facebook.com/docs/graph-api)
- [Webhook Reference](https://developers.facebook.com/docs/messenger-platform/webhooks)
- [Message Templates](https://developers.facebook.com/docs/messenger-platform/send-messages/templates)

---

## Поддержка

Если возникли проблемы:
1. Проверьте логи сервера: `npm run start:dev`
2. Проверьте статус webhook в Meta Console
3. Убедитесь, что все переменные окружения заполнены
4. Проверьте, что Instagram аккаунт — Business
5. Убедитесь, что пользователь первым написал боту

**Готово!** 🎉 Теперь ваши клиенты могут записываться через Instagram Direct.
