"""Business OS - Reports & Weekly AI Reports"""
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timedelta
from pydantic import BaseModel
from typing import Optional, List
from app.core.database import get_db

router = APIRouter()


class StaffPerformance(BaseModel):
    id: int
    name: str
    revenue: float
    appointments: int
    avg_check: float
    rating: float
    utilization: float
    trend: str


class ClientMetrics(BaseModel):
    new_clients: int
    returning_clients: int
    lost_clients: int
    reactivated_clients: int
    avg_ltv: float
    churn_rate: float


@router.get("/dashboard")
async def get_dashboard(db: AsyncSession = Depends(get_db)):
    return {
        "revenue_today": 45000,
        "revenue_week": 285000,
        "revenue_month": 1150000,
        "appointments_today": 23,
        "new_clients_month": 45,
        "retention_rate": 78,
    }


@router.get("/money")
async def get_money_report(db: AsyncSession = Depends(get_db)):
    return {
        "lost": 60000,
        "recovered": 96000,
        "potential": 150000,
        "breakdown": {
            "cancellations": 15000,
            "no_shows": 8000,
            "empty_slots": 25000,
            "discounts": 12000
        }
    }


@router.get("/weekly")
async def get_weekly_report(
    tenant_id: int = Query(1),
    week_offset: int = Query(0),
    db: AsyncSession = Depends(get_db)
):
    """Еженедельный AI-отчёт для владельца"""
    
    today = datetime.now().date()
    week_start = today - timedelta(days=today.weekday() + (week_offset * 7))
    week_end = week_start + timedelta(days=6)
    
    revenue = 285000
    prev_week_revenue = 254000
    revenue_vs_prev = ((revenue - prev_week_revenue) / prev_week_revenue * 100)
    
    staff = [
        StaffPerformance(id=1, name="Анна Петрова", revenue=85000, appointments=28, avg_check=3035, rating=4.9, utilization=92, trend="hero"),
        StaffPerformance(id=2, name="Елена Козлова", revenue=72000, appointments=24, avg_check=3000, rating=4.8, utilization=85, trend="stable"),
        StaffPerformance(id=3, name="Мария Иванова", revenue=58000, appointments=22, avg_check=2636, rating=4.7, utilization=78, trend="stable"),
        StaffPerformance(id=4, name="Ольга Сидорова", revenue=45000, appointments=18, avg_check=2500, rating=4.5, utilization=65, trend="declining"),
        StaffPerformance(id=5, name="Татьяна Новикова", revenue=25000, appointments=12, avg_check=2083, rating=4.6, utilization=55, trend="declining"),
    ]
    
    clients = ClientMetrics(
        new_clients=12, returning_clients=45, lost_clients=3,
        reactivated_clients=5, avg_ltv=15000, churn_rate=8.5
    )
    
    return {
        "period_start": week_start.strftime("%Y-%m-%d"),
        "period_end": week_end.strftime("%Y-%m-%d"),
        "ai_verdict": "Отличная неделя! Выручка выросла на 12% — команда работает на максимуме.",
        "ai_verdict_emoji": "🚀",
        "revenue": revenue,
        "revenue_vs_prev_week": round(revenue_vs_prev, 1),
        "avg_check": 2850,
        "total_losses": 35000,
        "total_returns": 48000,
        "staff_performance": [s.dict() for s in staff],
        "hero_of_week": "Анна Петрова",
        "needs_attention": "Татьяна Новикова",
        "client_metrics": clients.dict(),
        "next_week_forecast": 295000,
        "recommendations": [
            "🎯 Увеличьте загрузку Ольги и Татьяны",
            "💡 Запустите акцию на среду — загрузка 45%",
            "📞 Позвоните 8 клиентам без подтверждения",
            "🎁 5 VIP-клиентов отмечают ДР"
        ]
    }


@router.get("/staff-performance")
async def get_staff_performance(db: AsyncSession = Depends(get_db)):
    return {
        "items": [
            {"id": 1, "name": "Анна Петрова", "revenue": 85000, "rating": 4.9, "utilization": 92},
            {"id": 2, "name": "Елена Козлова", "revenue": 72000, "rating": 4.8, "utilization": 85},
            {"id": 3, "name": "Мария Иванова", "revenue": 58000, "rating": 4.7, "utilization": 78},
        ],
        "total": 3
    }
