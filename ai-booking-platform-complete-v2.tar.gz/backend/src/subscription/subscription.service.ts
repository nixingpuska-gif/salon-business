import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import {
  FeatureFlagsService,
  SubscriptionTier,
} from '../feature-flags/feature-flags.service';

/**
 * Subscription Service
 * 
 * Управление подписками:
 * - Создание и обновление подписок
 * - История платежей
 * - Автоматическое продление
 * - Уведомления об истечении
 */

export enum SubscriptionStatus {
  ACTIVE = 'active',
  EXPIRED = 'expired',
  CANCELLED = 'cancelled',
  TRIAL = 'trial',
}

export interface SubscriptionInfo {
  id: string;
  businessId: string;
  tier: SubscriptionTier;
  status: SubscriptionStatus;
  startDate: Date;
  validUntil: Date;
  autoRenew: boolean;
  cancelledAt?: Date;
  trialEndsAt?: Date;
}

@Injectable()
export class SubscriptionService {
  private readonly logger = new Logger(SubscriptionService.name);

  constructor(
    private prisma: PrismaService,
    private featureFlags: FeatureFlagsService,
  ) {
    this.logger.log('Subscription Service initialized');
  }

  /**
   * Создать подписку
   */
  async createSubscription(
    businessId: string,
    tier: SubscriptionTier,
    durationMonths: number = 1,
    isTrial: boolean = false,
  ): Promise<SubscriptionInfo> {
    const now = new Date();
    const validUntil = new Date(now);
    validUntil.setMonth(validUntil.getMonth() + durationMonths);

    const trialEndsAt = isTrial ? validUntil : null;

    // Обновить подписку в business
    await this.featureFlags.updateSubscription(businessId, tier, validUntil);

    // Создать запись в истории
    const subscription = await this.prisma.subscription.create({
      data: {
        businessId,
        tier,
        status: isTrial ? SubscriptionStatus.TRIAL : SubscriptionStatus.ACTIVE,
        startDate: now,
        validUntil,
        autoRenew: !isTrial,
        trialEndsAt,
      },
    });

    this.logger.log(
      `Subscription created for business ${businessId}: ${tier} (${isTrial ? 'trial' : 'paid'})`,
    );

    return this.mapToSubscriptionInfo(subscription);
  }

  /**
   * Обновить подписку (upgrade/downgrade)
   */
  async updateSubscription(
    businessId: string,
    newTier: SubscriptionTier,
    durationMonths: number = 1,
  ): Promise<SubscriptionInfo> {
    const currentSubscription = await this.getCurrentSubscription(businessId);

    // Если есть активная подписка, отменить её
    if (currentSubscription) {
      await this.cancelSubscription(businessId);
    }

    // Создать новую подписку
    return this.createSubscription(businessId, newTier, durationMonths, false);
  }

  /**
   * Продлить подписку
   */
  async renewSubscription(
    businessId: string,
    durationMonths: number = 1,
  ): Promise<SubscriptionInfo> {
    const currentSubscription = await this.getCurrentSubscription(businessId);

    if (!currentSubscription) {
      throw new Error('No active subscription found');
    }

    const now = new Date();
    const validUntil = new Date(
      Math.max(currentSubscription.validUntil.getTime(), now.getTime()),
    );
    validUntil.setMonth(validUntil.getMonth() + durationMonths);

    // Обновить подписку
    await this.featureFlags.updateSubscription(
      businessId,
      currentSubscription.tier,
      validUntil,
    );

    // Обновить запись
    const subscription = await this.prisma.subscription.update({
      where: { id: currentSubscription.id },
      data: {
        validUntil,
        status: SubscriptionStatus.ACTIVE,
      },
    });

    this.logger.log(
      `Subscription renewed for business ${businessId} until ${validUntil.toISOString()}`,
    );

    return this.mapToSubscriptionInfo(subscription);
  }

  /**
   * Отменить подписку
   */
  async cancelSubscription(businessId: string): Promise<void> {
    const currentSubscription = await this.getCurrentSubscription(businessId);

    if (!currentSubscription) {
      throw new Error('No active subscription found');
    }

    await this.prisma.subscription.update({
      where: { id: currentSubscription.id },
      data: {
        status: SubscriptionStatus.CANCELLED,
        cancelledAt: new Date(),
        autoRenew: false,
      },
    });

    this.logger.log(`Subscription cancelled for business ${businessId}`);
  }

  /**
   * Получить текущую подписку
   */
  async getCurrentSubscription(
    businessId: string,
  ): Promise<SubscriptionInfo | null> {
    const subscription = await this.prisma.subscription.findFirst({
      where: {
        businessId,
        status: {
          in: [SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIAL],
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return subscription ? this.mapToSubscriptionInfo(subscription) : null;
  }

  /**
   * Получить историю подписок
   */
  async getSubscriptionHistory(businessId: string): Promise<SubscriptionInfo[]> {
    const subscriptions = await this.prisma.subscription.findMany({
      where: { businessId },
      orderBy: { createdAt: 'desc' },
    });

    return subscriptions.map((s) => this.mapToSubscriptionInfo(s));
  }

  /**
   * Проверить истекающие подписки
   */
  async checkExpiringSubscriptions(daysBeforeExpiry: number = 7): Promise<
    Array<{
      businessId: string;
      tier: SubscriptionTier;
      validUntil: Date;
      daysLeft: number;
    }>
  > {
    const now = new Date();
    const checkDate = new Date(now);
    checkDate.setDate(checkDate.getDate() + daysBeforeExpiry);

    const businesses = await this.prisma.business.findMany({
      where: {
        subscriptionValidUntil: {
          gte: now,
          lte: checkDate,
        },
      },
      select: {
        id: true,
        subscriptionTier: true,
        subscriptionValidUntil: true,
      },
    });

    return businesses.map((b) => {
      const daysLeft = Math.ceil(
        (b.subscriptionValidUntil.getTime() - now.getTime()) /
          (1000 * 60 * 60 * 24),
      );

      return {
        businessId: b.id,
        tier: b.subscriptionTier as SubscriptionTier,
        validUntil: b.subscriptionValidUntil,
        daysLeft,
      };
    });
  }

  /**
   * Автоматическое продление подписок
   */
  async autoRenewSubscriptions(): Promise<{
    renewed: number;
    failed: number;
    errors: string[];
  }> {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Найти подписки, которые истекают завтра и имеют autoRenew
    const expiringSubscriptions = await this.prisma.subscription.findMany({
      where: {
        validUntil: {
          gte: now,
          lte: tomorrow,
        },
        autoRenew: true,
        status: SubscriptionStatus.ACTIVE,
      },
    });

    const results = {
      renewed: 0,
      failed: 0,
      errors: [] as string[],
    };

    for (const subscription of expiringSubscriptions) {
      try {
        await this.renewSubscription(subscription.businessId, 1);
        results.renewed++;
      } catch (error) {
        results.failed++;
        results.errors.push(
          `Business ${subscription.businessId}: ${error.message}`,
        );
        this.logger.error(
          `Failed to auto-renew subscription for business ${subscription.businessId}:`,
          error,
        );
      }
    }

    this.logger.log(
      `Auto-renewal completed: ${results.renewed} renewed, ${results.failed} failed`,
    );

    return results;
  }

  /**
   * Создать пробную подписку
   */
  async createTrialSubscription(
    businessId: string,
    tier: SubscriptionTier = SubscriptionTier.PRO,
    durationDays: number = 14,
  ): Promise<SubscriptionInfo> {
    // Проверить, была ли уже пробная подписка
    const existingTrial = await this.prisma.subscription.findFirst({
      where: {
        businessId,
        status: SubscriptionStatus.TRIAL,
      },
    });

    if (existingTrial) {
      throw new Error('Trial subscription already used');
    }

    const durationMonths = Math.ceil(durationDays / 30);
    return this.createSubscription(businessId, tier, durationMonths, true);
  }

  /**
   * Получить статистику подписок
   */
  async getSubscriptionStats(): Promise<{
    total: number;
    active: number;
    trial: number;
    expired: number;
    cancelled: number;
    byTier: Record<SubscriptionTier, number>;
    revenue: {
      monthly: number;
      yearly: number;
    };
  }> {
    const [total, active, trial, expired, cancelled] = await Promise.all([
      this.prisma.subscription.count(),
      this.prisma.subscription.count({
        where: { status: SubscriptionStatus.ACTIVE },
      }),
      this.prisma.subscription.count({
        where: { status: SubscriptionStatus.TRIAL },
      }),
      this.prisma.subscription.count({
        where: { status: SubscriptionStatus.EXPIRED },
      }),
      this.prisma.subscription.count({
        where: { status: SubscriptionStatus.CANCELLED },
      }),
    ]);

    // Подсчёт по тарифам
    const subscriptionsByTier = await this.prisma.subscription.groupBy({
      by: ['tier'],
      where: {
        status: {
          in: [SubscriptionStatus.ACTIVE, SubscriptionStatus.TRIAL],
        },
      },
      _count: true,
    });

    const byTier: Record<SubscriptionTier, number> = {
      [SubscriptionTier.FREE]: 0,
      [SubscriptionTier.BASIC]: 0,
      [SubscriptionTier.PRO]: 0,
      [SubscriptionTier.ENTERPRISE]: 0,
    };

    subscriptionsByTier.forEach((item) => {
      byTier[item.tier as SubscriptionTier] = item._count;
    });

    // Расчёт дохода
    const plans = this.featureFlags.getAllPlans();
    let monthlyRevenue = 0;

    for (const tier of Object.values(SubscriptionTier)) {
      const plan = plans.find((p) => p.tier === tier);
      if (plan) {
        monthlyRevenue += plan.price * byTier[tier];
      }
    }

    return {
      total,
      active,
      trial,
      expired,
      cancelled,
      byTier,
      revenue: {
        monthly: monthlyRevenue,
        yearly: monthlyRevenue * 12,
      },
    };
  }

  /**
   * Маппинг из Prisma модели в SubscriptionInfo
   */
  private mapToSubscriptionInfo(subscription: any): SubscriptionInfo {
    return {
      id: subscription.id,
      businessId: subscription.businessId,
      tier: subscription.tier as SubscriptionTier,
      status: subscription.status as SubscriptionStatus,
      startDate: subscription.startDate,
      validUntil: subscription.validUntil,
      autoRenew: subscription.autoRenew,
      cancelledAt: subscription.cancelledAt,
      trialEndsAt: subscription.trialEndsAt,
    };
  }
}
