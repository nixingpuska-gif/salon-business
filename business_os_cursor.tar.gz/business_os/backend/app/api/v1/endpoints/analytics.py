"""
Analytics API - LTV скоринг, метки клиентов, анализ себестоимости
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, case, and_
from datetime import datetime, timedelta
from typing import Optional
from pydantic import BaseModel
from enum import Enum
import json

from app.core.database import get_db
from app.models import Client, Appointment, Payment, Service, Staff

router = APIRouter()


class ClientSegment(str, Enum):
    VIP = "vip"
    LOYAL = "loyal"
    REGULAR = "regular"
    NEW = "new"
    SLEEPING = "sleeping"
    LOST = "lost"
    AT_RISK = "at_risk"


class LTVScore(BaseModel):
    client_id: int
    client_name: str
    segment: ClientSegment
    ltv_score: float
    total_spent: float
    visits_count: int
    avg_check: float
    days_since_last_visit: int
    predicted_next_visit: Optional[str]
    churn_risk: float  # 0-100%
    recommendations: list[str]


class ServiceMargin(BaseModel):
    service_id: int
    service_name: str
    price: float
    cost: float
    margin: float
    margin_percent: float
    monthly_count: int
    monthly_revenue: float
    monthly_profit: float


class InventoryForecast(BaseModel):
    product_id: int
    product_name: str
    current_stock: int
    daily_usage: float
    days_until_empty: int
    recommended_order_qty: int
    recommended_order_date: str
    estimated_cost: float


@router.get("/ltv-scores")
async def get_ltv_scores(
    tenant_id: int = Query(...),
    segment: Optional[ClientSegment] = None,
    limit: int = Query(50, le=200),
    db: AsyncSession = Depends(get_db)
):
    """Получить LTV-скоринг всех клиентов с AI-рекомендациями"""
    
    # Получаем клиентов с их статистикой
    query = select(Client).where(
        and_(Client.tenant_id == tenant_id, Client.is_deleted == False)
    )
    result = await db.execute(query)
    clients = result.scalars().all()
    
    scores = []
    for client in clients:
        # Расчёт метрик
        total_spent = client.total_spent or 0
        visits = client.visits_count or 0
        avg_check = total_spent / visits if visits > 0 else 0
        
        # Дни с последнего визита
        if client.last_visit_date:
            days_since = (datetime.now().date() - client.last_visit_date).days
        else:
            days_since = 999
        
        # Определение сегмента
        if total_spent >= 100000 and visits >= 10:
            seg = ClientSegment.VIP
        elif visits >= 5 and days_since <= 45:
            seg = ClientSegment.LOYAL
        elif visits >= 2 and days_since <= 60:
            seg = ClientSegment.REGULAR
        elif visits <= 1 and days_since <= 30:
            seg = ClientSegment.NEW
        elif days_since > 90:
            seg = ClientSegment.LOST
        elif days_since > 60:
            seg = ClientSegment.SLEEPING
        elif days_since > 45:
            seg = ClientSegment.AT_RISK
        else:
            seg = ClientSegment.REGULAR
        
        # Фильтр по сегменту
        if segment and seg != segment:
            continue
        
        # Расчёт риска оттока (0-100)
        churn_risk = min(100, max(0, (days_since - 30) * 2))
        if seg == ClientSegment.VIP:
            churn_risk *= 0.5
        
        # LTV Score (упрощённый расчёт)
        ltv = total_spent * (1 - churn_risk/100) * (1 + visits/10)
        
        # AI-рекомендации
        recommendations = []
        if seg == ClientSegment.SLEEPING:
            recommendations.append("Отправить реактивационное сообщение со скидкой 15%")
        if seg == ClientSegment.AT_RISK:
            recommendations.append("Позвонить и предложить удобное время")
        if seg == ClientSegment.VIP and days_since > 30:
            recommendations.append("Персональное приглашение от мастера")
        if seg == ClientSegment.NEW:
            recommendations.append("Отправить приветственный бонус 500₽")
        if visits >= 5 and not client.birthday:
            recommendations.append("Узнать дату рождения для поздравления")
        
        # Прогноз следующего визита
        if visits >= 2 and client.avg_days_between_visits:
            next_visit = datetime.now() + timedelta(days=client.avg_days_between_visits)
            predicted = next_visit.strftime("%Y-%m-%d")
        else:
            predicted = None
        
        scores.append(LTVScore(
            client_id=client.id,
            client_name=client.full_name or f"{client.first_name} {client.last_name or ''}".strip(),
            segment=seg,
            ltv_score=round(ltv, 2),
            total_spent=total_spent,
            visits_count=visits,
            avg_check=round(avg_check, 2),
            days_since_last_visit=days_since,
            predicted_next_visit=predicted,
            churn_risk=round(churn_risk, 1),
            recommendations=recommendations
        ))
    
    # Сортировка по LTV
    scores.sort(key=lambda x: x.ltv_score, reverse=True)
    
    return {
        "items": scores[:limit],
        "total": len(scores),
        "segments_summary": {
            "vip": len([s for s in scores if s.segment == ClientSegment.VIP]),
            "loyal": len([s for s in scores if s.segment == ClientSegment.LOYAL]),
            "regular": len([s for s in scores if s.segment == ClientSegment.REGULAR]),
            "new": len([s for s in scores if s.segment == ClientSegment.NEW]),
            "at_risk": len([s for s in scores if s.segment == ClientSegment.AT_RISK]),
            "sleeping": len([s for s in scores if s.segment == ClientSegment.SLEEPING]),
            "lost": len([s for s in scores if s.segment == ClientSegment.LOST]),
        }
    }


@router.get("/service-margins")
async def get_service_margins(
    tenant_id: int = Query(...),
    db: AsyncSession = Depends(get_db)
):
    """Анализ себестоимости и маржинальности услуг"""
    
    query = select(Service).where(
        and_(Service.tenant_id == tenant_id, Service.is_active == True)
    )
    result = await db.execute(query)
    services = result.scalars().all()
    
    margins = []
    for service in services:
        price = service.price or 0
        # Себестоимость = материалы + % от зарплаты мастера
        cost = (service.cost or 0) + (price * 0.3)  # 30% на мастера
        margin = price - cost
        margin_percent = (margin / price * 100) if price > 0 else 0
        
        # Статистика за месяц (упрощённо)
        monthly_count = 15  # TODO: реальный подсчёт
        
        margins.append(ServiceMargin(
            service_id=service.id,
            service_name=service.name,
            price=price,
            cost=round(cost, 2),
            margin=round(margin, 2),
            margin_percent=round(margin_percent, 1),
            monthly_count=monthly_count,
            monthly_revenue=price * monthly_count,
            monthly_profit=round(margin * monthly_count, 2)
        ))
    
    # Сортировка по прибыли
    margins.sort(key=lambda x: x.monthly_profit, reverse=True)
    
    total_revenue = sum(m.monthly_revenue for m in margins)
    total_profit = sum(m.monthly_profit for m in margins)
    
    return {
        "items": margins,
        "summary": {
            "total_monthly_revenue": total_revenue,
            "total_monthly_profit": round(total_profit, 2),
            "avg_margin_percent": round(total_profit / total_revenue * 100, 1) if total_revenue > 0 else 0,
            "top_profitable": margins[0].service_name if margins else None,
            "least_profitable": margins[-1].service_name if margins else None
        }
    }


@router.get("/inventory-forecast")
async def get_inventory_forecast(
    tenant_id: int = Query(...),
    db: AsyncSession = Depends(get_db)
):
    """AI-прогнозирование закупок на основе трендов"""
    
    # Моковые данные для демонстрации
    forecasts = [
        InventoryForecast(
            product_id=1,
            product_name="Гель-лак OPI",
            current_stock=15,
            daily_usage=1.5,
            days_until_empty=10,
            recommended_order_qty=30,
            recommended_order_date=(datetime.now() + timedelta(days=5)).strftime("%Y-%m-%d"),
            estimated_cost=15000
        ),
        InventoryForecast(
            product_id=2,
            product_name="База каучуковая",
            current_stock=3,
            daily_usage=0.8,
            days_until_empty=4,
            recommended_order_qty=10,
            recommended_order_date=datetime.now().strftime("%Y-%m-%d"),
            estimated_cost=5000
        ),
        InventoryForecast(
            product_id=3,
            product_name="Топ без липкого слоя",
            current_stock=5,
            daily_usage=0.6,
            days_until_empty=8,
            recommended_order_qty=10,
            recommended_order_date=(datetime.now() + timedelta(days=3)).strftime("%Y-%m-%d"),
            estimated_cost=4500
        ),
    ]
    
    urgent = [f for f in forecasts if f.days_until_empty <= 5]
    
    return {
        "items": forecasts,
        "urgent_orders": urgent,
        "total_estimated_cost": sum(f.estimated_cost for f in forecasts),
        "ai_recommendation": "Рекомендуем сделать заказ сегодня: База каучуковая заканчивается через 4 дня. Объединённый заказ сэкономит на доставке."
    }


@router.post("/auto-deduct")
async def auto_deduct_inventory(
    appointment_id: int,
    db: AsyncSession = Depends(get_db)
):
    """Автоматическое списание материалов после услуги"""
    
    # TODO: Реализовать реальное списание
    return {
        "success": True,
        "appointment_id": appointment_id,
        "deducted_items": [
            {"name": "Гель-лак OPI Red", "quantity": 1, "unit": "мл"},
            {"name": "База", "quantity": 0.5, "unit": "мл"},
            {"name": "Топ", "quantity": 0.5, "unit": "мл"},
        ],
        "message": "Материалы списаны автоматически"
    }
