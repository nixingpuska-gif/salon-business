"""
Business OS - Users Endpoints
User management for platform users (owners, admins)
"""

from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from pydantic import BaseModel, EmailStr
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.database import get_db
from app.models import User

router = APIRouter()


class UserUpdate(BaseModel):
    """User update request"""
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    language: Optional[str] = None
    timezone: Optional[str] = None


class UserResponse(BaseModel):
    """User response"""
    id: int
    email: str
    first_name: str
    last_name: Optional[str]
    phone: Optional[str]
    role: str
    is_active: bool
    is_verified: bool
    language: str
    timezone: str
    
    class Config:
        from_attributes = True


@router.get("/me", response_model=UserResponse)
async def get_me(
    db: AsyncSession = Depends(get_db)
):
    """Get current user profile"""
    # TODO: Get from auth dependency
    raise HTTPException(status_code=501, detail="Not implemented")


@router.patch("/me", response_model=UserResponse)
async def update_me(
    data: UserUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update current user profile"""
    # TODO: Implement
    raise HTTPException(status_code=501, detail="Not implemented")


@router.post("/me/change-password")
async def change_password(
    db: AsyncSession = Depends(get_db)
):
    """Change current user password"""
    # TODO: Implement
    raise HTTPException(status_code=501, detail="Not implemented")


@router.delete("/me")
async def delete_account(
    db: AsyncSession = Depends(get_db)
):
    """Delete current user account"""
    # TODO: Implement
    raise HTTPException(status_code=501, detail="Not implemented")
