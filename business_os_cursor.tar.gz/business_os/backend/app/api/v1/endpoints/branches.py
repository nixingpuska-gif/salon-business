"""Business OS - Branches Endpoints"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db

router = APIRouter()

@router.get("")
async def list_branches(db: AsyncSession = Depends(get_db)):
    return {"items": [], "total": 0}

@router.post("")
async def create_branch(db: AsyncSession = Depends(get_db)):
    raise HTTPException(status_code=501, detail="Not implemented")

@router.get("/{branch_id}")
async def get_branch(branch_id: int, db: AsyncSession = Depends(get_db)):
    raise HTTPException(status_code=501, detail="Not implemented")
