"""
Business OS - Billing Endpoints
Subscription and payment management
"""

from datetime import datetime, timedelta
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.database import get_db
from app.core.security import get_current_user, TokenData
from app.models import Tenant

router = APIRouter()


# ==================== SCHEMAS ====================

class PlanInfo(BaseModel):
    """Subscription plan info"""
    id: str
    name: str
    price: int
    price_yearly: int
    features: List[str]
    limits: dict


class SubscriptionStatus(BaseModel):
    """Current subscription status"""
    plan: str
    status: str  # trial, active, past_due, cancelled
    trial_ends_at: Optional[datetime]
    current_period_start: Optional[datetime]
    current_period_end: Optional[datetime]
    cancel_at_period_end: bool
    amount: int


class PaymentMethod(BaseModel):
    """Payment method info"""
    id: str
    type: str  # card, bank_account
    last4: str
    brand: Optional[str]
    exp_month: Optional[int]
    exp_year: Optional[int]
    is_default: bool


class Invoice(BaseModel):
    """Invoice info"""
    id: str
    number: str
    amount: int
    status: str  # paid, open, void
    created_at: datetime
    paid_at: Optional[datetime]
    pdf_url: Optional[str]


class ChangePlanRequest(BaseModel):
    """Change plan request"""
    plan_id: str
    billing_cycle: str = "monthly"  # monthly, yearly


class AddPaymentMethodRequest(BaseModel):
    """Add payment method request"""
    token: str  # Payment provider token


# ==================== PLANS ====================

PLANS = {
    "starter": PlanInfo(
        id="starter",
        name="Starter",
        price=990,
        price_yearly=9900,
        features=[
            "До 100 клиентов",
            "1 сотрудник",
            "Базовая аналитика",
            "Email поддержка",
        ],
        limits={
            "clients": 100,
            "staff": 1,
            "branches": 1,
            "sms_per_month": 50,
        }
    ),
    "professional": PlanInfo(
        id="professional",
        name="Professional",
        price=2990,
        price_yearly=29900,
        features=[
            "До 1000 клиентов",
            "До 10 сотрудников",
            "Полная аналитика",
            "SMS и Telegram уведомления",
            "Онлайн-запись",
            "Приоритетная поддержка",
        ],
        limits={
            "clients": 1000,
            "staff": 10,
            "branches": 3,
            "sms_per_month": 500,
        }
    ),
    "enterprise": PlanInfo(
        id="enterprise",
        name="Enterprise",
        price=9990,
        price_yearly=99900,
        features=[
            "Безлимит клиентов",
            "Безлимит сотрудников",
            "API доступ",
            "Белый лейбл",
            "Выделенный менеджер",
            "SLA 99.9%",
        ],
        limits={
            "clients": -1,  # unlimited
            "staff": -1,
            "branches": -1,
            "sms_per_month": 5000,
        }
    ),
}


# ==================== ENDPOINTS ====================

@router.get("/plans", response_model=List[PlanInfo])
async def get_plans():
    """Get available subscription plans"""
    return list(PLANS.values())


@router.get("/subscription", response_model=SubscriptionStatus)
async def get_subscription(
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get current subscription status"""
    result = await db.execute(select(Tenant).where(Tenant.id == current_user.tenant_id))
    tenant = result.scalar_one_or_none()
    
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    # Default trial subscription
    trial_end = datetime.utcnow() + timedelta(days=14)
    
    return SubscriptionStatus(
        plan=getattr(tenant, 'subscription_plan', 'professional') or 'professional',
        status=getattr(tenant, 'subscription_status', 'trial') or 'trial',
        trial_ends_at=trial_end,
        current_period_start=datetime.utcnow(),
        current_period_end=trial_end,
        cancel_at_period_end=False,
        amount=2990,
    )


@router.post("/subscription/change")
async def change_plan(
    data: ChangePlanRequest,
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Change subscription plan"""
    if data.plan_id not in PLANS:
        raise HTTPException(status_code=400, detail="Invalid plan")
    
    result = await db.execute(select(Tenant).where(Tenant.id == current_user.tenant_id))
    tenant = result.scalar_one_or_none()
    
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    # In production, this would integrate with Stripe/YooKassa
    # For now, just update the plan
    tenant.subscription_plan = data.plan_id
    await db.commit()
    
    return {"message": f"Plan changed to {data.plan_id}"}


@router.post("/subscription/cancel")
async def cancel_subscription(
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Cancel subscription at period end"""
    result = await db.execute(select(Tenant).where(Tenant.id == current_user.tenant_id))
    tenant = result.scalar_one_or_none()
    
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    # Mark for cancellation
    tenant.subscription_status = 'cancelled'
    await db.commit()
    
    return {"message": "Subscription will be cancelled at period end"}


@router.get("/payment-methods", response_model=List[PaymentMethod])
async def get_payment_methods(
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get saved payment methods"""
    # In production, this would fetch from Stripe/YooKassa
    return []


@router.post("/payment-methods")
async def add_payment_method(
    data: AddPaymentMethodRequest,
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Add a new payment method"""
    # In production, this would integrate with Stripe/YooKassa
    return {"message": "Payment method added"}


@router.delete("/payment-methods/{method_id}")
async def delete_payment_method(
    method_id: str,
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Delete a payment method"""
    return {"message": "Payment method deleted"}


@router.get("/invoices", response_model=List[Invoice])
async def get_invoices(
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get billing history / invoices"""
    # In production, this would fetch from payment provider
    return []


@router.get("/invoices/{invoice_id}")
async def get_invoice(
    invoice_id: str,
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get specific invoice details"""
    raise HTTPException(status_code=404, detail="Invoice not found")


@router.post("/checkout")
async def create_checkout_session(
    data: ChangePlanRequest,
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create a checkout session for subscription"""
    if data.plan_id not in PLANS:
        raise HTTPException(status_code=400, detail="Invalid plan")
    
    plan = PLANS[data.plan_id]
    amount = plan.price if data.billing_cycle == "monthly" else plan.price_yearly
    
    # In production, this would create a Stripe/YooKassa checkout session
    # and return a URL to redirect the user to
    
    return {
        "checkout_url": f"/billing/checkout?plan={data.plan_id}&cycle={data.billing_cycle}",
        "amount": amount,
        "plan": plan.name,
    }


@router.get("/usage")
async def get_usage(
    current_user: TokenData = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get current usage against plan limits"""
    result = await db.execute(select(Tenant).where(Tenant.id == current_user.tenant_id))
    tenant = result.scalar_one_or_none()
    
    if not tenant:
        raise HTTPException(status_code=404, detail="Tenant not found")
    
    plan_id = getattr(tenant, 'subscription_plan', 'professional') or 'professional'
    plan = PLANS.get(plan_id, PLANS['professional'])
    
    # In production, these would be actual counts from the database
    return {
        "plan": plan.name,
        "limits": plan.limits,
        "usage": {
            "clients": 30,
            "staff": 5,
            "branches": 1,
            "sms_this_month": 45,
        }
    }
