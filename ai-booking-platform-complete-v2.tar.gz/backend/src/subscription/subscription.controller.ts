import {
  Controller,
  Get,
  Post,
  Delete,
  Body,
  Param,
  HttpStatus,
  HttpException,
} from '@nestjs/common';
import { SubscriptionService } from './subscription.service';
import { SubscriptionTier } from '../feature-flags/feature-flags.service';

/**
 * Subscription Controller
 * 
 * API endpoints для управления подписками
 */
@Controller('subscription')
export class SubscriptionController {
  constructor(private subscriptionService: SubscriptionService) {}

  /**
   * POST /subscription/create - Создать подписку
   */
  @Post('create')
  async createSubscription(
    @Body()
    body: {
      businessId: string;
      tier: SubscriptionTier;
      durationMonths?: number;
    },
  ) {
    try {
      const subscription = await this.subscriptionService.createSubscription(
        body.businessId,
        body.tier,
        body.durationMonths || 1,
        false,
      );

      return {
        success: true,
        data: subscription,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to create subscription',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /subscription/update - Обновить подписку (upgrade/downgrade)
   */
  @Post('update')
  async updateSubscription(
    @Body()
    body: {
      businessId: string;
      tier: SubscriptionTier;
      durationMonths?: number;
    },
  ) {
    try {
      const subscription = await this.subscriptionService.updateSubscription(
        body.businessId,
        body.tier,
        body.durationMonths || 1,
      );

      return {
        success: true,
        data: subscription,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to update subscription',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /subscription/renew - Продлить подписку
   */
  @Post('renew')
  async renewSubscription(
    @Body() body: { businessId: string; durationMonths?: number },
  ) {
    try {
      const subscription = await this.subscriptionService.renewSubscription(
        body.businessId,
        body.durationMonths || 1,
      );

      return {
        success: true,
        data: subscription,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to renew subscription',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * DELETE /subscription/cancel/:businessId - Отменить подписку
   */
  @Delete('cancel/:businessId')
  async cancelSubscription(@Param('businessId') businessId: string) {
    try {
      await this.subscriptionService.cancelSubscription(businessId);

      return {
        success: true,
        message: 'Subscription cancelled successfully',
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to cancel subscription',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /subscription/current/:businessId - Получить текущую подписку
   */
  @Get('current/:businessId')
  async getCurrentSubscription(@Param('businessId') businessId: string) {
    try {
      const subscription = await this.subscriptionService.getCurrentSubscription(
        businessId,
      );

      return {
        success: true,
        data: subscription,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get subscription',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /subscription/history/:businessId - Получить историю подписок
   */
  @Get('history/:businessId')
  async getSubscriptionHistory(@Param('businessId') businessId: string) {
    try {
      const history = await this.subscriptionService.getSubscriptionHistory(
        businessId,
      );

      return {
        success: true,
        count: history.length,
        data: history,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get subscription history',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /subscription/trial - Создать пробную подписку
   */
  @Post('trial')
  async createTrialSubscription(
    @Body()
    body: {
      businessId: string;
      tier?: SubscriptionTier;
      durationDays?: number;
    },
  ) {
    try {
      const subscription = await this.subscriptionService.createTrialSubscription(
        body.businessId,
        body.tier,
        body.durationDays,
      );

      return {
        success: true,
        data: subscription,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to create trial subscription',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /subscription/expiring - Получить истекающие подписки
   */
  @Get('expiring')
  async getExpiringSubscriptions() {
    try {
      const expiring = await this.subscriptionService.checkExpiringSubscriptions(
        7,
      );

      return {
        success: true,
        count: expiring.length,
        data: expiring,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get expiring subscriptions',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * POST /subscription/auto-renew - Автоматическое продление подписок
   */
  @Post('auto-renew')
  async autoRenewSubscriptions() {
    try {
      const result = await this.subscriptionService.autoRenewSubscriptions();

      return {
        success: true,
        data: result,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to auto-renew subscriptions',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  /**
   * GET /subscription/stats - Получить статистику подписок
   */
  @Get('stats')
  async getSubscriptionStats() {
    try {
      const stats = await this.subscriptionService.getSubscriptionStats();

      return {
        success: true,
        data: stats,
      };
    } catch (error) {
      throw new HttpException(
        error.message || 'Failed to get subscription stats',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
