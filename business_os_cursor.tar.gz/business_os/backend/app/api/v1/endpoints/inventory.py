"""
Business OS - Inventory API
Управление складом и расходниками
"""

from datetime import datetime, date
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, UploadFile, File
from pydantic import BaseModel, Field
from sqlalchemy import select, func, and_, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.models.inventory import InventoryItem, InventoryCategory, InventorySupply, InventoryConsumption

router = APIRouter()


# === Schemas ===

class InventoryCategoryCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: Optional[str] = None
    sort_order: int = 0


class InventoryCategoryResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    sort_order: int
    
    class Config:
        from_attributes = True


class InventoryItemCreate(BaseModel):
    category_id: Optional[int] = None
    name: str = Field(..., min_length=1, max_length=200)
    sku: Optional[str] = None
    description: Optional[str] = None
    unit: str = "шт"
    quantity: float = 0
    min_quantity: float = 0
    purchase_price: Optional[float] = None


class InventoryItemUpdate(BaseModel):
    category_id: Optional[int] = None
    name: Optional[str] = None
    sku: Optional[str] = None
    description: Optional[str] = None
    unit: Optional[str] = None
    min_quantity: Optional[float] = None
    purchase_price: Optional[float] = None


class InventoryItemResponse(BaseModel):
    id: int
    tenant_id: int
    category_id: Optional[int]
    name: str
    sku: Optional[str]
    description: Optional[str]
    unit: str
    quantity: float
    min_quantity: float
    purchase_price: Optional[float]
    status: str
    total_value: Optional[float]
    created_at: datetime
    
    class Config:
        from_attributes = True


class InventoryListResponse(BaseModel):
    items: List[InventoryItemResponse]
    total: int
    low_stock_count: int
    out_of_stock_count: int


class InventoryStats(BaseModel):
    total_items: int
    total_value: float
    low_stock_items: int
    out_of_stock_items: int
    supplies_this_month: float
    consumption_this_month: float


class ConsumptionCreate(BaseModel):
    item_id: int
    quantity: float
    appointment_id: Optional[int] = None
    staff_id: Optional[int] = None
    consumption_type: str = "service"
    reason: Optional[str] = None


class ConsumptionResponse(BaseModel):
    id: int
    item_id: int
    item_name: str
    quantity: float
    appointment_id: Optional[int]
    staff_id: Optional[int]
    consumption_type: str
    reason: Optional[str]
    created_at: datetime
    
    class Config:
        from_attributes = True


# === Helper Functions ===

def _get_item_status(item: InventoryItem) -> str:
    qty = float(item.quantity or 0)
    min_qty = float(item.min_quantity or 0)
    if qty <= 0:
        return "out_of_stock"
    elif min_qty > 0 and qty <= min_qty * 0.5:
        return "critical"
    elif min_qty > 0 and qty <= min_qty:
        return "low"
    return "ok"


def _item_to_response(item: InventoryItem) -> InventoryItemResponse:
    total_value = None
    if item.purchase_price and item.quantity:
        total_value = float(item.purchase_price) * float(item.quantity)
    return InventoryItemResponse(
        id=item.id, tenant_id=item.tenant_id, category_id=item.category_id,
        name=item.name, sku=item.sku, description=item.description,
        unit=item.unit or "шт", quantity=float(item.quantity or 0),
        min_quantity=float(item.min_quantity or 0),
        purchase_price=float(item.purchase_price) if item.purchase_price else None,
        status=_get_item_status(item),
        total_value=total_value, created_at=item.created_at
    )


# === Category Endpoints ===

@router.get("/categories", response_model=List[InventoryCategoryResponse])
async def list_categories(db: AsyncSession = Depends(get_db)):
    tenant_id = 1
    query = select(InventoryCategory).where(InventoryCategory.tenant_id == tenant_id, InventoryCategory.is_deleted == False)
    return [InventoryCategoryResponse.model_validate(c) for c in (await db.execute(query.order_by(InventoryCategory.sort_order))).scalars().all()]


@router.post("/categories", response_model=InventoryCategoryResponse, status_code=201)
async def create_category(data: InventoryCategoryCreate, db: AsyncSession = Depends(get_db)):
    tenant_id = 1
    category = InventoryCategory(tenant_id=tenant_id, **data.model_dump())
    db.add(category)
    await db.commit()
    await db.refresh(category)
    return InventoryCategoryResponse.model_validate(category)


# === Item Endpoints ===

@router.get("", response_model=InventoryListResponse)
async def list_items(category_id: Optional[int] = None, status: Optional[str] = None, search: Optional[str] = None, db: AsyncSession = Depends(get_db)):
    tenant_id = 1
    query = select(InventoryItem).where(InventoryItem.tenant_id == tenant_id, InventoryItem.is_deleted == False)
    if category_id:
        query = query.where(InventoryItem.category_id == category_id)
    if search:
        query = query.where(InventoryItem.name.ilike(f"%{search}%"))
    
    items = (await db.execute(query.order_by(InventoryItem.name))).scalars().all()
    filtered, low, out = [], 0, 0
    for item in items:
        s = _get_item_status(item)
        if s == "out_of_stock": out += 1
        elif s in ("low", "critical"): low += 1
        if status is None or s == status:
            filtered.append(item)
    
    return InventoryListResponse(items=[_item_to_response(i) for i in filtered], total=len(filtered), low_stock_count=low, out_of_stock_count=out)


@router.get("/stats", response_model=InventoryStats)
async def get_inventory_stats(db: AsyncSession = Depends(get_db)):
    tenant_id = 1
    items = (await db.execute(select(InventoryItem).where(InventoryItem.tenant_id == tenant_id, InventoryItem.is_deleted == False))).scalars().all()
    
    total_value = sum(float(i.quantity or 0) * float(i.purchase_price or 0) for i in items)
    low = sum(1 for i in items if _get_item_status(i) in ("low", "critical"))
    out = sum(1 for i in items if _get_item_status(i) == "out_of_stock")
    
    month_start = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    supplies = float((await db.execute(select(func.sum(InventorySupply.total_amount)).where(InventorySupply.tenant_id == tenant_id, InventorySupply.created_at >= month_start, InventorySupply.is_deleted == False))).scalar() or 0)
    
    return InventoryStats(total_items=len(items), total_value=total_value, low_stock_items=low, out_of_stock_items=out, supplies_this_month=supplies, consumption_this_month=0)


@router.get("/low-stock")
async def get_low_stock_items(db: AsyncSession = Depends(get_db)):
    tenant_id = 1
    items = (await db.execute(select(InventoryItem).where(InventoryItem.tenant_id == tenant_id, InventoryItem.is_deleted == False))).scalars().all()
    low = [_item_to_response(i) for i in items if _get_item_status(i) in ("low", "critical", "out_of_stock")]
    return {"items": low, "total": len(low)}


@router.get("/{item_id}", response_model=InventoryItemResponse)
async def get_item(item_id: int, db: AsyncSession = Depends(get_db)):
    tenant_id = 1
    item = (await db.execute(select(InventoryItem).where(InventoryItem.id == item_id, InventoryItem.tenant_id == tenant_id, InventoryItem.is_deleted == False))).scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    return _item_to_response(item)


@router.post("", response_model=InventoryItemResponse, status_code=201)
async def create_item(data: InventoryItemCreate, db: AsyncSession = Depends(get_db)):
    tenant_id = 1
    item = InventoryItem(tenant_id=tenant_id, **data.model_dump())
    db.add(item)
    await db.commit()
    await db.refresh(item)
    return _item_to_response(item)


@router.put("/{item_id}", response_model=InventoryItemResponse)
async def update_item(item_id: int, data: InventoryItemUpdate, db: AsyncSession = Depends(get_db)):
    tenant_id = 1
    item = (await db.execute(select(InventoryItem).where(InventoryItem.id == item_id, InventoryItem.tenant_id == tenant_id, InventoryItem.is_deleted == False))).scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(item, field, value)
    await db.commit()
    await db.refresh(item)
    return _item_to_response(item)


@router.delete("/{item_id}", status_code=204)
async def delete_item(item_id: int, db: AsyncSession = Depends(get_db)):
    tenant_id = 1
    item = (await db.execute(select(InventoryItem).where(InventoryItem.id == item_id, InventoryItem.tenant_id == tenant_id, InventoryItem.is_deleted == False))).scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    item.is_deleted = True
    item.deleted_at = datetime.utcnow()
    await db.commit()


# === Supply Endpoints ===

@router.post("/supply/photo")
async def create_supply_from_photo(photo: UploadFile = File(...), db: AsyncSession = Depends(get_db)):
    """Оприходовать поставку по фото (AI анализ)"""
    return {"status": "processing", "message": "Photo received. AI analysis will be implemented.", "filename": photo.filename}


# === Consumption Endpoints ===

@router.post("/consumption", response_model=ConsumptionResponse, status_code=201)
async def create_consumption(data: ConsumptionCreate, db: AsyncSession = Depends(get_db)):
    """Списать расходник"""
    tenant_id = 1
    item = (await db.execute(select(InventoryItem).where(InventoryItem.id == data.item_id, InventoryItem.tenant_id == tenant_id, InventoryItem.is_deleted == False))).scalar_one_or_none()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    if float(item.quantity or 0) < data.quantity:
        raise HTTPException(status_code=400, detail="Insufficient quantity")
    
    consumption = InventoryConsumption(
        tenant_id=tenant_id, item_id=data.item_id, quantity=data.quantity,
        appointment_id=data.appointment_id, staff_id=data.staff_id,
        consumption_type=data.consumption_type, reason=data.reason
    )
    db.add(consumption)
    item.quantity = float(item.quantity or 0) - data.quantity
    
    await db.commit()
    await db.refresh(consumption)
    return ConsumptionResponse(
        id=consumption.id, item_id=consumption.item_id, item_name=item.name,
        quantity=float(consumption.quantity), appointment_id=consumption.appointment_id,
        staff_id=consumption.staff_id, consumption_type=consumption.consumption_type,
        reason=consumption.reason, created_at=consumption.created_at
    )


@router.get("/consumption", response_model=List[ConsumptionResponse])
async def list_consumption(item_id: Optional[int] = None, staff_id: Optional[int] = None, date_from: Optional[date] = None, date_to: Optional[date] = None, limit: int = Query(50, ge=1, le=200), db: AsyncSession = Depends(get_db)):
    """Получить историю списаний"""
    tenant_id = 1
    query = select(InventoryConsumption, InventoryItem.name).join(InventoryItem, InventoryConsumption.item_id == InventoryItem.id).where(InventoryConsumption.tenant_id == tenant_id, InventoryConsumption.is_deleted == False)
    if item_id:
        query = query.where(InventoryConsumption.item_id == item_id)
    if staff_id:
        query = query.where(InventoryConsumption.staff_id == staff_id)
    if date_from:
        query = query.where(InventoryConsumption.created_at >= datetime.combine(date_from, datetime.min.time()))
    if date_to:
        query = query.where(InventoryConsumption.created_at <= datetime.combine(date_to, datetime.max.time()))
    
    return [ConsumptionResponse(
        id=c.id, item_id=c.item_id, item_name=name, quantity=float(c.quantity),
        appointment_id=c.appointment_id, staff_id=c.staff_id,
        consumption_type=c.consumption_type, reason=c.reason, created_at=c.created_at
    ) for c, name in (await db.execute(query.order_by(desc(InventoryConsumption.created_at)).limit(limit))).all()]
