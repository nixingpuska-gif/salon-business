# 🚀 Quick Start: Feature Flags + Подписки

## За 10 минут

### 1. Обновить Prisma Schema

Добавьте в `schema.prisma`:

```prisma
model Business {
  id                      String    @id @default(cuid())
  name                    String
  // ... существующие поля ...
  
  // Подписка
  subscriptionTier        String    @default("free")
  subscriptionValidUntil  DateTime  @default(now())
  
  subscriptions           Subscription[]
}

model Subscription {
  id            String    @id @default(cuid())
  businessId    String
  tier          String    // free, basic, pro, enterprise
  status        String    // active, expired, cancelled, trial
  startDate     DateTime
  validUntil    DateTime
  autoRenew     Boolean   @default(true)
  cancelledAt   DateTime?
  trialEndsAt   DateTime?
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt

  business      Business  @relation(fields: [businessId], references: [id], onDelete: Cascade)

  @@index([businessId])
  @@index([status])
}

model SocialMediaPost {
  id          String    @id @default(cuid())
  businessId  String
  platform    String    // instagram, facebook
  postId      String
  content     String?
  imageUrl    String?
  status      String    // published, failed
  publishedAt DateTime?
  createdAt   DateTime  @default(now())

  business    Business  @relation(fields: [businessId], references: [id], onDelete: Cascade)

  @@index([businessId])
  @@index([platform])
}
```

### 2. Применить миграцию

```bash
cd backend
npx prisma migrate dev --name add_subscriptions
```

### 3. Запустить сервер

```bash
npm run start:dev
```

### 4. Проверить API

#### Получить все планы:
```bash
curl http://localhost:3000/feature-flags/plans
```

#### Создать подписку:
```bash
curl -X POST http://localhost:3000/subscription/create \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "1",
    "tier": "pro",
    "durationMonths": 1
  }'
```

#### Проверить доступ к функции:
```bash
curl -X POST http://localhost:3000/feature-flags/check-feature \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "1",
    "feature": "whatsapp_business"
  }'
```

#### Получить использование лимитов:
```bash
curl http://localhost:3000/feature-flags/business/1/usage
```

---

## Тарифные планы

| План | Цена | Записи/мес | Клиенты | Услуги | Каналы |
|------|------|------------|---------|--------|--------|
| **Free** | 0 ₽ | 50 | 100 | 5 | Telegram |
| **Basic** | 990 ₽ | 200 | 500 | 20 | Telegram, WhatsApp |
| **Pro** | 2,990 ₽ | 1,000 | 5,000 | 100 | Все + OCR + SMM |
| **Enterprise** | 9,990 ₽ | ♾️ | ♾️ | ♾️ | Все + API + White Label |

---

## Использование в коде

### Защита endpoint с Guard:

```typescript
import { Controller, Post, UseGuards } from '@nestjs/common';
import { FeatureAccessGuard, RequireFeature } from './feature-flags/feature-access.guard';
import { Feature } from './feature-flags/feature-flags.service';

@Controller('ocr')
@UseGuards(FeatureAccessGuard)
export class OCRController {
  @Post('import')
  @RequireFeature(Feature.OCR_IMPORT)
  async importFromImage(@Body() body: any) {
    // Доступно только на Pro и Enterprise
    // ...
  }
}
```

### Проверка в сервисе:

```typescript
import { FeatureFlagsService, Feature } from './feature-flags/feature-flags.service';

@Injectable()
export class MyService {
  constructor(private featureFlags: FeatureFlagsService) {}

  async doSomething(businessId: string) {
    // Проверить доступ и лимит
    const check = await this.featureFlags.canPerformAction(businessId, {
      feature: Feature.SMM_POSTING,
      limitType: 'maxSMMPostsPerMonth',
    });

    if (!check.allowed) {
      throw new Error(check.reason);
    }

    // Выполнить действие
    // ...
  }
}
```

---

## Автоматизация

### Cron job для автопродления:

```typescript
import { Injectable } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { SubscriptionService } from './subscription/subscription.service';

@Injectable()
export class SubscriptionCronService {
  constructor(private subscriptionService: SubscriptionService) {}

  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT)
  async handleAutoRenew() {
    await this.subscriptionService.autoRenewSubscriptions();
  }
}
```

---

## Готово! 🎉

**Система feature flags и подписок работает!**

Подробнее: см. **FEATURE-FLAGS-SUBSCRIPTION-GUIDE.md**
