"""
Business OS - Service Models
Модели услуг салона
"""

from datetime import datetime
from typing import Optional
from sqlalchemy import (
    Column, String, Text, Boolean, Integer, BigInteger, 
    DateTime, Numeric, ForeignKey, JSON, Index
)
from sqlalchemy.orm import relationship

from app.models.base import TenantBaseModel


class ServiceCategory(TenantBaseModel):
    """
    Категория услуг.
    Например: "Ногтевой сервис", "Парикмахерские услуги"
    """
    __tablename__ = "service_categories"
    
    # === Привязка к филиалу (опционально) ===
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=True)
    
    # === Основная информация ===
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    icon = Column(String(50), nullable=True)  # Иконка (emoji или код)
    color = Column(String(20), nullable=True)  # Цвет для UI
    
    # === Сортировка ===
    sort_order = Column(Integer, default=0)
    
    # === Статус ===
    is_active = Column(Boolean, default=True)
    
    # === Relationships ===
    services = relationship("Service", back_populates="category", lazy="dynamic")
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_service_categories_tenant_branch', 'tenant_id', 'branch_id'),
    )


class Service(TenantBaseModel):
    """
    Услуга салона.
    """
    __tablename__ = "services"
    
    # === Привязка ===
    branch_id = Column(BigInteger, ForeignKey("branches.id"), nullable=True)
    category_id = Column(BigInteger, ForeignKey("service_categories.id"), nullable=True, index=True)
    
    # === Основная информация ===
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # === Цена ===
    price = Column(Numeric(10, 2), nullable=False)
    price_from = Column(Numeric(10, 2), nullable=True)  # "от" (для диапазона)
    price_to = Column(Numeric(10, 2), nullable=True)  # "до"
    
    # === Длительность ===
    duration_minutes = Column(Integer, nullable=False, default=60)
    buffer_before_minutes = Column(Integer, default=0)
    buffer_after_minutes = Column(Integer, default=0)
    
    # === Онлайн-запись ===
    is_active = Column(Boolean, default=True)
    online_booking_enabled = Column(Boolean, default=True)
    
    # === Сортировка и отображение ===
    sort_order = Column(Integer, default=0)
    is_popular = Column(Boolean, default=False)  # Популярная услуга
    
    # === Цикл возврата ===
    return_cycle_days = Column(Integer, default=21)  # Через сколько дней клиент должен вернуться
    
    # === Расходники ===
    consumables = Column(JSON, default=list)
    # [{"item_id": 1, "quantity": 0.5, "unit": "ml"}, ...]
    
    # === Себестоимость ===
    cost_price = Column(Numeric(10, 2), nullable=True)  # Себестоимость (расходники + время)
    
    # === Статистика ===
    total_bookings = Column(Integer, default=0)
    avg_rating = Column(Numeric(3, 2), nullable=True)
    
    # === SEO/Маркетинг ===
    seo_title = Column(String(255), nullable=True)
    seo_description = Column(Text, nullable=True)
    
    # === Relationships ===
    category = relationship("ServiceCategory", back_populates="services")
    branch = relationship("Branch", back_populates="services")
    staff_services = relationship("StaffService", back_populates="service", lazy="dynamic")
    appointments = relationship("Appointment", back_populates="service", lazy="dynamic")
    
    # === Indexes ===
    __table_args__ = (
        Index('ix_services_tenant_category', 'tenant_id', 'category_id'),
        Index('ix_services_tenant_branch', 'tenant_id', 'branch_id'),
    )


class ServiceCombo(TenantBaseModel):
    """
    Комбо-услуга (пакет из нескольких услуг).
    """
    __tablename__ = "service_combos"
    
    # === Основная информация ===
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # === Цена ===
    price = Column(Numeric(10, 2), nullable=False)  # Цена комбо
    discount_percent = Column(Numeric(5, 2), nullable=True)  # Скидка от суммы услуг
    
    # === Услуги в комбо ===
    services = Column(JSON, default=list)
    # [{"service_id": 1, "quantity": 1}, {"service_id": 2, "quantity": 1}]
    
    # === Длительность ===
    total_duration_minutes = Column(Integer, nullable=True)  # Общая длительность
    
    # === Статус ===
    is_active = Column(Boolean, default=True)
    
    # === Период действия ===
    valid_from = Column(DateTime, nullable=True)
    valid_until = Column(DateTime, nullable=True)


class ServicePromotion(TenantBaseModel):
    """
    Акции и скидки на услуги.
    """
    __tablename__ = "service_promotions"
    
    # === Основная информация ===
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    
    # === Тип скидки ===
    discount_type = Column(String(20), nullable=False)  # percent, fixed, price
    discount_value = Column(Numeric(10, 2), nullable=False)
    
    # === Применимость ===
    applies_to = Column(String(20), default="all")  # all, category, service, combo
    applies_to_ids = Column(JSON, default=list)  # ID категорий/услуг
    
    # === Условия ===
    min_order_amount = Column(Numeric(10, 2), nullable=True)
    max_uses_total = Column(Integer, nullable=True)
    max_uses_per_client = Column(Integer, nullable=True)
    
    # === Период действия ===
    valid_from = Column(DateTime, nullable=False)
    valid_until = Column(DateTime, nullable=True)
    
    # === Дни недели ===
    valid_days = Column(JSON, default=[0, 1, 2, 3, 4, 5, 6])  # 0=Пн, 6=Вс
    valid_hours_from = Column(String(5), nullable=True)  # "09:00"
    valid_hours_to = Column(String(5), nullable=True)  # "18:00"
    
    # === Для новых/постоянных клиентов ===
    for_new_clients_only = Column(Boolean, default=False)
    for_returning_clients_only = Column(Boolean, default=False)
    min_visits_required = Column(Integer, nullable=True)
    
    # === Промокод ===
    promo_code = Column(String(50), nullable=True, index=True)
    
    # === Статус ===
    is_active = Column(Boolean, default=True)
    
    # === Статистика ===
    times_used = Column(Integer, default=0)
    total_discount_given = Column(Numeric(12, 2), default=0)
