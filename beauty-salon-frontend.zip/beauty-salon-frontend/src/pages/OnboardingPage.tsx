/**
 * Onboarding Component
 * To be implemented
 */
export default function Onboarding() {
  return (
    <div className="min-h-screen bg-gray-900 p-8">
      <h1 className="text-3xl font-bold text-white">Onboarding</h1>
      <p className="text-gray-400 mt-4">This page is under development</p>
    </div>
  )
}
