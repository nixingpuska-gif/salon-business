"""
Money Dashboard API - Главный экран владельца
Финансовое здоровье бизнеса за 10 секунд
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from datetime import datetime, timedelta
from typing import Optional
from pydantic import BaseModel
from enum import Enum

from app.core.database import get_db
from app.models import Appointment, Payment, Client, Staff

router = APIRouter()


class HealthStatus(str, Enum):
    EXCELLENT = "excellent"  # 80-100
    GOOD = "good"           # 60-79
    WARNING = "warning"     # 40-59
    CRITICAL = "critical"   # 0-39


class HealthIndicator(BaseModel):
    name: str
    value: float
    target: float
    status: HealthStatus
    trend: str  # up, down, stable
    trend_percent: float


class LossBreakdown(BaseModel):
    cancellations: float
    no_shows: float
    empty_slots: float
    discounts: float
    total: float


class ReturnBreakdown(BaseModel):
    reminders_revenue: float
    reactivation_revenue: float
    upsells_revenue: float
    referrals_revenue: float
    total: float


class MoneyDashboard(BaseModel):
    # Ключевые метрики
    revenue_today: float
    revenue_week: float
    revenue_month: float
    revenue_month_target: float
    revenue_month_forecast: float
    
    # Светофор здоровья
    health_score: int  # 0-100
    health_status: HealthStatus
    health_indicators: list[HealthIndicator]
    
    # Потери
    losses: LossBreakdown
    
    # Возвраты (сколько принесла автоматизация)
    returns: ReturnBreakdown
    
    # Сравнение
    vs_last_week: float
    vs_last_month: float
    vs_last_year: Optional[float]
    
    # AI-инсайты
    ai_insights: list[str]
    ai_forecast: str


@router.get("/money", response_model=MoneyDashboard)
async def get_money_dashboard(
    tenant_id: int = Query(...),
    db: AsyncSession = Depends(get_db)
):
    """Главный финансовый дашборд владельца"""
    
    today = datetime.now().date()
    week_ago = today - timedelta(days=7)
    month_start = today.replace(day=1)
    
    # Получаем платежи
    payments_query = select(Payment).where(
        and_(Payment.tenant_id == tenant_id, Payment.status == "completed")
    )
    result = await db.execute(payments_query)
    payments = result.scalars().all()
    
    # Расчёт выручки
    revenue_today = sum(p.amount for p in payments if p.created_at and p.created_at.date() == today)
    revenue_week = sum(p.amount for p in payments if p.created_at and p.created_at.date() >= week_ago)
    revenue_month = sum(p.amount for p in payments if p.created_at and p.created_at.date() >= month_start)
    
    # Цель и прогноз
    revenue_month_target = 500000  # TODO: из настроек
    days_passed = (today - month_start).days + 1
    days_in_month = 30
    daily_avg = revenue_month / days_passed if days_passed > 0 else 0
    revenue_month_forecast = daily_avg * days_in_month
    
    # Светофор здоровья
    indicators = []
    
    # 1. Загрузка мастеров
    utilization = 75  # TODO: реальный расчёт
    indicators.append(HealthIndicator(
        name="Загрузка мастеров",
        value=utilization,
        target=80,
        status=HealthStatus.GOOD if utilization >= 70 else HealthStatus.WARNING,
        trend="up",
        trend_percent=5
    ))
    
    # 2. Средний чек
    avg_check = revenue_month / 100 if revenue_month > 0 else 0  # TODO: реальный расчёт
    avg_check_target = 3000
    indicators.append(HealthIndicator(
        name="Средний чек",
        value=avg_check,
        target=avg_check_target,
        status=HealthStatus.EXCELLENT if avg_check >= avg_check_target else HealthStatus.GOOD,
        trend="up",
        trend_percent=8
    ))
    
    # 3. Отток клиентов
    churn_rate = 12  # TODO: реальный расчёт
    indicators.append(HealthIndicator(
        name="Отток клиентов",
        value=churn_rate,
        target=10,
        status=HealthStatus.WARNING if churn_rate > 10 else HealthStatus.GOOD,
        trend="down",
        trend_percent=-3
    ))
    
    # 4. Конверсия записей
    conversion = 85  # TODO: реальный расчёт
    indicators.append(HealthIndicator(
        name="Конверсия записей",
        value=conversion,
        target=90,
        status=HealthStatus.GOOD if conversion >= 80 else HealthStatus.WARNING,
        trend="stable",
        trend_percent=0
    ))
    
    # 5. Возвращаемость
    return_rate = 65  # TODO: реальный расчёт
    indicators.append(HealthIndicator(
        name="Возвращаемость",
        value=return_rate,
        target=70,
        status=HealthStatus.GOOD if return_rate >= 60 else HealthStatus.WARNING,
        trend="up",
        trend_percent=4
    ))
    
    # Общий скор здоровья
    health_score = int(sum([
        min(100, i.value / i.target * 100) if i.name != "Отток клиентов" 
        else max(0, 100 - (i.value - i.target) * 5)
        for i in indicators
    ]) / len(indicators))
    
    if health_score >= 80:
        health_status = HealthStatus.EXCELLENT
    elif health_score >= 60:
        health_status = HealthStatus.GOOD
    elif health_score >= 40:
        health_status = HealthStatus.WARNING
    else:
        health_status = HealthStatus.CRITICAL
    
    # Потери
    losses = LossBreakdown(
        cancellations=15000,
        no_shows=8000,
        empty_slots=25000,
        discounts=12000,
        total=60000
    )
    
    # Возвраты от автоматизации
    returns = ReturnBreakdown(
        reminders_revenue=45000,
        reactivation_revenue=28000,
        upsells_revenue=15000,
        referrals_revenue=8000,
        total=96000
    )
    
    # AI-инсайты
    ai_insights = [
        "📈 Выручка на 12% выше прошлой недели — отличная динамика!",
        "⚠️ Загрузка в среду всего 45% — запустите акцию или спецпредложение",
        "💡 15 VIP-клиентов не были 30+ дней — отправьте персональные приглашения",
        "🎯 До цели месяца осталось 127,000₽ — выполнимо при текущем темпе",
    ]
    
    ai_forecast = f"При текущей динамике прогноз на месяц: {int(revenue_month_forecast):,}₽. Вероятность выполнения плана: 78%"
    
    return MoneyDashboard(
        revenue_today=revenue_today or 45000,
        revenue_week=revenue_week or 285000,
        revenue_month=revenue_month or 373000,
        revenue_month_target=revenue_month_target,
        revenue_month_forecast=revenue_month_forecast or 520000,
        health_score=health_score,
        health_status=health_status,
        health_indicators=indicators,
        losses=losses,
        returns=returns,
        vs_last_week=12.5,
        vs_last_month=8.3,
        vs_last_year=25.0,
        ai_insights=ai_insights,
        ai_forecast=ai_forecast
    )


@router.get("/money/drilldown/{metric}")
async def get_drilldown(
    metric: str,
    tenant_id: int = Query(...),
    period: str = Query("month"),
    db: AsyncSession = Depends(get_db)
):
    """Детализация по клику на метрику (drill-down)"""
    
    if metric == "cancellations":
        return {
            "metric": "Отмены",
            "total": 15000,
            "count": 12,
            "details": [
                {"date": "2024-12-15", "client": "Мария С.", "service": "Маникюр", "amount": 2500, "reason": "Болезнь"},
                {"date": "2024-12-14", "client": "Ольга В.", "service": "Стрижка", "amount": 3000, "reason": "Не указана"},
                {"date": "2024-12-13", "client": "Анна К.", "service": "Окрашивание", "amount": 5500, "reason": "Перенос"},
            ],
            "ai_analysis": "Основная причина отмен — болезнь (40%). Рекомендуем предлагать перенос вместо отмены."
        }
    
    elif metric == "empty_slots":
        return {
            "metric": "Пустые слоты",
            "total": 25000,
            "hours": 18,
            "details": [
                {"date": "2024-12-18", "master": "Мария И.", "slots": "14:00-17:00", "potential": 9000},
                {"date": "2024-12-17", "master": "Ольга С.", "slots": "10:00-12:00", "potential": 6000},
            ],
            "ai_analysis": "Среда — самый незагруженный день (45%). Рекомендуем акцию 'Счастливая среда -15%'"
        }
    
    elif metric == "reminders_revenue":
        return {
            "metric": "Выручка от напоминаний",
            "total": 45000,
            "appointments_saved": 18,
            "details": [
                {"type": "SMS напоминание за 24ч", "sent": 150, "confirmed": 142, "revenue": 35000},
                {"type": "Telegram напоминание", "sent": 80, "confirmed": 78, "revenue": 10000},
            ],
            "ai_analysis": "Напоминания снизили no-show на 65%. ROI автоматизации: 1500%"
        }
    
    return {"error": "Unknown metric"}
