import { Injectable } from '@nestjs/common';
import { Counter, Gauge, Histogram, Registry, collectDefaultMetrics } from 'prom-client';

/**
 * Metrics Service
 * 
 * Сбор метрик для Prometheus:
 * - HTTP запросы (количество, время ответа)
 * - Бизнес-метрики (записи, клиенты, платежи)
 * - Системные метрики (CPU, память, uptime)
 * - Метрики очередей (BullMQ)
 */

@Injectable()
export class MetricsService {
  public readonly register: Registry;

  // HTTP метрики
  private httpRequestsTotal: Counter;
  private httpRequestDuration: Histogram;
  private httpRequestsInProgress: Gauge;

  // Бизнес-метрики
  private bookingsTotal: Counter;
  private bookingsActive: Gauge;
  private clientsTotal: Gauge;
  private paymentsTotal: Counter;
  private paymentsAmount: Counter;

  // Метрики уведомлений
  private notificationsSent: Counter;
  private notificationsFailed: Counter;

  // Метрики очередей
  private queueJobsActive: Gauge;
  private queueJobsCompleted: Counter;
  private queueJobsFailed: Counter;
  private queueJobsDuration: Histogram;

  // Метрики API интеграций
  private apiCallsTotal: Counter;
  private apiCallsFailed: Counter;
  private apiCallDuration: Histogram;

  constructor() {
    this.register = new Registry();

    // Собирать системные метрики (CPU, память, etc)
    collectDefaultMetrics({ register: this.register });

    // Инициализировать HTTP метрики
    this.httpRequestsTotal = new Counter({
      name: 'http_requests_total',
      help: 'Total number of HTTP requests',
      labelNames: ['method', 'route', 'status'],
      registers: [this.register],
    });

    this.httpRequestDuration = new Histogram({
      name: 'http_request_duration_seconds',
      help: 'Duration of HTTP requests in seconds',
      labelNames: ['method', 'route', 'status'],
      buckets: [0.1, 0.5, 1, 2, 5, 10],
      registers: [this.register],
    });

    this.httpRequestsInProgress = new Gauge({
      name: 'http_requests_in_progress',
      help: 'Number of HTTP requests in progress',
      labelNames: ['method', 'route'],
      registers: [this.register],
    });

    // Инициализировать бизнес-метрики
    this.bookingsTotal = new Counter({
      name: 'bookings_total',
      help: 'Total number of bookings created',
      labelNames: ['status'],
      registers: [this.register],
    });

    this.bookingsActive = new Gauge({
      name: 'bookings_active',
      help: 'Number of active bookings',
      registers: [this.register],
    });

    this.clientsTotal = new Gauge({
      name: 'clients_total',
      help: 'Total number of clients',
      registers: [this.register],
    });

    this.paymentsTotal = new Counter({
      name: 'payments_total',
      help: 'Total number of payments',
      labelNames: ['status'],
      registers: [this.register],
    });

    this.paymentsAmount = new Counter({
      name: 'payments_amount_rub',
      help: 'Total amount of payments in RUB',
      labelNames: ['status'],
      registers: [this.register],
    });

    // Инициализировать метрики уведомлений
    this.notificationsSent = new Counter({
      name: 'notifications_sent_total',
      help: 'Total number of notifications sent',
      labelNames: ['channel', 'type'],
      registers: [this.register],
    });

    this.notificationsFailed = new Counter({
      name: 'notifications_failed_total',
      help: 'Total number of failed notifications',
      labelNames: ['channel', 'type', 'reason'],
      registers: [this.register],
    });

    // Инициализировать метрики очередей
    this.queueJobsActive = new Gauge({
      name: 'queue_jobs_active',
      help: 'Number of active jobs in queue',
      labelNames: ['queue'],
      registers: [this.register],
    });

    this.queueJobsCompleted = new Counter({
      name: 'queue_jobs_completed_total',
      help: 'Total number of completed jobs',
      labelNames: ['queue'],
      registers: [this.register],
    });

    this.queueJobsFailed = new Counter({
      name: 'queue_jobs_failed_total',
      help: 'Total number of failed jobs',
      labelNames: ['queue'],
      registers: [this.register],
    });

    this.queueJobsDuration = new Histogram({
      name: 'queue_job_duration_seconds',
      help: 'Duration of queue jobs in seconds',
      labelNames: ['queue'],
      buckets: [1, 5, 10, 30, 60, 120],
      registers: [this.register],
    });

    // Инициализировать метрики API интеграций
    this.apiCallsTotal = new Counter({
      name: 'api_calls_total',
      help: 'Total number of external API calls',
      labelNames: ['service', 'method'],
      registers: [this.register],
    });

    this.apiCallsFailed = new Counter({
      name: 'api_calls_failed_total',
      help: 'Total number of failed API calls',
      labelNames: ['service', 'method', 'reason'],
      registers: [this.register],
    });

    this.apiCallDuration = new Histogram({
      name: 'api_call_duration_seconds',
      help: 'Duration of external API calls in seconds',
      labelNames: ['service', 'method'],
      buckets: [0.5, 1, 2, 5, 10, 30],
      registers: [this.register],
    });
  }

  /**
   * Получить все метрики в формате Prometheus
   */
  async getMetrics(): Promise<string> {
    return this.register.metrics();
  }

  /**
   * Записать HTTP запрос
   */
  recordHttpRequest(method: string, route: string, status: number, duration: number) {
    this.httpRequestsTotal.inc({ method, route, status });
    this.httpRequestDuration.observe({ method, route, status }, duration / 1000);
  }

  /**
   * Начать отслеживание HTTP запроса
   */
  startHttpRequest(method: string, route: string) {
    this.httpRequestsInProgress.inc({ method, route });
  }

  /**
   * Завершить отслеживание HTTP запроса
   */
  endHttpRequest(method: string, route: string) {
    this.httpRequestsInProgress.dec({ method, route });
  }

  /**
   * Записать создание записи
   */
  recordBookingCreated(status: string = 'confirmed') {
    this.bookingsTotal.inc({ status });
  }

  /**
   * Обновить количество активных записей
   */
  setActiveBookings(count: number) {
    this.bookingsActive.set(count);
  }

  /**
   * Обновить количество клиентов
   */
  setTotalClients(count: number) {
    this.clientsTotal.set(count);
  }

  /**
   * Записать платёж
   */
  recordPayment(status: string, amount: number) {
    this.paymentsTotal.inc({ status });
    this.paymentsAmount.inc({ status }, amount);
  }

  /**
   * Записать отправку уведомления
   */
  recordNotificationSent(channel: string, type: string) {
    this.notificationsSent.inc({ channel, type });
  }

  /**
   * Записать ошибку уведомления
   */
  recordNotificationFailed(channel: string, type: string, reason: string) {
    this.notificationsFailed.inc({ channel, type, reason });
  }

  /**
   * Обновить количество активных задач в очереди
   */
  setQueueJobsActive(queue: string, count: number) {
    this.queueJobsActive.set({ queue }, count);
  }

  /**
   * Записать завершённую задачу очереди
   */
  recordQueueJobCompleted(queue: string, duration: number) {
    this.queueJobsCompleted.inc({ queue });
    this.queueJobsDuration.observe({ queue }, duration / 1000);
  }

  /**
   * Записать ошибку задачи очереди
   */
  recordQueueJobFailed(queue: string) {
    this.queueJobsFailed.inc({ queue });
  }

  /**
   * Записать вызов внешнего API
   */
  recordApiCall(service: string, method: string, duration: number, success: boolean, reason?: string) {
    this.apiCallsTotal.inc({ service, method });
    this.apiCallDuration.observe({ service, method }, duration / 1000);

    if (!success) {
      this.apiCallsFailed.inc({ service, method, reason: reason || 'unknown' });
    }
  }

  /**
   * Получить текущие значения метрик (для dashboard)
   */
  async getCurrentMetrics(): Promise<Record<string, any>> {
    const metrics = await this.register.getMetricsAsJSON();
    
    const result: Record<string, any> = {};
    
    for (const metric of metrics) {
      if (metric.values && metric.values.length > 0) {
        result[metric.name] = metric.values;
      }
    }

    return result;
  }
}
