import { Injectable } from '@nestjs/common';

export interface NormalizedMessage {
  channel: 'telegram' | 'whatsapp' | 'instagram';
  userId: string;
  chatId: string;
  text?: string;
  attachments?: Array<{ type: string; url: string }>;
  metadata: Record<string, any>;
  timestamp: Date;
}

export interface UIChoices {
  type: 'choices';
  question: string;
  options: Array<{ id: string; label: string }>;
}

export interface UIResponse {
  text: string;
  ui?: UIChoices | null;
}

@Injectable()
export class ChannelGatewayService {
  /**
   * Normalize incoming message from any channel
   */
  normalizeMessage(channel: string, rawMessage: any): NormalizedMessage {
    if (channel === 'telegram') {
      return {
        channel: 'telegram',
        userId: rawMessage.from.id.toString(),
        chatId: rawMessage.chat.id.toString(),
        text: rawMessage.text,
        metadata: { 
          username: rawMessage.from.username,
          firstName: rawMessage.from.first_name,
          lastName: rawMessage.from.last_name,
        },
        timestamp: new Date(rawMessage.date * 1000),
      };
    }
    
    // WhatsApp normalization
    if (channel === 'whatsapp') {
      return {
        channel: 'whatsapp',
        userId: rawMessage.from,
        chatId: rawMessage.from,
        text: rawMessage.text?.body,
        metadata: {},
        timestamp: new Date(rawMessage.timestamp * 1000),
      };
    }

    // Instagram normalization
    if (channel === 'instagram') {
      return {
        channel: 'instagram',
        userId: rawMessage.sender.id,
        chatId: rawMessage.sender.id,
        text: rawMessage.message?.text,
        metadata: {},
        timestamp: new Date(rawMessage.timestamp),
      };
    }

    throw new Error(`Unsupported channel: ${channel}`);
  }

  /**
   * Render UI choices for specific channel
   */
  renderChoices(channel: string, ui: UIChoices): any {
    if (channel === 'telegram') {
      return {
        text: ui.question,
        reply_markup: {
          inline_keyboard: ui.options.map((opt) => [
            { text: opt.label, callback_data: opt.id },
          ]),
        },
      };
    }

    // WhatsApp: Quick replies
    if (channel === 'whatsapp') {
      return {
        text: ui.question,
        buttons: ui.options.slice(0, 3).map((opt) => ({
          type: 'reply',
          reply: { id: opt.id, title: opt.label },
        })),
      };
    }

    // Fallback: numbered list
    return {
      text: `${ui.question}\n\n${ui.options.map((opt, i) => `${i + 1}. ${opt.label}`).join('\n')}`,
    };
  }
}
