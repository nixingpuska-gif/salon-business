import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  HttpCode,
  HttpStatus,
} from '@nestjs/common';
import { ClientService } from './client.service';
import { CreateClientDto } from './dto/create-client.dto';
import { UpdateClientDto } from './dto/update-client.dto';
import { AddNoteDto } from './dto/add-note.dto';

@Controller('clients')
export class ClientController {
  constructor(private readonly clientService: ClientService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(@Body() createClientDto: CreateClientDto) {
    return this.clientService.findOrCreate(
      createClientDto.businessId,
      createClientDto,
    );
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    return this.clientService.findOne(id);
  }

  @Get()
  async findByBusiness(
    @Query('businessId') businessId: string,
    @Query('search') search?: string,
    @Query('tags') tags?: string,
    @Query('skip') skip?: string,
    @Query('take') take?: string,
  ) {
    return this.clientService.findByBusiness(businessId, {
      search,
      tags: tags ? tags.split(',') : undefined,
      skip: skip ? parseInt(skip, 10) : undefined,
      take: take ? parseInt(take, 10) : undefined,
    });
  }

  @Put(':id')
  async update(
    @Param('id') id: string,
    @Body() updateClientDto: UpdateClientDto,
  ) {
    return this.clientService.update(id, updateClientDto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  async delete(@Param('id') id: string) {
    await this.clientService.delete(id);
  }

  @Post(':id/notes')
  @HttpCode(HttpStatus.CREATED)
  async addNote(
    @Param('id') id: string,
    @Query('businessId') businessId: string,
    @Body() addNoteDto: AddNoteDto,
  ) {
    await this.clientService.addNote(
      id,
      businessId,
      addNoteDto.note,
      addNoteDto.createdBy,
    );
    return { message: 'Note added successfully' };
  }
}
