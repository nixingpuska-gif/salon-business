import { Injectable, BadRequestException, Inject, forwardRef } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Booking } from '@prisma/client';
import { addMinutes, startOfDay, endOfDay } from 'date-fns';
import { NotificationService } from '../notification/notification.service';

@Injectable()
export class BookingService {
  constructor(
    private prisma: PrismaService,
    @Inject(forwardRef(() => NotificationService))
    private notificationService: NotificationService,
  ) {}

  /**
   * Create a new booking
   */
  async create(data: {
    businessId: string;
    clientId: string;
    serviceId: string;
    startTime: Date;
    sourceChannel?: string;
    notes?: string;
  }): Promise<Booking> {
    // 1. Get service to determine duration and price
    const service = await this.prisma.service.findUnique({
      where: { id: data.serviceId },
    });

    if (!service) {
      throw new BadRequestException('Service not found');
    }

    if (!service.isActive) {
      throw new BadRequestException('Service is not active');
    }

    const endTime = addMinutes(data.startTime, service.durationMinutes);

    // 2. Check for conflicts
    const conflicts = await this.prisma.booking.count({
      where: {
        businessId: data.businessId,
        status: { in: ['confirmed', 'pending'] },
        OR: [
          {
            // New booking starts during existing booking
            AND: [
              { startTime: { lte: data.startTime } },
              { endTime: { gt: data.startTime } },
            ],
          },
          {
            // New booking ends during existing booking
            AND: [
              { startTime: { lt: endTime } },
              { endTime: { gte: endTime } },
            ],
          },
          {
            // New booking completely overlaps existing booking
            AND: [
              { startTime: { gte: data.startTime } },
              { endTime: { lte: endTime } },
            ],
          },
        ],
      },
    });

    if (conflicts > 0) {
      throw new BadRequestException('Time slot is not available');
    }

    // 3. Create booking
    const booking = await this.prisma.booking.create({
      data: {
        businessId: data.businessId,
        clientId: data.clientId,
        serviceId: data.serviceId,
        startTime: data.startTime,
        endTime,
        price: service.price,
        sourceChannel: data.sourceChannel,
        status: 'confirmed',
        notes: data.notes,
      },
      include: {
        client: true,
        service: true,
      },
    });

    // 4. Update client stats
    await this.prisma.client.update({
      where: { id: data.clientId },
      data: {
        totalBookings: { increment: 1 },
        lastVisitAt: data.startTime,
      },
    });

    // 5. Schedule reminders (24h and 2h before)
    try {
      await this.notificationService.scheduleBookingReminders(booking.id);
    } catch (error) {
      // Log error but don't fail the booking
      console.error('Failed to schedule reminders:', error);
    }

    return booking;
  }

  /**
   * Find booking by ID
   */
  async findOne(id: string): Promise<Booking> {
    const booking = await this.prisma.booking.findUnique({
      where: { id },
      include: {
        client: true,
        service: true,
        business: true,
      },
    });

    if (!booking) {
      throw new NotFoundException(`Booking with ID ${id} not found`);
    }

    return booking;
  }

  /**
   * Find bookings by business
   */
  async findByBusiness(businessId: string, params?: {
    startDate?: Date;
    endDate?: Date;
    status?: string;
    clientId?: string;
    skip?: number;
    take?: number;
  }): Promise<Booking[]> {
    const where: any = {
      businessId,
    };

    if (params?.startDate) {
      where.startTime = { gte: params.startDate };
    }
    if (params?.endDate) {
      where.endTime = { lte: params.endDate };
    }
    if (params?.status) {
      where.status = params.status;
    }
    if (params?.clientId) {
      where.clientId = params.clientId;
    }

    return this.prisma.booking.findMany({
      where,
      include: {
        client: true,
        service: true,
      },
      orderBy: { startTime: 'asc' },
      skip: params?.skip || 0,
      take: params?.take || 100,
    });
  }

  /**
   * Find bookings by client
   */
  async findByClient(clientId: string): Promise<Booking[]> {
    return this.prisma.booking.findMany({
      where: { clientId },
      include: {
        service: true,
        business: true,
      },
      orderBy: { startTime: 'desc' },
    });
  }

  /**
   * Reschedule booking
   */
  async reschedule(bookingId: string, newStartTime: Date): Promise<Booking> {
    const booking = await this.findOne(bookingId);

    if (booking.status === 'cancelled' || booking.status === 'completed') {
      throw new BadRequestException(`Cannot reschedule ${booking.status} booking`);
    }

    const service = await this.prisma.service.findUnique({
      where: { id: booking.serviceId },
    });

    if (!service) {
      throw new BadRequestException('Service not found');
    }

    const newEndTime = addMinutes(newStartTime, service.durationMinutes);

    // Check for conflicts (excluding current booking)
    const conflicts = await this.prisma.booking.count({
      where: {
        businessId: booking.businessId,
        id: { not: bookingId },
        status: { in: ['confirmed', 'pending'] },
        OR: [
          {
            AND: [
              { startTime: { lte: newStartTime } },
              { endTime: { gt: newStartTime } },
            ],
          },
          {
            AND: [
              { startTime: { lt: newEndTime } },
              { endTime: { gte: newEndTime } },
            ],
          },
          {
            AND: [
              { startTime: { gte: newStartTime } },
              { endTime: { lte: newEndTime } },
            ],
          },
        ],
      },
    });

    if (conflicts > 0) {
      throw new BadRequestException('New time slot is not available');
    }

    const updatedBooking = await this.prisma.booking.update({
      where: { id: bookingId },
      data: {
        startTime: newStartTime,
        endTime: newEndTime,
      },
      include: {
        client: true,
        service: true,
      },
    });

    // Reschedule reminders with new time
    try {
      await this.notificationService.rescheduleBookingReminders(parseInt(bookingId));
    } catch (error) {
      console.error('Failed to reschedule reminders:', error);
    }

    return updatedBooking;
  }

  /**
   * Cancel booking
   */
  async cancel(bookingId: string, reason?: string): Promise<Booking> {
    const booking = await this.findOne(bookingId);

    if (booking.status === 'cancelled') {
      throw new BadRequestException('Booking is already cancelled');
    }

    if (booking.status === 'completed') {
      throw new BadRequestException('Cannot cancel completed booking');
    }

    const cancelledBooking = await this.prisma.booking.update({
      where: { id: bookingId },
      data: {
        status: 'cancelled',
        cancelledAt: new Date(),
        cancelledReason: reason,
      },
      include: {
        client: true,
        service: true,
      },
    });

    // Cancel scheduled reminders
    try {
      await this.notificationService.cancelBookingReminders(parseInt(bookingId));
    } catch (error) {
      console.error('Failed to cancel reminders:', error);
    }

    return cancelledBooking;
  }

  /**
   * Mark booking as completed
   */
  async complete(bookingId: string): Promise<Booking> {
    const booking = await this.findOne(bookingId);

    if (booking.status === 'cancelled') {
      throw new BadRequestException('Cannot complete cancelled booking');
    }

    if (booking.status === 'completed') {
      throw new BadRequestException('Booking is already completed');
    }

    const updatedBooking = await this.prisma.booking.update({
      where: { id: bookingId },
      data: {
        status: 'completed',
      },
      include: {
        client: true,
        service: true,
      },
    });

    // Update client stats
    await this.prisma.client.update({
      where: { id: booking.clientId },
      data: {
        totalSpent: { increment: booking.price || 0 },
      },
    });

    return updatedBooking;
  }

  /**
   * Mark booking as no-show
   */
  async markNoShow(bookingId: string): Promise<Booking> {
    const booking = await this.findOne(bookingId);

    return this.prisma.booking.update({
      where: { id: bookingId },
      data: {
        status: 'no_show',
      },
      include: {
        client: true,
        service: true,
      },
    });
  }

  /**
   * Update booking notes
   */
  async updateNotes(bookingId: string, notes: string): Promise<Booking> {
    const booking = await this.findOne(bookingId);

    return this.prisma.booking.update({
      where: { id: booking.id },
      data: { notes },
    });
  }

  /**
   * Get booking statistics for a business
   */
  async getStats(businessId: string, startDate: Date, endDate: Date): Promise<{
    total: number;
    confirmed: number;
    completed: number;
    cancelled: number;
    noShow: number;
    totalRevenue: number;
  }> {
    const bookings = await this.prisma.booking.findMany({
      where: {
        businessId,
        startTime: { gte: startDate },
        endTime: { lte: endDate },
      },
    });

    return {
      total: bookings.length,
      confirmed: bookings.filter((b) => b.status === 'confirmed').length,
      completed: bookings.filter((b) => b.status === 'completed').length,
      cancelled: bookings.filter((b) => b.status === 'cancelled').length,
      noShow: bookings.filter((b) => b.status === 'no_show').length,
      totalRevenue: bookings
        .filter((b) => b.status === 'completed')
        .reduce((sum, b) => sum + (b.price || 0), 0),
    };
  }
}
