import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { PrismaService } from '../prisma/prisma.service';
import { BookingService } from '../booking/booking.service';

/**
 * OCR Service
 * 
 * Извлечение данных о записях из скриншотов и фотографий:
 * - Распознавание текста на изображениях
 * - Извлечение информации о записях (дата, время, клиент, услуга)
 * - Автоматический импорт в систему
 * - Поддержка различных форматов (скриншоты мессенджеров, фото записных книжек)
 */
@Injectable()
export class OCRService {
  private readonly logger = new Logger(OCRService.name);
  private openai: OpenAI;

  constructor(
    private configService: ConfigService,
    private prisma: PrismaService,
    private bookingService: BookingService,
  ) {
    const apiKey = this.configService.get<string>('OPENAI_API_KEY');
    if (!apiKey) {
      this.logger.warn('OPENAI_API_KEY not configured, OCR features will be disabled');
    } else {
      this.openai = new OpenAI({ apiKey });
      this.logger.log('OCR Service initialized with OpenAI Vision API');
    }
  }

  /**
   * Извлечь данные о записях из изображения
   */
  async extractBookingsFromImage(
    imageUrl: string,
    businessId: string,
  ): Promise<any[]> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }

    try {
      this.logger.log(`Extracting bookings from image: ${imageUrl}`);

      const prompt = `Ты — система распознавания записей клиентов. Проанализируй изображение и извлеки все записи.

Для каждой записи найди:
- Имя клиента (обязательно)
- Телефон клиента (если есть)
- Дата записи (обязательно, формат: YYYY-MM-DD)
- Время записи (обязательно, формат: HH:MM)
- Название услуги (обязательно)
- Цена (если есть)
- Заметки/комментарии (если есть)

Верни результат в формате JSON массива:
[
  {
    "clientName": "Иван Иванов",
    "clientPhone": "+79991234567",
    "date": "2024-12-01",
    "time": "14:00",
    "serviceName": "Маникюр",
    "price": 1500,
    "notes": "Гель-лак красный"
  }
]

Если на изображении нет записей, верни пустой массив [].
Если какое-то поле не найдено, используй null.
Телефон нормализуй в формат +7XXXXXXXXXX.`;

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: prompt },
              {
                type: 'image_url',
                image_url: { url: imageUrl },
              },
            ],
          },
        ],
        max_tokens: 2000,
        temperature: 0.1,
      });

      const content = response.choices[0]?.message?.content;
      if (!content) {
        throw new Error('No response from OpenAI');
      }

      // Парсим JSON из ответа
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      if (!jsonMatch) {
        this.logger.warn('No JSON found in response:', content);
        return [];
      }

      const bookings = JSON.parse(jsonMatch[0]);
      this.logger.log(`Extracted ${bookings.length} bookings from image`);

      return bookings;
    } catch (error) {
      this.logger.error('Failed to extract bookings from image:', error);
      throw error;
    }
  }

  /**
   * Импортировать записи из изображения в систему
   */
  async importBookingsFromImage(
    imageUrl: string,
    businessId: string,
  ): Promise<{
    success: number;
    failed: number;
    errors: string[];
    imported: any[];
  }> {
    try {
      const extractedBookings = await this.extractBookingsFromImage(
        imageUrl,
        businessId,
      );

      const results = {
        success: 0,
        failed: 0,
        errors: [] as string[],
        imported: [] as any[],
      };

      for (const booking of extractedBookings) {
        try {
          const imported = await this.importSingleBooking(booking, businessId);
          results.success++;
          results.imported.push(imported);
        } catch (error) {
          results.failed++;
          results.errors.push(
            `${booking.clientName} (${booking.date} ${booking.time}): ${error.message}`,
          );
          this.logger.error(`Failed to import booking:`, error);
        }
      }

      this.logger.log(
        `Import completed: ${results.success} success, ${results.failed} failed`,
      );

      return results;
    } catch (error) {
      this.logger.error('Failed to import bookings from image:', error);
      throw error;
    }
  }

  /**
   * Импортировать одну запись
   */
  private async importSingleBooking(
    booking: any,
    businessId: string,
  ): Promise<any> {
    // 1. Найти или создать клиента
    let client = await this.prisma.client.findFirst({
      where: {
        businessId,
        OR: [
          { name: booking.clientName },
          booking.clientPhone ? { phone: booking.clientPhone } : {},
        ],
      },
    });

    if (!client) {
      client = await this.prisma.client.create({
        data: {
          businessId,
          name: booking.clientName,
          phone: booking.clientPhone,
          source: 'ocr_import',
        },
      });
      this.logger.log(`Created new client: ${client.name}`);
    }

    // 2. Найти услугу по названию
    const service = await this.prisma.service.findFirst({
      where: {
        businessId,
        name: {
          contains: booking.serviceName,
          mode: 'insensitive',
        },
        isActive: true,
      },
    });

    if (!service) {
      throw new Error(`Service not found: ${booking.serviceName}`);
    }

    // 3. Создать запись
    const startTime = new Date(`${booking.date}T${booking.time}:00`);

    const createdBooking = await this.bookingService.create({
      businessId,
      clientId: client.id,
      serviceId: service.id,
      startTime,
      sourceChannel: 'ocr_import',
      notes: booking.notes || 'Импортировано из изображения',
    });

    this.logger.log(
      `Imported booking: ${client.name} - ${service.name} at ${startTime.toISOString()}`,
    );

    return createdBooking;
  }

  /**
   * Извлечь текст из изображения (общий OCR)
   */
  async extractTextFromImage(imageUrl: string): Promise<string> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }

    try {
      this.logger.log(`Extracting text from image: ${imageUrl}`);

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: 'Извлеки весь текст с этого изображения. Верни только текст, без дополнительных комментариев.',
              },
              {
                type: 'image_url',
                image_url: { url: imageUrl },
              },
            ],
          },
        ],
        max_tokens: 2000,
      });

      const text = response.choices[0]?.message?.content || '';
      this.logger.log(`Extracted ${text.length} characters from image`);

      return text;
    } catch (error) {
      this.logger.error('Failed to extract text from image:', error);
      throw error;
    }
  }

  /**
   * Анализ изображения (определить тип контента)
   */
  async analyzeImage(imageUrl: string): Promise<{
    type: 'booking_screenshot' | 'handwritten_notes' | 'calendar' | 'other';
    description: string;
    hasBookings: boolean;
  }> {
    if (!this.openai) {
      throw new Error('OpenAI API key not configured');
    }

    try {
      this.logger.log(`Analyzing image: ${imageUrl}`);

      const response = await this.openai.chat.completions.create({
        model: 'gpt-4o',
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: `Проанализируй изображение и определи его тип:
- booking_screenshot: скриншот из мессенджера с записями
- handwritten_notes: рукописные записи/заметки
- calendar: календарь или расписание
- other: другое

Верни JSON:
{
  "type": "тип",
  "description": "краткое описание",
  "hasBookings": true/false
}`,
              },
              {
                type: 'image_url',
                image_url: { url: imageUrl },
              },
            ],
          },
        ],
        max_tokens: 500,
        temperature: 0.1,
      });

      const content = response.choices[0]?.message?.content || '{}';
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      const analysis = jsonMatch ? JSON.parse(jsonMatch[0]) : {};

      this.logger.log(`Image analysis: ${JSON.stringify(analysis)}`);

      return analysis;
    } catch (error) {
      this.logger.error('Failed to analyze image:', error);
      throw error;
    }
  }
}
