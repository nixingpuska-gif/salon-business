# 🎯 Руководство по Feature Flags и Подпискам

## Обзор

Система управления доступом к функциям и монетизации платформы AI-Booking через тарифные планы.

### Компоненты:
1. **Feature Flags Service** - управление доступом к функциям
2. **Subscription Service** - управление подписками
3. **Feature Access Guard** - middleware для проверки доступа
4. **API Endpoints** - REST API для управления

---

## Тарифные планы

### 🆓 Бесплатный (Free)
**Цена:** 0 ₽/месяц

**Функции:**
- ✅ Базовые записи
- ✅ Управление клиентами
- ✅ Управление услугами
- ✅ Telegram бот
- ✅ Базовая аналитика

**Лимиты:**
- 50 записей/месяц
- 100 клиентов
- 5 услуг
- 1 сотрудник
- 1 локация
- 50 уведомлений/месяц

---

### 💼 Базовый (Basic)
**Цена:** 990 ₽/месяц

**Функции:**
- ✅ Все из Free
- ✅ WhatsApp Business
- ✅ Напоминания о записях
- ✅ Синхронизация с Google Calendar

**Лимиты:**
- 200 записей/месяц
- 500 клиентов
- 20 услуг
- 3 сотрудника
- 1 локация
- 10 SMM постов/месяц
- 10 OCR импортов/месяц
- 200 уведомлений/месяц

---

### 🚀 Профессиональный (Pro)
**Цена:** 2,990 ₽/месяц

**Функции:**
- ✅ Все из Basic
- ✅ Instagram Direct
- ✅ Кастомные уведомления
- ✅ OCR импорт
- ✅ SMM автопостинг
- ✅ AI ассистент
- ✅ Расширенная аналитика
- ✅ Приём платежей
- ✅ Несколько локаций
- ✅ Управление командой

**Лимиты:**
- 1,000 записей/месяц
- 5,000 клиентов
- 100 услуг
- 10 сотрудников
- 3 локации
- 50 SMM постов/месяц
- 50 OCR импортов/месяц
- 1,000 уведомлений/месяц

---

### 🏢 Корпоративный (Enterprise)
**Цена:** 9,990 ₽/месяц

**Функции:**
- ✅ Все функции платформы
- ✅ API доступ
- ✅ White label
- ✅ Приоритетная поддержка
- ✅ Кастомные отчёты

**Лимиты:**
- ♾️ Безлимит по всем параметрам

---

## API Endpoints

### Feature Flags

#### GET /feature-flags/plans
Получить все тарифные планы

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "tier": "free",
      "name": "Бесплатный",
      "price": 0,
      "features": ["basic_booking", "client_management", ...],
      "limits": {
        "maxBookingsPerMonth": 50,
        "maxClients": 100,
        ...
      }
    }
  ]
}
```

#### GET /feature-flags/business/:businessId
Получить подписку бизнеса

**Response:**
```json
{
  "success": true,
  "data": {
    "tier": "pro",
    "validUntil": "2025-01-01T00:00:00.000Z",
    "isActive": true,
    "plan": {
      "tier": "pro",
      "name": "Профессиональный",
      "price": 2990,
      ...
    }
  }
}
```

#### POST /feature-flags/check-feature
Проверить доступ к функции

**Request:**
```json
{
  "businessId": "1",
  "feature": "whatsapp_business"
}
```

**Response:**
```json
{
  "success": true,
  "hasAccess": true
}
```

#### GET /feature-flags/business/:businessId/usage
Получить использование лимитов

**Response:**
```json
{
  "success": true,
  "data": {
    "bookings": {
      "current": 45,
      "limit": 200,
      "percentage": 22
    },
    "clients": {
      "current": 123,
      "limit": 500,
      "percentage": 24
    },
    ...
  }
}
```

#### GET /feature-flags/business/:businessId/recommended-upgrade
Получить рекомендацию по upgrade

**Response:**
```json
{
  "success": true,
  "data": {
    "currentTier": "basic",
    "recommendedTier": "pro",
    "reasons": [
      "Использовано 85% лимита записей",
      "Использовано 90% лимита клиентов"
    ],
    "currentPlan": {...},
    "recommendedPlan": {...}
  }
}
```

#### POST /feature-flags/can-perform-action
Проверить возможность выполнения действия

**Request:**
```json
{
  "businessId": "1",
  "feature": "ocr_import",
  "limitType": "maxOCRImportsPerMonth"
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "allowed": true
  }
}
```

Или:
```json
{
  "success": true,
  "data": {
    "allowed": false,
    "reason": "Достигнут лимит: 10/10. Обновите подписку."
  }
}
```

---

### Subscription

#### POST /subscription/create
Создать подписку

**Request:**
```json
{
  "businessId": "1",
  "tier": "pro",
  "durationMonths": 1
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "sub_123",
    "businessId": "1",
    "tier": "pro",
    "status": "active",
    "startDate": "2024-11-25T00:00:00.000Z",
    "validUntil": "2024-12-25T00:00:00.000Z",
    "autoRenew": true
  }
}
```

#### POST /subscription/update
Обновить подписку (upgrade/downgrade)

**Request:**
```json
{
  "businessId": "1",
  "tier": "enterprise",
  "durationMonths": 1
}
```

#### POST /subscription/renew
Продлить подписку

**Request:**
```json
{
  "businessId": "1",
  "durationMonths": 3
}
```

#### DELETE /subscription/cancel/:businessId
Отменить подписку

**Response:**
```json
{
  "success": true,
  "message": "Subscription cancelled successfully"
}
```

#### GET /subscription/current/:businessId
Получить текущую подписку

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "sub_123",
    "tier": "pro",
    "status": "active",
    "validUntil": "2024-12-25T00:00:00.000Z",
    ...
  }
}
```

#### GET /subscription/history/:businessId
Получить историю подписок

**Response:**
```json
{
  "success": true,
  "count": 3,
  "data": [
    {
      "id": "sub_123",
      "tier": "pro",
      "status": "active",
      ...
    },
    {
      "id": "sub_122",
      "tier": "basic",
      "status": "cancelled",
      ...
    }
  ]
}
```

#### POST /subscription/trial
Создать пробную подписку

**Request:**
```json
{
  "businessId": "1",
  "tier": "pro",
  "durationDays": 14
}
```

**Response:**
```json
{
  "success": true,
  "data": {
    "id": "sub_123",
    "status": "trial",
    "trialEndsAt": "2024-12-09T00:00:00.000Z",
    ...
  }
}
```

#### GET /subscription/expiring
Получить истекающие подписки (за 7 дней)

**Response:**
```json
{
  "success": true,
  "count": 5,
  "data": [
    {
      "businessId": "1",
      "tier": "pro",
      "validUntil": "2024-12-01T00:00:00.000Z",
      "daysLeft": 6
    }
  ]
}
```

#### POST /subscription/auto-renew
Автоматическое продление подписок

**Response:**
```json
{
  "success": true,
  "data": {
    "renewed": 10,
    "failed": 2,
    "errors": [
      "Business 123: Payment failed",
      "Business 456: Card expired"
    ]
  }
}
```

#### GET /subscription/stats
Получить статистику подписок

**Response:**
```json
{
  "success": true,
  "data": {
    "total": 1000,
    "active": 750,
    "trial": 50,
    "expired": 150,
    "cancelled": 50,
    "byTier": {
      "free": 500,
      "basic": 200,
      "pro": 40,
      "enterprise": 10
    },
    "revenue": {
      "monthly": 500000,
      "yearly": 6000000
    }
  }
}
```

---

## Использование в коде

### Проверка доступа к функции

```typescript
import { FeatureFlagsService, Feature } from './feature-flags/feature-flags.service';

@Injectable()
export class MyService {
  constructor(private featureFlags: FeatureFlagsService) {}

  async doSomething(businessId: string) {
    // Проверить доступ
    const hasAccess = await this.featureFlags.hasFeature(
      businessId,
      Feature.WHATSAPP_BUSINESS,
    );

    if (!hasAccess) {
      throw new Error('Feature not available on your plan');
    }

    // Выполнить действие
    // ...
  }
}
```

### Использование Guard в контроллере

```typescript
import { Controller, Post, UseGuards } from '@nestjs/common';
import { FeatureAccessGuard, RequireFeature } from './feature-flags/feature-access.guard';
import { Feature } from './feature-flags/feature-flags.service';

@Controller('whatsapp')
@UseGuards(FeatureAccessGuard)
export class WhatsAppController {
  @Post('send')
  @RequireFeature(Feature.WHATSAPP_BUSINESS)
  async sendMessage(@Body() body: any) {
    // Этот endpoint доступен только если есть доступ к WHATSAPP_BUSINESS
    // ...
  }
}
```

### Проверка лимита

```typescript
import { FeatureFlagsService } from './feature-flags/feature-flags.service';

@Injectable()
export class BookingService {
  constructor(private featureFlags: FeatureFlagsService) {}

  async createBooking(businessId: string, data: any) {
    // Получить текущее количество записей
    const currentBookings = await this.getBookingsCount(businessId);

    // Проверить лимит
    const limitCheck = await this.featureFlags.checkLimit(
      businessId,
      'maxBookingsPerMonth',
      currentBookings,
    );

    if (!limitCheck.allowed) {
      throw new Error(
        `Booking limit reached: ${limitCheck.current}/${limitCheck.limit}`,
      );
    }

    // Создать запись
    // ...
  }
}
```

### Комплексная проверка

```typescript
import { FeatureFlagsService, Feature } from './feature-flags/feature-flags.service';

@Injectable()
export class OCRService {
  constructor(private featureFlags: FeatureFlagsService) {}

  async importFromImage(businessId: string, imageUrl: string) {
    // Проверить и функцию, и лимит одновременно
    const check = await this.featureFlags.canPerformAction(businessId, {
      feature: Feature.OCR_IMPORT,
      limitType: 'maxOCRImportsPerMonth',
    });

    if (!check.allowed) {
      throw new Error(check.reason);
    }

    // Выполнить импорт
    // ...
  }
}
```

---

## Интеграция с биллингом

### Создание подписки после оплаты

```typescript
import { SubscriptionService } from './subscription/subscription.service';
import { SubscriptionTier } from './feature-flags/feature-flags.service';

@Injectable()
export class PaymentService {
  constructor(private subscriptionService: SubscriptionService) {}

  async handlePaymentSuccess(
    businessId: string,
    tier: SubscriptionTier,
    durationMonths: number,
  ) {
    // Создать или обновить подписку
    await this.subscriptionService.createSubscription(
      businessId,
      tier,
      durationMonths,
    );

    // Отправить уведомление
    // ...
  }
}
```

### Автоматическое продление (cron job)

```typescript
import { Injectable } from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { SubscriptionService } from './subscription/subscription.service';

@Injectable()
export class SubscriptionCronService {
  constructor(private subscriptionService: SubscriptionService) {}

  @Cron(CronExpression.EVERY_DAY_AT_MIDNIGHT)
  async handleAutoRenew() {
    const result = await this.subscriptionService.autoRenewSubscriptions();
    console.log(`Auto-renewal: ${result.renewed} renewed, ${result.failed} failed`);
  }

  @Cron(CronExpression.EVERY_DAY_AT_9AM)
  async notifyExpiringSubscriptions() {
    const expiring = await this.subscriptionService.checkExpiringSubscriptions(7);
    
    for (const subscription of expiring) {
      // Отправить уведомление о скором истечении
      // ...
    }
  }
}
```

---

## Уведомления пользователей

### При достижении лимита

```typescript
async checkAndNotifyLimit(businessId: string) {
  const usage = await this.featureFlags.getUsageStats(businessId);
  const subscription = await this.featureFlags.getBusinessSubscription(businessId);
  const plan = this.featureFlags.getPlan(subscription.tier);

  // Проверить, достигнут ли 80% лимита
  if (
    plan.limits.maxBookingsPerMonth !== -1 &&
    usage.bookings > plan.limits.maxBookingsPerMonth * 0.8
  ) {
    // Отправить уведомление
    await this.notificationService.send({
      businessId,
      type: 'limit_warning',
      message: `Вы использовали ${Math.round((usage.bookings / plan.limits.maxBookingsPerMonth) * 100)}% лимита записей. Рекомендуем обновить подписку.`,
    });
  }
}
```

### При истечении подписки

```typescript
async notifySubscriptionExpiring(businessId: string, daysLeft: number) {
  await this.notificationService.send({
    businessId,
    type: 'subscription_expiring',
    message: `Ваша подписка истекает через ${daysLeft} дней. Продлите подписку, чтобы продолжить использование всех функций.`,
  });
}
```

---

## Миграция существующих пользователей

### Установка начальной подписки

```typescript
import { SubscriptionTier } from './feature-flags/feature-flags.service';

async function migrateExistingUsers() {
  const businesses = await prisma.business.findMany({
    where: {
      subscriptionTier: null,
    },
  });

  for (const business of businesses) {
    // Установить Free план для всех существующих
    await subscriptionService.createSubscription(
      business.id,
      SubscriptionTier.FREE,
      1,
      false,
    );
  }
}
```

---

## Рекомендации

### Для разработчиков:
1. **Всегда проверяйте доступ** перед выполнением платных функций
2. **Используйте Guard** для защиты endpoints
3. **Проверяйте лимиты** перед созданием ресурсов
4. **Логируйте попытки** доступа к платным функциям
5. **Обрабатывайте ошибки** с понятными сообщениями

### Для бизнеса:
1. **Предлагайте trial** для новых пользователей
2. **Уведомляйте** о достижении лимитов заранее
3. **Показывайте ценность** upgrade в нужный момент
4. **Упрощайте процесс** upgrade/downgrade
5. **Анализируйте использование** для оптимизации планов

---

## Будущие улучшения

### Feature Flags:
- [ ] A/B тестирование функций
- [ ] Постепенный rollout новых функций
- [ ] Персональные лимиты для отдельных бизнесов
- [ ] Временные промо-акции
- [ ] Кастомные планы для Enterprise

### Subscription:
- [ ] Интеграция с ЮKassa (Этап 6)
- [ ] Автоматическое списание средств
- [ ] Скидки при годовой оплате
- [ ] Реферальная программа
- [ ] Корпоративные тарифы

---

## Полезные ссылки

- **Prisma Schema** - см. `schema.prisma` (добавить таблицы `Subscription`)
- **Billing Integration** - см. Этап 6 (ЮKassa)

**Готово!** 🎉 Система feature flags и подписок полностью интегрирована.
