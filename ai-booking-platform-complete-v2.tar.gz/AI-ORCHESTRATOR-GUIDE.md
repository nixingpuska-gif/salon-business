# 🤖 AI Orchestrator - Руководство

## Обзор

AI Orchestrator - это ключевой компонент платформы, который использует GPT-4 для понимания естественного языка и автоматического выполнения действий через function calling.

**Реализовано:**
- ✅ GPT-4 Turbo integration
- ✅ Client AI Agent (для клиентов)
- ✅ Admin AI Agent (для владельцев бизнеса)
- ✅ 7 client tools (function calling)
- ✅ 8 admin tools (function calling)
- ✅ Intent detection
- ✅ Context-aware responses

---

## Архитектура

```
User Message (Telegram/WhatsApp/Instagram)
    ↓
Channel Gateway (нормализация)
    ↓
AI Orchestrator
    ↓
GPT-4 Turbo (intent detection)
    ↓
Function Calling (выполнение действий)
    ↓
Backend Services (Business, Client, Service, Schedule, Booking)
    ↓
Database (PostgreSQL)
    ↓
Response to User
```

---

## Client AI Agent

### Возможности

Client AI Agent помогает клиентам:
1. **Записаться на услугу** - понимает естественные запросы
2. **Перенести запись** - автоматически находит запись и переносит
3. **Отменить запись** - с указанием причины
4. **Узнать цены** - показывает стоимость услуг
5. **Посмотреть свои записи** - история всех записей
6. **Выбрать время** - показывает доступные слоты

### Function Calling Tools

#### 1. `get_available_services`
Получить список всех доступных услуг бизнеса.

**Параметры:**
- `businessId` (string) - ID бизнеса

**Пример вызова:**
```json
{
  "businessId": "550e8400-e29b-41d4-a716-446655440000"
}
```

**Ответ:**
```json
[
  {
    "id": "service-uuid-1",
    "name": "Маникюр классический",
    "durationMinutes": 60,
    "price": 1500,
    "description": "Классический маникюр с покрытием"
  },
  {
    "id": "service-uuid-2",
    "name": "Педикюр",
    "durationMinutes": 90,
    "price": 2000
  }
]
```

#### 2. `get_available_slots`
Получить доступные слоты для записи.

**Параметры:**
- `businessId` (string) - ID бизнеса
- `serviceId` (string) - ID услуги
- `date` (string) - Дата в формате YYYY-MM-DD

**Пример вызова:**
```json
{
  "businessId": "550e8400-e29b-41d4-a716-446655440000",
  "serviceId": "service-uuid-1",
  "date": "2025-11-25"
}
```

**Ответ:**
```json
[
  {
    "id": "slot_0900",
    "startTime": "2025-11-25T09:00:00.000Z",
    "endTime": "2025-11-25T10:00:00.000Z",
    "available": true
  },
  {
    "id": "slot_1000",
    "startTime": "2025-11-25T10:00:00.000Z",
    "endTime": "2025-11-25T11:00:00.000Z",
    "available": true
  }
]
```

#### 3. `create_booking`
Создать новую запись.

**Параметры:**
- `businessId` (string) - ID бизнеса
- `serviceId` (string) - ID услуги
- `startTime` (string) - Время начала (ISO 8601)
- `clientPhone` (string) - Телефон клиента
- `clientName` (string, optional) - Имя клиента

**Пример вызова:**
```json
{
  "businessId": "550e8400-e29b-41d4-a716-446655440000",
  "serviceId": "service-uuid-1",
  "startTime": "2025-11-25T09:00:00Z",
  "clientPhone": "+79161234567",
  "clientName": "Анна"
}
```

#### 4. `get_client_bookings`
Получить все записи клиента.

**Параметры:**
- `clientPhone` (string) - Телефон клиента
- `businessId` (string) - ID бизнеса

#### 5. `reschedule_booking`
Перенести запись на другое время.

**Параметры:**
- `bookingId` (string) - ID записи
- `newStartTime` (string) - Новое время (ISO 8601)

#### 6. `cancel_booking`
Отменить запись.

**Параметры:**
- `bookingId` (string) - ID записи
- `reason` (string, optional) - Причина отмены

#### 7. `get_service_price`
Узнать цену услуги.

**Параметры:**
- `serviceId` (string) - ID услуги

---

## Admin AI Agent

### Возможности

Admin AI Agent помогает владельцам бизнеса:
1. **Создать услугу** - добавить новую услугу в каталог
2. **Настроить расписание** - установить рабочие часы
3. **Добавить перерывы** - настроить обеденные перерывы
4. **Добавить отпуска** - отметить выходные дни
5. **Посмотреть записи** - на сегодня или за период
6. **Получить статистику** - по записям и выручке
7. **Найти клиентов** - поиск по имени или телефону
8. **Добавить заметки** - о клиентах

### Function Calling Tools

#### 1. `create_service`
Создать новую услугу.

**Параметры:**
- `businessId` (string) - ID бизнеса
- `name` (string) - Название услуги
- `durationMinutes` (number) - Длительность в минутах
- `price` (number, optional) - Цена
- `description` (string, optional) - Описание

**Пример:**
```json
{
  "businessId": "business-uuid",
  "name": "Маникюр с дизайном",
  "durationMinutes": 90,
  "price": 2500,
  "description": "Маникюр с художественным дизайном"
}
```

#### 2. `set_working_hours`
Настроить рабочие часы.

**Параметры:**
- `businessId` (string) - ID бизнеса
- `daysOfWeek` (number[]) - Дни недели (1=Пн, 7=Вс)
- `startTime` (string) - Время начала (HH:MM)
- `endTime` (string) - Время окончания (HH:MM)

**Пример:**
```json
{
  "businessId": "business-uuid",
  "daysOfWeek": [1, 2, 3, 4, 5],
  "startTime": "09:00",
  "endTime": "18:00"
}
```

#### 3. `add_break`
Добавить перерыв.

**Параметры:**
- `businessId` (string)
- `daysOfWeek` (number[])
- `startTime` (string)
- `endTime` (string)

#### 4. `add_vacation`
Добавить отпуск.

**Параметры:**
- `businessId` (string)
- `startDate` (string) - YYYY-MM-DD
- `endDate` (string) - YYYY-MM-DD
- `type` (string) - "vacation" или "holiday"

#### 5. `get_bookings_today`
Получить записи на сегодня.

#### 6. `get_bookings_stats`
Получить статистику за период.

**Параметры:**
- `businessId` (string)
- `startDate` (string)
- `endDate` (string)

**Ответ:**
```json
{
  "total": 45,
  "confirmed": 30,
  "completed": 10,
  "cancelled": 3,
  "noShow": 2,
  "totalRevenue": 67500
}
```

#### 7. `search_clients`
Найти клиентов.

**Параметры:**
- `businessId` (string)
- `search` (string) - Имя или телефон

#### 8. `add_client_note`
Добавить заметку о клиенте.

**Параметры:**
- `clientId` (string)
- `businessId` (string)
- `note` (string)

---

## Примеры диалогов

### Client Bot: Запись на услугу

**Клиент:**
> Хочу записаться на маникюр в субботу

**AI:**
> Отлично! Давайте подберём удобное время для маникюра в субботу.
> 
> У нас доступны следующие услуги:
> 1. Маникюр классический - 60 мин, 1500₽
> 2. Маникюр с дизайном - 90 мин, 2500₽
> 
> Какой вариант вам подходит?

**Клиент:**
> Классический

**AI:**
> Отлично! Вот доступные слоты на субботу, 25 ноября:
> - 09:00
> - 10:00
> - 11:00
> - 14:00
> - 15:00
> 
> Какое время вам удобно?

**Клиент:**
> 10:00

**AI:**
> Отлично! Чтобы подтвердить запись, укажите, пожалуйста, ваше имя и телефон.

**Клиент:**
> Анна, +79161234567

**AI:**
> ✅ Запись создана!
> 
> **Детали записи:**
> - Услуга: Маникюр классический
> - Дата: 25 ноября (суббота)
> - Время: 10:00
> - Длительность: 60 минут
> - Стоимость: 1500₽
> 
> Ждём вас! За день до визита пришлём напоминание.

---

### Client Bot: Перенос записи

**Клиент:**
> Нужно перенести мою запись на другой день

**AI:**
> Конечно, помогу перенести запись. Давайте сначала найдём вашу запись.
> 
> Ваш телефон: +79161234567?

**Клиент:**
> Да

**AI:**
> Нашёл вашу запись:
> - Маникюр классический
> - 25 ноября, 10:00
> 
> На какую дату хотите перенести?

**Клиент:**
> На 26 ноября, если можно на 14:00

**AI:**
> Проверяю доступность... Время 14:00 свободно!
> 
> Подтверждаете перенос на 26 ноября, 14:00?

**Клиент:**
> Да

**AI:**
> ✅ Запись успешно перенесена!
> 
> **Новые детали:**
> - Дата: 26 ноября (воскресенье)
> - Время: 14:00
> - Услуга: Маникюр классический
> 
> До встречи!

---

### Admin Bot: Настройка расписания

**Владелец:**
> Хочу настроить рабочие часы

**AI:**
> Отлично! Давайте настроим ваше расписание.
> 
> В какие дни недели вы работаете?

**Владелец:**
> Понедельник-пятница

**AI:**
> Понял, будни. Какое время работы?

**Владелец:**
> С 9 до 18

**AI:**
> ✅ Рабочие часы настроены!
> 
> **Ваше расписание:**
> - Дни: Понедельник - Пятница
> - Время: 09:00 - 18:00
> 
> Хотите добавить обеденный перерыв?

**Владелец:**
> Да, с 13 до 14

**AI:**
> ✅ Перерыв добавлен!
> 
> Теперь клиенты не смогут записаться с 13:00 до 14:00.
> 
> Что ещё настроим?

---

### Admin Bot: Создание услуги

**Владелец:**
> Добавь новую услугу: педикюр, 90 минут, 2000 рублей

**AI:**
> ✅ Услуга создана!
> 
> **Педикюр**
> - Длительность: 90 минут
> - Цена: 2000₽
> 
> Услуга сразу доступна для записи клиентов.
> 
> Хотите добавить описание?

**Владелец:**
> Да, "Классический педикюр с покрытием гель-лаком"

**AI:**
> ✅ Описание добавлено! Услуга полностью настроена.

---

### Admin Bot: Статистика

**Владелец:**
> Покажи статистику за ноябрь

**AI:**
> **Статистика за ноябрь 2025:**
> 
> 📊 **Записи:**
> - Всего: 45
> - Завершено: 30
> - Подтверждено (предстоящие): 10
> - Отменено: 3
> - Не пришли: 2
> 
> 💰 **Выручка:**
> - Общая: 67 500₽
> - Средний чек: 2 250₽
> 
> 📈 **Тренд:**
> - +15% к октябрю
> 
> Отличные результаты! 🎉

---

## Конфигурация

### Переменные окружения

```env
# OpenAI API
OPENAI_API_KEY=sk-your-openai-api-key-here
```

### Модель GPT-4

Используется: **gpt-4-turbo-preview**

Преимущества:
- Большой контекст (128K tokens)
- Поддержка function calling
- Высокая точность intent detection
- Быстрые ответы

---

## Обработка ошибок

AI Orchestrator обрабатывает следующие ошибки:

1. **OPENAI_API_KEY не установлен**
   - Возвращает: "AI функции временно недоступны"
   - Решение: Установить OPENAI_API_KEY в .env

2. **Ошибка API OpenAI**
   - Возвращает: "Извините, произошла ошибка. Попробуйте переформулировать запрос"
   - Логирует ошибку в консоль

3. **Неизвестная функция**
   - Выбрасывает: `Unknown function: ${functionName}`
   - Логирует в консоль

4. **Ошибка выполнения функции**
   - Пробрасывает ошибку из backend service
   - GPT-4 получает ошибку и объясняет пользователю

---

## Логирование

AI Orchestrator логирует:

```typescript
// При вызове функции
this.logger.log(`AI calling function: ${functionName}`, functionArgs);

// При ошибке
this.logger.error('Error in handleClientMessage:', error);
this.logger.error('Error in handleAdminMessage:', error);
```

Пример лога:
```
[AIService] AI calling function: create_booking {
  businessId: '550e8400-e29b-41d4-a716-446655440000',
  serviceId: 'service-uuid-1',
  startTime: '2025-11-25T09:00:00Z',
  clientPhone: '+79161234567',
  clientName: 'Анна'
}
```

---

## Расширение функциональности

### Добавление новой функции для Client Agent

1. Добавьте описание в `client-tools.ts`:

```typescript
{
  type: 'function' as const,
  function: {
    name: 'get_business_info',
    description: 'Получить информацию о бизнесе',
    parameters: {
      type: 'object',
      properties: {
        businessId: {
          type: 'string',
          description: 'ID бизнеса',
        },
      },
      required: ['businessId'],
    },
  },
}
```

2. Добавьте обработчик в `ai.service.ts`:

```typescript
private async executeClientFunction(...) {
  switch (functionName) {
    // ...
    case 'get_business_info':
      return this.businessService.findOne(args.businessId);
    // ...
  }
}
```

3. Обновите system prompt (опционально):

```typescript
const systemPrompt = `...
Доступные действия:
- ...
- Получить информацию о бизнесе
...`;
```

---

## Тестирование

### Тестирование через Telegram

1. Запустите backend:
```bash
pnpm run start:dev
```

2. Откройте Telegram, найдите вашего бота

3. Отправьте сообщение:
```
Хочу записаться на маникюр завтра в 10 утра
```

4. Проверьте логи:
```bash
# Должны увидеть:
[AIService] AI calling function: get_available_services
[AIService] AI calling function: get_available_slots
[AIService] AI calling function: create_booking
```

### Тестирование через API (для отладки)

Создайте тестовый endpoint:

```typescript
@Controller('test')
export class TestController {
  constructor(private aiService: AIService) {}

  @Post('ai-client')
  async testClient(@Body() body: { text: string }) {
    const message: NormalizedMessage = {
      channel: 'telegram',
      userId: 'test-user',
      chatId: 'test-chat',
      text: body.text,
      metadata: {},
      timestamp: new Date(),
    };

    return this.aiService.handleClientMessage(message, 'business-uuid');
  }
}
```

Тест:
```bash
curl -X POST http://localhost:3000/test/ai-client \
  -H "Content-Type: application/json" \
  -d '{"text": "Хочу записаться на маникюр"}'
```

---

## Стоимость использования

### GPT-4 Turbo Pricing (на момент написания)

- **Input:** $0.01 / 1K tokens
- **Output:** $0.03 / 1K tokens

### Примерная стоимость одного диалога

**Простой запрос (без function calling):**
- Input: ~200 tokens (system prompt + user message)
- Output: ~100 tokens
- **Стоимость:** ~$0.005 (0.5 цента)

**Запрос с function calling:**
- Input: ~500 tokens (system + user + function definitions + results)
- Output: ~200 tokens
- **Стоимость:** ~$0.011 (1.1 цента)

**Месячная стоимость (1000 активных пользователей, 5 запросов/день):**
- 1000 users × 5 requests × 30 days = 150,000 requests
- 150,000 × $0.011 = **$1,650/month**

---

## Best Practices

1. **System Prompts:**
   - Будьте конкретны в инструкциях
   - Указывайте контекст (businessId, userId)
   - Перечисляйте доступные действия

2. **Function Definitions:**
   - Описывайте параметры подробно
   - Используйте enum для ограниченных значений
   - Указывайте required параметры

3. **Error Handling:**
   - Всегда логируйте ошибки
   - Возвращайте понятные сообщения пользователю
   - Не раскрывайте технические детали

4. **Performance:**
   - Кэшируйте частые запросы
   - Используйте streaming для длинных ответов (будущее улучшение)
   - Ограничивайте длину истории диалога

5. **Security:**
   - Валидируйте все параметры функций
   - Проверяйте права доступа (businessId, userId)
   - Не передавайте чувствительные данные в prompts

---

## Roadmap

### Ближайшие улучшения

- [ ] **Context Management** - сохранение истории диалога
- [ ] **Multi-turn Conversations** - поддержка сложных диалогов
- [ ] **Streaming Responses** - потоковая передача ответов
- [ ] **Voice Input** - распознавание голоса
- [ ] **Proactive Notifications** - проактивные уведомления
- [ ] **A/B Testing** - тестирование разных prompts
- [ ] **Analytics Dashboard** - дашборд с метриками AI

### Долгосрочные планы

- [ ] **Fine-tuning** - дообучение модели на своих данных
- [ ] **Multi-language Support** - поддержка других языков
- [ ] **Custom Models** - использование собственных моделей
- [ ] **Sentiment Analysis** - анализ тональности
- [ ] **Recommendation Engine** - рекомендации услуг

---

**AI Orchestrator готов к использованию!** 🚀

Для вопросов и предложений смотрите основную документацию проекта.
