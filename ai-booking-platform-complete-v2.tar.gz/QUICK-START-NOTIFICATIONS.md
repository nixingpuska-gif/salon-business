# 🚀 Быстрый старт: Система уведомлений (BullMQ)

## За 5 минут до первого напоминания

### Шаг 1: Установите Redis (1 минута)

#### Docker (рекомендуется)
```bash
docker run -d --name redis -p 6379:6379 redis:7-alpine
```

#### Ubuntu/Debian
```bash
sudo apt update && sudo apt install redis-server -y
sudo systemctl start redis
```

#### macOS
```bash
brew install redis
brew services start redis
```

### Шаг 2: Проверьте Redis (10 секунд)

```bash
redis-cli ping
# Должно вернуть: PONG
```

### Шаг 3: Настройте переменные окружения (30 секунд)

Добавьте в `backend/.env`:
```env
# Redis Configuration
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=
```

### Шаг 4: Запустите сервер (30 секунд)

```bash
cd backend
npm run start:dev
```

Проверьте логи:
```
[NotificationService] Notification Service initialized
[NotificationProcessor] Notification Processor initialized
[BullModule] Connected to Redis
```

### Шаг 5: Создайте тестовую запись (1 минута)

#### Через API
```bash
curl -X POST http://localhost:3000/bookings \
  -H "Content-Type: application/json" \
  -d '{
    "businessId": "1",
    "clientId": "123",
    "serviceId": "456",
    "startTime": "2024-12-01T14:00:00Z"
  }'
```

#### Через AI-бота
Отправьте в Telegram/WhatsApp/Instagram:
```
Хочу записаться на маникюр 1 декабря в 14:00
```

### Шаг 6: Проверьте запланированные напоминания (30 секунд)

```bash
curl http://localhost:3000/notifications/scheduled
```

Ответ:
```json
{
  "success": true,
  "count": 2,
  "data": [
    {
      "id": "booking-123-24h",
      "name": "booking-reminder-24h",
      "scheduledFor": "2024-11-30T14:00:00.000Z"
    },
    {
      "id": "booking-123-2h",
      "name": "booking-reminder-2h",
      "scheduledFor": "2024-12-01T12:00:00.000Z"
    }
  ]
}
```

### Шаг 7: Проверьте статистику (30 секунд)

```bash
curl http://localhost:3000/notifications/stats
```

Ответ:
```json
{
  "success": true,
  "data": {
    "waiting": 0,
    "active": 0,
    "completed": 0,
    "failed": 0,
    "delayed": 2,
    "total": 2
  }
}
```

## ✅ Готово!

Система уведомлений работает. Напоминания будут отправлены автоматически:
- За 24 часа до записи
- За 2 часа до записи

---

## 🧪 Тестирование

### Тест с коротким интервалом

Для быстрого тестирования временно измените интервалы:

```typescript
// backend/src/notification/notification.service.ts

// Было:
const reminder24h = new Date(bookingTime.getTime() - 24 * 60 * 60 * 1000);
const reminder2h = new Date(bookingTime.getTime() - 2 * 60 * 60 * 1000);

// Для теста (напоминания через 2 и 1 минуту):
const reminder24h = new Date(bookingTime.getTime() - 2 * 60 * 1000);
const reminder2h = new Date(bookingTime.getTime() - 1 * 60 * 1000);
```

Создайте запись на текущее время + 3 минуты:
```bash
curl -X POST http://localhost:3000/bookings \
  -H "Content-Type: application/json" \
  -d "{
    \"businessId\": \"1\",
    \"clientId\": \"123\",
    \"serviceId\": \"456\",
    \"startTime\": \"$(date -u -d '+3 minutes' +%Y-%m-%dT%H:%M:%SZ)\"
  }"
```

Через 1-2 минуты проверьте логи:
```bash
npm run start:dev | grep Notification
```

Вы увидите:
```
[NotificationProcessor] Processing job booking-123-24h
[NotificationService] Sent to WhatsApp: +79991234567
[NotificationProcessor] Processing job booking-123-2h
[NotificationService] Sent to WhatsApp: +79991234567
```

---

## 🔧 Быстрое решение проблем

### ❌ Redis connection refused
```bash
# Проверьте, что Redis запущен
redis-cli ping

# Если не запущен:
sudo systemctl start redis  # Linux
brew services start redis   # macOS
docker start redis          # Docker
```

### ❌ Jobs не обрабатываются
```bash
# Проверьте логи
npm run start:dev | grep Processor

# Проверьте Redis
redis-cli LRANGE bull:notifications:wait 0 -1
```

### ❌ Напоминания не отправляются
```bash
# Проверьте, что у клиента есть канал
# В БД должно быть: telegramId, phone или instagramId

# Проверьте логи на ошибки
npm run start:dev | grep "Failed to send"
```

---

## 📊 Мониторинг

### Просмотр логов в реальном времени
```bash
# Все логи уведомлений
npm run start:dev | grep Notification

# Только отправка
npm run start:dev | grep "Sent to"

# Только ошибки
npm run start:dev | grep "Failed"
```

### Redis мониторинг
```bash
# Все операции в реальном времени
redis-cli MONITOR

# Просмотр delayed jobs
redis-cli ZRANGE bull:notifications:delayed 0 -1 WITHSCORES

# Просмотр waiting jobs
redis-cli LRANGE bull:notifications:wait 0 -1
```

---

## 🎯 Что дальше?

### Настройте каналы

1. **WhatsApp** - см. `QUICK-START-WHATSAPP.md`
2. **Instagram** - см. `QUICK-START-INSTAGRAM.md`
3. **Telegram** - TODO (в разработке)

### Кастомизируйте сообщения

Отредактируйте метод `formatReminderMessage()` в `notification.service.ts`:
```typescript
private formatReminderMessage(booking: any, reminderType: '24h' | '2h'): string {
  // Ваш кастомный текст
  return `Ваше напоминание...`;
}
```

### Добавьте новые интервалы

Добавьте напоминание за 1 час:
```typescript
// В scheduleBookingReminders()
const reminder1h = new Date(bookingTime.getTime() - 1 * 60 * 60 * 1000);
if (reminder1h > now) {
  await this.notificationQueue.add('booking-reminder-1h', {...}, {...});
}
```

### Настройте мониторинг

Установите Bull Board для UI:
```bash
npm install @bull-board/api @bull-board/nestjs
```

---

## 📚 Полная документация

- **NOTIFICATION-SYSTEM-GUIDE.md** - подробное руководство
- **NOTIFICATION-IMPLEMENTATION-SUMMARY.md** - технические детали

**Ваши клиенты больше не забудут о записях! 🔔**
