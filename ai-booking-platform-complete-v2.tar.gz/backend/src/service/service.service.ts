import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Service } from '@prisma/client';

@Injectable()
export class ServiceService {
  constructor(private prisma: PrismaService) {}

  /**
   * Create a new service
   */
  async create(businessId: string, data: {
    name: string;
    durationMinutes: number;
    price?: number;
    description?: string;
    displayOrder?: number;
  }): Promise<Service> {
    // Get the next display order if not provided
    let displayOrder = data.displayOrder;
    if (displayOrder === undefined) {
      const maxOrder = await this.prisma.service.aggregate({
        where: { businessId },
        _max: { displayOrder: true },
      });
      displayOrder = (maxOrder._max.displayOrder || 0) + 1;
    }

    return this.prisma.service.create({
      data: {
        businessId,
        name: data.name,
        durationMinutes: data.durationMinutes,
        price: data.price,
        description: data.description,
        displayOrder,
      },
    });
  }

  /**
   * Find service by ID
   */
  async findOne(id: string): Promise<Service> {
    const service = await this.prisma.service.findUnique({
      where: { id },
      include: {
        business: true,
        _count: {
          select: {
            bookings: true,
          },
        },
      },
    });

    if (!service) {
      throw new NotFoundException(`Service with ID ${id} not found`);
    }

    return service;
  }

  /**
   * Find all services for a business
   */
  async findByBusiness(businessId: string, includeInactive = false): Promise<Service[]> {
    return this.prisma.service.findMany({
      where: {
        businessId,
        ...(includeInactive ? {} : { isActive: true }),
      },
      orderBy: { displayOrder: 'asc' },
    });
  }

  /**
   * Update service
   */
  async update(id: string, data: Partial<{
    name: string;
    durationMinutes: number;
    price: number;
    description: string;
    displayOrder: number;
    isActive: boolean;
  }>): Promise<Service> {
    const service = await this.findOne(id);

    return this.prisma.service.update({
      where: { id: service.id },
      data,
    });
  }

  /**
   * Delete service (soft delete by setting isActive to false)
   */
  async delete(id: string): Promise<Service> {
    const service = await this.findOne(id);

    return this.prisma.service.update({
      where: { id: service.id },
      data: {
        isActive: false,
      },
    });
  }

  /**
   * Reorder services
   */
  async reorder(businessId: string, serviceIds: string[]): Promise<void> {
    // Update display order for each service
    const updates = serviceIds.map((serviceId, index) =>
      this.prisma.service.update({
        where: { id: serviceId },
        data: { displayOrder: index + 1 },
      }),
    );

    await this.prisma.$transaction(updates);
  }
}
