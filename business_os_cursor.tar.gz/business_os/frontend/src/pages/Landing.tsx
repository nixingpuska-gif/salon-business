import { Link } from 'react-router-dom'
import { 
  Calendar, Users, TrendingUp, MessageSquare, Shield, Zap,
  Check, Star, ArrowRight, Play, AlertTriangle, Clock, UserMinus, PhoneOff, BarChart3, Heart
} from 'lucide-react'
import { useLanguage } from '../contexts/LanguageContext'
import LanguageSwitcher from '../components/LanguageSwitcher'

export default function Landing() {
  const { t, language } = useLanguage()

  const features = [
    {
      icon: Calendar,
      titleKey: 'features.booking.title',
      descKey: 'features.booking.desc'
    },
    {
      icon: Users,
      titleKey: 'features.crm.title',
      descKey: 'features.crm.desc'
    },
    {
      icon: TrendingUp,
      titleKey: 'features.analytics.title',
      descKey: 'features.analytics.desc'
    },
    {
      icon: MessageSquare,
      titleKey: 'features.notifications.title',
      descKey: 'features.notifications.desc'
    },
    {
      icon: Shield,
      titleKey: 'features.security.title',
      descKey: 'features.security.desc'
    },
    {
      icon: Zap,
      titleKey: 'features.integrations.title',
      descKey: 'features.integrations.desc'
    },
  ]

  const testimonials = language === 'ru' ? [
    {
      name: 'Анна Петрова',
      role: 'Владелец салона "Beauty Lab"',
      avatar: 'AP',
      text: 'Перешли на Business OS полгода назад. Записи выросли на 40%, а время на администрирование сократилось вдвое.',
    },
    {
      name: 'Михаил Козлов',
      role: 'Сеть барбершопов "Бородач"',
      avatar: 'МК',
      text: 'Наконец-то нормальная аналитика! Теперь вижу реальную картину по каждому филиалу и мастеру.',
    },
    {
      name: 'Елена Сидорова',
      role: 'Студия маникюра',
      avatar: 'ЕС',
      text: 'Клиенты в восторге от онлайн-записи. Больше не нужно отвечать на звонки — всё автоматизировано.',
    },
  ] : [
    {
      name: 'Anna Schmidt',
      role: 'Owner of "Beauty Lab" Salon',
      avatar: 'AS',
      text: 'Switched to Business OS six months ago. Bookings increased by 40%, and admin time was cut in half.',
    },
    {
      name: 'Michael Weber',
      role: 'Barbershop Chain Owner',
      avatar: 'MW',
      text: 'Finally proper analytics! Now I can see the real picture for each location and stylist.',
    },
    {
      name: 'Elena Müller',
      role: 'Nail Studio Owner',
      avatar: 'EM',
      text: 'Clients love the online booking. No more answering phone calls — everything is automated.',
    },
  ]

  const pricingFeatures = [
    'pricing.f1', 'pricing.f2', 'pricing.f3', 'pricing.f4', 'pricing.f5',
    'pricing.f6', 'pricing.f7', 'pricing.f8', 'pricing.f9', 'pricing.f10'
  ]

  const stats = [
    { value: '5000+', labelKey: 'stats.salons' },
    { value: '2M+', labelKey: 'stats.bookings' },
    { value: '99.9%', labelKey: 'stats.uptime' },
    { value: '4.9', labelKey: 'stats.rating' },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">B</span>
              </div>
              <span className="font-bold text-xl text-gray-900">Business OS</span>
            </div>
            <nav className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-gray-600 hover:text-gray-900">{t('nav.features')}</a>
              <a href="#pricing" className="text-gray-600 hover:text-gray-900">{t('nav.pricing')}</a>
              <a href="#testimonials" className="text-gray-600 hover:text-gray-900">{t('nav.testimonials')}</a>
            </nav>
            <div className="flex items-center gap-4">
              <LanguageSwitcher />
              <Link to="/login" className="text-gray-600 hover:text-gray-900 font-medium">
                {t('nav.login')}
              </Link>
              <Link to="/register" className="bg-primary-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-primary-700 transition-colors">
                {t('nav.tryFree')}
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="pt-32 pb-20 bg-gradient-to-b from-primary-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary-100 rounded-full text-primary-700 text-sm font-medium mb-6">
              <Zap className="w-4 h-4" />
              {t('hero.badge')}
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 leading-tight">
              {t('hero.title1')}{' '}
              <span className="text-primary-600">{t('hero.title2')}</span>
            </h1>
            <p className="mt-6 text-xl text-gray-600 max-w-2xl mx-auto">
              {t('hero.subtitle')}
            </p>
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/register" className="w-full sm:w-auto bg-primary-600 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:bg-primary-700 transition-colors flex items-center justify-center gap-2">
                {t('hero.cta')}
                <ArrowRight className="w-5 h-5" />
              </Link>
              <button className="w-full sm:w-auto border-2 border-gray-200 text-gray-700 px-8 py-4 rounded-xl font-semibold text-lg hover:border-gray-300 transition-colors flex items-center justify-center gap-2">
                <Play className="w-5 h-5" />
                {t('hero.demo')}
              </button>
            </div>
            <p className="mt-4 text-sm text-gray-500">
              {t('hero.trial')}
            </p>
          </div>

          {/* Dashboard Preview */}
          <div className="mt-16 relative">
            <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent z-10 pointer-events-none" />
            <div className="bg-gray-900 rounded-2xl shadow-2xl overflow-hidden border border-gray-800">
              <div className="bg-gray-800 px-4 py-3 flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                <div className="w-3 h-3 rounded-full bg-green-500" />
              </div>
              <div className="p-4 bg-gray-100">
                <div className="h-96 bg-gradient-to-br from-primary-50 to-primary-100 rounded-lg flex items-center justify-center">
                  <span className="text-primary-600 font-medium">
                    {language === 'ru' ? 'Превью дашборда' : 'Dashboard Preview'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.labelKey} className="text-center">
                <div className="text-4xl font-bold text-white">{stat.value}</div>
                <div className="text-gray-400 mt-1">{t(stat.labelKey)}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pain Points */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-red-100 rounded-full text-red-700 text-sm font-medium mb-6">
              <AlertTriangle className="w-4 h-4" />
              {language === 'ru' ? 'Знакомо?' : 'Sound familiar?'}
            </div>
            <h2 className="text-4xl font-bold text-gray-900">
              {language === 'ru' ? 'Боли владельцев салонов' : 'Salon Owner Pain Points'}
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              {language === 'ru' ? 'Мы понимаем ваши проблемы и знаем, как их решить' : 'We understand your challenges and know how to solve them'}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Pain 1 */}
            <div className="p-6 rounded-2xl bg-white border border-red-100 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <UserMinus className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {language === 'ru' ? 'Клиенты не возвращаются' : 'Clients Don\'t Return'}
              </h3>
              <p className="text-gray-600 mb-4">
                {language === 'ru' ? 'До 40% клиентов уходят после первого визита и больше не приходят' : 'Up to 40% of clients leave after first visit and never come back'}
              </p>
              <div className="flex items-center gap-2 text-primary-600 font-medium">
                <Heart className="w-4 h-4" />
                {language === 'ru' ? 'Решение: Программа лояльности + AI-напоминания' : 'Solution: Loyalty program + AI reminders'}
              </div>
            </div>

            {/* Pain 2 */}
            <div className="p-6 rounded-2xl bg-white border border-red-100 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <Clock className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {language === 'ru' ? 'Рутина съедает время' : 'Admin Tasks Eat Your Time'}
              </h3>
              <p className="text-gray-600 mb-4">
                {language === 'ru' ? '3-4 часа в день на звонки, записи, отчёты вместо развития бизнеса' : '3-4 hours daily on calls, bookings, reports instead of growing your business'}
              </p>
              <div className="flex items-center gap-2 text-primary-600 font-medium">
                <Zap className="w-4 h-4" />
                {language === 'ru' ? 'Решение: Полная автоматизация' : 'Solution: Full automation'}
              </div>
            </div>

            {/* Pain 3 */}
            <div className="p-6 rounded-2xl bg-white border border-red-100 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <PhoneOff className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {language === 'ru' ? 'Пропущенные звонки' : 'Missed Calls = Lost Revenue'}
              </h3>
              <p className="text-gray-600 mb-4">
                {language === 'ru' ? 'Каждый пропущенный звонок — это потерянный клиент и деньги' : 'Every missed call is a lost client and money'}
              </p>
              <div className="flex items-center gap-2 text-primary-600 font-medium">
                <MessageSquare className="w-4 h-4" />
                {language === 'ru' ? 'Решение: Онлайн-запись 24/7' : 'Solution: Online booking 24/7'}
              </div>
            </div>

            {/* Pain 4 */}
            <div className="p-6 rounded-2xl bg-white border border-red-100 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {language === 'ru' ? 'Нет понимания цифр' : 'No Clear Picture of Numbers'}
              </h3>
              <p className="text-gray-600 mb-4">
                {language === 'ru' ? 'Не знаете, сколько реально зарабатываете и куда уходят деньги' : 'Don\'t know your real profit and where money goes'}
              </p>
              <div className="flex items-center gap-2 text-primary-600 font-medium">
                <TrendingUp className="w-4 h-4" />
                {language === 'ru' ? 'Решение: BI-аналитика в реальном времени' : 'Solution: Real-time BI analytics'}
              </div>
            </div>

            {/* Pain 5 */}
            <div className="p-6 rounded-2xl bg-white border border-red-100 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {language === 'ru' ? 'Текучка мастеров' : 'Staff Turnover'}
              </h3>
              <p className="text-gray-600 mb-4">
                {language === 'ru' ? 'Мастера уходят и забирают клиентов с собой' : 'Stylists leave and take clients with them'}
              </p>
              <div className="flex items-center gap-2 text-primary-600 font-medium">
                <Shield className="w-4 h-4" />
                {language === 'ru' ? 'Решение: Клиенты привязаны к салону' : 'Solution: Clients tied to salon, not staff'}
              </div>
            </div>

            {/* Pain 6 */}
            <div className="p-6 rounded-2xl bg-white border border-red-100 hover:shadow-lg transition-all">
              <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                <Calendar className="w-6 h-6 text-red-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {language === 'ru' ? 'Неявки клиентов' : 'No-Shows'}
              </h3>
              <p className="text-gray-600 mb-4">
                {language === 'ru' ? 'До 15% клиентов не приходят на запись без предупреждения' : 'Up to 15% of clients don\'t show up without notice'}
              </p>
              <div className="flex items-center gap-2 text-primary-600 font-medium">
                <MessageSquare className="w-4 h-4" />
                {language === 'ru' ? 'Решение: Авто-напоминания' : 'Solution: Auto-reminders'}
              </div>
            </div>
          </div>

          {/* Retention Stats */}
          <div className="mt-16 bg-primary-600 rounded-2xl p-8 text-white">
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-4xl font-bold">+35%</div>
                <div className="text-primary-100 mt-2">
                  {language === 'ru' ? 'Рост возврата клиентов' : 'Client Retention Increase'}
                </div>
              </div>
              <div>
                <div className="text-4xl font-bold">-70%</div>
                <div className="text-primary-100 mt-2">
                  {language === 'ru' ? 'Снижение неявок' : 'Reduction in No-Shows'}
                </div>
              </div>
              <div>
                <div className="text-4xl font-bold">4 часа</div>
                <div className="text-primary-100 mt-2">
                  {language === 'ru' ? 'Экономия времени в день' : 'Time Saved Daily'}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold text-gray-900">
              {t('features.title')}
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              {t('features.subtitle')}
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature) => (
              <div key={feature.titleKey} className="p-6 rounded-2xl border border-gray-100 hover:border-primary-200 hover:shadow-lg transition-all">
                <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-primary-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{t(feature.titleKey)}</h3>
                <p className="text-gray-600">{t(feature.descKey)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-4xl font-bold text-gray-900">
              {t('pricing.title')}
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              {t('pricing.subtitle')}
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Business Plan */}
            <div className="rounded-2xl p-8 bg-white border-2 border-gray-200 hover:border-primary-300 transition-all">
              <div className="inline-block px-3 py-1 bg-primary-100 text-primary-700 rounded-full text-sm font-medium mb-4">
                {t('pricing.business.badge')}
              </div>
              <h3 className="text-2xl font-bold text-gray-900">
                {t('pricing.business.name')}
              </h3>
              <p className="mt-1 text-gray-600">
                {t('pricing.business.desc')}
              </p>
              <div className="mt-6 space-y-2">
                <div>
                  <span className="text-4xl font-bold" style={{color: '#111827'}}>
                    {language === 'ru' ? '100,000 ₽' : '€1,000'}
                  </span>
                  <span className="text-gray-600">{t('pricing.perMonth')}</span>
                </div>
                <div className="text-gray-500 text-sm">
                  {language === 'ru' ? 'или 1,000 €/мес для Европы' : 'or 100,000 ₽/mo for Russia'}
                </div>
              </div>
              <ul className="mt-8 space-y-3">
                {pricingFeatures.map((featureKey) => (
                  <li key={featureKey} className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-primary-600" />
                    <span className="text-gray-700 text-sm">{t(featureKey)}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/register"
                className="mt-8 block w-full py-4 rounded-xl font-semibold text-center transition-colors bg-primary-600 text-white hover:bg-primary-700"
              >
                {t('pricing.cta')}
              </Link>
              <p className="mt-4 text-center text-gray-500 text-sm">
                {t('pricing.trial')}
              </p>
            </div>

            {/* Enterprise Plan */}
            <div className="rounded-2xl p-8 bg-primary-600 text-white ring-4 ring-primary-600 ring-offset-4">
              <div className="inline-block px-3 py-1 bg-white/20 rounded-full text-sm font-medium mb-4">
                {t('pricing.enterprise.badge')}
              </div>
              <h3 className="text-2xl font-bold text-white">
                {t('pricing.enterprise.name')}
              </h3>
              <p className="mt-1 text-white/80">
                {t('pricing.enterprise.desc')}
              </p>
              <div className="mt-6 space-y-2">
                <div>
                  <span className="text-4xl font-bold text-white">
                    {language === 'ru' ? '200,000' : '€2,000'}
                  </span>
                  <span className="text-white/80"> {language === 'ru' ? '₽' : ''}{t('pricing.perMonth')}</span>
                </div>
                <div className="text-white/60 text-sm">
                  {language === 'ru' ? 'или 2,000 €/мес для Европы' : 'or 200,000 ₽/mo for Russia'}
                </div>
              </div>
              <ul className="mt-8 space-y-3">
                {pricingFeatures.map((featureKey) => (
                  <li key={featureKey} className="flex items-center gap-3">
                    <Check className="w-5 h-5 text-white" />
                    <span className="text-white text-sm">{t(featureKey)}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/register"
                className="mt-8 block w-full py-4 rounded-xl font-semibold text-center transition-colors bg-white text-primary-600 hover:bg-gray-100"
              >
                {t('pricing.cta')}
              </Link>
              <p className="mt-4 text-center text-white/60 text-sm">
                {t('pricing.trial')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            {/* Rating Badge */}
            <div className="inline-flex items-center gap-3 px-6 py-3 bg-yellow-50 border border-yellow-200 rounded-full mb-6">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <span className="text-2xl font-bold text-gray-900">4.9</span>
              <span className="text-gray-600">
                {language === 'ru' ? 'из 5 на основе 1,247 отзывов' : 'out of 5 based on 1,247 reviews'}
              </span>
            </div>
            <h2 className="text-4xl font-bold text-gray-900">
              {t('testimonials.title')}
            </h2>
            <p className="mt-4 text-xl text-gray-600">
              {t('testimonials.subtitle')}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <div key={testimonial.name} className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-6">"{testimonial.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                    <span className="text-primary-600 font-semibold text-sm">{testimonial.avatar}</span>
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">{testimonial.name}</div>
                    <div className="text-sm text-gray-500">{testimonial.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-primary-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            {t('cta.title')}
          </h2>
          <p className="text-xl text-white/80 mb-8">
            {t('cta.subtitle')}
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/register" className="w-full sm:w-auto bg-white text-primary-600 px-8 py-4 rounded-xl font-semibold text-lg hover:bg-gray-100 transition-colors flex items-center justify-center gap-2">
              {t('cta.button')}
              <ArrowRight className="w-5 h-5" />
            </Link>
            <a href="mailto:contact@business-os.com" className="text-white/80 hover:text-white font-medium">
              {t('cta.contact')}
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-5 gap-8 mb-12">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 bg-primary-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">B</span>
                </div>
                <span className="font-bold text-xl text-white">Business OS</span>
              </div>
              <p className="text-gray-400 max-w-xs">
                {language === 'ru' 
                  ? 'Операционная система для салонов красоты. Всё для управления бизнесом в одном месте.'
                  : 'Operating system for beauty salons. Everything for business management in one place.'
                }
              </p>
              <div className="mt-4">
                <LanguageSwitcher className="text-white" />
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">{t('footer.product')}</h4>
              <ul className="space-y-2">
                <li><a href="#features" className="text-gray-400 hover:text-white">{t('nav.features')}</a></li>
                <li><a href="#pricing" className="text-gray-400 hover:text-white">{t('nav.pricing')}</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">{t('footer.integrations')}</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">{t('footer.api')}</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">{t('footer.company')}</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white">{t('footer.about')}</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">{t('footer.blog')}</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">{t('footer.careers')}</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">{t('footer.contacts')}</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-4">{t('footer.support')}</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-400 hover:text-white">{t('footer.docs')}</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">{t('footer.faq')}</a></li>
                <li><a href="#" className="text-gray-400 hover:text-white">Telegram</a></li>
                <li><a href="mailto:support@business-os.com" className="text-gray-400 hover:text-white">support@business-os.com</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-gray-400 text-sm">
              {t('footer.copyright')}
            </p>
            <div className="flex items-center gap-6">
              <a href="#" className="text-gray-400 hover:text-white text-sm">{t('footer.privacy')}</a>
              <a href="#" className="text-gray-400 hover:text-white text-sm">{t('footer.terms')}</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
