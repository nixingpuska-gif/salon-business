import { Module } from '@nestjs/common';
import { ChannelGatewayService } from './channel-gateway.service';

@Module({
  providers: [ChannelGatewayService],
  exports: [ChannelGatewayService],
})
export class ChannelGatewayModule {}
