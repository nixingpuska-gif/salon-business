"""
Partner/Affiliate Program API - Реферальная программа
"""
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime
from pydantic import BaseModel
from typing import Optional, List

from app.core.database import get_db

router = APIRouter()


class PartnerType(str):
    SALON_OWNER = "salon_owner"
    SUPPLIER = "supplier"
    INFLUENCER = "influencer"


class Referral(BaseModel):
    id: int
    salon_name: str
    owner_name: str
    joined_date: str
    status: str  # trial, active, churned
    monthly_payment: float
    your_commission: float
    total_earned: float


class PartnerDashboard(BaseModel):
    partner_id: int
    partner_name: str
    partner_type: str
    referral_code: str
    referral_link: str
    
    # Статистика
    total_referrals: int
    active_referrals: int
    total_earned: float
    pending_payout: float
    
    # Комиссии
    first_payment_commission: float  # %
    recurring_commission: float  # %
    
    # Рефералы
    referrals: List[Referral]


@router.get("/dashboard")
async def get_partner_dashboard(
    partner_id: int = Query(...),
    db: AsyncSession = Depends(get_db)
):
    """Кабинет партнёра"""
    
    referrals = [
        Referral(
            id=1, salon_name="Beauty Studio", owner_name="Елена М.",
            joined_date="2024-10-15", status="active",
            monthly_payment=100000, your_commission=5000, total_earned=15000
        ),
        Referral(
            id=2, salon_name="Nail Art Pro", owner_name="Ольга К.",
            joined_date="2024-11-01", status="active",
            monthly_payment=100000, your_commission=5000, total_earned=10000
        ),
        Referral(
            id=3, salon_name="Hair Masters", owner_name="Анна С.",
            joined_date="2024-12-01", status="trial",
            monthly_payment=0, your_commission=0, total_earned=0
        ),
    ]
    
    return PartnerDashboard(
        partner_id=partner_id,
        partner_name="Иван Партнёров",
        partner_type="salon_owner",
        referral_code="IVAN2024",
        referral_link="https://business-os.ru/ref/IVAN2024",
        total_referrals=3,
        active_referrals=2,
        total_earned=25000,
        pending_payout=10000,
        first_payment_commission=25,
        recurring_commission=5,
        referrals=referrals
    ).dict()


@router.get("/program-info")
async def get_program_info():
    """Информация о партнёрской программе"""
    
    return {
        "levels": [
            {
                "type": "salon_owner",
                "name": "Владелец салона",
                "description": "Приглашайте других владельцев",
                "first_payment": "25% от первой оплаты",
                "recurring": "5% ежемесячно",
                "example": "При подписке 100,000₽/мес вы получаете 25,000₽ сразу + 5,000₽ каждый месяц"
            },
            {
                "type": "supplier",
                "name": "Поставщик",
                "description": "Рекомендуйте своим клиентам-салонам",
                "first_payment": "25% от первой оплаты",
                "recurring": "15% ежемесячно",
                "bonus": "Владелец, который вас привёл, получает 5% от ВСЕХ ваших рефералов",
                "example": "Вы привели 10 салонов — получаете 250,000₽ сразу + 150,000₽ каждый месяц"
            },
            {
                "type": "influencer",
                "name": "Инфлюенсер",
                "description": "Блогеры и эксперты индустрии",
                "first_payment": "20% от первой оплаты",
                "recurring": "10% ежемесячно",
                "bonus": "Промокод на скидку 10% для подписчиков"
            }
        ],
        "payout": {
            "min_amount": 5000,
            "methods": ["Банковская карта", "Расчётный счёт"],
            "schedule": "Выплаты 1 и 15 числа каждого месяца"
        },
        "rules": [
            "Комиссия начисляется только за оплаченные подписки",
            "Реферал закрепляется за вами навсегда",
            "Вывод от 5,000₽",
            "Без ограничений по количеству рефералов"
        ]
    }


@router.post("/generate-link")
async def generate_referral_link(
    partner_id: int,
    campaign_name: Optional[str] = None,
    db: AsyncSession = Depends(get_db)
):
    """Сгенерировать реферальную ссылку"""
    
    code = f"REF{partner_id}_{datetime.now().strftime('%Y%m%d')}"
    
    return {
        "code": code,
        "link": f"https://business-os.ru/ref/{code}",
        "qr_code": f"https://api.qrserver.com/v1/create-qr-code/?data=https://business-os.ru/ref/{code}",
        "campaign": campaign_name
    }


@router.get("/payouts")
async def get_payouts(
    partner_id: int = Query(...),
    db: AsyncSession = Depends(get_db)
):
    """История выплат"""
    
    return {
        "pending": 10000,
        "next_payout_date": "2024-12-15",
        "history": [
            {"date": "2024-12-01", "amount": 15000, "method": "Карта *4567", "status": "completed"},
            {"date": "2024-11-15", "amount": 10000, "method": "Карта *4567", "status": "completed"},
            {"date": "2024-11-01", "amount": 25000, "method": "Карта *4567", "status": "completed"},
        ],
        "total_paid": 50000
    }


@router.post("/request-payout")
async def request_payout(
    partner_id: int,
    amount: float,
    method: str = "card",
    db: AsyncSession = Depends(get_db)
):
    """Запросить выплату"""
    
    return {
        "success": True,
        "payout_id": 123,
        "amount": amount,
        "method": method,
        "estimated_date": "2024-12-15",
        "message": "Заявка на выплату принята. Деньги поступят в течение 3 рабочих дней."
    }
