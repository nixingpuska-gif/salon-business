"""
Business OS - Staff API
Управление сотрудниками салона
"""

from datetime import datetime, date, time
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import select, func, and_, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.models.staff import Staff, StaffSchedule, StaffService
from app.models.appointment import Appointment

router = APIRouter()


# === Schemas ===

class StaffCreate(BaseModel):
    branch_id: int
    user_id: Optional[int] = None
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[EmailStr] = None
    position: Optional[str] = None
    specialization: Optional[str] = None
    bio: Optional[str] = None
    hire_date: Optional[date] = None
    commission_percent: float = Field(0, ge=0, le=100)
    is_active: bool = True
    accepts_online_booking: bool = True
    color: Optional[str] = "#3B82F6"


class StaffUpdate(BaseModel):
    branch_id: Optional[int] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[EmailStr] = None
    position: Optional[str] = None
    specialization: Optional[str] = None
    bio: Optional[str] = None
    commission_percent: Optional[float] = None
    is_active: Optional[bool] = None
    accepts_online_booking: Optional[bool] = None
    color: Optional[str] = None


class StaffResponse(BaseModel):
    id: int
    tenant_id: Optional[int] = None
    branch_id: Optional[int] = None
    first_name: str
    last_name: Optional[str] = None
    full_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    position: Optional[str] = None
    role: Optional[str] = "master"
    status: Optional[str] = "active"
    bio: Optional[str] = None
    avatar_url: Optional[str] = None
    hired_at: Optional[date] = None
    salary_percent: Optional[float] = 40
    online_booking_enabled: Optional[bool] = True
    avg_rating: Optional[float] = 0
    total_reviews: Optional[int] = 0
    total_appointments: Optional[int] = 0
    total_revenue: Optional[float] = 0
    created_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True


class StaffListResponse(BaseModel):
    items: List[StaffResponse]
    total: int


class StaffScheduleCreate(BaseModel):
    day_of_week: int = Field(..., ge=0, le=6)
    start_time: time
    end_time: time
    break_start: Optional[time] = None
    break_end: Optional[time] = None
    is_working: bool = True


class StaffScheduleResponse(BaseModel):
    id: int
    day_of_week: int
    start_time: time
    end_time: time
    break_start: Optional[time]
    break_end: Optional[time]
    is_working: bool
    
    class Config:
        from_attributes = True


class StaffServiceAssign(BaseModel):
    service_ids: List[int]


class StaffStats(BaseModel):
    total_appointments: int
    completed_appointments: int
    cancelled_appointments: int
    no_show_appointments: int
    total_revenue: float
    avg_rating: Optional[float]
    utilization_percent: float


# === Endpoints ===

@router.get("", response_model=StaffListResponse)
async def list_staff(
    branch_id: Optional[int] = None,
    is_active: Optional[bool] = None,
    search: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
):
    """Получить список сотрудников"""
    tenant_id = 1
    
    query = select(Staff).where(
        Staff.tenant_id == tenant_id,
        Staff.is_deleted == False
    )
    
    if branch_id:
        query = query.where(Staff.branch_id == branch_id)
    if is_active is not None:
        query = query.where(Staff.is_active == is_active)
    if search:
        query = query.where(
            Staff.first_name.ilike(f"%{search}%") |
            Staff.last_name.ilike(f"%{search}%")
        )
    
    query = query.order_by(Staff.first_name)
    result = await db.execute(query)
    staff_list = result.scalars().all()
    
    return StaffListResponse(
        items=[StaffResponse.model_validate(s) for s in staff_list],
        total=len(staff_list)
    )


@router.get("/{staff_id}", response_model=StaffResponse)
async def get_staff(staff_id: int, db: AsyncSession = Depends(get_db)):
    """Получить сотрудника по ID"""
    tenant_id = 1
    query = select(Staff).where(
        Staff.id == staff_id,
        Staff.tenant_id == tenant_id,
        Staff.is_deleted == False
    )
    result = await db.execute(query)
    staff = result.scalar_one_or_none()
    if not staff:
        raise HTTPException(status_code=404, detail="Staff not found")
    return StaffResponse.model_validate(staff)


@router.post("", response_model=StaffResponse, status_code=201)
async def create_staff(data: StaffCreate, db: AsyncSession = Depends(get_db)):
    """Создать сотрудника"""
    tenant_id = 1
    staff = Staff(tenant_id=tenant_id, **data.model_dump())
    db.add(staff)
    await db.commit()
    await db.refresh(staff)
    return StaffResponse.model_validate(staff)


@router.put("/{staff_id}", response_model=StaffResponse)
async def update_staff(staff_id: int, data: StaffUpdate, db: AsyncSession = Depends(get_db)):
    """Обновить сотрудника"""
    tenant_id = 1
    query = select(Staff).where(Staff.id == staff_id, Staff.tenant_id == tenant_id, Staff.is_deleted == False)
    result = await db.execute(query)
    staff = result.scalar_one_or_none()
    if not staff:
        raise HTTPException(status_code=404, detail="Staff not found")
    
    for field, value in data.model_dump(exclude_unset=True).items():
        setattr(staff, field, value)
    await db.commit()
    await db.refresh(staff)
    return StaffResponse.model_validate(staff)


@router.delete("/{staff_id}", status_code=204)
async def delete_staff(staff_id: int, db: AsyncSession = Depends(get_db)):
    """Удалить сотрудника"""
    tenant_id = 1
    query = select(Staff).where(Staff.id == staff_id, Staff.tenant_id == tenant_id, Staff.is_deleted == False)
    result = await db.execute(query)
    staff = result.scalar_one_or_none()
    if not staff:
        raise HTTPException(status_code=404, detail="Staff not found")
    staff.is_deleted = True
    staff.deleted_at = datetime.utcnow()
    await db.commit()


@router.get("/{staff_id}/schedule", response_model=List[StaffScheduleResponse])
async def get_staff_schedule(staff_id: int, db: AsyncSession = Depends(get_db)):
    """Получить расписание сотрудника"""
    tenant_id = 1
    staff_query = select(Staff).where(Staff.id == staff_id, Staff.tenant_id == tenant_id, Staff.is_deleted == False)
    if not (await db.execute(staff_query)).scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Staff not found")
    
    query = select(StaffSchedule).where(StaffSchedule.staff_id == staff_id, StaffSchedule.is_deleted == False).order_by(StaffSchedule.day_of_week)
    result = await db.execute(query)
    return [StaffScheduleResponse.model_validate(s) for s in result.scalars().all()]


@router.put("/{staff_id}/schedule", response_model=List[StaffScheduleResponse])
async def update_staff_schedule(staff_id: int, schedules: List[StaffScheduleCreate], db: AsyncSession = Depends(get_db)):
    """Обновить расписание сотрудника"""
    tenant_id = 1
    staff_query = select(Staff).where(Staff.id == staff_id, Staff.tenant_id == tenant_id, Staff.is_deleted == False)
    if not (await db.execute(staff_query)).scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Staff not found")
    
    # Delete existing
    existing = await db.execute(select(StaffSchedule).where(StaffSchedule.staff_id == staff_id))
    for s in existing.scalars().all():
        await db.delete(s)
    
    # Create new
    new_schedules = []
    for data in schedules:
        schedule = StaffSchedule(tenant_id=tenant_id, staff_id=staff_id, **data.model_dump())
        db.add(schedule)
        new_schedules.append(schedule)
    
    await db.commit()
    for s in new_schedules:
        await db.refresh(s)
    return [StaffScheduleResponse.model_validate(s) for s in new_schedules]


@router.get("/{staff_id}/services")
async def get_staff_services(staff_id: int, db: AsyncSession = Depends(get_db)):
    """Получить услуги сотрудника"""
    tenant_id = 1
    query = select(StaffService).where(StaffService.staff_id == staff_id, StaffService.tenant_id == tenant_id, StaffService.is_deleted == False)
    result = await db.execute(query)
    return {"staff_id": staff_id, "service_ids": [ss.service_id for ss in result.scalars().all()]}


@router.put("/{staff_id}/services")
async def assign_staff_services(staff_id: int, data: StaffServiceAssign, db: AsyncSession = Depends(get_db)):
    """Назначить услуги сотруднику"""
    tenant_id = 1
    staff_query = select(Staff).where(Staff.id == staff_id, Staff.tenant_id == tenant_id, Staff.is_deleted == False)
    if not (await db.execute(staff_query)).scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Staff not found")
    
    # Delete existing
    existing = await db.execute(select(StaffService).where(StaffService.staff_id == staff_id, StaffService.tenant_id == tenant_id))
    for ss in existing.scalars().all():
        await db.delete(ss)
    
    # Create new
    for service_id in data.service_ids:
        db.add(StaffService(tenant_id=tenant_id, staff_id=staff_id, service_id=service_id))
    
    await db.commit()
    return {"staff_id": staff_id, "service_ids": data.service_ids, "message": "Services assigned"}


@router.get("/{staff_id}/stats", response_model=StaffStats)
async def get_staff_stats(staff_id: int, date_from: Optional[date] = None, date_to: Optional[date] = None, db: AsyncSession = Depends(get_db)):
    """Получить статистику сотрудника"""
    tenant_id = 1
    staff_query = select(Staff).where(Staff.id == staff_id, Staff.tenant_id == tenant_id, Staff.is_deleted == False)
    staff = (await db.execute(staff_query)).scalar_one_or_none()
    if not staff:
        raise HTTPException(status_code=404, detail="Staff not found")
    
    base_filter = and_(Appointment.staff_id == staff_id, Appointment.tenant_id == tenant_id, Appointment.is_deleted == False)
    if date_from:
        base_filter = and_(base_filter, Appointment.date >= date_from)
    if date_to:
        base_filter = and_(base_filter, Appointment.date <= date_to)
    
    total = (await db.execute(select(func.count()).where(base_filter))).scalar() or 0
    completed = (await db.execute(select(func.count()).where(and_(base_filter, Appointment.status == "completed")))).scalar() or 0
    cancelled = (await db.execute(select(func.count()).where(and_(base_filter, Appointment.status == "cancelled")))).scalar() or 0
    no_show = (await db.execute(select(func.count()).where(and_(base_filter, Appointment.status == "no_show")))).scalar() or 0
    revenue = float((await db.execute(select(func.sum(Appointment.total_price)).where(and_(base_filter, Appointment.status == "completed")))).scalar() or 0)
    
    return StaffStats(
        total_appointments=total, completed_appointments=completed, cancelled_appointments=cancelled,
        no_show_appointments=no_show, total_revenue=revenue, avg_rating=float(staff.rating) if staff.rating else None, utilization_percent=0
    )
