import { Module, forwardRef } from '@nestjs/common';
import { OCRService } from './ocr.service';
import { OCRController } from './ocr.controller';
import { PrismaModule } from '../prisma/prisma.module';
import { BookingModule } from '../booking/booking.module';

@Module({
  imports: [PrismaModule, forwardRef(() => BookingModule)],
  controllers: [OCRController],
  providers: [OCRService],
  exports: [OCRService],
})
export class OCRModule {}
