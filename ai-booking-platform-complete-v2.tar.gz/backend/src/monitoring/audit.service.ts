import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { LoggerService } from './logger.service';

/**
 * Audit Service
 * 
 * Логирование критических операций для аудита:
 * - Создание/изменение/удаление записей
 * - Платежи и возвраты
 * - Изменение подписок
 * - Доступ к конфиденциальным данным
 * - Изменение настроек
 */

export enum AuditAction {
  // Записи
  BOOKING_CREATED = 'booking.created',
  BOOKING_UPDATED = 'booking.updated',
  BOOKING_CANCELLED = 'booking.cancelled',
  BOOKING_RESCHEDULED = 'booking.rescheduled',

  // Клиенты
  CLIENT_CREATED = 'client.created',
  CLIENT_UPDATED = 'client.updated',
  CLIENT_DELETED = 'client.deleted',
  CLIENT_DATA_ACCESSED = 'client.data_accessed',

  // Платежи
  PAYMENT_CREATED = 'payment.created',
  PAYMENT_SUCCEEDED = 'payment.succeeded',
  PAYMENT_CANCELLED = 'payment.cancelled',
  PAYMENT_REFUNDED = 'payment.refunded',

  // Подписки
  SUBSCRIPTION_CREATED = 'subscription.created',
  SUBSCRIPTION_UPDATED = 'subscription.updated',
  SUBSCRIPTION_CANCELLED = 'subscription.cancelled',
  SUBSCRIPTION_RENEWED = 'subscription.renewed',

  // Бизнес
  BUSINESS_CREATED = 'business.created',
  BUSINESS_UPDATED = 'business.updated',
  BUSINESS_SETTINGS_CHANGED = 'business.settings_changed',

  // Пользователи
  USER_LOGIN = 'user.login',
  USER_LOGOUT = 'user.logout',
  USER_PASSWORD_CHANGED = 'user.password_changed',
  USER_ROLE_CHANGED = 'user.role_changed',

  // Уведомления
  NOTIFICATION_SENT = 'notification.sent',
  NOTIFICATION_FAILED = 'notification.failed',

  // Импорт/Экспорт
  DATA_IMPORTED = 'data.imported',
  DATA_EXPORTED = 'data.exported',

  // API
  API_KEY_CREATED = 'api_key.created',
  API_KEY_REVOKED = 'api_key.revoked',
}

export interface AuditLogEntry {
  id?: string;
  action: AuditAction;
  userId: string;
  businessId?: string;
  resourceType?: string;
  resourceId?: string;
  details: Record<string, any>;
  ipAddress?: string;
  userAgent?: string;
  timestamp: Date;
}

@Injectable()
export class AuditService {
  constructor(
    private prisma: PrismaService,
    private logger: LoggerService,
  ) {
    this.logger.setContext('AuditService');
  }

  /**
   * Записать аудит лог
   */
  async log(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>): Promise<void> {
    try {
      // Сохранить в БД
      await this.prisma.auditLog.create({
        data: {
          action: entry.action,
          userId: entry.userId,
          businessId: entry.businessId,
          resourceType: entry.resourceType,
          resourceId: entry.resourceId,
          details: entry.details,
          ipAddress: entry.ipAddress,
          userAgent: entry.userAgent,
        },
      });

      // Также записать в логи
      this.logger.logAudit(entry.action, entry.userId, {
        businessId: entry.businessId,
        resourceType: entry.resourceType,
        resourceId: entry.resourceId,
        details: entry.details,
      });
    } catch (error) {
      this.logger.error(`Failed to log audit entry: ${error.message}`, error.stack);
    }
  }

  /**
   * Получить аудит логи
   */
  async getLogs(params: {
    userId?: string;
    businessId?: string;
    action?: AuditAction;
    resourceType?: string;
    resourceId?: string;
    startDate?: Date;
    endDate?: Date;
    limit?: number;
    offset?: number;
  }): Promise<{
    logs: AuditLogEntry[];
    total: number;
  }> {
    const where: any = {};

    if (params.userId) where.userId = params.userId;
    if (params.businessId) where.businessId = params.businessId;
    if (params.action) where.action = params.action;
    if (params.resourceType) where.resourceType = params.resourceType;
    if (params.resourceId) where.resourceId = params.resourceId;

    if (params.startDate || params.endDate) {
      where.createdAt = {};
      if (params.startDate) where.createdAt.gte = params.startDate;
      if (params.endDate) where.createdAt.lte = params.endDate;
    }

    const [logs, total] = await Promise.all([
      this.prisma.auditLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: params.limit || 100,
        skip: params.offset || 0,
      }),
      this.prisma.auditLog.count({ where }),
    ]);

    return {
      logs: logs.map((log) => ({
        id: log.id,
        action: log.action as AuditAction,
        userId: log.userId,
        businessId: log.businessId,
        resourceType: log.resourceType,
        resourceId: log.resourceId,
        details: log.details as Record<string, any>,
        ipAddress: log.ipAddress,
        userAgent: log.userAgent,
        timestamp: log.createdAt,
      })),
      total,
    };
  }

  /**
   * Получить статистику аудит логов
   */
  async getStats(params: {
    businessId?: string;
    startDate?: Date;
    endDate?: Date;
  }): Promise<{
    totalActions: number;
    actionsByType: Record<string, number>;
    topUsers: Array<{ userId: string; count: number }>;
  }> {
    const where: any = {};

    if (params.businessId) where.businessId = params.businessId;
    if (params.startDate || params.endDate) {
      where.createdAt = {};
      if (params.startDate) where.createdAt.gte = params.startDate;
      if (params.endDate) where.createdAt.lte = params.endDate;
    }

    const [total, actionGroups, userGroups] = await Promise.all([
      this.prisma.auditLog.count({ where }),
      this.prisma.auditLog.groupBy({
        by: ['action'],
        where,
        _count: true,
      }),
      this.prisma.auditLog.groupBy({
        by: ['userId'],
        where,
        _count: true,
        orderBy: { _count: { userId: 'desc' } },
        take: 10,
      }),
    ]);

    const actionsByType: Record<string, number> = {};
    for (const group of actionGroups) {
      actionsByType[group.action] = group._count;
    }

    const topUsers = userGroups.map((group) => ({
      userId: group.userId,
      count: group._count,
    }));

    return {
      totalActions: total,
      actionsByType,
      topUsers,
    };
  }

  /**
   * Удалить старые аудит логи (для очистки)
   */
  async cleanupOldLogs(daysToKeep: number = 90): Promise<number> {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

    const result = await this.prisma.auditLog.deleteMany({
      where: {
        createdAt: {
          lt: cutoffDate,
        },
      },
    });

    this.logger.log(`Cleaned up ${result.count} old audit logs`);

    return result.count;
  }

  // Вспомогательные методы для частых операций

  async logBookingCreated(
    userId: string,
    businessId: string,
    bookingId: string,
    details: Record<string, any>,
  ) {
    await this.log({
      action: AuditAction.BOOKING_CREATED,
      userId,
      businessId,
      resourceType: 'booking',
      resourceId: bookingId,
      details,
    });
  }

  async logPaymentCreated(
    userId: string,
    businessId: string,
    paymentId: string,
    amount: number,
  ) {
    await this.log({
      action: AuditAction.PAYMENT_CREATED,
      userId,
      businessId,
      resourceType: 'payment',
      resourceId: paymentId,
      details: { amount },
    });
  }

  async logSubscriptionChanged(
    userId: string,
    businessId: string,
    subscriptionId: string,
    oldTier: string,
    newTier: string,
  ) {
    await this.log({
      action: AuditAction.SUBSCRIPTION_UPDATED,
      userId,
      businessId,
      resourceType: 'subscription',
      resourceId: subscriptionId,
      details: { oldTier, newTier },
    });
  }

  async logUserLogin(userId: string, ipAddress?: string, userAgent?: string) {
    await this.log({
      action: AuditAction.USER_LOGIN,
      userId,
      details: {},
      ipAddress,
      userAgent,
    });
  }

  async logDataExport(
    userId: string,
    businessId: string,
    exportType: string,
    recordCount: number,
  ) {
    await this.log({
      action: AuditAction.DATA_EXPORTED,
      userId,
      businessId,
      details: { exportType, recordCount },
    });
  }
}
