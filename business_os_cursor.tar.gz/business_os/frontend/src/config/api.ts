// API Configuration
const getApiUrl = (): string => {
  // Check for environment variable first
  const envUrl = (import.meta as any).env?.VITE_API_URL
  if (envUrl) return envUrl
  
  // In production, use the same origin with /api prefix
  // In development, use localhost:8000
  if (typeof window !== 'undefined') {
    const hostname = window.location.hostname
    if (hostname.includes('manusvm.computer')) {
      // Production - use the 8000 port variant
      return window.location.origin.replace('5000-', '8000-')
    }
  }
  
  return 'http://localhost:8000'
}

export const API_URL = getApiUrl()

export const api = {
  get: async (path: string) => {
    const response = await fetch(`${API_URL}${path}`)
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`)
    return response.json()
  },
  
  post: async (path: string, data?: any) => {
    const response = await fetch(`${API_URL}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: data ? JSON.stringify(data) : undefined
    })
    return response
  }
}
